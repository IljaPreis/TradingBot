# TradingBot V20 Master

V16 bis V20 zusammen:
- V16 Live Scanner / Top-10 Ranking
- V17 Multi-Timeframe State
- V18 Auto TP/SL + RR + Confidence
- V19 Macro/News Engine
- V20 Trade Manager + Dashboard Pro

Installation im bestehenden Server-Ordner:

```bash
cd /opt/tradingbot_v9
cp .env /tmp/tradingbot.env
docker compose down
find . -mindepth 1 ! -name ".git" ! -name ".env" -exec rm -rf {} +
unzip /opt/tradingbot_v20_master.zip
cp /tmp/tradingbot.env .env
docker compose up -d --build
```

Tests:

```bash
curl http://localhost/health
curl http://localhost/test-telegram
curl http://localhost/top
curl http://localhost/market-rankings
curl http://localhost/trades
curl http://localhost/performance
curl http://localhost/dashboard
```

GitHub speichern:

```bash
git add .
git commit -m "TradingBot V20 Master"
git push
```
