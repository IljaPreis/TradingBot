# TradingBot V25 Master

V21 bis V25 zusammen:
- V21 robuster TradingView Webhook + Signal Parser
- V22 0-100 Punkte Rating Engine
- V23 automatische Entry/SL/TP/RR Berechnung
- V24 Session- und Wirtschaftskalender-Filter
- V25 Prioritäts-Telegram-Signale + Screenshot-Anforderung

Installation:

```bash
cd /opt/tradingbot_v9
git pull
unzip -o tradingbot_v25_master.zip
cp .env.example .env   # nur falls .env fehlt
nano .env              # Telegram Daten prüfen
docker compose down
docker compose up -d --build
```

Tests:

```bash
curl http://localhost/health
curl http://localhost/test-telegram
curl http://localhost/top
curl http://localhost/market-rankings
curl http://localhost/calendar
curl http://localhost/dashboard
```
