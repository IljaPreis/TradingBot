# TradingBot V5000

Start:
```bash
unzip tradingbot_v5000.zip
cd tradingbot_v5000
nano .env
bash install.sh
```

URLs:
- /health
- /terminal
- /scan-all
- /news-terminal
- /risk
- /learning-dashboard
- /history/upload/{market}/{tf}
- /backtest/{market}/{tf}
- /webhook/tradingview

CSV Format:
time,open,high,low,close,volume,trigger,side,entry,sl,tp1,tp2,tp3,result
