import csv, io
from app.core.state import HISTORY, LEARNING, BACKTESTS

def normalize_trigger(t):
    return str(t or "-").lower().replace(" ", "_")

def upload_csv(market, tf, text):
    key = f"{market.upper()}_{tf}"
    rows = list(csv.DictReader(io.StringIO(text)))
    HISTORY[key] = rows
    return {"key": key, "rows": len(rows)}

def backtest(market, tf):
    key = f"{market.upper()}_{tf}"
    rows = HISTORY.get(key, [])
    stats = {}
    for r in rows:
        trigger = normalize_trigger(r.get("trigger"))
        result = str(r.get("result","")).lower()
        s = stats.setdefault(trigger, {"trades":0,"wins":0,"losses":0,"tp2":0})
        s["trades"] += 1
        if result in ["win","tp1","tp2","tp3"]:
            s["wins"] += 1
        if result in ["loss","sl"]:
            s["losses"] += 1
        if result in ["tp2","tp3"]:
            s["tp2"] += 1
    for k, s in stats.items():
        t = max(1, s["trades"])
        s["winrate"] = round(s["wins"]/t*100, 1)
        s["tp2rate"] = round(s["tp2"]/t*100, 1)
        s["score_adjustment"] = 5 if s["trades"] >= 10 and s["winrate"] >= 60 else (-5 if s["trades"] >= 10 and s["winrate"] < 45 else 0)
    BACKTESTS[key] = stats
    LEARNING[market.upper()] = {"score_adjustment": max([v["score_adjustment"] for v in stats.values()] or [0]), "stats": stats}
    return {"key": key, "summary": stats}

def learning_summary():
    return {"history_files": len(HISTORY), "backtests": len(BACKTESTS), "learning": LEARNING}
