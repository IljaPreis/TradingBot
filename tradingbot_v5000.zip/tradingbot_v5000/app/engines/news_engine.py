from datetime import datetime
from app.core.state import NEWS, STATE

KEYS = {
    "US100": ["nfp","payroll","jobless","cpi","fed","yields","nasdaq","dollar"],
    "US500": ["nfp","payroll","jobless","cpi","fed","yields","sp500","dollar"],
    "DXY": ["dollar","fed","cpi","nfp","payroll","yields"],
    "US10Y": ["fed","yields","inflation","cpi","treasury"],
    "XAUUSD": ["gold","fed","inflation","cpi","dollar","yields","geopolitical"],
    "UKOIL": ["oil","brent","iran","opec","crude"],
    "BRENT": ["oil","brent","iran","opec","crude"],
    "AUDUSD": ["china","australia","risk","commodities"],
    "NZDUSD": ["china","new zealand","risk"],
    "FTSE100": ["boe","uk","bailey","pound"],
    "GER40": ["ecb","eurozone","germany","china"]
}

def de_translate(text):
    repl = {
        "jobless claims": "Erstanträge auf Arbeitslosenhilfe",
        "non-farm payrolls": "US-Arbeitsmarktbericht NFP",
        "factory orders": "Auftragseingänge Industrie",
        "services PMI": "Dienstleistungs-PMI",
        "consumer confidence": "Verbrauchervertrauen",
        "dollar falls": "US-Dollar fällt",
        "yields": "Renditen"
    }
    out = text
    for k, v in repl.items():
        out = out.replace(k, v).replace(k.title(), v)
    return out

def add_news(original, score=3, source="manual"):
    text = original.strip()
    low = text.lower()
    impacts = []
    for market, keys in KEYS.items():
        if any(k in low for k in keys):
            direction, impact = "neutral", 50
            if any(k in low for k in ["miss","weaker","falls","unter erwartung","schwach"]):
                if market in ["US100","US500","XAUUSD"]:
                    direction, impact = "bullish", 65
                if market in ["DXY","US10Y"]:
                    direction, impact = "bearish", 40
            impacts.append({"market": market, "direction": direction, "impact": impact})
            STATE.setdefault(market, {})["news_score"] = max(float(STATE.get(market, {}).get("news_score", 0) or 0), impact)
    item = {
        "time": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "original": text,
        "headline_de": de_translate(text),
        "score": score,
        "direction": "neutral",
        "impacts": impacts or [{"market":"ALL","direction":"neutral","impact":45}],
        "source": source
    }
    NEWS.insert(0, item)
    del NEWS[50:]
    return item

def seed_news():
    if NEWS:
        return
    for s in [
        "US initial jobless claims 215K vs 220K forecast.",
        "US June non-farm payrolls +57K vs +110K expected",
        "US May factory orders -1.3% vs -1.8% expected",
        "BOE Mann: Loosening of financing conditions since June will be important for rate decision",
        "China services PMI, June",
        "US dollar falls as US labor market report misses expectations"
    ]:
        add_news(s, 4, "seed")

def news_terminal(limit=12):
    seed_news()
    return NEWS[:limit]
