from app.core.state import TRADES
RISK = {"balance": 100000, "risk_per_trade": 0.5, "max_trades": 3, "daily_loss_limit": 2.0}

def risk_ok():
    return len(TRADES) < RISK["max_trades"]

def risk_status():
    return {**RISK, "open_trades": len(TRADES), "risk_ok": risk_ok()}
