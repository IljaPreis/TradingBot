from app.core.state import STATE, LEARNING
from app.core.config import WATCHLIST

def safe(x):
    try:
        return float(x or 0)
    except Exception:
        return 0.0

def grade(score):
    if score >= 90: return "A++"
    if score >= 80: return "A+"
    if score >= 70: return "A"
    if score >= 60: return "B"
    return "WAIT"

def decide(market):
    m = market.upper()
    st = STATE.get(m, {})
    final = round(
        safe(st.get("tech_score"))*0.22 +
        safe(st.get("smc_score"))*0.18 +
        safe(st.get("news_score"))*0.18 +
        safe(st.get("vp_score"))*0.10 +
        safe(st.get("delta_score"))*0.10 +
        safe(st.get("mtf_score"))*0.10 +
        safe(st.get("regime_score"))*0.07 +
        safe(st.get("risk_score",50))*0.05, 1
    )
    adj = safe(LEARNING.get(m, {}).get("score_adjustment", 0))
    final = max(0, min(100, round(final + adj, 1)))
    return {
        "market": m,
        "bias": st.get("bias", "Flat"),
        "score": final,
        "grade": grade(final),
        "decision": "TRADE_ALLOWED" if final >= 70 else "WAIT",
        "trigger": st.get("trigger", "-"),
        "price": st.get("price", "-"),
        "news_score": safe(st.get("news_score")),
        "learned_adjustment": adj,
        "updated": st.get("updated", "-")
    }

def scan_all():
    rows = [decide(m) for m in WATCHLIST]
    rows.sort(key=lambda x: x["score"], reverse=True)
    return rows
