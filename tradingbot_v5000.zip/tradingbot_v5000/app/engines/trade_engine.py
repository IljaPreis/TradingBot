from datetime import datetime
from app.core.state import STATE, TRADES
from app.engines.scoring_engine import decide

def new_signal(data):
    m = data["market"].upper()
    price = float(data["price"])
    side = data["side"].upper()
    st = STATE.setdefault(m, {})
    st.update({
        "bias": side,
        "price": price,
        "trigger": data.get("trigger","manual"),
        "tech_score": 90 if data.get("trend_state") else 60,
        "smc_score": 80 if data.get("structure_state") in ["bos","choch"] else st.get("smc_score",0),
        "vp_score": 70 if data.get("vwap_state") else st.get("vp_score",0),
        "risk_score": 80,
        "updated": datetime.utcnow().strftime("%H:%M:%S")
    })
    d = decide(m)
    if d["score"] >= 70:
        atr = float(data.get("atr") or 50)
        sl = price - atr*1.2 if side == "LONG" else price + atr*1.2
        tp1 = price + atr*1.8 if side == "LONG" else price - atr*1.8
        tp2 = price + atr*3.6 if side == "LONG" else price - atr*3.6
        tp3 = price + atr*5.4 if side == "LONG" else price - atr*5.4
        trade = {"market":m,"side":side,"entry":price,"sl":round(sl,2),"tp1":round(tp1,2),"tp2":round(tp2,2),"tp3":round(tp3,2),"status":"OPEN","rating":round(d["score"]/10,1),"score100":d["score"],"trigger":d["trigger"],"opened":st["updated"]}
        TRADES[m] = trade
        return {"accepted": True, "decision": d, "trade": trade}
    return {"accepted": False, "decision": d}

def manage(market, price):
    m = market.upper()
    trade = TRADES.get(m)
    events = []
    if not trade:
        return {"market":m,"price":price,"events":[],"trade":None}
    p = float(price)
    long = trade["side"] == "LONG"
    if trade["status"] == "OPEN":
        if (long and p >= trade["tp1"]) or ((not long) and p <= trade["tp1"]):
            events.append(f"{m}: TP1 erreicht. SL auf Break-Even prüfen.")
        if (long and p >= trade["tp2"]) or ((not long) and p <= trade["tp2"]):
            events.append(f"{m}: TP2 erreicht. Teilgewinn sichern.")
        if (long and p >= trade["tp3"]) or ((not long) and p <= trade["tp3"]):
            trade["status"] = "TP3_DONE"
            events.append(f"{m}: TP3 erreicht. Trade abgeschlossen.")
    trade["last_price"] = p
    return {"market":m,"price":p,"events":events,"trade":trade}
