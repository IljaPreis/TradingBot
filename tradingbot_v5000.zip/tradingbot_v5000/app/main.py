from fastapi import FastAPI
from app.routes.api import router as api_router
from app.routes.dashboard import router as dashboard_router
from app.engines.news_engine import seed_news

app = FastAPI(title="TradingBot V5000 Institutional Learning Engine")
app.include_router(api_router)
app.include_router(dashboard_router)

@app.on_event("startup")
async def startup():
    seed_news()
