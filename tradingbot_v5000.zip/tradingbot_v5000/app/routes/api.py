from fastapi import APIRouter, UploadFile, File
from pydantic import BaseModel
from app.core.config import WATCHLIST
from app.core.state import STATE, TRADES
from app.engines.scoring_engine import scan_all
from app.engines.news_engine import add_news, news_terminal
from app.engines.trade_engine import new_signal, manage
from app.engines.risk_engine import risk_status
from app.engines.learning_engine import upload_csv, backtest, learning_summary

router = APIRouter()

class Signal(BaseModel):
    market: str
    side: str
    price: float
    trigger: str = "manual"
    timeframe: str | None = None
    trend_state: str | None = None
    volume_state: str | None = None
    vwap_state: str | None = None
    structure_state: str | None = None
    session: str | None = None
    atr: float | None = 50

class PriceUpdate(BaseModel):
    market: str
    price: float

class NewsIn(BaseModel):
    text: str
    score: int = 3

@router.get("/health")
def health():
    return {"status":"online","version":"TradingBot V5000 Modular Learning Engine","markets":len(WATCHLIST),"trades":len(TRADES)}

@router.post("/webhook/tradingview")
def webhook(s: Signal):
    return new_signal(s.model_dump())

@router.post("/manage-trade")
def manage_trade(p: PriceUpdate):
    return manage(p.market, p.price)

@router.get("/scan-all")
def scan():
    return {"version":"V5000","scan":scan_all()}

@router.get("/top")
def top():
    return {"top":[x for x in scan_all() if x["score"] >= 70][:10]}

@router.post("/news/add")
def news_add(n: NewsIn):
    return add_news(n.text, n.score)

@router.get("/news-terminal")
def news():
    return {"version":"V5000 German News AI","news_de":news_terminal()}

@router.get("/risk")
def risk():
    return risk_status()

@router.post("/history/upload/{market}/{tf}")
async def upload_history(market: str, tf: str, file: UploadFile = File(...)):
    text = (await file.read()).decode("utf-8", "ignore")
    return upload_csv(market, tf, text)

@router.get("/backtest/{market}/{tf}")
def run_backtest(market: str, tf: str):
    return backtest(market, tf)

@router.get("/performance")
def performance():
    return learning_summary()
