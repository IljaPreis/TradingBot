from fastapi import APIRouter
from fastapi.responses import HTMLResponse
from app.engines.scoring_engine import scan_all
from app.engines.news_engine import news_terminal
from app.engines.risk_engine import risk_status
from app.engines.learning_engine import learning_summary
from app.core.state import TRADES

router = APIRouter()

CSS = """
body{font-family:Arial;background:#07111f;color:#e8f1ff;padding:24px}
.card{background:#101d33;border-radius:14px;padding:18px;margin:0 0 18px 0}
table{width:100%;border-collapse:collapse}td,th{padding:9px;border-bottom:1px solid #263854;text-align:left}
h1,h2{margin-top:0}.wait{color:#ffd166}
"""

@router.get("/terminal", response_class=HTMLResponse)
def terminal():
    scan = scan_all()
    news = news_terminal(12)
    risk = risk_status()
    learning = learning_summary()
    rows = ""
    for x in scan[:15]:
        rows += f"<tr><td>{x['market']}</td><td>{x['bias']}</td><td>{x['score']}</td><td>{x['grade']}</td><td>{x['decision']}</td><td>{x['trigger']}</td></tr>"
    news_html = ""
    for n in news:
        impact_html = ""
        for i in n.get("impacts", []):
            impact_html += f"<div>• {i['market']} {i['direction']} | Impact {i['impact']}/100</div>"
        news_html += f"<div style='margin-bottom:18px'><b>{'⭐'*int(n.get('score',2))} {n['headline_de']}</b><br><small>{n['time']} | {n['direction']}</small><br>{impact_html}</div>"
    trades_html = "".join([f"<li>{k}: {v}</li>" for k,v in TRADES.items()]) or "<li>Keine aktiven Trades</li>"
    return f"""<html><head><title>TradingBot V5000</title><style>{CSS}</style></head><body>
    <h1>TradingBot V5000 Institutional Learning Terminal</h1>
    <div class='card'><b>Status:</b> Online<br><b>Märkte:</b> {len(scan)}<br><b>Trades:</b> {len(TRADES)}</div>
    <div class='card'><h2>Top Setups</h2><table><tr><th>Markt</th><th>Bias</th><th>Score</th><th>Grade</th><th>Entscheidung</th><th>Trigger</th></tr>{rows}</table></div>
    <div class='card'><h2>Aktive Trades</h2><ul>{trades_html}</ul></div>
    <div class='card'><h2>Deutsche News AI + Watchlist Impact</h2>{news_html}</div>
    <div class='card'><h2>Risk Terminal</h2>Balance: {risk['balance']} | Risiko/Trade: {risk['risk_per_trade']}% | Max Trades: {risk['max_trades']} | Open Trades: {risk['open_trades']}</div>
    <div class='card'><h2>Learning</h2>History Files: {learning['history_files']} | Backtests: {learning['backtests']} | Learned Setups: {len(learning['learning'])}</div>
    </body></html>"""

@router.get("/learning-dashboard", response_class=HTMLResponse)
def learning_dashboard():
    l = learning_summary()
    rows = ""
    for market, data in l["learning"].items():
        rows += f"<tr><td>{market}</td><td>{data.get('score_adjustment',0)}</td><td>{data.get('stats',{})}</td></tr>"
    return f"<html><head><style>{CSS}</style></head><body><h1>Learning Dashboard</h1><div class='card'><table><tr><th>Market</th><th>Score-Anpassung</th><th>Stats</th></tr>{rows}</table></div></body></html>"
