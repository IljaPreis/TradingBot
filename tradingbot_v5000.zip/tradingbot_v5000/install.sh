#!/usr/bin/env bash
set -e
mkdir -p data
cp -n .env.example .env || true
docker compose down || true
docker compose up --build -d
echo "✅ TradingBot V5000 gestartet"
echo "Dashboard: http://SERVER-IP/terminal"
