# V7241 Master Pine + Server Pack

Dieses Paket ersetzt die nicht installierte V7240-Idee durch V7241.

## Inhalt

- `pine/TradingBot_V7241_Master_Pine_Engine.pine`
- `server/v7241_master_pine_server_pack.sh`
- `examples/sample_v7241_alert.json`
- `README_INSTALL.md`

## Server installieren

```bash
cd /opt/tradingbot_v6000 || exit 1

rm -rf /tmp/TradingBot_github
git clone --depth 1 https://github.com/IljaPreis/TradingBot.git /tmp/TradingBot_github

SCRIPT_PATH="$(find /tmp/TradingBot_github -type f -name 'v7241_master_pine_server_pack.sh' | head -n 1)"

if [ -z "$SCRIPT_PATH" ]; then
  echo "FEHLER: v7241_master_pine_server_pack.sh nicht gefunden."
  find /tmp/TradingBot_github -type f -name '*.sh'
  exit 1
fi

cp "$SCRIPT_PATH" /tmp/v7241_master_pine_server_pack.sh
sed -i 's/\r$//' /tmp/v7241_master_pine_server_pack.sh
chmod +x /tmp/v7241_master_pine_server_pack.sh

bash /tmp/v7241_master_pine_server_pack.sh
```

## Neue Server-Seiten

```text
/pine-master
/pine-master.json
/pine-master-config.json
/pine-master-review
/pine-master-review.json
```

Direkt:

```text
http://91.107.237.214/pine-master?token=eHwFukO31kypn0KZenWjht2T815BlQeeZNygm9nUwTg
```

## TradingView

1. Pine Editor öffnen.
2. `TradingBot_V7241_Master_Pine_Engine.pine` komplett einfügen.
3. Speichern und auf Chart legen.
4. Alert erstellen:
   - Condition: `TradingBot V7241 Master Pine Engine`
   - Alert: `Any alert() function call`
   - Webhook URL wie bisher
   - Message-Feld leer lassen/Standard lassen.

## Wichtig

Nicht parallel alte V6000/V7000 PineScripts und V7241 senden lassen.
V7241 ist der Master. Sonst entstehen doppelte Webhooks.
