#!/usr/bin/env bash
set -euo pipefail

cd /opt/tradingbot_v6000 || exit 1

TS="$(date -u +%Y%m%d_%H%M%S)"
TOKEN_DEFAULT="eHwFukO31kypn0KZenWjht2T815BlQeeZNygm9nUwTg"

echo "== V7241 MASTER PINE SERVER PACK =="
echo "No V7240 install required. Adds V7241 Master Pine evaluator and connects it to V7239 Soft Live Gate."

mkdir -p backups app data ops

echo "== Backup =="
tar -czf "backups/v7241_master_pine_before_${TS}.tar.gz" \
  --exclude='backups' --exclude='__pycache__' --exclude='.git' . || true

echo "== Config =="
cat > data/v7241_master_pine_config.json <<'JSON'
{
  "version": "V7241",
  "enabled": true,
  "apply_to_v7239": true,
  "force_shadow_score_below": 38.0,
  "downgrade_live_candidate_below": 54.0,
  "allow_rescue_shadow_only": false,
  "min_master_fields_required": 6,
  "notes": "V7241 evaluates Master Pine fields: timing, chase, HTF bias, S/R, EMA/VWAP, volume, wick rejection. Missing fields = no change."
}
JSON

echo "== Module =="
cat > app/v7241_master_pine_evaluator.py <<'PY'
import json
import html
import sqlite3
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
from typing import Optional

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

MASTER_FIELDS = [
    "schema_version", "bars_since_bos", "bars_since_mss", "bars_since_sweep",
    "bars_since_fvg_created", "bars_since_signal_zone_touch",
    "distance_to_vwap_atr", "distance_to_ema_atr", "distance_to_ribbon_atr",
    "distance_to_last_swing_atr", "entry_candle_range_atr", "entry_candle_body_atr",
    "wick_rejection_percent", "volume_spike", "volume_ratio",
    "htf_15m_bias", "htf_1h_bias", "htf_4h_bias", "market_structure_bias",
    "vwap_bias", "ema_bias", "ema_long_bias", "bias_aligned_count", "bias_opposed_count",
    "risk_reward", "sl_distance_atr", "tp_distance_atr",
    "distance_to_support_atr", "distance_to_resistance_atr",
    "near_support", "near_resistance", "is_fresh", "is_late_entry", "is_chase",
    "bos_bull", "bos_bear", "mss_bull", "mss_bear", "choch_bull", "choch_bear",
    "sweep_low", "sweep_high", "bull_fvg_retest", "bear_fvg_retest", "bpr_long", "bpr_short"
]

def _root():
    for p in [Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()]:
        if (p / "data").exists():
            return p
    return Path.cwd()

def _data(name):
    return _root() / "data" / name

def _esc(x):
    return html.escape(str(x))

def _read_json(name, default=None):
    if default is None:
        default = {}
    try:
        p = _data(name)
        if p.exists():
            x = json.loads(p.read_text(encoding="utf-8", errors="ignore"))
            return x if isinstance(x, dict) else default
    except Exception as exc:
        return {"load_error": str(exc)}
    return default

def _cfg():
    c = {
        "version": "V7241",
        "enabled": True,
        "apply_to_v7239": True,
        "force_shadow_score_below": 38.0,
        "downgrade_live_candidate_below": 54.0,
        "allow_rescue_shadow_only": False,
        "min_master_fields_required": 6,
        "notes": "V7241 evaluates Master Pine fields. Missing fields = no change.",
    }
    c.update(_read_json("v7241_master_pine_config.json", {}))
    return c

def _token_ok(request: Request):
    try:
        from app.v7200_event_risk import _token_ok as real_token_ok
        return real_token_ok(request)
    except Exception:
        return bool(request.query_params.get("token", ""))

def _connect():
    con = sqlite3.connect(str(_data("v7000_learning.sqlite3")))
    con.row_factory = sqlite3.Row
    return con

def _json_loads(x):
    try:
        y = json.loads(x or "{}")
        return y if isinstance(y, dict) else {}
    except Exception:
        return {}

def _num(x, default=None):
    try:
        if x is None or x == "":
            return default
        if isinstance(x, bool):
            return 1.0 if x else 0.0
        return float(str(x).replace(",", "."))
    except Exception:
        return default

def _bool(x, default=False):
    if isinstance(x, bool):
        return x
    if x is None:
        return default
    return str(x).strip().lower() in {"1", "true", "yes", "y", "on"}

def _raw_for_client_trade_id(client_trade_id):
    if not client_trade_id:
        return {}
    try:
        con = _connect()
        r = con.execute("""
            SELECT raw_json
            FROM signal_audit
            WHERE client_trade_id=?
            ORDER BY id DESC
            LIMIT 1
        """, (str(client_trade_id),)).fetchone()
        if not r:
            return {}
        return _json_loads(r["raw_json"])
    except Exception:
        return {}
    finally:
        try:
            con.close()
        except Exception:
            pass

def _features(raw):
    if not isinstance(raw, dict):
        return {}
    signal = raw.get("signal", {}) if isinstance(raw.get("signal"), dict) else {}
    out = {}
    for k in MASTER_FIELDS:
        if k in signal:
            out[k] = signal.get(k)
        elif k in raw:
            out[k] = raw.get(k)
    return out

def _feature_count(f):
    return sum(1 for k in MASTER_FIELDS if k in f and f.get(k) is not None)

def _direction(row, raw):
    d = str(row.get("direction") or raw.get("direction") or raw.get("side") or "").upper()
    if d == "BUY":
        return "LONG"
    if d == "SELL":
        return "SHORT"
    return d or "UNKNOWN"

def _is_align(direction, bias):
    b = str(bias or "").lower()
    return (direction == "LONG" and b == "bullish") or (direction == "SHORT" and b == "bearish")

def _is_opp(direction, bias):
    b = str(bias or "").lower()
    return (direction == "LONG" and b == "bearish") or (direction == "SHORT" and b == "bullish")

def _score_master(row, raw):
    cfg = _cfg()
    f = _features(raw)
    cnt = _feature_count(f)

    if cnt < int(cfg.get("min_master_fields_required", 6)):
        return {
            "version": "V7241",
            "master_present": False,
            "master_field_count": cnt,
            "score": None,
            "action": "NO_MASTER_FIELDS",
            "effect": "NO_CHANGE",
            "reasons": ["NO_MASTER_FIELDS"],
            "features": f,
        }

    direction = _direction(row, raw)
    score = 50.0
    reasons = []

    aligned = int(_num(f.get("bias_aligned_count"), 0) or 0)
    opposed = int(_num(f.get("bias_opposed_count"), 0) or 0)

    if aligned >= 4:
        score += 16
        reasons.append("MULTI_BIAS_STRONG_ALIGNED")
    elif aligned >= 3:
        score += 10
        reasons.append("MULTI_BIAS_ALIGNED")

    if opposed >= 4:
        score -= 24
        reasons.append("MULTI_BIAS_STRONG_OPPOSED")
    elif opposed >= 3:
        score -= 16
        reasons.append("MULTI_BIAS_OPPOSED")

    for k in ["htf_15m_bias", "htf_1h_bias", "htf_4h_bias", "market_structure_bias", "vwap_bias", "ema_bias"]:
        if _is_align(direction, f.get(k)):
            score += 2
        elif _is_opp(direction, f.get(k)):
            score -= 3

    bars_bos = int(_num(f.get("bars_since_bos"), 9999) or 9999)
    bars_mss = int(_num(f.get("bars_since_mss"), 9999) or 9999)
    bars_sweep = int(_num(f.get("bars_since_sweep"), 9999) or 9999)
    bars_zone = int(_num(f.get("bars_since_signal_zone_touch"), 9999) or 9999)

    if min(bars_bos, bars_mss) <= 8:
        score += 10
        reasons.append("FRESH_STRUCTURE")
    if min(bars_bos, bars_mss) >= 13:
        score -= 12
        reasons.append("LATE_STRUCTURE")
    if min(bars_sweep, bars_zone) <= 6:
        score += 6
        reasons.append("FRESH_SWEEP_OR_ZONE")

    if _bool(f.get("is_fresh"), False):
        score += 5
        reasons.append("PINE_FRESH_TRUE")
    if _bool(f.get("is_late_entry"), False):
        score -= 12
        reasons.append("PINE_LATE_ENTRY_TRUE")
    if _bool(f.get("is_chase"), False):
        score -= 16
        reasons.append("PINE_CHASE_TRUE")

    dist_vwap = _num(f.get("distance_to_vwap_atr"), None)
    dist_ema = _num(f.get("distance_to_ema_atr"), None)
    dist_ribbon = _num(f.get("distance_to_ribbon_atr"), None)
    candle_range = _num(f.get("entry_candle_range_atr"), None)
    candle_body = _num(f.get("entry_candle_body_atr"), None)
    wick = _num(f.get("wick_rejection_percent"), None)
    vol_ratio = _num(f.get("volume_ratio"), None)
    rr = _num(f.get("risk_reward"), None)

    if dist_vwap is not None and dist_vwap > 1.50:
        score -= 12
        reasons.append("CHASE_FAR_FROM_VWAP")
    if dist_ema is not None and dist_ema > 1.50:
        score -= 10
        reasons.append("CHASE_FAR_FROM_EMA")
    if dist_ribbon is not None and dist_ribbon <= 0.55:
        score += 5
        reasons.append("NEAR_EMA_RIBBON")
    if candle_range is not None and candle_range > 1.20:
        score -= 10
        reasons.append("BIG_ENTRY_CANDLE")
    if candle_body is not None and candle_body > 0.90:
        score -= 7
        reasons.append("BIG_ENTRY_BODY")
    if wick is not None and wick >= 45:
        score += 7
        reasons.append("GOOD_WICK_REJECTION")
    elif wick is not None and wick < 18:
        score -= 5
        reasons.append("LOW_WICK_REJECTION")
    if _bool(f.get("volume_spike"), False) or (vol_ratio is not None and vol_ratio >= 1.8):
        score += 4
        reasons.append("VOLUME_SPIKE")
    if rr is not None and rr < 1.20:
        score -= 12
        reasons.append("BAD_RISK_REWARD")

    near_support = _bool(f.get("near_support"), False)
    near_resistance = _bool(f.get("near_resistance"), False)
    if direction == "LONG" and near_resistance:
        score -= 12
        reasons.append("LONG_INTO_RESISTANCE")
    if direction == "SHORT" and near_support:
        score -= 12
        reasons.append("SHORT_INTO_SUPPORT")
    if direction == "LONG" and near_support:
        score += 5
        reasons.append("LONG_FROM_SUPPORT")
    if direction == "SHORT" and near_resistance:
        score += 5
        reasons.append("SHORT_FROM_RESISTANCE")

    # Setup-specific confirmations
    if direction == "LONG" and (_bool(f.get("bos_bull"), False) or _bool(f.get("mss_bull"), False) or _bool(f.get("choch_bull"), False)):
        score += 6
        reasons.append("LONG_STRUCTURE_TRIGGER")
    if direction == "SHORT" and (_bool(f.get("bos_bear"), False) or _bool(f.get("mss_bear"), False) or _bool(f.get("choch_bear"), False)):
        score += 6
        reasons.append("SHORT_STRUCTURE_TRIGGER")
    if direction == "LONG" and _bool(f.get("sweep_low"), False):
        score += 4
        reasons.append("LONG_SWEEP_RECLAIM")
    if direction == "SHORT" and _bool(f.get("sweep_high"), False):
        score += 4
        reasons.append("SHORT_SWEEP_RECLAIM")

    score = max(0.0, min(100.0, round(score, 2)))

    if score < float(cfg.get("force_shadow_score_below", 38.0)):
        action = "FORCE_SHADOW_ONLY"
        effect = "DOWNGRADE_TO_SHADOW"
    elif score < float(cfg.get("downgrade_live_candidate_below", 54.0)):
        action = "CAUTION_REVIEW"
        effect = "DOWNGRADE_LIVE_CANDIDATE_TO_REVIEW"
    elif score >= 82.0:
        action = "MASTER_STRONG_CONFIRM"
        effect = "CONFIRM_ONLY"
    else:
        action = "MASTER_CONFIRM"
        effect = "NO_CHANGE"

    return {
        "version": "V7241",
        "master_present": True,
        "master_field_count": cnt,
        "score": score,
        "action": action,
        "effect": effect,
        "reasons": reasons,
        "features": f,
    }

def _init_log(con):
    con.execute("""
    CREATE TABLE IF NOT EXISTS v7241_master_pine_eval_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT,
        client_trade_id TEXT,
        market TEXT,
        direction TEXT,
        setup_name TEXT,
        master_present INTEGER,
        master_field_count INTEGER,
        v7241_score REAL,
        v7241_action TEXT,
        v7241_effect TEXT,
        reasons_json TEXT,
        original_gate_action TEXT,
        final_gate_action TEXT,
        row_json TEXT,
        raw_json TEXT
    )
    """)

def _log(row, raw, result, original_gate, final_gate):
    try:
        con = _connect()
        _init_log(con)
        con.execute("""
        INSERT INTO v7241_master_pine_eval_log
        (created_at, client_trade_id, market, direction, setup_name,
         master_present, master_field_count, v7241_score, v7241_action, v7241_effect,
         reasons_json, original_gate_action, final_gate_action, row_json, raw_json)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            datetime.now(timezone.utc).isoformat(),
            str(row.get("client_trade_id") or ""),
            str(row.get("market") or ""),
            str(row.get("direction") or ""),
            str(row.get("setup_name") or ""),
            1 if result.get("master_present") else 0,
            int(result.get("master_field_count") or 0),
            _num(result.get("score"), None),
            str(result.get("action") or ""),
            str(result.get("effect") or ""),
            json.dumps(result.get("reasons", []), ensure_ascii=False),
            str(original_gate.get("action") if isinstance(original_gate, dict) else ""),
            str(final_gate.get("action") if isinstance(final_gate, dict) else ""),
            json.dumps(row, ensure_ascii=False, default=str),
            json.dumps(raw, ensure_ascii=False, default=str),
        ))
        con.commit()
    except Exception:
        pass
    finally:
        try:
            con.close()
        except Exception:
            pass

def v7241_adjust_soft_gate(row, gate):
    cfg = _cfg()
    if not cfg.get("enabled", True) or not cfg.get("apply_to_v7239", True):
        return gate

    cid = row.get("client_trade_id")
    raw = _raw_for_client_trade_id(cid)
    result = _score_master(row, raw)

    if not result.get("master_present"):
        return gate

    original = dict(gate) if isinstance(gate, dict) else {}
    new_gate = dict(gate) if isinstance(gate, dict) else {"action": "UNKNOWN", "score": None, "reasons": []}
    reasons = list(new_gate.get("reasons", []))
    reasons.append("V7241_SCORE_" + str(result.get("score")))
    for r in result.get("reasons", []):
        reasons.append("V7241_" + str(r))

    action = str(result.get("action"))
    if action == "FORCE_SHADOW_ONLY":
        new_gate["action"] = "SHADOW_ONLY_RECOMMENDED"
        new_gate["severity"] = "WEAK_MASTER_PINE"
        if new_gate.get("score") is None:
            new_gate["score"] = result.get("score")
        else:
            new_gate["score"] = min(float(new_gate.get("score") or 0), float(result.get("score") or 0))
    elif action == "CAUTION_REVIEW" and str(new_gate.get("action")) == "LIVE_CANDIDATE":
        new_gate["action"] = "LIVE_SMALL_OR_SHADOW_REVIEW"
        new_gate["severity"] = "CAUTION_MASTER_PINE"
    elif action == "MASTER_STRONG_CONFIRM":
        if str(new_gate.get("action")) != "SHADOW_ONLY_RECOMMENDED":
            new_gate["action"] = "LIVE_CANDIDATE"
            new_gate["severity"] = "GOOD_MASTER_PINE"
        elif bool(cfg.get("allow_rescue_shadow_only", False)):
            new_gate["action"] = "LIVE_SMALL_OR_SHADOW_REVIEW"
            new_gate["severity"] = "CAUTION_RESCUE_MASTER_PINE"

    new_gate["reasons"] = reasons
    new_gate["v7241_master_pine_score"] = result

    _log(row, raw, result, original, new_gate)
    return new_gate

def _logs(limit=250):
    try:
        con = _connect()
        _init_log(con)
        rows = [dict(r) for r in con.execute(
            "SELECT * FROM v7241_master_pine_eval_log ORDER BY id DESC LIMIT ?",
            (int(limit),)
        ).fetchall()]
        rows.reverse()
        return rows
    except Exception as exc:
        return [{"error": str(exc)}]
    finally:
        try:
            con.close()
        except Exception:
            pass

def _latest_master(limit=300):
    rows = []
    try:
        con = _connect()
        q = """
        SELECT id, created_at, client_trade_id, market, direction, trigger, confidence, allow_trade, reason, raw_json
        FROM signal_audit
        ORDER BY id DESC
        LIMIT ?
        """
        for r in con.execute(q, (int(limit),)).fetchall():
            d = dict(r)
            raw = _json_loads(d.get("raw_json"))
            f = _features(raw)
            cnt = _feature_count(f)
            if cnt:
                row = {
                    "client_trade_id": d.get("client_trade_id"),
                    "market": d.get("market"),
                    "direction": d.get("direction"),
                    "setup_name": d.get("trigger"),
                    "confidence": d.get("confidence"),
                }
                score = _score_master(row, raw)
                row.update({
                    "audit_id": d.get("id"),
                    "created_at": d.get("created_at"),
                    "allow_trade": d.get("allow_trade"),
                    "master_field_count": cnt,
                    "v7241_score": score.get("score"),
                    "v7241_action": score.get("action"),
                    "v7241_reasons": score.get("reasons"),
                })
                rows.append(row)
    except Exception as exc:
        return [{"error": str(exc)}]
    finally:
        try:
            con.close()
        except Exception:
            pass
    rows.reverse()
    return rows

def _stats():
    logs = _logs(1000)
    master = _latest_master(600)
    if logs and "error" in logs[0]:
        return {"error": logs[0]["error"], "config": _cfg()}
    action_counts = Counter(str(r.get("v7241_action")) for r in logs)
    final_gate_counts = Counter(str(r.get("final_gate_action")) for r in logs)
    reason_counts = Counter()
    for r in logs:
        try:
            reasons = json.loads(r.get("reasons_json") or "[]")
        except Exception:
            reasons = []
        for reason in reasons:
            reason_counts[str(reason)] += 1
    return {
        "version": "V7241",
        "mode": "MASTER_PINE_EVALUATOR_STATS",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "config": _cfg(),
        "log_rows": len(logs),
        "latest_master_audit_rows": len(master),
        "v7241_action_counts": dict(action_counts),
        "final_gate_counts": dict(final_gate_counts),
        "top_reasons": dict(reason_counts.most_common(25)),
        "latest_logs": logs[-100:],
        "latest_master_signals": master[-100:],
    }

def _links(token):
    links = [
        ("Pine Master", "/pine-master"),
        ("Review", "/pine-master-review"),
        ("V7239", "/soft-live-gate"),
        ("V7238", "/entry-bias-optimizer"),
        ("Master", "/master"),
    ]
    return " · ".join(f'<a href="{url}?token={_esc(token)}">{_esc(label)}</a>' for label, url in links)

def _html(title, body, request):
    token = request.query_params.get("token", "")
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{_esc(title)}</title>
<style>
body{{background:#09111b;color:#e8eef5;font-family:Arial,sans-serif;margin:22px}}
a{{color:#8cc8ff;text-decoration:none}}.card{{background:#121b27;border:1px solid #27364a;border-radius:14px;padding:15px;margin-bottom:16px}}
.badge{{display:inline-block;background:#1e5d9b;color:white;border-radius:999px;padding:7px 11px;font-weight:bold}}
table{{width:100%;border-collapse:collapse;font-size:13px;margin-top:10px}}th,td{{border-bottom:1px solid #27364a;padding:8px;text-align:left;vertical-align:top}}th{{color:#a9bfd6}}
.muted{{color:#a9b8c9}}@media(max-width:760px){{body{{margin:12px}}table{{font-size:12px}}th,td{{padding:6px}}}}
</style></head><body><h1>{_esc(title)}</h1><div class="card">{_links(token)}</div>{body}</body></html>"""

def _table(rows, log=False):
    trs = ""
    for r in rows:
        trs += f"""<tr><td>{_esc(r.get("created_at"))}</td><td>{_esc(r.get("market"))}</td><td>{_esc(r.get("direction"))}</td><td>{_esc(r.get("setup_name"))}</td><td>{_esc(r.get("master_field_count"))}</td><td>{_esc(r.get("v7241_score"))}</td><td>{_esc(r.get("v7241_action"))}</td><td>{_esc(r.get("final_gate_action", r.get("allow_trade")))}</td><td>{_esc(r.get("v7241_reasons", r.get("reasons_json")))}</td></tr>"""
    if not trs:
        trs = "<tr><td colspan='9'>No V7241 Master Pine rows yet.</td></tr>"
    return f"<table><tr><th>Time</th><th>Market</th><th>Dir</th><th>Setup</th><th>Fields</th><th>Score</th><th>Action</th><th>Gate/Allow</th><th>Reasons</th></tr>{trs}</table>"

def install_v7241_master_pine_evaluator(app):
    if getattr(app.state, "v7241_master_pine_evaluator_installed", False):
        return

    @app.get("/pine-master", response_class=HTMLResponse)
    def pine_master_page(request: Request):
        if not _token_ok(request):
            return HTMLResponse("unauthorized", status_code=401)
        s = _stats()
        body = f"""<div class="card"><span class="badge">V7241 MASTER PINE EVALUATOR</span>
<p class="muted">Master audit rows: <b>{_esc(s.get("latest_master_audit_rows"))}</b> · Log rows: <b>{_esc(s.get("log_rows"))}</b></p>
<p><b>V7241 actions:</b> {_esc(s.get("v7241_action_counts"))}</p>
<p><b>Final gates:</b> {_esc(s.get("final_gate_counts"))}</p>
<p><b>Top reasons:</b> {_esc(s.get("top_reasons"))}</p>
</div><div class="card"><h2>Latest V7241 Master Signals</h2>{_table(s.get("latest_master_signals", [])[-100:])}</div>"""
        return HTMLResponse(_html("TradingBot V7241 - Pine Master", body, request))

    @app.get("/pine-master.json")
    def pine_master_json(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(_stats())

    @app.get("/pine-master-config.json")
    def pine_master_config_json(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(_cfg())

    @app.get("/pine-master-review", response_class=HTMLResponse)
    def pine_master_review_page(request: Request, limit: Optional[int] = 250):
        if not _token_ok(request):
            return HTMLResponse("unauthorized", status_code=401)
        rows = _logs(int(limit or 250))
        body = f"""<div class="card"><span class="badge">V7241 REVIEW LOG</span><p>Rows: {_esc(len(rows))}</p>{_table(rows, log=True)}</div>"""
        return HTMLResponse(_html("TradingBot V7241 - Pine Master Review", body, request))

    @app.get("/pine-master-review.json")
    def pine_master_review_json(request: Request, limit: Optional[int] = 250):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse({"version": "V7241", "rows": _logs(int(limit or 250))})

    app.state.v7241_master_pine_evaluator_installed = True
    print("[V7241] Master Pine Evaluator installed")
PY

echo "== Patch V7239 to call V7241 adjuster =="
python3 - <<'PY'
from pathlib import Path
from datetime import datetime

p = Path("app/v7239_soft_live_gate_enforcement.py")
s = p.read_text(encoding="utf-8")
Path(f"backups/v7239_before_v7241_adjust_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.py").write_text(s, encoding="utf-8")

if "V7241 MASTER PINE FEATURE ADJUST" not in s:
    marker = "    gate = _soft_gate(row)\n"
    insert = """    # === V7241 MASTER PINE FEATURE ADJUST ===
    try:
        from app.v7241_master_pine_evaluator import v7241_adjust_soft_gate
        gate = v7241_adjust_soft_gate(row, gate)
    except Exception as _v7241_e:
        try:
            gate["v7241_error"] = str(_v7241_e)
        except Exception:
            pass
    # === END V7241 MASTER PINE FEATURE ADJUST ===
"""
    if marker not in s:
        raise SystemExit("Could not find gate = _soft_gate(row) in V7239 module")
    s = s.replace(marker, marker + insert, 1)
    p.write_text(s, encoding="utf-8")
    print("V7241 adjuster inserted into V7239")
else:
    print("V7241 adjuster already present")
PY

echo "== Header targets =="
python3 - <<'PY'
from pathlib import Path
p = Path("app/v7208_single_header_mode.py")
if p.exists():
    s = p.read_text(encoding="utf-8")
    if '/pine-master?token=' not in s:
        s = s.replace(
            '<a href="/soft-live-gate?token={_esc(token)}">SoftGate</a> |',
            '<a href="/soft-live-gate?token={_esc(token)}">SoftGate</a> |\\n    <a href="/pine-master?token={_esc(token)}">PineMaster</a> |'
        )
    p.write_text(s, encoding="utf-8")
PY

echo "== main install hook =="
if ! grep -q "V7241 MASTER PINE EVALUATOR INSTALL" app/main.py; then
cat >> app/main.py <<'PY'

# === V7241 MASTER PINE EVALUATOR INSTALL ===
try:
    from app.v7241_master_pine_evaluator import install_v7241_master_pine_evaluator
    install_v7241_master_pine_evaluator(app)
except Exception as exc:
    print("[V7241] Master Pine Evaluator install failed:", exc)
# === END V7241 MASTER PINE EVALUATOR INSTALL ===
PY
fi

echo "== ops report =="
cat > ops/v7241_master_pine_report.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail
TOKEN="${1:-eHwFukO31kypn0KZenWjht2T815BlQeeZNygm9nUwTg}"
BASE_URL="${BASE_URL:-http://127.0.0.1}"
cd /opt/tradingbot_v6000 || exit 1
mkdir -p data
TMP="$(mktemp /tmp/v7241_master_pine.XXXXXX.json)"
trap 'rm -f "$TMP"' EXIT
curl -fsS "${BASE_URL}/pine-master.json?token=${TOKEN}" > "$TMP"
python3 -m json.tool "$TMP" >/dev/null
mv "$TMP" data/v7241_master_pine_report_last.json
trap - EXIT
echo "v7241 master pine report ok $(date -u +%Y-%m-%dT%H:%M:%SZ)"
SH
chmod +x ops/v7241_master_pine_report.sh

echo "== cron =="
cat > /etc/cron.d/tradingbot_v7241_master_pine <<'CRON'
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
34,59 * * * * root cd /opt/tradingbot_v6000 && /opt/tradingbot_v6000/ops/v7241_master_pine_report.sh >> /opt/tradingbot_v6000/data/v7241_master_pine_cron.log 2>&1
CRON
chmod 0644 /etc/cron.d/tradingbot_v7241_master_pine
if command -v systemctl >/dev/null 2>&1; then systemctl restart cron >/dev/null 2>&1 || true; else service cron restart || true; fi

echo "== check script =="
CHECK_FILE="ops/v7000_check.sh"
if [ -f "$CHECK_FILE" ] && ! grep -q "V7241 MASTER PINE ROUTES" "$CHECK_FILE"; then
cat >> "$CHECK_FILE" <<'EOF'

echo ""
echo "===== V7241 MASTER PINE ROUTES ====="
TOKEN_FOR_V7241="eHwFukO31kypn0KZenWjht2T815BlQeeZNygm9nUwTg"
for U in pine-master pine-master.json pine-master-config.json pine-master-review pine-master-review.json; do
  echo "/${U}?token=*** -> $(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/${U}?token=${TOKEN_FOR_V7241}")"
done
echo "master_pine_cron -> $(test -f /etc/cron.d/tradingbot_v7241_master_pine && echo OK || echo MISSING)"
echo "master_pine_file -> $(test -f data/v7241_master_pine_report_last.json && echo OK || echo MISSING)"
for R in pine-master pine-master-review soft-live-gate entry-bias-optimizer setup-optimizer master markets single-header; do
  TMP="/tmp/v7241_${R}.html"
  CODE="$(curl -s -o "$TMP" -w "%{http_code}" "http://127.0.0.1/${R}?token=${TOKEN_FOR_V7241}")"
  HEADER="$(grep -c 'id="v7208_single_header_bar"' "$TMP" || true)"
  PINE="$(grep -c '/pine-master' "$TMP" || true)"
  echo "/${R}?token=*** -> ${CODE} | single_header_hits=${HEADER} | pine_master_link_hits=${PINE}"
done
EOF
chmod +x "$CHECK_FILE"
fi

echo "== syntax =="
python3 -m py_compile app/v7241_master_pine_evaluator.py app/v7239_soft_live_gate_enforcement.py app/main.py

echo "== docker rebuild =="
docker compose up -d --build tradingbot || docker restart tradingbot
sleep 7

TOKEN_TEST="${1:-$TOKEN_DEFAULT}"

echo "== Route Test =="
for U in pine-master pine-master.json pine-master-config.json pine-master-review pine-master-review.json; do
  echo "${U}_http=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/${U}?token=${TOKEN_TEST}")"
done

echo ""
echo "== Header Link Test =="
for R in pine-master pine-master-review soft-live-gate entry-bias-optimizer setup-optimizer master markets single-header; do
  TMP="/tmp/v7241_${R}.html"
  CODE="$(curl -s -o "$TMP" -w "%{http_code}" "http://127.0.0.1/${R}?token=${TOKEN_TEST}")"
  HEADER="$(grep -c 'id="v7208_single_header_bar"' "$TMP" || true)"
  PINE="$(grep -c '/pine-master' "$TMP" || true)"
  echo "/${R}?token=*** -> ${CODE} | single_header=${HEADER} | pine_master_link=${PINE}"
done

echo ""
echo "== Snapshot =="
bash ops/v7241_master_pine_report.sh "$TOKEN_TEST" || true
echo "master_pine_file=$(test -f data/v7241_master_pine_report_last.json && echo OK || echo MISSING)"
echo "master_pine_cron=$(test -f /etc/cron.d/tradingbot_v7241_master_pine && echo OK || echo MISSING)"

echo ""
echo "== V7241 Preview =="
curl -s "http://127.0.0.1/pine-master.json?token=${TOKEN_TEST}" \
  | python3 -m json.tool \
  | grep -E '"latest_master_audit_rows"|"log_rows"|"v7241_action_counts"|"final_gate_counts"|"top_reasons"' \
  | head -n 120 || true

echo ""
echo "== V7239 Adjust Hook Check =="
grep -n "V7241 MASTER PINE FEATURE ADJUST" app/v7239_soft_live_gate_enforcement.py || true

echo ""
echo "== Smoke Existing =="
echo "master_http=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/master?token=${TOKEN_TEST}")"
echo "markets_http=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/markets?token=${TOKEN_TEST}")"
echo "soft_live_gate_http=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/soft-live-gate?token=${TOKEN_TEST}")"
echo "entry_bias_optimizer_http=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/entry-bias-optimizer?token=${TOKEN_TEST}")"

echo ""
echo "== V7241 MASTER PINE SERVER PACK DONE =="
