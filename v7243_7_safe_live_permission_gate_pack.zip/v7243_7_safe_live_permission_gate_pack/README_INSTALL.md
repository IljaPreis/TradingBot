# V7243.7 Safe Live Permission Gate

Upload/Install:

```powershell
cd $env:USERPROFILE\Downloads
scp .\v7243_7_safe_live_permission_gate_pack.zip root@91.107.237.214:/tmp/
```

```bash
cd /opt/tradingbot_v6000 || exit 1
rm -rf /tmp/v7243_7_live
mkdir -p /tmp/v7243_7_live
unzip -o /tmp/v7243_7_safe_live_permission_gate_pack.zip -d /tmp/v7243_7_live
SCRIPT_PATH="$(find /tmp/v7243_7_live -type f -name 'install_v7243_7_safe_live.sh' | head -n 1)"
echo "SCRIPT_PATH=$SCRIPT_PATH"
sed -i 's/\r$//' "$SCRIPT_PATH"
chmod +x "$SCRIPT_PATH"
bash "$SCRIPT_PATH"
```
