#!/usr/bin/env bash
set -Eeuo pipefail
cd /opt/tradingbot_v6000 || exit 1
TS="$(date -u +%Y%m%d_%H%M%S)"
TOKEN="${1:-eHwFukO31kypn0KZenWjht2T815BlQeeZNygm9nUwTg}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "== V7243.7 SAFE LIVE PERMISSION GATE PACK =="
mkdir -p backups ops data app
cp app/main.py "backups/main_before_v7243_7_safe_live_${TS}.py"
cp app/v7239_soft_live_gate_enforcement.py "backups/v7239_before_v7243_7_safe_live_${TS}.py"
cp "$SRC_DIR/v7243_7_safe_live_gate.py" app/v7243_7_safe_live_gate.py
if [ ! -f data/v72437_live_permission_config.json ]; then
cat > data/v72437_live_permission_config.json <<'JSON'
{"enabled":true,"mode":"enforce","min_live_confidence":62.0,"min_review_confidence":55.0,"news_conflict_block":45.0,"news_alignment_support":35.0,"same_market_open_hard_block":true,"opposite_open_hard_block":true,"raw_fj_impact_for_live":false}
JSON
fi
python3 -m py_compile "$SRC_DIR/patch_v7243_7_safe_live.py"
python3 "$SRC_DIR/patch_v7243_7_safe_live.py"
cat > ops/v7243_7_safe_live_check.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail
TOKEN="${1:-eHwFukO31kypn0KZenWjht2T815BlQeeZNygm9nUwTg}"
cd /opt/tradingbot_v6000 || exit 1
echo "===== ROUTES ====="
echo "/health -> $(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/health")"
echo "/live-permission-v7243 -> $(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/live-permission-v7243?token=$TOKEN")"
echo "/live-permission-v7243.json -> $(curl -s -o /tmp/v72437_live.json -w "%{http_code}" "http://127.0.0.1/live-permission-v7243.json?token=$TOKEN")"
echo "/master -> $(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1/master?token=$TOKEN")"
echo "===== SUMMARY ====="
python3 - <<'PY'
import json
d=json.load(open('/tmp/v72437_live.json'))
print('version:',d.get('version'))
print('mode:',d.get('config',{}).get('mode'))
print('min_live_confidence:',d.get('config',{}).get('min_live_confidence'))
print('news_conflict_block:',d.get('config',{}).get('news_conflict_block'))
for x in d.get('simulation',[])[:20]:
    print(x.get('id'),x.get('market'),x.get('direction'),'conf',x.get('confidence'),'news',x.get('news_score'),'=>',x.get('proposed_state'),','.join((x.get('reasons') or [])[:3]))
PY
echo "===== HOOK PRESENT ====="
grep -n "V7243.7 SAFE LIVE PERMISSION HOOK\|v72437_apply_live_permission" app/v7239_soft_live_gate_enforcement.py || true
echo "===== RECENT V72437 LOGS ====="
sqlite3 data/v7000_learning.sqlite3 <<'SQL'
.headers on
.mode column
SELECT id, created_at, market, direction, confidence, news_score, old_action, new_action, proposed_state, substr(reasons_json,1,160) AS reasons
FROM v72437_live_permission_log
ORDER BY id DESC
LIMIT 15;
SQL
echo "Open: http://91.107.237.214/live-permission-v7243?token=$TOKEN"
SH
chmod +x ops/v7243_7_safe_live_check.sh
python3 -m py_compile app/v7243_7_safe_live_gate.py app/v7239_soft_live_gate_enforcement.py app/main.py
docker compose up -d --build tradingbot || docker restart tradingbot
sleep 8
bash ops/v7243_7_safe_live_check.sh "$TOKEN"
echo "== DONE =="
echo "http://91.107.237.214/live-permission-v7243?token=$TOKEN"
