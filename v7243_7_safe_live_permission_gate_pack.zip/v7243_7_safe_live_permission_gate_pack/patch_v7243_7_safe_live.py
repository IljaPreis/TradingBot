
from pathlib import Path
ROOT=Path('/opt/tradingbot_v6000')
main=ROOT/'app'/'main.py'
gate_file=ROOT/'app'/'v7239_soft_live_gate_enforcement.py'
s=main.read_text(encoding='utf-8')
block='''

# === V7243.7 SAFE LIVE PERMISSION ROUTES INSTALL ===
try:
    from app.v7243_7_safe_live_gate import install_v7243_7_safe_live_permission_gate
    install_v7243_7_safe_live_permission_gate(app)
except Exception as exc:
    print('[V7243_7_SAFE_LIVE_PERMISSION_ROUTES] install failed:', exc)
# === END V7243.7 SAFE LIVE PERMISSION ROUTES INSTALL ===
'''
if 'V7243.7 SAFE LIVE PERMISSION ROUTES INSTALL' not in s:
    s += block
    print('added V7243.7 routes block')
else:
    print('V7243.7 routes block already present')
main.write_text(s,encoding='utf-8')

g=gate_file.read_text(encoding='utf-8')
if 'V7243.7 SAFE LIVE PERMISSION HOOK' in g:
    print('V7243.7 hook already present')
else:
    start=g.find('def v7239_apply_soft_gate')
    if start < 0: raise SystemExit('Could not find def v7239_apply_soft_gate')
    end=g.find('\ndef ', start+1)
    if end < 0: end=len(g)
    seg=g[start:end]
    idx=seg.rfind('    return gate')
    if idx < 0: raise SystemExit('Could not find return gate')
    hook='''    # === V7243.7 SAFE LIVE PERMISSION HOOK ===
    try:
        from app.v7243_7_safe_live_gate import v72437_apply_live_permission
        gate = v72437_apply_live_permission(row, gate)
    except Exception as exc:
        try:
            gate.setdefault('reasons', []).append('V72437_HOOK_ERROR:' + str(exc)[:120])
        except Exception:
            pass
    # === END V7243.7 SAFE LIVE PERMISSION HOOK ===

'''
    g = g[:start] + seg[:idx] + hook + seg[idx:] + g[end:]
    gate_file.write_text(g,encoding='utf-8')
    print('inserted V7243.7 hook')
print('V7243.7 patch complete')
