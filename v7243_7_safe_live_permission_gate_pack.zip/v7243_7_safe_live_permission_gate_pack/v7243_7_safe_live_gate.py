
import json, html, sqlite3
from pathlib import Path
from datetime import datetime, timezone
from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse
VERSION='V7243.7-SAFE-LIVE-PERMISSION-GATE'
DEFAULT_CONFIG={'enabled':True,'mode':'enforce','min_live_confidence':62.0,'min_review_confidence':55.0,'news_conflict_block':45.0,'news_alignment_support':35.0,'same_market_open_hard_block':True,'opposite_open_hard_block':True,'raw_fj_impact_for_live':False}

def _esc(x): return html.escape('' if x is None else str(x))
def _root():
    for p in [Path('/app'),Path('/opt/tradingbot_v6000'),Path.cwd()]:
        try:
            if (p/'data').exists(): return p
        except Exception: pass
    return Path.cwd()
def _db(): return _root()/'data'/'v7000_learning.sqlite3'
def _cfg(): return _root()/'data'/'v72437_live_permission_config.json'
def _now(): return datetime.now(timezone.utc).isoformat()
def _con():
    c=sqlite3.connect(str(_db()),timeout=20); c.row_factory=sqlite3.Row; return c

def _token_ok(req:Request):
    try:
        from app.v7200_event_risk import _token_ok as ok
        return ok(req)
    except Exception:
        return bool(req.query_params.get('token',''))

def load_config():
    cfg=dict(DEFAULT_CONFIG); p=_cfg()
    try:
        if p.exists():
            x=json.loads(p.read_text(encoding='utf-8'))
            if isinstance(x,dict): cfg.update(x)
    except Exception as e: cfg['config_error']=str(e)
    return cfg

def _init(c):
    c.execute('CREATE TABLE IF NOT EXISTS v72437_live_permission_log(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT,market TEXT,direction TEXT,setup_name TEXT,confidence REAL,news_score REAL,open_position TEXT,old_action TEXT,new_action TEXT,proposed_state TEXT,mode TEXT,reasons_json TEXT,raw_json TEXT)')
    c.commit()

def _table(c,t):
    try: return c.execute('SELECT 1 FROM sqlite_master WHERE type="table" AND name=?',(t,)).fetchone() is not None
    except Exception: return False

def _open_live():
    c=_con(); out={}
    try:
        if _table(c,'open_trades'):
            for r in c.execute("SELECT market,direction FROM open_trades WHERE UPPER(COALESCE(status,''))='OPEN'"):
                out[str(r['market']).upper()]=str(r['direction']).upper()
    except Exception: pass
    c.close(); return out

def _news_scores():
    try:
        from app.v7243_5_calendar_fj_cluster_decay import _summary
        s=_summary(minutes=720)
        x=((s.get('clustered_news_impact') or {}).get('market_scores') or {})
        return x if isinstance(x,dict) else {}
    except Exception: return {}

def _f(x,d=0.0):
    try: return float(x)
    except Exception: return d

def _v(row,k,d=None):
    try:
        if isinstance(row,dict): return row.get(k,d)
        return row[k]
    except Exception: return getattr(row,k,d)

def _sig(row):
    raw=_v(row,'raw_json',None); obj={}
    if isinstance(raw,str):
        try: obj=json.loads(raw)
        except Exception: obj={}
    elif isinstance(raw,dict): obj=raw
    s=obj.get('signal') if isinstance(obj,dict) else {}
    if not isinstance(s,dict): s={}
    return {'market':str(_v(row,'market',None) or s.get('market') or s.get('symbol') or '').upper(),'direction':str(_v(row,'direction',None) or s.get('direction') or s.get('side') or '').upper(),'setup_name':str(_v(row,'setup_name',None) or _v(row,'trigger',None) or s.get('setup_name') or s.get('trigger') or ''),'confidence':_f(_v(row,'confidence',None) or s.get('confidence') or s.get('score') or 0)}

def evaluate_signal(sig,cfg=None,news=None,open_live=None):
    cfg=cfg or load_config(); news=news if news is not None else _news_scores(); open_live=open_live if open_live is not None else _open_live()
    m=sig.get('market',''); d=sig.get('direction',''); conf=_f(sig.get('confidence')); ns=_f((news.get(m) or {}).get('score'),0.0)
    reasons=[]; hard=False; open_pos=''
    if m in open_live:
        open_pos=open_live[m]
        if open_pos==d: reasons.append('V72437_DUPLICATE_OPEN_HARD_BLOCK'); hard=True
        else: reasons.append('V72437_OPPOSITE_OPEN_HARD_BLOCK'); hard=True
    if conf < float(cfg.get('min_review_confidence',55)): reasons.append('V72437_LOW_CONFIDENCE_SHADOW'); hard=True
    if d=='LONG' and ns <= -float(cfg.get('news_conflict_block',45)): reasons.append('V72437_NEWS_CONFLICT_LONG_BLOCK'); hard=True
    if d=='SHORT' and ns >= float(cfg.get('news_conflict_block',45)): reasons.append('V72437_NEWS_CONFLICT_SHORT_BLOCK'); hard=True
    align=(d=='LONG' and ns>=float(cfg.get('news_alignment_support',35))) or (d=='SHORT' and ns<=-float(cfg.get('news_alignment_support',35)))
    proposed='SHADOW_ONLY_RECOMMENDED'
    if not hard:
        if conf>=float(cfg.get('min_live_confidence',62)): proposed='LIVE_CANDIDATE'; reasons.append('V72437_STRONG_CONF_NO_HARD_CONFLICT')
        elif conf>=58 or (conf>=float(cfg.get('min_review_confidence',55)) and align): proposed='REVIEW_ONLY'; reasons.append('V72437_REVIEW_ONLY')
        else: reasons.append('V72437_MID_CONF_SHADOW')
    return {'market':m,'direction':d,'confidence':conf,'news_score':ns,'open_position':open_pos,'proposed_state':proposed,'live_allowed':proposed=='LIVE_CANDIDATE','reasons':reasons,'hard_block':hard}

def _old(g): return str((g or {}).get('action') or (g or {}).get('final_gate_action') or '') if isinstance(g,dict) else ''
def _reasons(g):
    if isinstance(g,dict):
        if not isinstance(g.get('reasons'),list): g['reasons']=[]
        return g['reasons']
    return []
def _log(sig,cfg,old,new,dec):
    try:
        c=_con(); _init(c)
        c.execute('INSERT INTO v72437_live_permission_log(created_at,market,direction,setup_name,confidence,news_score,open_position,old_action,new_action,proposed_state,mode,reasons_json,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(_now(),sig.get('market'),sig.get('direction'),sig.get('setup_name'),sig.get('confidence'),dec.get('news_score'),dec.get('open_position'),old,new,dec.get('proposed_state'),cfg.get('mode'),json.dumps(dec.get('reasons') or []),json.dumps(dec)))
        c.commit(); c.close()
    except Exception: pass

def v72437_apply_live_permission(row,gate):
    cfg=load_config()
    if not cfg.get('enabled',True): return gate
    sig=_sig(row); dec=evaluate_signal(sig,cfg=cfg); old=_old(gate)
    rs=_reasons(gate)
    for r in dec.get('reasons',[]):
        if r not in rs: rs.append(r)
    if isinstance(gate,dict): gate['v72437_safe_live_permission']=dec
    if str(cfg.get('mode','observe')).lower()!='observe':
        if dec.get('live_allowed'):
            gate['action']='LIVE_CANDIDATE'; gate['allow_trade']=True; gate['v72437_live_allowed']=True
        else:
            gate['action']='SHADOW_ONLY_RECOMMENDED'; gate['allow_trade']=False; gate['v72437_live_allowed']=False
    _log(sig,cfg,old,_old(gate),dec)
    return gate

def _simulate(limit=40):
    c=_con(); cfg=load_config(); news=_news_scores(); op=_open_live(); out=[]
    try:
        if _table(c,'signal_audit'):
            for r in c.execute("SELECT id,created_at,market,direction,trigger,confidence,allow_trade,json_extract(raw_json,'$.v7000.v7239_soft_gate.action') AS gate_action,raw_json FROM signal_audit ORDER BY id DESC LIMIT ?",(limit,)):
                row=dict(r); s=_sig(row); d=evaluate_signal(s,cfg,news,op); d.update({'id':row.get('id'),'created_at':row.get('created_at'),'current_gate_action':row.get('gate_action'),'trigger':row.get('trigger')}); out.append(d)
    except Exception: pass
    c.close(); return out

def _summary():
    p=_cfg()
    if not p.exists(): p.write_text(json.dumps(DEFAULT_CONFIG,indent=2),encoding='utf-8')
    c=_con(); _init(c)
    logs=[dict(r) for r in c.execute('SELECT * FROM v72437_live_permission_log ORDER BY id DESC LIMIT 50').fetchall()]
    c.close()
    return {'version':VERSION,'config':load_config(),'open_live':_open_live(),'news_scores':_news_scores(),'simulation':_simulate(40),'latest_logs':logs}

def _page(token=''):
    s=_summary(); cfg=s.get('config',{}); rows=''
    for d in s.get('simulation',[])[:40]:
        rows += '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (_esc(d.get('id')),_esc(d.get('market')),_esc(d.get('direction')),_esc(d.get('confidence')),_esc(d.get('news_score')),_esc(d.get('open_position')),_esc(d.get('proposed_state')),_esc(','.join(d.get('reasons') or [])))
    if not rows: rows='<tr><td colspan="8">Keine Simulation.</td></tr>'
    css='body{font-family:Arial;background:#07111e;color:#eef6ff;padding:20px}a{color:#7dd3fc}.card{background:#101d2e;border:1px solid #273a52;border-radius:12px;padding:12px;margin:10px 0}table{width:100%;border-collapse:collapse;font-size:12px}td,th{border-bottom:1px solid #273a52;padding:7px;text-align:left}th{background:#13243a}'
    return '<html><head><style>%s</style></head><body><h1>%s</h1><p><a href="/master?token=%s">Master</a> <a href="/live-permission-v7243.json?token=%s">JSON</a></p><div class="card">Mode: %s | Min Live Conf: %s | News Conflict: %s</div><table><tr><th>ID</th><th>Market</th><th>Dir</th><th>Conf</th><th>News</th><th>Open</th><th>Proposed</th><th>Reasons</th></tr>%s</table></body></html>' % (css,_esc(VERSION),_esc(token),_esc(token),_esc(cfg.get('mode')),_esc(cfg.get('min_live_confidence')),_esc(cfg.get('news_conflict_block')),rows)

def install_v7243_7_safe_live_permission_gate(app):
    if getattr(app.state,'v7243_7_safe_live_permission_gate_installed',False): return
    @app.get('/live-permission-v7243', response_class=HTMLResponse)
    def page(request:Request):
        if not _token_ok(request): return HTMLResponse('<h1>403</h1>',status_code=403)
        return HTMLResponse(_page(request.query_params.get('token','')))
    @app.get('/live-permission-v7243.json')
    def js(request:Request):
        if not _token_ok(request): return JSONResponse({'error':'unauthorized'},status_code=403)
        return JSONResponse(_summary())
    app.state.v7243_7_safe_live_permission_gate_installed=True
