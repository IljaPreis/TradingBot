# V8000 Dual Playbook Pack

Großer Konzeptwechsel für den TradingBot:

- Portfolio Manager vor Entry-Signalen
- Dual Playbook:
  - Playbook A: HTF Orderblock / Supply-Demand Reaction
  - Playbook B: Session Momentum / ORB Continuation
- Nutzt vorhandene V7245/V7246-Auswertungen:
  - V7246F Clean Candidates
  - V7246G Entry Guard
  - Entry Grade / TP Bias
  - Price Heartbeats, falls vorhanden
- Observe only:
  - keine Live-Regeländerung
  - keine automatische Freigabe
  - keine Orders
  - Live bleibt gesperrt, wenn V7246G NO_GO_LIVE meldet

## Installation

```bash
cd /opt/tradingbot_v6000 || exit 1
unzip -o v8000_dual_playbook_pack.zip -d /opt/tradingbot_v6000
bash /opt/tradingbot_v6000/v8000_dual_playbook_pack/install_v8000.sh
```

## Routes

- `/v8000/master`
- `/v8000/master.json`
- `/v8000/portfolio`
- `/v8000/portfolio.json`
- `/v8000/playbooks`
- `/v8000/playbooks.json`
- `/v8000/a-plus`
- `/v8000/a-plus.json`

## Check

```bash
cd /opt/tradingbot_v6000 || exit 1
bash ops/v8000_check.sh
```
