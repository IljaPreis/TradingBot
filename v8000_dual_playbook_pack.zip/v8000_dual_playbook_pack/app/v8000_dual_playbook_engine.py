# V8000 Dual Playbook Engine
# Portfolio Manager + HTF OB Reaction + Session Momentum.
# Observe only. No live rule changes.

from datetime import datetime, timezone
from pathlib import Path
import html, json, sqlite3, sys

ROOT = str(Path(__file__).resolve().parents[1])
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

VERSION = "V8000-DUAL-PLAYBOOK-ENGINE"
MODE = "observe_only_a_plus_framework"
DBS = [Path("data/v7000_learning.sqlite3"), Path("/opt/tradingbot_v6000/data/v7000_learning.sqlite3"), Path("/app/data/v7000_learning.sqlite3")]
REVIEW_THRESHOLD = 55.0
LIVE_THRESHOLD = 62.0

WEAK = ["BPR", "BULL_FVG", "FVG_RETEST", "FVG_RECENT", "BOS_BULL", "INTERNAL_MSS_BULL_RECENT", "REVERSAL_LONG_MSS_RECLAIM"]
STRONG = ["INTERNAL_MSS_BEAR_RECENT", "INTERNAL_MSS_BEAR", "BOS_BEAR_RECENT", "MSS_BEAR_RECENT", "MSS_BEAR", "BEAR_OB_RETEST", "BEAR_OB_RECENT", "BULL_OB_RETEST", "BULL_OB_RECENT", "BOS_BEAR", "MSS_BULL_RECENT"]
OB_KEYS = ["_OB", " OB", "ORDER_BLOCK", "BEAR_OB", "BULL_OB"]
MOM_KEYS = ["MSS", "BOS", "ORB", "BREAKOUT", "OPENING_RANGE"]
TF_ALIAS = {"15":"15M","15M":"15M","M15":"15M","60":"1H","1H":"1H","H1":"1H","240":"4H","4H":"4H","H4":"4H","D":"1D","1D":"1D","DAY":"1D","DAILY":"1D"}


def now():
    return datetime.now(timezone.utc).isoformat()

def esc(x):
    return html.escape(str(x if x is not None else ""))

def norm(x):
    return str(x or "").strip().upper()

def fnum(x, default=None):
    try:
        if x is None or str(x).strip() == "":
            return default
        return float(x)
    except Exception:
        return default

def pct(a,b):
    return round(float(a)/float(b)*100.0,1) if b else 0.0

def pick_db():
    for p in DBS:
        if p.exists(): return p
    return None

def q(name):
    return '"' + str(name).replace('"','""') + '"'

def safe_payload(modname, fnname, **kw):
    try:
        m = __import__(modname, fromlist=[fnname])
        return getattr(m, fnname)(**kw), None
    except Exception as e:
        return None, str(e)

def load_f(limit=220):
    d, e = safe_payload("app.v7246f_clean_upgrade_candidates", "v7246f_payload", limit=limit)
    if d and d.get("ok"):
        return d, None
    return {"ok":False,"version":"fallback","summary":{},"clean_signals":[],"potential_review_candidates":[],"potential_live_candidates":[],"downgrade_candidates":[]}, e

def load_g(limit=220):
    d, e = safe_payload("app.v7246g_entry_guard_recommendation", "v7246g_payload", limit=limit)
    if d and d.get("ok"):
        return d, None
    return {"ok":False,"version":"fallback","summary":{},"recommendation":{"grade":"UNKNOWN","safe_to_apply":False,"allow_future_entry_bonus":False,"recommended_bonus":0,"recommended_scope":"OBSERVE_ONLY","action":"KEEP_OBSERVE_ONLY","live_rule_changes":False,"warnings":["V7246G nicht verfügbar."],"reasons":[]}}, e

def tfkey(x):
    t = norm(x).replace(" ","").replace("_","")
    return TF_ALIAS.get(t,t)

def bias(o,c):
    o=fnum(o); c=fnum(c)
    if o is None or c is None: return "UNKNOWN"
    if c>o: return "BULLISH"
    if c<o: return "BEARISH"
    return "NEUTRAL"

def direction(sig):
    t = norm(sig.get("direction")) + " " + norm(sig.get("setup_name"))
    if "SHORT" in t or "SELL" in t or "BEAR" in t: return "SHORT"
    if "LONG" in t or "BUY" in t or "BULL" in t: return "LONG"
    return "UNKNOWN"

def family(setup):
    t=norm(setup)
    if "BPR" in t: return "BPR"
    if "FVG" in t: return "FVG"
    if any(k in t for k in OB_KEYS): return "OB"
    if "MSS" in t: return "MSS"
    if "BOS" in t: return "BOS"
    if "SWEEP" in t or "LIQ" in t: return "LIQ_SWEEP"
    if "RECLAIM" in t: return "RECLAIM"
    if "REVERSAL" in t: return "REVERSAL"
    return "OTHER"

def setup_info(setup, grade="", tp=""):
    t=norm(setup); fam=family(t); grade=norm(grade); tp=norm(tp)
    weak_hits=[p for p in WEAK if p in t]
    strong_hits=[p for p in STRONG if p in t]
    if "BULL_OB_RETEST" in t or "BULL_OB_RECENT" in t:
        weak_hits=[p for p in weak_hits if p not in ["BOS_BULL","BULL_FVG"]]
    is_weak = bool(weak_hits) or grade in ["D","RISKY"] or tp in ["SHADOW_ONLY","REVIEW_ONLY"]
    is_strong = bool(strong_hits) or grade in ["A","B"]
    if fam == "OB" and is_strong:
        is_weak = False
    return {"family":fam,"is_weak":is_weak,"is_strong":is_strong,"weak_hits":weak_hits,"strong_hits":strong_hits}

def heartbeats():
    db=pick_db()
    if not db: return {}
    try:
        con=sqlite3.connect(str(db)); con.row_factory=sqlite3.Row
        tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        if "price_heartbeats" not in tables: return {}
        rows=con.execute("SELECT market,timeframe,open,high,low,close,received_at,source,ticker FROM price_heartbeats ORDER BY received_at DESC LIMIT 5000").fetchall()
        out={}
        for r in rows:
            m=norm(r["market"] or r["ticker"]); tf=tfkey(r["timeframe"])
            if not m or not tf: continue
            out.setdefault(m,{})
            if tf in out[m]: continue
            out[m][tf]={"timeframe":tf,"open":fnum(r["open"]),"high":fnum(r["high"]),"low":fnum(r["low"]),"close":fnum(r["close"]),"received_at":r["received_at"],"source":r["source"],"bias":bias(r["open"],r["close"])}
        return out
    except Exception:
        return {}

def tf_status(hb):
    d1=hb.get("1D"); h4=hb.get("4H"); h1=hb.get("1H"); m15=hb.get("15M")
    return {"available_timeframes":sorted(hb.keys()),"d1_bias":(d1 or {}).get("bias","MISSING"),"h4_bias":(h4 or {}).get("bias","MISSING"),"h1_bias":(h1 or {}).get("bias","MISSING"),"m15_bias":(m15 or {}).get("bias","MISSING"),"has_d1":bool(d1),"has_4h":bool(h4),"has_1h":bool(h1),"has_15m":bool(m15),"latest_close":(m15 or h1 or h4 or d1 or {}).get("close"),"latest_received_at":(m15 or h1 or h4 or d1 or {}).get("received_at")}

def bias_allows(b,d):
    b=norm(b); d=norm(d)
    if b in ["MISSING","UNKNOWN"]: return "UNKNOWN"
    if b=="NEUTRAL": return "NEUTRAL"
    if d=="LONG" and b=="BULLISH": return "ALIGNED"
    if d=="SHORT" and b=="BEARISH": return "ALIGNED"
    if d in ["LONG","SHORT"]: return "AGAINST"
    return "UNKNOWN"

def htf_assess(tf,d):
    vals=[("D1",bias_allows(tf.get("d1_bias"),d),2),("4H",bias_allows(tf.get("h4_bias"),d),3),("1H",bias_allows(tf.get("h1_bias"),d),1)]
    score=0; notes=[]
    for name,val,w in vals:
        if val=="ALIGNED": score+=w; notes.append(name+" aligned")
        elif val=="AGAINST": score-=w; notes.append(name+" against")
        elif val=="NEUTRAL": notes.append(name+" neutral")
        else: notes.append(name+" missing")
    if not (tf.get("has_d1") or tf.get("has_4h")): status="HTF_DATA_MISSING"
    elif score>=3: status="HTF_ALIGNED"
    elif score<=-3: status="HTF_AGAINST"
    else: status="HTF_MIXED_OR_NEUTRAL"
    return {"htf_status":status,"htf_score":score,"d1_alignment":vals[0][1],"h4_alignment":vals[1][1],"h1_alignment":vals[2][1],"notes":notes}

def eval_signal(sig, tf, guard):
    setup=sig.get("setup_name") or ""; d=direction(sig); info=setup_info(setup,sig.get("entry_grade"),sig.get("tp_bias")); htf=htf_assess(tf,d); t=norm(setup)
    rec=guard.get("recommendation") or {}; live_guard=bool(rec.get("safe_to_apply")) and bool(rec.get("allow_future_entry_bonus"))
    play="NO_PLAYBOOK"; score=0; reasons=[]; blocks=[]
    if info["is_weak"]: blocks.append("Historisch schwaches/riskantes Setup."); score-=5
    if info["family"]=="OB":
        play="PLAYBOOK_A_HTF_OB_REACTION"; score+=5; reasons.append("Orderblock-Reaction erkannt.")
        if info["is_strong"]: score+=2; reasons.append("OB/Entry-Daten A/B oder stark.")
        if htf["htf_status"]=="HTF_ALIGNED": score+=2; reasons.append("HTF unterstützt Richtung.")
        elif htf["htf_status"]=="HTF_DATA_MISSING": blocks.append("4H/1D Zone-Daten fehlen; nur Review/Observe.")
        elif htf["htf_status"]=="HTF_AGAINST": blocks.append("HTF dagegen; nur echte Zonenreaktion beobachten.")
    elif any(k in t for k in MOM_KEYS) and not info["is_weak"]:
        play="PLAYBOOK_B_SESSION_MOMENTUM"; score+=4; reasons.append("MSS/BOS/Momentum erkannt.")
        if htf["htf_status"]=="HTF_ALIGNED": score+=4; reasons.append("HTF unterstützt Momentum.")
        elif htf["htf_status"]=="HTF_MIXED_OR_NEUTRAL": score+=1; reasons.append("HTF gemischt/neutral; maximal Review.")
        elif htf["htf_status"]=="HTF_DATA_MISSING": blocks.append("4H/1D fehlen; 1H/15m alleine reicht nicht.")
        else: blocks.append("Momentum gegen HTF; kein A+.")
    elif info["family"] in ["FVG","BPR"]:
        play="NO_PLAYBOOK_CONFLUENCE_ONLY"; blocks.append("FVG/BPR nur Confluence, kein Hauptsetup.")
    cls=norm(sig.get("candidate_class") or sig.get("overlay_decision"))
    if "POTENTIAL_REVIEW" in cls: score+=2; reasons.append("V7246F sieht Potential-Review.")
    if "DOWNGRADE" in cls: score-=4; blocks.append("V7246F markiert Downgrade.")
    sim=fnum(sig.get("simulated_confidence")); conf=fnum(sig.get("confidence")); c=sim if sim is not None else conf
    if c is not None and c>=REVIEW_THRESHOLD: score+=1; reasons.append("Confidence im Review-Bereich.")
    if c is not None and c>=LIVE_THRESHOLD: score+=1; reasons.append("Confidence über Live-Schwelle, aber V8000 bleibt Observe.")
    if not live_guard: blocks.append("V7246G erlaubt keinen Live-Entry-Bonus.")
    if info["is_weak"]: state="NO_TRADE_WEAK_MODEL"
    elif blocks and score<7: state="WATCH_ONLY"
    elif score>=8 and not blocks: state="A_PLUS_REVIEW_CANDIDATE"
    elif score>=6: state="REVIEW_CANDIDATE"
    elif score>=3: state="WATCH_ONLY"
    else: state="NO_TRADE"
    return {"market":sig.get("market"),"direction":d,"setup_name":setup,"playbook":play,"playbook_score":score,"final_state":state,"live_allowed":False,"review_allowed":state in ["A_PLUS_REVIEW_CANDIDATE","REVIEW_CANDIDATE"],"entry_grade":sig.get("entry_grade"),"tp_bias":sig.get("tp_bias"),"confidence":sig.get("confidence"),"simulated_confidence":sig.get("simulated_confidence"),"candidate_class":sig.get("candidate_class"),"candidate_recommendation":sig.get("candidate_recommendation"),"setup_family":info["family"],"is_weak_setup":info["is_weak"],"is_strong_setup":info["is_strong"],"htf":htf,"reasons":reasons,"blocks":blocks,"time":sig.get("time"),"source_table":sig.get("source_table")}

def v8000_playbooks_payload(limit=220):
    f,fe=load_f(limit); g,ge=load_g(limit); hb=heartbeats(); signals=f.get("clean_signals") or []
    evaluated=[]
    for sig in signals[:limit]:
        m=norm(sig.get("market")); tf=tf_status(hb.get(m,{})); evaluated.append(eval_signal(sig,tf,g))
    evaluated.sort(key=lambda x:(x.get("review_allowed"),x.get("playbook_score") or 0), reverse=True)
    pa=[x for x in evaluated if x["playbook"]=="PLAYBOOK_A_HTF_OB_REACTION"]
    pb=[x for x in evaluated if x["playbook"]=="PLAYBOOK_B_SESSION_MOMENTUM"]
    rev=[x for x in evaluated if x["review_allowed"]]
    weak=[x for x in evaluated if x["final_state"]=="NO_TRADE_WEAK_MODEL"]
    watch=[x for x in evaluated if x["final_state"]=="WATCH_ONLY"]
    return {"ok":True,"version":VERSION,"module":"V8000B-DUAL-PLAYBOOK-ENGINE","mode":MODE,"generated_utc":now(),"summary":{"signals_evaluated":len(evaluated),"playbook_a_ob_reaction":len(pa),"playbook_b_session_momentum":len(pb),"review_candidates":len(rev),"weak_model_blocks":len(weak),"watch_only":len(watch),"live_candidates":0,"live_rule_changes":False},"dependency_errors":{"v7246f":fe,"v7246g":ge},"playbook_a":pa[:80],"playbook_b":pb[:80],"review_candidates":rev[:80],"weak_model_blocks":weak[:80],"watch_only":watch[:80],"all_evaluated":evaluated[:limit],"note":"Observe only."}

def v8000_portfolio_payload(limit=220):
    f,fe=load_f(limit); g,ge=load_g(limit); hb=heartbeats(); signals=f.get("clean_signals") or []
    by={}
    for s in signals:
        m=norm(s.get("market"));
        if m: by.setdefault(m,[]).append(s)
    markets=sorted(set(list(by.keys())+list(hb.keys()))); rows=[]
    for m in markets:
        tf=tf_status(hb.get(m,{})); sig=(by.get(m) or [None])[0]
        if sig:
            ev=eval_signal(sig,tf,g); state=ev["final_state"]; idea=ev["playbook"]; reasons=(ev["reasons"]+ev["blocks"])[:8]
            row={"market":m,"tradeable_state":state,"allowed_idea":idea,"review_allowed":ev["review_allowed"],"live_allowed":False,"direction":ev["direction"],"setup_name":ev["setup_name"],"entry_grade":ev["entry_grade"],"tp_bias":ev["tp_bias"],"confidence":ev["confidence"],"simulated_confidence":ev["simulated_confidence"],"tf":tf,"htf":ev["htf"],"reasons":reasons}
        else:
            row={"market":m,"tradeable_state":"NO_SIGNAL","allowed_idea":"WAIT","review_allowed":False,"live_allowed":False,"direction":"","setup_name":"","entry_grade":"","tp_bias":"","confidence":"","simulated_confidence":"","tf":tf,"htf":{"htf_status":"NO_RECENT_SIGNAL"},"reasons":["Keine aktuellen sauberen Signale."]}
        row["data_warning"]="4H/1D heartbeats fehlen; nur Observe/Review." if not (tf.get("has_d1") or tf.get("has_4h")) else ""
        rows.append(row)
    summ={"markets":len(rows),"review_candidates":sum(1 for r in rows if r.get("review_allowed")),"live_candidates":0,"no_trade_or_watch":sum(1 for r in rows if not r.get("review_allowed")),"htf_data_missing":sum(1 for r in rows if r.get("data_warning")),"source_clean_signals":(f.get("summary") or {}).get("clean_signals"),"source_guard_grade":(g.get("recommendation") or {}).get("grade"),"safe_to_apply":(g.get("recommendation") or {}).get("safe_to_apply",False),"live_rule_changes":False}
    return {"ok":True,"version":VERSION,"module":"V8000A-PORTFOLIO-MANAGER","mode":MODE,"generated_utc":now(),"summary":summ,"guard":g.get("recommendation"),"dependency_errors":{"v7246f":fe,"v7246g":ge},"markets":rows,"note":"Observe only."}

def v8000_a_plus_payload(limit=220):
    p=v8000_playbooks_payload(limit); g,ge=load_g(limit); guard=g.get("recommendation") or {}
    candidates=sorted(p.get("review_candidates") or [], key=lambda x:(x.get("playbook_score") or 0, fnum(x.get("simulated_confidence"),0) or 0), reverse=True)
    blocked=[]
    if not guard.get("safe_to_apply"): blocked.append("V7246G safe_to_apply=False")
    if (guard.get("recommended_bonus") or 0)==0: blocked.append("V7246G recommended_bonus=0")
    if norm(guard.get("grade")) in ["NO_GO_LIVE","WAIT","UNKNOWN"]: blocked.append("V7246G grade="+str(guard.get("grade")))
    out=[]
    for x in candidates[:50]:
        y=dict(x); y["a_plus_state"]="A_PLUS_REVIEW_ONLY"; y["live_blocked_by"]=blocked + y.get("blocks",[]); y["next_required_data"]=["4H/1D HTF-Zonen/Heartbeats liefern", "Downgrade-Anteil senken", "A+ Review Forwardtest separat messen", "20-30 geschlossene A+ Fälle vor Live-Bonus"] ; out.append(y)
    return {"ok":True,"version":VERSION,"module":"V8000C-A-PLUS-SELECTOR","mode":MODE,"generated_utc":now(),"summary":{"a_plus_review_candidates":len(out),"a_plus_live_candidates":0,"live_allowed":False,"guard_grade":guard.get("grade"),"guard_action":guard.get("action"),"guard_scope":guard.get("recommended_scope"),"live_rule_changes":False},"guard":guard,"a_plus_review_candidates":out,"live_block_reasons":blocked,"note":"Review only. No live changes."}

def v8000_master_payload(limit=220):
    port=v8000_portfolio_payload(limit); play=v8000_playbooks_payload(limit); sel=v8000_a_plus_payload(limit)
    return {"ok":True,"version":VERSION,"mode":MODE,"generated_utc":now(),"summary":{"portfolio_markets":port["summary"].get("markets"),"portfolio_review_candidates":port["summary"].get("review_candidates"),"playbook_a":play["summary"].get("playbook_a_ob_reaction"),"playbook_b":play["summary"].get("playbook_b_session_momentum"),"a_plus_review_candidates":sel["summary"].get("a_plus_review_candidates"),"a_plus_live_candidates":0,"guard_grade":sel["guard"].get("grade"),"safe_to_apply":sel["guard"].get("safe_to_apply"),"live_rule_changes":False},"portfolio":port,"playbooks":play,"selector":sel,"note":"V8000 Dual Playbook: HTF OB Reaction + Session Momentum, observe only."}

def cls(x):
    t=norm(x)
    if any(k in t for k in ["A_PLUS","REVIEW_CANDIDATE","ALIGNED","PLAYBOOK"]): return "good"
    if any(k in t for k in ["WATCH","MIXED","MISSING","CAUTIOUS"]): return "warn"
    if any(k in t for k in ["NO_TRADE","WEAK","AGAINST","NO_GO","DOWNGRADE"]): return "bad"
    return "muted"

def base_html(title,sub,body):
    return f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title><style>body{{margin:0;background:#07111e;color:#eef6ff;font-family:Arial,sans-serif}}.wrap{{max-width:1540px;margin:0 auto;padding:14px}}h1{{font-size:30px;margin:8px 0}}h2{{font-size:21px;margin:4px 0 12px}}.sub{{color:#9caec4;margin-bottom:14px;line-height:1.35}}.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}}.card,.section{{background:#101d2e;border:1px solid #273a52;border-radius:16px;padding:14px;margin:10px 0;overflow:auto}}.value{{font-size:26px;font-weight:900;margin-top:5px}}.good{{color:#22c55e;font-weight:900}}.ok{{color:#38bdf8;font-weight:900}}.warn{{color:#facc15;font-weight:900}}.bad{{color:#f87171;font-weight:900}}.muted{{color:#9ca3af;font-weight:900}}table{{width:100%;border-collapse:collapse;font-size:12px}}th,td{{border-bottom:1px solid #273a52;padding:7px;text-align:left;white-space:nowrap;vertical-align:top}}th{{color:#a5d8ff;position:sticky;top:0;background:#101d2e}}a{{color:#93c5fd;text-decoration:none}}.note{{background:#0f243b;border:1px solid #1e40af;border-radius:14px;padding:12px;margin:10px 0;color:#c7d2fe}}.small{{font-size:12px;color:#9ca3af;line-height:1.35;white-space:normal;min-width:250px}}@media(max-width:900px){{.grid{{grid-template-columns:1fr 1fr}}h1{{font-size:25px}}table{{font-size:11px}}}}</style></head><body><div class="wrap"><h1>{esc(title)}</h1><div class="sub">{sub}</div>{body}<div class="section"><a href="/master">← Master</a> · <a href="/v8000/master">V8000 Master</a> · <a href="/v8000/portfolio">Portfolio</a> · <a href="/v8000/playbooks">Playbooks</a> · <a href="/v8000/a-plus">A+ Selector</a> · <a href="/v7246g-entry-guard">V7246G Guard</a></div></div></body></html>'''

def market_row(r):
    tf=r.get("tf") or {}; h=r.get("htf") or {}; reasons="<br>".join(esc(x) for x in (r.get("reasons") or [])[:6])
    return f'''<tr><td><b>{esc(r.get("market"))}</b></td><td class="{cls(r.get("tradeable_state"))}">{esc(r.get("tradeable_state"))}</td><td>{esc(r.get("allowed_idea"))}</td><td>{esc(r.get("direction"))}</td><td><b>{esc(r.get("setup_name"))}</b></td><td>{esc(r.get("entry_grade"))}</td><td>{esc(r.get("tp_bias"))}</td><td>{esc(r.get("confidence"))}</td><td>{esc(r.get("simulated_confidence"))}</td><td>{esc(tf.get("d1_bias"))}</td><td>{esc(tf.get("h4_bias"))}</td><td>{esc(tf.get("h1_bias"))}</td><td>{esc(tf.get("m15_bias"))}</td><td>{esc(h.get("htf_status"))}</td><td class="small">{reasons}</td><td class="small">{esc(r.get("data_warning"))}</td></tr>'''

def v8000_portfolio_html():
    d=v8000_portfolio_payload(); s=d.get("summary") or {}; rows="".join(market_row(x) for x in d.get("markets",[])) or '<tr><td colspan="16">Keine Daten.</td></tr>'
    body=f'''<div class="grid"><div class="card"><div>Markets</div><div class="value good">{esc(s.get("markets"))}</div></div><div class="card"><div>Review</div><div class="value ok">{esc(s.get("review_candidates"))}</div></div><div class="card"><div>Live</div><div class="value bad">{esc(s.get("live_candidates"))}</div></div><div class="card"><div>HTF Missing</div><div class="value warn">{esc(s.get("htf_data_missing"))}</div></div></div><div class="note"><b>Observe only.</b> 4H/1D fehlen? Dann kein Live, nur Review/Watch.</div><div class="section"><h2>Portfolio / Market Tradeability</h2><table><thead><tr><th>Market</th><th>State</th><th>Idea</th><th>Dir</th><th>Setup</th><th>Grade</th><th>TP</th><th>Conf</th><th>Sim</th><th>D1</th><th>4H</th><th>1H</th><th>15M</th><th>HTF</th><th>Reason</th><th>Data</th></tr></thead><tbody>{rows}</tbody></table></div>'''
    return base_html("🧭 V8000A Portfolio Manager","Market Tradeability · HTF Bias · Playbook-Idee · keine Live-Regeländerung",body)

def play_row(x):
    reasons="<br>".join(esc(r) for r in (x.get("reasons") or [])[:5]); blocks="<br>".join(esc(r) for r in (x.get("blocks") or [])[:5])
    return f'''<tr><td>{esc(x.get("time"))}</td><td><b>{esc(x.get("market"))}</b></td><td>{esc(x.get("direction"))}</td><td><b>{esc(x.get("setup_name"))}</b></td><td>{esc(x.get("playbook"))}</td><td class="{cls(x.get("final_state"))}">{esc(x.get("final_state"))}</td><td>{esc(x.get("playbook_score"))}</td><td>{esc(x.get("entry_grade"))}</td><td>{esc(x.get("tp_bias"))}</td><td>{esc(x.get("confidence"))}</td><td>{esc(x.get("simulated_confidence"))}</td><td>{esc((x.get("htf") or {}).get("htf_status"))}</td><td class="small">{reasons}</td><td class="small">{blocks}</td></tr>'''

def play_table(title,rows):
    body="".join(play_row(x) for x in rows) or '<tr><td colspan="14">Keine Daten.</td></tr>'
    return f'<div class="section"><h2>{esc(title)}</h2><table><thead><tr><th>Zeit</th><th>Market</th><th>Dir</th><th>Setup</th><th>Playbook</th><th>State</th><th>Score</th><th>Grade</th><th>TP</th><th>Conf</th><th>Sim</th><th>HTF</th><th>Reasons</th><th>Blocks</th></tr></thead><tbody>{body}</tbody></table></div>'

def v8000_playbooks_html():
    d=v8000_playbooks_payload(); s=d.get("summary") or {}
    body=f'''<div class="grid"><div class="card"><div>Signals</div><div class="value good">{esc(s.get("signals_evaluated"))}</div></div><div class="card"><div>OB Reaction</div><div class="value ok">{esc(s.get("playbook_a_ob_reaction"))}</div></div><div class="card"><div>Momentum</div><div class="value ok">{esc(s.get("playbook_b_session_momentum"))}</div></div><div class="card"><div>Weak Blocks</div><div class="value bad">{esc(s.get("weak_model_blocks"))}</div></div></div><div class="note"><b>Dual Playbook:</b> A = HTF OB/Supply-Demand Reaction. B = Session Momentum/ORB Continuation.</div>{play_table("1. Review Candidates",d.get("review_candidates",[]))}{play_table("2. Playbook A · HTF OB Reaction",d.get("playbook_a",[]))}{play_table("3. Playbook B · Session Momentum",d.get("playbook_b",[]))}{play_table("4. Weak Model Blocks",d.get("weak_model_blocks",[]))}{play_table("5. Watch Only",d.get("watch_only",[]))}'''
    return base_html("📘 V8000B Dual Playbook Engine","HTF OB-Reaction + Session Momentum · keine Live-Regeländerung",body)

def aplus_row(x):
    blocks="<br>".join(esc(r) for r in (x.get("live_blocked_by") or [])[:8]); req="<br>".join(esc(r) for r in (x.get("next_required_data") or [])[:8])
    return f'''<tr><td>{esc(x.get("time"))}</td><td><b>{esc(x.get("market"))}</b></td><td>{esc(x.get("direction"))}</td><td><b>{esc(x.get("setup_name"))}</b></td><td class="good">{esc(x.get("a_plus_state"))}</td><td>{esc(x.get("playbook"))}</td><td>{esc(x.get("playbook_score"))}</td><td>{esc(x.get("entry_grade"))}</td><td>{esc(x.get("tp_bias"))}</td><td>{esc(x.get("confidence"))}</td><td>{esc(x.get("simulated_confidence"))}</td><td class="small">{blocks}</td><td class="small">{req}</td></tr>'''

def v8000_a_plus_html():
    d=v8000_a_plus_payload(); s=d.get("summary") or {}; rows="".join(aplus_row(x) for x in d.get("a_plus_review_candidates",[])) or '<tr><td colspan="13">Keine A+ Review Kandidaten.</td></tr>'
    body=f'''<div class="grid"><div class="card"><div>A+ Review</div><div class="value good">{esc(s.get("a_plus_review_candidates"))}</div></div><div class="card"><div>A+ Live</div><div class="value bad">{esc(s.get("a_plus_live_candidates"))}</div></div><div class="card"><div>Guard</div><div class="value warn">{esc(s.get("guard_grade"))}</div></div><div class="card"><div>Scope</div><div class="value muted">{esc(s.get("guard_scope"))}</div></div></div><div class="note"><b>Live bleibt gesperrt:</b> {esc('; '.join(d.get("live_block_reasons") or []))}</div><div class="section"><h2>A+ Review Kandidaten</h2><table><thead><tr><th>Zeit</th><th>Market</th><th>Dir</th><th>Setup</th><th>State</th><th>Playbook</th><th>Score</th><th>Grade</th><th>TP</th><th>Conf</th><th>Sim</th><th>Live Blocked By</th><th>Next Required Data</th></tr></thead><tbody>{rows}</tbody></table></div>'''
    return base_html("⭐ V8000C A+ Selector","Wenige A+ Review Kandidaten · Live bleibt aus",body)

def v8000_master_html():
    d=v8000_master_payload(); s=d.get("summary") or {}
    body=f'''<div class="grid"><div class="card"><div>Portfolio Markets</div><div class="value good">{esc(s.get("portfolio_markets"))}</div></div><div class="card"><div>Review Candidates</div><div class="value ok">{esc(s.get("portfolio_review_candidates"))}</div></div><div class="card"><div>A+ Review</div><div class="value good">{esc(s.get("a_plus_review_candidates"))}</div></div><div class="card"><div>A+ Live</div><div class="value bad">{esc(s.get("a_plus_live_candidates"))}</div></div></div><div class="grid"><div class="card"><div>Playbook A OB</div><div class="value ok">{esc(s.get("playbook_a"))}</div></div><div class="card"><div>Playbook B Momentum</div><div class="value ok">{esc(s.get("playbook_b"))}</div></div><div class="card"><div>Guard Grade</div><div class="value warn">{esc(s.get("guard_grade"))}</div></div><div class="card"><div>Safe To Apply</div><div class="value bad">{esc(s.get("safe_to_apply"))}</div></div></div><div class="note"><b>V8000:</b> Portfolio Manager entscheidet erst Markt/Regime/Playbook, danach zählt der Entry. A = HTF Orderblock/Supply-Demand-Reaktion. B = Session Momentum/ORB Continuation. Alles Observe only.</div><div class="section"><h2>Boards</h2><table><tbody><tr><td><a href="/v8000/portfolio">🧭 V8000A Portfolio Manager</a></td><td>Market Tradeability, HTF Bias, aktuelle Playbook-Idee.</td></tr><tr><td><a href="/v8000/playbooks">📘 V8000B Dual Playbook</a></td><td>OB Reaction und Session Momentum getrennt bewertet.</td></tr><tr><td><a href="/v8000/a-plus">⭐ V8000C A+ Selector</a></td><td>Nur A+ Review Kandidaten, keine Live-Freigabe.</td></tr></tbody></table></div>'''
    return base_html("🚀 V8000 A+ Dual Playbook Master","Großer Konzeptwechsel: weniger Trades, klare Playbooks, harte No-Trade-Regeln",body)

if __name__ == "__main__":
    print(json.dumps(v8000_master_payload(limit=80), indent=2))
