#!/usr/bin/env bash
set -euo pipefail

echo "===== V8000 DUAL PLAYBOOK PACK INSTALL ====="
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${PROJECT_DIR:-/opt/tradingbot_v6000}"
cd "$PROJECT_DIR" || { echo "ERROR: PROJECT_DIR not found: $PROJECT_DIR"; exit 1; }

mkdir -p backups app ops
TS="$(date -u +%Y%m%d_%H%M%S)"

echo "[1] Backup main.py"
cp app/main.py "backups/main_before_v8000_dual_playbook_${TS}.py"

echo "[2] Copy files"
cp "$SRC_DIR/app/v8000_dual_playbook_engine.py" app/v8000_dual_playbook_engine.py
cp "$SRC_DIR/ops/v8000_check.sh" ops/v8000_check.sh
chmod +x ops/v8000_check.sh

echo "[3] Patch routes + master card"
python3 - <<'PY'
from pathlib import Path
p = Path("app/main.py")
s = p.read_text(encoding="utf-8")

if "V8000 DUAL PLAYBOOK ROUTES" in s:
    print("V8000 routes already installed")
else:
    routes = r'''

# === V8000 DUAL PLAYBOOK ROUTES ===
try:
    from fastapi.responses import HTMLResponse, JSONResponse
    from app.v8000_dual_playbook_engine import (
        v8000_master_payload, v8000_master_html,
        v8000_portfolio_payload, v8000_portfolio_html,
        v8000_playbooks_payload, v8000_playbooks_html,
        v8000_a_plus_payload, v8000_a_plus_html,
    )

    @app.get("/v8000/master.json")
    def v8000_master_json(token: str = "", limit: int = 220):
        return JSONResponse(v8000_master_payload(limit=limit))

    @app.get("/v8000/master", response_class=HTMLResponse)
    def v8000_master_page(token: str = ""):
        return HTMLResponse(v8000_master_html())

    @app.get("/v8000.json")
    def v8000_short_json(token: str = "", limit: int = 220):
        return JSONResponse(v8000_master_payload(limit=limit))

    @app.get("/v8000", response_class=HTMLResponse)
    def v8000_short_page(token: str = ""):
        return HTMLResponse(v8000_master_html())

    @app.get("/v8000/portfolio.json")
    def v8000_portfolio_json(token: str = "", limit: int = 220):
        return JSONResponse(v8000_portfolio_payload(limit=limit))

    @app.get("/v8000/portfolio", response_class=HTMLResponse)
    def v8000_portfolio_page(token: str = ""):
        return HTMLResponse(v8000_portfolio_html())

    @app.get("/v8000/playbooks.json")
    def v8000_playbooks_json(token: str = "", limit: int = 220):
        return JSONResponse(v8000_playbooks_payload(limit=limit))

    @app.get("/v8000/playbooks", response_class=HTMLResponse)
    def v8000_playbooks_page(token: str = ""):
        return HTMLResponse(v8000_playbooks_html())

    @app.get("/v8000/a-plus.json")
    def v8000_a_plus_json(token: str = "", limit: int = 220):
        return JSONResponse(v8000_a_plus_payload(limit=limit))

    @app.get("/v8000/a-plus", response_class=HTMLResponse)
    def v8000_a_plus_page(token: str = ""):
        return HTMLResponse(v8000_a_plus_html())

    print("[V8000] Dual Playbook routes installed.")
except Exception as exc:
    print("[V8000] install failed:", exc)
# === END V8000 DUAL PLAYBOOK ROUTES ===
'''
    s += "\n\n" + routes
    print("PATCHED V8000 routes")

if "V8000 A+ Engine" in s:
    print("V8000 master card already installed")
else:
    card = r'''
<a class="card" href="/v8000/master?token=TOKEN_PLACEHOLDER">
  <div class="icon">🚀</div>
  <div>
    <h3>V8000 A+ Engine</h3>
    <p>Dual Playbook: HTF OB-Reaction + Session Momentum. Portfolio Manager vor Entry-Signalen.</p>
    <p id="v8000Status" style="font-weight:900;margin-top:6px;color:#22c55e;font-size:15px;line-height:1.2">V8000 lädt...</p>
  </div>
  <div class="arrow">›</div>
</a>

<script>
(async function(){
  async function updateV8000(){
    try{
      var el=document.getElementById("v8000Status");
      if(!el) return;
      var r=await fetch("/v8000/master.json?token=TOKEN_PLACEHOLDER&ts="+Date.now(),{cache:"no-store"});
      var d=await r.json();
      var s=d.summary||{};
      el.textContent="A+ Review " + (s.a_plus_review_candidates||0) + " · Live " + (s.a_plus_live_candidates||0) + " · Guard " + (s.guard_grade||"");
      el.style.color=(s.a_plus_live_candidates||0)>0 ? "#22c55e" : "#facc15";
    }catch(e){
      var el=document.getElementById("v8000Status");
      if(el){el.textContent="V8000 Fehler"; el.style.color="#ef4444";}
    }
  }
  updateV8000();
  setInterval(updateV8000,45000);
})();
</script>
'''
    target = '<h2>📂 V7000 Boards</h2>'
    if target in s:
        s = s.replace(target, card + "\n" + target, 1)
        print("PATCHED V8000 master card")
    else:
        print("WARN: V7000 Boards target not found, master card not inserted")

p.write_text(s, encoding="utf-8")
PY

echo "[4] Compile"
python3 -m py_compile app/v8000_dual_playbook_engine.py app/main.py

echo "[5] Selftest"
python3 app/v8000_dual_playbook_engine.py >/tmp/v8000_selftest.json
python3 - <<'PY'
import json
d=json.load(open('/tmp/v8000_selftest.json','r',encoding='utf-8'))
print('version:', d.get('version'))
print('ok:', d.get('ok'))
print('summary:', d.get('summary'))
PY

echo "[6] Rebuild"
docker compose up -d --build tradingbot || docker restart tradingbot
sleep 10

echo "[7] Check"
TOKEN="${TOKEN:-eHwFukO31kypn0KZenWjht2T815BlQeeZNygm9nUwTg}"
bash ops/v8000_check.sh "$TOKEN"

echo "===== V8000 INSTALL DONE ====="
