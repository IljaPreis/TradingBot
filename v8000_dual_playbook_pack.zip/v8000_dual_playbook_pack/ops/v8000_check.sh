#!/usr/bin/env bash
set -euo pipefail
TOKEN="${1:-${TOKEN:-eHwFukO31kypn0KZenWjht2T815BlQeeZNygm9nUwTg}}"

echo "===== V8000 CHECK ROUTES ====="
for URL in "/v8000/master" "/v8000/master.json" "/v8000/portfolio" "/v8000/portfolio.json" "/v8000/playbooks" "/v8000/playbooks.json" "/v8000/a-plus" "/v8000/a-plus.json" "/master"; do
  echo -n "$URL -> "
  curl -sS -m 45 -o "/tmp/check_${URL//\//_}.out" -w "http=%{http_code} time=%{time_total} size=%{size_download}\n" "http://127.0.0.1$URL?token=$TOKEN"
done

echo "===== V8000 SUMMARY ====="
curl -sS -m 45 "http://127.0.0.1/v8000/master.json?token=$TOKEN&limit=220" -o /tmp/v8000_master.json
python3 - <<'PY'
import json
d=json.load(open('/tmp/v8000_master.json','r',encoding='utf-8'))
print('version:', d.get('version'))
print('ok:', d.get('ok'))
print('mode:', d.get('mode'))
print('summary:', d.get('summary'))
sel=d.get('selector') or {}
print('')
print('A+ summary:', sel.get('summary'))
print('live_block_reasons:', sel.get('live_block_reasons'))
print('')
print('Top A+ Review:')
for x in (sel.get('a_plus_review_candidates') or [])[:12]:
    print(x.get('market'), x.get('direction'), x.get('setup_name'), 'playbook', x.get('playbook'), 'score', x.get('playbook_score'), 'grade', x.get('entry_grade'), 'tp', x.get('tp_bias'), 'state', x.get('a_plus_state'))
PY

echo "===== MASTER MARKER ====="
grep -oE "V8000 A\+ Engine|v8000Status|V8000 lädt" /tmp/check__master.out | sort | uniq -c || true
