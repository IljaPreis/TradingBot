# V8005 Dashboard Performance

V8005 beschleunigt ausschließlich langsame Legacy-GET-Dashboards.

## Methode

- direkter Aufruf der tatsächlich registrierten FastAPI-Route ohne die lange globale Legacy-Middleware-Kette
- In-Memory-TTL-Cache
- stale-while-revalidate
- höchstens zwei gleichzeitige Refreshes
- bei einem langsamen Erstaufbau erscheint sofort eine automatische Warmup-Seite
- V8005-Karte in `/master` und `/master-ai-review`

## Unverändert

- Pine- und TradingView-Webhooks
- V8000/V8001/V8002/V8004 Signal- und Routinglogik
- Telegram-Live-/Shadow-Zweige
- Live-Gates und News-Gates
- Broker-Ausführung
- Produktionsdatenbanken

## Sicherheit

```text
observe_only true
enforce false
live_rule_changes false
auto_blocking false
auto_filtering false
db_writes false
broker_auto_execution false
```

## Neue Routen

```text
/v8005/performance
/v8005/performance.json
/v8005/performance-config.json
/v8005/warmup
```

## Installation

```bash
bash install.sh
```

## Prüfung

```bash
bash verify.sh
```

## Rollback

```bash
bash rollback.sh
```

Oder mit einem bestimmten Backup:

```bash
bash rollback.sh /opt/tradingbot_v6000/backups/v8005_before_YYYYMMDD_HHMMSS
```
