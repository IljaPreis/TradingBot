from __future__ import annotations

import asyncio
import hashlib
import html
import json
import time
from dataclasses import dataclass
from contextlib import AsyncExitStack
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Tuple

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.routing import Match

VERSION = "V8005-LEGACY-DASHBOARD-PERFORMANCE"

DEFAULT_TARGET_TTLS: Dict[str, int] = {
    "/event-risk": 30,
    "/pre-news-manager": 30,
    "/signal-quality": 30,
    "/entry-scoring": 30,
    "/ranking-snapshot": 30,
    "/control-center": 30,
    "/decision-suite": 45,
    "/position-overview": 30,
    "/open-trade-risk": 30,
    "/exit-readiness": 30,
    "/trade-management-recommendations": 45,
    "/performance-learning": 120,
    "/setup-performance": 120,
    "/market-session-performance": 120,
    "/news-performance": 120,
    "/shadow-edge": 120,
    "/best-times": 120,
    "/weak-setups": 120,
    "/daily-performance-report": 300,
}

MASTER_PATHS = {"/master", "/master-ai-review"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _root() -> Path:
    here = Path(__file__).resolve()
    for candidate in (Path("/app"), Path("/opt/tradingbot_v6000"), here.parent.parent, Path.cwd()):
        if (candidate / "data").exists():
            return candidate
    return here.parent.parent


def _config_path() -> Path:
    return _root() / "data" / "v8005_performance_config.json"


def default_config() -> Dict[str, Any]:
    return {
        "version": VERSION,
        "enabled": True,
        "mode": "display_route_bypass_and_memory_cache",
        "observe_only": True,
        "enforce": False,
        "live_rule_changes": False,
        "auto_blocking": False,
        "auto_filtering": False,
        "db_writes": False,
        "broker_auto_execution": False,
        "bypass_global_middlewares_for_display_routes": True,
        "stale_while_revalidate": True,
        "initial_wait_seconds": 8.0,
        "max_concurrent_refreshes": 2,
        "target_ttls_seconds": dict(DEFAULT_TARGET_TTLS),
        "note": "V8005 optimizes legacy GET dashboards only. It does not change signals, gates, Telegram routing, orders, or databases.",
    }


def load_config() -> Dict[str, Any]:
    cfg = default_config()
    path = _config_path()
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict):
            cfg.update(loaded)
            merged = dict(DEFAULT_TARGET_TTLS)
            custom = loaded.get("target_ttls_seconds")
            if isinstance(custom, dict):
                for path_key, ttl in custom.items():
                    try:
                        merged[str(path_key)] = max(1, int(ttl))
                    except (TypeError, ValueError):
                        continue
            cfg["target_ttls_seconds"] = merged
    except FileNotFoundError:
        pass
    except Exception as exc:
        cfg["config_load_error"] = f"{type(exc).__name__}: {exc}"
    return cfg


@dataclass(frozen=True)
class CachedResponse:
    status: int
    headers: Tuple[Tuple[bytes, bytes], ...]
    body: bytes
    created_monotonic: float
    created_utc: str
    render_seconds: float
    source_route: str

    def age_seconds(self) -> float:
        return max(0.0, time.monotonic() - self.created_monotonic)


class V8005PerformanceMiddleware:
    def __init__(self, app: Any, root_app: Any, config: Mapping[str, Any]):
        self.app = app
        self.root_app = root_app
        self.config = dict(config)
        self.enabled = bool(self.config.get("enabled", True))
        raw_ttls = self.config.get("target_ttls_seconds", DEFAULT_TARGET_TTLS)
        self.target_ttls = {str(k): max(1, int(v)) for k, v in dict(raw_ttls).items()}
        self.initial_wait = max(0.1, float(self.config.get("initial_wait_seconds", 8.0)))
        self.cache: Dict[str, CachedResponse] = {}
        self.inflight: Dict[str, asyncio.Task[CachedResponse]] = {}
        self.last_errors: Dict[str, Dict[str, Any]] = {}
        self.hits: Dict[str, int] = {}
        self.misses: Dict[str, int] = {}
        self.refreshes: Dict[str, int] = {}
        self.semaphore = asyncio.Semaphore(max(1, int(self.config.get("max_concurrent_refreshes", 2))))
        root_app.state.v8005_performance_middleware = self

    @staticmethod
    def _query_hash(scope: Mapping[str, Any]) -> str:
        query = bytes(scope.get("query_string", b""))
        return hashlib.sha256(query).hexdigest()[:16] if query else "noquery"

    def _cache_key(self, scope: Mapping[str, Any]) -> str:
        return f"{scope.get('path', '')}|{self._query_hash(scope)}"

    def _find_route(self, scope: Mapping[str, Any]):
        for route in getattr(self.root_app.router, "routes", []):
            try:
                match, child_scope = route.matches(dict(scope))
            except Exception:
                continue
            if match is Match.FULL:
                methods = getattr(route, "methods", None)
                if methods and "GET" not in methods and "HEAD" not in methods:
                    continue
                return route, child_scope
        return None, None

    @staticmethod
    def _clean_headers(headers: Iterable[Tuple[bytes, bytes]], body_len: int, marker: str) -> List[Tuple[bytes, bytes]]:
        cleaned: List[Tuple[bytes, bytes]] = []
        for name, value in headers:
            lower = name.lower()
            if lower in {b"content-length", b"x-v8005-cache"}:
                continue
            cleaned.append((name, value))
        cleaned.append((b"content-length", str(body_len).encode("ascii")))
        cleaned.append((b"x-v8005-cache", marker.encode("ascii", errors="ignore")))
        return cleaned

    async def _send_cached(self, send: Any, cached: CachedResponse, marker: str) -> None:
        headers = self._clean_headers(cached.headers, len(cached.body), marker)
        await send({"type": "http.response.start", "status": cached.status, "headers": headers})
        await send({"type": "http.response.body", "body": cached.body, "more_body": False})

    async def _capture_asgi(self, asgi_app: Any, scope: MutableMapping[str, Any]) -> Tuple[int, Tuple[Tuple[bytes, bytes], ...], bytes]:
        messages: List[Dict[str, Any]] = []
        receive_done = False

        async def receive() -> Dict[str, Any]:
            nonlocal receive_done
            if not receive_done:
                receive_done = True
                return {"type": "http.request", "body": b"", "more_body": False}
            await asyncio.sleep(0)
            return {"type": "http.disconnect"}

        async def capture_send(message: Dict[str, Any]) -> None:
            messages.append(message)

        async with AsyncExitStack() as middleware_stack:
            scope["fastapi_middleware_astack"] = middleware_stack
            await asgi_app(scope, receive, capture_send)

        status = 500
        headers: Tuple[Tuple[bytes, bytes], ...] = tuple()
        body_parts: List[bytes] = []
        for message in messages:
            if message.get("type") == "http.response.start":
                status = int(message.get("status", 500))
                headers = tuple((bytes(k), bytes(v)) for k, v in message.get("headers", []))
            elif message.get("type") == "http.response.body":
                body_parts.append(bytes(message.get("body", b"")))
        return status, headers, b"".join(body_parts)

    async def _render_route(self, key: str, scope: Mapping[str, Any]) -> CachedResponse:
        async with self.semaphore:
            started = time.perf_counter()
            route, child_scope = self._find_route(scope)
            if route is None:
                raise RuntimeError(f"No GET route found for {scope.get('path')}")
            route_scope: Dict[str, Any] = dict(scope)
            if isinstance(child_scope, dict):
                route_scope.update(child_scope)
            route_scope["app"] = self.root_app
            status, headers, body = await self._capture_asgi(route.app, route_scope)
            elapsed = time.perf_counter() - started
            source_name = str(getattr(route, "name", None) or getattr(getattr(route, "endpoint", None), "__name__", "unknown"))
            cached = CachedResponse(
                status=status,
                headers=headers,
                body=body,
                created_monotonic=time.monotonic(),
                created_utc=_utc_now(),
                render_seconds=round(elapsed, 6),
                source_route=source_name,
            )
            if status == 200:
                self.cache[key] = cached
                self.refreshes[str(scope.get("path", ""))] = self.refreshes.get(str(scope.get("path", "")), 0) + 1
                self.last_errors.pop(key, None)
            return cached

    def _on_task_done(self, key: str, path: str, task: asyncio.Task[CachedResponse]) -> None:
        self.inflight.pop(key, None)
        try:
            result = task.result()
            if result.status != 200:
                self.last_errors[key] = {
                    "path": path,
                    "utc": _utc_now(),
                    "error": f"HTTP {result.status}",
                }
        except asyncio.CancelledError:
            self.last_errors[key] = {"path": path, "utc": _utc_now(), "error": "refresh cancelled"}
        except Exception as exc:
            self.last_errors[key] = {
                "path": path,
                "utc": _utc_now(),
                "error": f"{type(exc).__name__}: {exc}",
            }

    def _start_refresh(self, key: str, scope: Mapping[str, Any]) -> asyncio.Task[CachedResponse]:
        existing = self.inflight.get(key)
        if existing and not existing.done():
            return existing
        path = str(scope.get("path", ""))
        task = asyncio.create_task(self._render_route(key, dict(scope)))
        self.inflight[key] = task
        task.add_done_callback(lambda completed: self._on_task_done(key, path, completed))
        return task

    async def _send_warming(self, send: Any, path: str, stale: Optional[CachedResponse] = None) -> None:
        if stale is not None:
            await self._send_cached(send, stale, "stale-refreshing")
            return
        escaped = html.escape(path)
        body = f"""<!doctype html><html><head><meta charset=\"utf-8\"><meta http-equiv=\"refresh\" content=\"5\"><title>V8005 cache warming</title><style>body{{font-family:Arial;background:#07111f;color:#e5eefc;padding:24px}}.card{{max-width:760px;background:#102039;border:1px solid #31527d;border-radius:14px;padding:20px}}a{{color:#7dc4ff}}</style></head><body><div class=\"card\"><h1>V8005 lädt diese Legacy-Seite</h1><p><code>{escaped}</code> wird im Hintergrund direkt und ohne die alte Middleware-Kette berechnet.</p><p>Die Seite aktualisiert sich automatisch in 5 Sekunden.</p><p><a href=\"/v8005/performance\">V8005 Performance-Status</a></p></div></body></html>""".encode("utf-8")
        headers = [
            (b"content-type", b"text/html; charset=utf-8"),
            (b"content-length", str(len(body)).encode("ascii")),
            (b"cache-control", b"no-store"),
            (b"x-v8005-cache", b"warming"),
        ]
        await send({"type": "http.response.start", "status": 200, "headers": headers})
        await send({"type": "http.response.body", "body": body, "more_body": False})

    async def _handle_target(self, scope: MutableMapping[str, Any], send: Any) -> None:
        path = str(scope.get("path", ""))
        key = self._cache_key(scope)
        ttl = self.target_ttls[path]
        cached = self.cache.get(key)
        if cached and cached.age_seconds() <= ttl:
            self.hits[path] = self.hits.get(path, 0) + 1
            await self._send_cached(send, cached, "hit")
            return

        self.misses[path] = self.misses.get(path, 0) + 1
        existing = self.inflight.get(key)
        if existing is not None and not existing.done():
            await self._send_warming(send, path, stale=cached)
            return
        task = self._start_refresh(key, scope)

        if cached is not None:
            await self._send_warming(send, path, stale=cached)
            return

        try:
            result = await asyncio.wait_for(asyncio.shield(task), timeout=self.initial_wait)
        except asyncio.TimeoutError:
            await self._send_warming(send, path)
            return
        except Exception as exc:
            self.last_errors[key] = {"path": path, "utc": _utc_now(), "error": f"{type(exc).__name__}: {exc}"}
            await self._send_warming(send, path)
            return

        if result.status == 200:
            await self._send_cached(send, result, "miss-rendered")
        else:
            await self._send_cached(send, result, "uncached-non200")

    @staticmethod
    def _inject_master_card(body: bytes) -> bytes:
        try:
            page = body.decode("utf-8")
        except UnicodeDecodeError:
            return body
        if "V8005 Dashboard Performance" in page:
            return body
        card = """
<section id="v8005-performance-card" style="margin:18px 0;padding:16px;border:1px solid #31527d;border-radius:14px;background:#102039;color:#e5eefc">
  <h2 style="margin:0 0 8px">V8005 Dashboard Performance</h2>
  <p style="margin:0 0 10px">Schneller Direktzugriff und Memory-Cache für langsame Legacy-Dashboards. Nur Anzeigeoptimierung.</p>
  <p style="margin:0"><a style="color:#7dc4ff" href="/v8005/performance">Performance-Status</a> · <a style="color:#7dc4ff" href="/v8005/performance.json">JSON</a></p>
  <small>observe_only=true · enforce=false · live_rule_changes=false · db_writes=false</small>
</section>
"""
        lower = page.lower()
        index = lower.rfind("</body>")
        if index >= 0:
            page = page[:index] + card + page[index:]
        else:
            page += card
        return page.encode("utf-8")

    async def _handle_master(self, scope: MutableMapping[str, Any], receive: Any, send: Any) -> None:
        messages: List[Dict[str, Any]] = []

        async def capture_send(message: Dict[str, Any]) -> None:
            messages.append(message)

        await self.app(scope, receive, capture_send)
        status = 500
        headers: Tuple[Tuple[bytes, bytes], ...] = tuple()
        body_parts: List[bytes] = []
        for message in messages:
            if message.get("type") == "http.response.start":
                status = int(message.get("status", 500))
                headers = tuple((bytes(k), bytes(v)) for k, v in message.get("headers", []))
            elif message.get("type") == "http.response.body":
                body_parts.append(bytes(message.get("body", b"")))
        body = b"".join(body_parts)
        content_type = b"".join(value.lower() for name, value in headers if name.lower() == b"content-type")
        if status == 200 and b"text/html" in content_type:
            body = self._inject_master_card(body)
        headers_out = self._clean_headers(headers, len(body), "master-injected")
        await send({"type": "http.response.start", "status": status, "headers": headers_out})
        await send({"type": "http.response.body", "body": body, "more_body": False})

    async def __call__(self, scope: MutableMapping[str, Any], receive: Any, send: Any) -> None:
        if not self.enabled or scope.get("type") != "http":
            await self.app(scope, receive, send)
            return
        method = str(scope.get("method", "GET")).upper()
        path = str(scope.get("path", ""))
        if method == "GET" and path in self.target_ttls:
            await self._handle_target(scope, send)
            return
        if method == "GET" and path in MASTER_PATHS:
            await self._handle_master(scope, receive, send)
            return
        await self.app(scope, receive, send)

    def status(self) -> Dict[str, Any]:
        entries: List[Dict[str, Any]] = []
        for key, cached in sorted(self.cache.items()):
            path = key.split("|", 1)[0]
            entries.append({
                "path": path,
                "key": key,
                "age_seconds": round(cached.age_seconds(), 3),
                "ttl_seconds": self.target_ttls.get(path),
                "render_seconds": cached.render_seconds,
                "created_utc": cached.created_utc,
                "status": cached.status,
                "bytes": len(cached.body),
                "source_route": cached.source_route,
            })
        return {
            "version": VERSION,
            "now_utc": _utc_now(),
            "safety": {
                "observe_only": True,
                "enforce": False,
                "live_rule_changes": False,
                "auto_blocking": False,
                "auto_filtering": False,
                "db_writes": False,
                "broker_auto_execution": False,
            },
            "mode": self.config.get("mode"),
            "enabled": self.enabled,
            "target_count": len(self.target_ttls),
            "cached_count": len(self.cache),
            "inflight_count": len([task for task in self.inflight.values() if not task.done()]),
            "entries": entries,
            "hits": dict(sorted(self.hits.items())),
            "misses": dict(sorted(self.misses.items())),
            "refreshes": dict(sorted(self.refreshes.items())),
            "last_errors": list(self.last_errors.values())[-20:],
            "config": self.config,
        }


def _status_html(payload: Mapping[str, Any]) -> str:
    rows = []
    for entry in payload.get("entries", []):
        rows.append(
            "<tr>"
            f"<td>{html.escape(str(entry.get('path')))}</td>"
            f"<td>{html.escape(str(entry.get('age_seconds')))}</td>"
            f"<td>{html.escape(str(entry.get('ttl_seconds')))}</td>"
            f"<td>{html.escape(str(entry.get('render_seconds')))}</td>"
            f"<td>{html.escape(str(entry.get('bytes')))}</td>"
            f"<td>{html.escape(str(entry.get('source_route')))}</td>"
            "</tr>"
        )
    rows_html = "".join(rows) or '<tr><td colspan="6">Noch kein Cache. Öffne eine Zielseite oder starte den Warmup.</td></tr>'
    target_links = "".join(
        f'<a class="chip" href="{html.escape(path)}">{html.escape(path)}</a>'
        for path in payload.get("config", {}).get("target_ttls_seconds", {})
    )
    safety = payload.get("safety", {})
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>V8005 Performance</title><style>body{{font-family:Arial;background:#07111f;color:#e5eefc;margin:0;padding:24px}}.wrap{{max-width:1200px;margin:auto}}.card{{background:#102039;border:1px solid #31527d;border-radius:14px;padding:18px;margin:14px 0}}a{{color:#7dc4ff}}.chip{{display:inline-block;margin:4px;padding:7px 10px;border:1px solid #31527d;border-radius:999px;text-decoration:none}}table{{width:100%;border-collapse:collapse}}th,td{{padding:8px;border-bottom:1px solid #274261;text-align:left}}code{{background:#07111f;padding:2px 5px;border-radius:5px}}</style></head><body><div class="wrap"><h1>V8005 Dashboard Performance</h1><div class="card"><b>DISPLAY OPTIMIZATION ONLY</b><p>Cache: {payload.get('cached_count')} · Inflight: {payload.get('inflight_count')} · Targets: {payload.get('target_count')}</p><p><code>observe_only={safety.get('observe_only')}</code> <code>enforce={safety.get('enforce')}</code> <code>live_rule_changes={safety.get('live_rule_changes')}</code> <code>db_writes={safety.get('db_writes')}</code></p><p><a href="/v8005/performance.json">JSON</a> · <a href="/v8005/warmup">Warmup starten</a> · <a href="/master">Master</a> · <a href="/master-ai-review">AI Review</a></p></div><div class="card"><h2>Zielseiten</h2>{target_links}</div><div class="card"><h2>Cache</h2><table><tr><th>Route</th><th>Alter</th><th>TTL</th><th>Renderzeit</th><th>Bytes</th><th>Quelle</th></tr>{rows_html}</table></div></div></body></html>"""


def install_v8005_legacy_performance(app: Any) -> None:
    if getattr(app.state, "v8005_legacy_performance_installed", False):
        return
    cfg = load_config()
    app.add_middleware(V8005PerformanceMiddleware, root_app=app, config=cfg)

    @app.get("/v8005/performance", response_class=HTMLResponse)
    async def v8005_performance_page() -> HTMLResponse:
        middleware = getattr(app.state, "v8005_performance_middleware", None)
        payload = middleware.status() if middleware else {
            "version": VERSION,
            "target_count": len(cfg.get("target_ttls_seconds", {})),
            "cached_count": 0,
            "inflight_count": 0,
            "entries": [],
            "config": cfg,
            "safety": {
                "observe_only": True,
                "enforce": False,
                "live_rule_changes": False,
                "db_writes": False,
            },
        }
        return HTMLResponse(_status_html(payload))

    @app.get("/v8005/performance.json")
    async def v8005_performance_json() -> JSONResponse:
        middleware = getattr(app.state, "v8005_performance_middleware", None)
        payload = middleware.status() if middleware else {
            "version": VERSION,
            "enabled": bool(cfg.get("enabled", True)),
            "target_count": len(cfg.get("target_ttls_seconds", {})),
            "cached_count": 0,
            "inflight_count": 0,
            "entries": [],
            "config": cfg,
            "safety": {
                "observe_only": True,
                "enforce": False,
                "live_rule_changes": False,
                "auto_blocking": False,
                "auto_filtering": False,
                "db_writes": False,
                "broker_auto_execution": False,
            },
        }
        return JSONResponse(payload)

    @app.get("/v8005/performance-config.json")
    async def v8005_performance_config_json() -> JSONResponse:
        return JSONResponse(cfg)

    @app.get("/v8005/warmup")
    async def v8005_warmup(request: Request) -> JSONResponse:
        middleware = getattr(app.state, "v8005_performance_middleware", None)
        if middleware is None:
            return JSONResponse({"ok": False, "error": "middleware_not_ready"}, status_code=503)
        started: List[str] = []
        for path in middleware.target_ttls:
            scope = dict(request.scope)
            scope.update({
                "path": path,
                "raw_path": path.encode("utf-8"),
                "method": "GET",
            })
            key = middleware._cache_key(scope)
            if key in middleware.cache:
                continue
            middleware._start_refresh(key, scope)
            started.append(path)
        return JSONResponse({
            "ok": True,
            "version": VERSION,
            "started": started,
            "started_count": len(started),
            "max_concurrent_refreshes": cfg.get("max_concurrent_refreshes", 2),
        })

    app.state.v8005_legacy_performance_installed = True
    print("[V8005] Legacy dashboard bypass/cache installed (display-only)")
