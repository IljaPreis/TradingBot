#!/usr/bin/env bash
set -euo pipefail

PROJECT="${PROJECT:-/opt/tradingbot_v6000}"
CONTAINER="${CONTAINER:-tradingbot}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8005_before_${STAMP}"
MAIN="$PROJECT/app/main.py"
MODULE="$PROJECT/app/v8005_legacy_performance.py"
CONFIG="$PROJECT/data/v8005_performance_config.json"
MARKER_BEGIN="# V8005_LEGACY_PERFORMANCE_INSTALL_BEGIN"
MARKER_END="# V8005_LEGACY_PERFORMANCE_INSTALL_END"

TARGETS=(
  /event-risk
  /pre-news-manager
  /signal-quality
  /entry-scoring
  /ranking-snapshot
  /control-center
  /decision-suite
  /position-overview
  /open-trade-risk
  /exit-readiness
  /trade-management-recommendations
  /performance-learning
  /setup-performance
  /market-session-performance
  /news-performance
  /shadow-edge
  /best-times
  /weak-setups
  /daily-performance-report
)

fail() {
  echo "FEHLER: $*" >&2
  exit 1
}

route_code() {
  curl --connect-timeout 3 --max-time 15 -sS -o /dev/null -w '%{http_code}' "http://127.0.0.1$1"
}

echo "=== V8005 DASHBOARD PERFORMANCE INSTALLATION ==="

test -d "$PROJECT" || fail "Projektordner fehlt: $PROJECT"
test -f "$MAIN" || fail "main.py fehlt"
test -f "$PACK_DIR/app/v8005_legacy_performance.py" || fail "V8005 Modul fehlt im Paket"
test -f "$PACK_DIR/data/v8005_performance_config.json" || fail "V8005 Config fehlt im Paket"

cd "$PROJECT"

echo "[1] Paket und Safety prüfen"
python3 -m py_compile "$PACK_DIR/app/v8005_legacy_performance.py"
python3 -m json.tool "$PACK_DIR/data/v8005_performance_config.json" >/dev/null
python3 - "$PACK_DIR/data/v8005_performance_config.json" <<'PY'
import json, sys
p = sys.argv[1]
cfg = json.load(open(p, encoding="utf-8"))
assert cfg["enabled"] is True
assert cfg["observe_only"] is True
assert cfg["enforce"] is False
assert cfg["live_rule_changes"] is False
assert cfg["auto_blocking"] is False
assert cfg["auto_filtering"] is False
assert cfg["db_writes"] is False
assert cfg["broker_auto_execution"] is False
assert cfg["bypass_global_middlewares_for_display_routes"] is True
assert len(cfg["target_ttls_seconds"]) == 19
print("Safety OK:", {k: cfg[k] for k in (
    "observe_only", "enforce", "live_rule_changes", "auto_blocking",
    "auto_filtering", "db_writes", "broker_auto_execution"
)})
PY

echo "[2] Backup erstellen"
mkdir -p "$BACKUP/app" "$BACKUP/data"
cp -a "$MAIN" "$BACKUP/app/main.py"
if [ -f "$MODULE" ]; then
  cp -a "$MODULE" "$BACKUP/app/v8005_legacy_performance.py"
  touch "$BACKUP/module_existed"
fi
if [ -f "$CONFIG" ]; then
  cp -a "$CONFIG" "$BACKUP/data/v8005_performance_config.json"
  touch "$BACKUP/config_existed"
fi
printf '%s\n' "$BACKUP" > /root/v8005_last_backup.txt

MAIN_MARKERS="$(grep -cF "$MARKER_BEGIN" "$MAIN" || true)"
if [ "$MAIN_MARKERS" -gt 1 ]; then
  fail "V8005 Marker ist mehrfach in main.py vorhanden"
fi

echo "[3] Modul und Config installieren"
install -m 0644 "$PACK_DIR/app/v8005_legacy_performance.py" "$MODULE"
install -m 0644 "$PACK_DIR/data/v8005_performance_config.json" "$CONFIG"

if [ "$MAIN_MARKERS" -eq 0 ]; then
  cat >> "$MAIN" <<'PY'

# V8005_LEGACY_PERFORMANCE_INSTALL_BEGIN
try:
    from app.v8005_legacy_performance import install_v8005_legacy_performance
    install_v8005_legacy_performance(app)
except Exception as _v8005_install_error:
    print(f"[V8005] install error: {_v8005_install_error}")
# V8005_LEGACY_PERFORMANCE_INSTALL_END
PY
  echo "V8005 Installblock an main.py angehängt."
else
  echo "V8005 Installblock bereits vorhanden; nicht doppelt eingefügt."
fi

[ "$(grep -cF "$MARKER_BEGIN" "$MAIN")" -eq 1 ] || fail "Begin-Marker nicht genau einmal vorhanden"
[ "$(grep -cF "$MARKER_END" "$MAIN")" -eq 1 ] || fail "End-Marker nicht genau einmal vorhanden"

echo "[4] Syntaxcheck"
python3 -m py_compile "$MAIN" "$MODULE"

echo "[5] Docker neu bauen"
docker compose up -d --build

echo "[6] Auf Health warten"
READY=0
for _ in $(seq 1 60); do
  if curl -fsS --max-time 3 http://127.0.0.1/health >/dev/null 2>&1; then
    READY=1
    break
  fi
  sleep 2
done
if [ "$READY" -ne 1 ]; then
  docker logs --tail 160 "$CONTAINER" || true
  fail "Server wurde nicht gesund"
fi

echo "[7] Container-Import und neue Routen"
docker exec "$CONTAINER" python -m py_compile \
  /app/app/main.py \
  /app/app/v8005_legacy_performance.py

for ROUTE in \
  /health \
  /master \
  /master-ai-review \
  /v8005/performance \
  /v8005/performance.json \
  /v8005/performance-config.json \
  /v8005/warmup \
  /v8000/master.json \
  /v8001/pine-audit.json \
  /v8002/news-policy-config.json \
  /v8003/master-map.json \
  /v8004/quality-router.json \
  /v8004/selftest.json
do
  CODE="$(route_code "$ROUTE")"
  echo "$ROUTE -> $CODE"
  [ "$CODE" = "200" ] || fail "Route $ROUTE liefert $CODE"
done

echo "[8] V8005 Safetycheck"
curl -fsS http://127.0.0.1/v8005/performance-config.json > /tmp/v8005_config_check.json
python3 - <<'PY'
import json
cfg = json.load(open('/tmp/v8005_config_check.json', encoding='utf-8'))
expected = {
    'observe_only': True,
    'enforce': False,
    'live_rule_changes': False,
    'auto_blocking': False,
    'auto_filtering': False,
    'db_writes': False,
    'broker_auto_execution': False,
}
for key, value in expected.items():
    assert cfg.get(key) is value, (key, cfg.get(key), value)
print('V8005 Safety:', expected)
PY

echo "[9] Master-Integration"
curl -fsS http://127.0.0.1/master | grep -q "V8005 Dashboard Performance" || fail "/master enthält V8005 nicht"
curl -fsS http://127.0.0.1/master-ai-review | grep -q "V8005 Dashboard Performance" || fail "/master-ai-review enthält V8005 nicht"
echo "/master enthält V8005"
echo "/master-ai-review enthält V8005"

echo "[10] Warmup starten"
curl -fsS http://127.0.0.1/v8005/warmup | python3 -m json.tool | head -80
sleep 2

echo "[11] Legacy-Routen: Antwort innerhalb 12 Sekunden"
FAILS=0
for ROUTE in "${TARGETS[@]}"; do
  HEADERS="$(mktemp)"
  RESULT="$(curl \
    --connect-timeout 3 \
    --max-time 12 \
    -sS \
    -D "$HEADERS" \
    -o /dev/null \
    -w 'HTTP=%{http_code} ZEIT=%{time_total}s' \
    "http://127.0.0.1${ROUTE}" 2>&1)" || true
  CACHE="$(awk 'BEGIN{IGNORECASE=1} /^x-v8005-cache:/ {gsub("\r", ""); print $2}' "$HEADERS" | tail -1)"
  rm -f "$HEADERS"
  echo "$ROUTE | $RESULT | CACHE=${CACHE:-none}"
  case "$RESULT" in
    *"HTTP=200"*) ;;
    *) FAILS=$((FAILS + 1)) ;;
  esac
done
[ "$FAILS" -eq 0 ] || fail "$FAILS Legacy-Routen lieferten nicht HTTP 200 innerhalb 12 Sekunden"

echo "[12] Status und Logs"
sleep 5
curl -fsS http://127.0.0.1/v8005/performance.json > /tmp/v8005_status.json
python3 - <<'PY'
import json
p = json.load(open('/tmp/v8005_status.json', encoding='utf-8'))
print('Version:', p.get('version'))
print('Targets:', p.get('target_count'))
print('Cached:', p.get('cached_count'))
print('Inflight:', p.get('inflight_count'))
print('Errors:', len(p.get('last_errors') or []))
print('Safety:', p.get('safety'))
for row in (p.get('entries') or [])[:10]:
    print(row.get('path'), 'render=', row.get('render_seconds'), 'age=', row.get('age_seconds'), 'source=', row.get('source_route'))
PY

docker ps --filter name="$CONTAINER"
ERRORS="$(docker logs --since 10m "$CONTAINER" 2>&1 | grep -Eic 'traceback|internal server error|HTTP/1.1" 500' || true)"
echo "Aktuelle Fehler-Muster: $ERRORS"
[ "$ERRORS" -eq 0 ] || fail "Traceback/HTTP-500 in den aktuellen Logs gefunden"

echo ""
echo "=== V8005 INSTALLATION FERTIG ==="
echo "Backup: $BACKUP"
echo "Display-Routen: Direkt-BYPASS + Memory-Cache"
echo "V8001/V8002/V8004 Logik: unverändert"
echo "observe_only: TRUE"
echo "enforce: FALSE"
echo "live_rule_changes: FALSE"
echo "db_writes: FALSE"
echo "broker_auto_execution: FALSE"
