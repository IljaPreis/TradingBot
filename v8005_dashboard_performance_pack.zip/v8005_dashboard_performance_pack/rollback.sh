#!/usr/bin/env bash
set -euo pipefail

PROJECT="${PROJECT:-/opt/tradingbot_v6000}"
CONTAINER="${CONTAINER:-tradingbot}"
BACKUP="${1:-$(cat /root/v8005_last_backup.txt 2>/dev/null || true)}"

[ -n "$BACKUP" ] || { echo "FEHLER: Kein Backup angegeben." >&2; exit 1; }
[ -d "$BACKUP" ] || { echo "FEHLER: Backup fehlt: $BACKUP" >&2; exit 1; }
[ -f "$BACKUP/app/main.py" ] || { echo "FEHLER: main.py fehlt im Backup." >&2; exit 1; }

cd "$PROJECT"
echo "=== V8005 ROLLBACK ==="
echo "Backup: $BACKUP"

cp -a "$BACKUP/app/main.py" app/main.py

if [ -f "$BACKUP/module_existed" ]; then
  cp -a "$BACKUP/app/v8005_legacy_performance.py" app/v8005_legacy_performance.py
else
  rm -f app/v8005_legacy_performance.py
fi

if [ -f "$BACKUP/config_existed" ]; then
  cp -a "$BACKUP/data/v8005_performance_config.json" data/v8005_performance_config.json
else
  rm -f data/v8005_performance_config.json
fi

python3 -m py_compile app/main.py
docker compose up -d --build

for _ in $(seq 1 60); do
  if curl -fsS --max-time 3 http://127.0.0.1/health >/dev/null 2>&1; then
    echo "Health: 200"
    echo "=== V8005 ROLLBACK FERTIG ==="
    exit 0
  fi
  sleep 2
done

docker logs --tail 160 "$CONTAINER" || true
echo "FEHLER: Server nach Rollback nicht gesund." >&2
exit 1
