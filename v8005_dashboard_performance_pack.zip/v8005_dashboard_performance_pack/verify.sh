#!/usr/bin/env bash
set -euo pipefail

BASE="${BASE:-http://127.0.0.1}"
TARGETS=(
  /event-risk /pre-news-manager /signal-quality /entry-scoring
  /ranking-snapshot /control-center /decision-suite
  /position-overview /open-trade-risk /exit-readiness
  /trade-management-recommendations /performance-learning
  /setup-performance /market-session-performance /news-performance
  /shadow-edge /best-times /weak-setups /daily-performance-report
)

echo "=== V8005 VERIFY ==="
for ROUTE in \
  /health /master /master-ai-review \
  /v8005/performance /v8005/performance.json \
  /v8005/performance-config.json /v8005/warmup \
  /v8000/master.json /v8001/pine-audit.json \
  /v8002/news-policy-config.json /v8003/master-map.json \
  /v8004/quality-router.json /v8004/selftest.json
do
  curl --connect-timeout 3 --max-time 15 -sS -o /dev/null \
    -w "$ROUTE -> %{http_code} %{time_total}s\n" "$BASE$ROUTE"
done

echo "=== LEGACY SPEED ==="
for ROUTE in "${TARGETS[@]}"; do
  H="$(mktemp)"
  R="$(curl --connect-timeout 3 --max-time 12 -sS -D "$H" -o /dev/null \
    -w 'HTTP=%{http_code} ZEIT=%{time_total}s' "$BASE$ROUTE" 2>&1 || true)"
  C="$(awk 'BEGIN{IGNORECASE=1} /^x-v8005-cache:/ {gsub("\r", ""); print $2}' "$H" | tail -1)"
  rm -f "$H"
  echo "$ROUTE | $R | CACHE=${C:-none}"
done

echo "=== STATUS ==="
curl -fsS "$BASE/v8005/performance.json" | python3 -m json.tool | head -180
