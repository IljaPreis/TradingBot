# V8006 Calendar + Execution Correction

This package fixes three confirmed issues from the read-only audit:

1. **Event times:** V8002 now uses `economic_calendar_events.event_time_utc` first.
   The former fallback interpreted UTC raw values as Europe/Berlin and shifted all
   76 checked events by 120 minutes.
2. **Impact:** the canonical calendar impact is authoritative. Broad title
   keywords no longer promote ordinary low/medium releases to high impact.
3. **Actuals:** FinancialJuice actual values are resolved read-only at runtime
   using event IDs first, then currency + event time + compatible title/metric.
   A percent change can no longer overwrite a level value such as `4.09M`.

Execution policy:

- V8002 remains `observe_only=true`, `enforce=false`.
- FinancialJuice Free is not used as a pre-news timing authority.
- Canonical scheduled high-impact windows remain 15 minutes before.
- After release: 15 minutes when Actual is confirmed; 30 minutes for Tier-1 or
  when Actual is still missing.
- V8004 changes only a would-be LIVE route to SHADOW during an active scheduled
  high-impact window.
- Medium and low events do not receive a new downgrade.
- Existing safety gates remain required.
- Broker auto execution remains false.

This package does make one limited live-routing change:
`scheduled high impact + otherwise LIVE -> SHADOW`.

No database rows are written by the calendar correction or audit routes.
