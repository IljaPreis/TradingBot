from __future__ import annotations

import html
import json
import re
import sqlite3
from difflib import SequenceMatcher
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
from zoneinfo import ZoneInfo

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8002.1-CALENDAR-TIME-ACTUAL-FIX"

TIER1_TERMS = (
    "interest rate", "rate decision", "fomc", "federal funds", "ecb rate",
    "boe rate", "boj rate", "rba rate", "rbnz rate", "boc rate", "snb rate",
    "nonfarm", "non-farm", "nfp", "employment situation", "cpi", "consumer price",
    "core pce", "pce price", "gdp", "gross domestic product", "unemployment rate",
    "average hourly earnings", "payrolls",
)
HIGH_TERMS = TIER1_TERMS + (
    "retail sales", "ism manufacturing", "ism services", "jobless claims",
    "employment change", "wage", "inflation", "pmi", "trade balance",
)
EXTREME_HEADLINE_TERMS = (
    "war", "attack", "missile", "invasion", "emergency", "default", "bank failure",
    "intervention", "capital controls", "rate cut", "rate hike", "unexpected decision",
)

MARKET_CURRENCIES: dict[str, set[str]] = {
    "US100": {"USD"}, "US500": {"USD"}, "US30": {"USD"},
    "GER40": {"EUR"}, "FRA40": {"EUR"}, "FTSE100": {"GBP"},
    "ASX200": {"AUD", "CNY"}, "JP225": {"JPY", "USD"},
    "XAUUSD": {"USD"}, "XAGUSD": {"USD"}, "USOIL": {"USD"}, "BRENT": {"USD", "GBP"},
    "BTCUSD": {"USD"}, "ETHUSD": {"USD"},
}


COUNTRY_TO_CURRENCY = {
    "US": "USD", "USA": "USD", "UNITED STATES": "USD",
    "EU": "EUR", "EA": "EUR", "EUROZONE": "EUR",
    "UK": "GBP", "GB": "GBP", "UNITED KINGDOM": "GBP",
    "JP": "JPY", "JAPAN": "JPY",
    "AU": "AUD", "AUSTRALIA": "AUD",
    "NZ": "NZD", "NEW ZEALAND": "NZD",
    "CA": "CAD", "CANADA": "CAD",
    "CH": "CHF", "SWITZERLAND": "CHF",
    "CN": "CNY", "CHINA": "CNY",
}

_MISSING_ACTUAL = {"", "none", "null", "-", "n/a", "na"}


def _root() -> Path:
    for p in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        if (p / "data").exists():
            return p
    return Path.cwd()


def _data(name: str) -> Path:
    return _root() / "data" / name


def _read_json(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    try:
        if path.exists():
            obj = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
            if isinstance(obj, dict):
                return {**default, **obj}
    except Exception:
        pass
    return dict(default)


def _cfg() -> dict[str, Any]:
    default = {
        "version": VERSION,
        "enabled": True,
        "observe_only": True,
        "enforce": False,
        "calendar_authority": "economic_calendar_events",
        "actual_and_headline_authority": "financialjuice",
        "secondary_calendar_mode": "display_and_healthcheck_only",
        "timezone": "Europe/Berlin",
        "high_pre_minutes": 15,
        "high_post_minutes_confirmed": 15,
        "high_post_minutes_unconfirmed": 30,
        "tier1_post_minutes": 30,
        "medium_pre_minutes": 10,
        "medium_post_minutes": 10,
        "low_events_block": False,
        "medium_events_hard_block": False,
        "financialjuice_headline_window_minutes": 15,
        "financialjuice_headlines_hard_block": False,
        "prefer_event_time_utc": True,
        "raw_calendar_timezone": "UTC",
        "canonical_impact_authoritative": True,
        "keyword_escalation_only_when_impact_missing": True,
        "financialjuice_actual_runtime_match": True,
        "financialjuice_actual_match_tolerance_minutes": 5,
        "financialjuice_actual_min_title_score": 0.72,
        "financialjuice_actual_reject_metric_mismatch": True,
    }
    return _read_json(_data("v8002_news_policy_config.json"), default)


def _connect() -> sqlite3.Connection:
    con = sqlite3.connect(str(_data("v7000_learning.sqlite3")))
    con.row_factory = sqlite3.Row
    return con


def _tables(con: sqlite3.Connection) -> set[str]:
    return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def _columns(con: sqlite3.Connection, table: str) -> list[str]:
    return [r[1] for r in con.execute(f'PRAGMA table_info("{table}")')]


def _pick_col(cols: Iterable[str], *names: str) -> str | None:
    low = {c.lower(): c for c in cols}
    for name in names:
        if name.lower() in low:
            return low[name.lower()]
    return None


def _as_text(value: Any) -> str:
    return str(value or "").strip()


def _parse_iso(value: Any) -> datetime | None:
    text = _as_text(value)
    if not text:
        return None
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _parse_event_dt(row: dict[str, Any], cfg: dict[str, Any]) -> datetime | None:
    # Canonical calendar timestamps are authoritative. The previous implementation
    # ignored event_time_utc and interpreted UTC raw values as Europe/Berlin,
    # shifting every event by two hours during summer time.
    direct_keys = (
        "event_time_utc",
        "event_time_berlin",
        "ts",
        "time_utc",
        "event_time",
        "datetime",
        "scheduled_at",
        "release_time",
    )
    for key in direct_keys:
        dt = _parse_iso(row.get(key))
        if dt:
            return dt

    date_raw = _as_text(row.get("date_raw") or row.get("date"))
    time_raw = _as_text(row.get("time_raw") or row.get("time"))
    if not date_raw or not time_raw or time_raw.lower() in {"all day", "tentative", "-"}:
        return None

    formats = (
        "%m-%d-%Y %I:%M%p", "%d-%m-%Y %I:%M%p", "%Y-%m-%d %I:%M%p",
        "%m/%d/%Y %I:%M%p", "%d/%m/%Y %I:%M%p", "%Y/%m/%d %I:%M%p",
        "%m-%d-%Y %H:%M", "%d-%m-%Y %H:%M", "%Y-%m-%d %H:%M",
        "%m/%d/%Y %H:%M", "%d/%m/%Y %H:%M", "%Y/%m/%d %H:%M",
    )
    joined = f"{date_raw} {time_raw}".strip()
    raw_tz_name = str(cfg.get("raw_calendar_timezone") or "UTC")
    try:
        raw_tz = timezone.utc if raw_tz_name.upper() == "UTC" else ZoneInfo(raw_tz_name)
    except Exception:
        raw_tz = timezone.utc

    for fmt in formats:
        try:
            naive = datetime.strptime(joined, fmt)
            return naive.replace(tzinfo=raw_tz).astimezone(timezone.utc)
        except Exception:
            continue
    return None


def _market_currencies(market: str) -> set[str]:
    m = _as_text(market).upper()
    if m in MARKET_CURRENCIES:
        return set(MARKET_CURRENCIES[m])
    if len(m) == 6 and m.isalpha():
        return {m[:3], m[3:]}
    out: set[str] = set()
    for code in ("USD", "EUR", "GBP", "JPY", "AUD", "NZD", "CAD", "CHF", "CNY"):
        if code in m:
            out.add(code)
    return out


def _impact(row: dict[str, Any]) -> str:
    # The canonical calendar impact is authoritative when present. Broad title
    # keywords previously promoted low/medium events such as final CPI, PMI,
    # trade balance and ordinary central-bank speakers to high impact.
    raw = " ".join(
        _as_text(row.get(k))
        for k in ("impact", "risk", "importance", "priority", "severity")
    ).strip().lower()
    tokens = {x for x in re.split(r"[^a-z0-9]+", raw) if x}

    if tokens & {"high", "red", "major"} or raw.strip() == "3":
        return "high"
    if tokens & {"medium", "orange", "moderate"} or raw.strip() == "2":
        return "medium"
    if tokens & {"low", "yellow", "minor"} or raw.strip() in {"0", "1"}:
        return "low"

    title = _as_text(row.get("title") or row.get("event") or row.get("name")).lower()
    if any(term in title for term in TIER1_TERMS):
        return "high"
    if any(term in title for term in HIGH_TERMS):
        return "high"
    return "low"


def _is_tier1(title: str) -> bool:
    low = title.lower()
    return any(term in low for term in TIER1_TERMS)


def _valid_actual(value: Any) -> bool:
    return _as_text(value).lower() not in _MISSING_ACTUAL


def _currency_code(value: Any) -> str:
    raw = _as_text(value).upper()
    return COUNTRY_TO_CURRENCY.get(raw, raw)


def _normalise_title(value: Any) -> str:
    text = _as_text(value).lower()
    replacements = {
        "initial jobless claims": "unemployment claims",
        "jobless claims": "unemployment claims",
        "continuing jobless claims": "continued jobless claims",
        "continued claims": "continued jobless claims",
        "consumer price index": "cpi",
        "gross domestic product": "gdp",
        "non-farm payrolls": "nonfarm payrolls",
        "non farm payrolls": "nonfarm payrolls",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"\b(us|u\.s\.|uk|eu|eurozone|german|french|italian|japanese|canadian|australian|new zealand|swiss|chinese)\b", " ", text)
    text = re.sub(r"\b(actual|forecast|previous|revised|final|preliminary|flash)\b", " ", text)
    text = re.sub(r"[^a-z0-9%]+", " ", text)
    return " ".join(text.split())


def _title_score(a: Any, b: Any) -> float:
    aa = _normalise_title(a)
    bb = _normalise_title(b)
    if not aa or not bb:
        return 0.0
    seq = SequenceMatcher(None, aa, bb).ratio()
    sa, sb = set(aa.split()), set(bb.split())
    jac = len(sa & sb) / max(1, len(sa | sb))
    return max(seq, jac)


def _unit_family(value: Any) -> str:
    text = _as_text(value).lower().replace(",", "")
    if not text:
        return "unknown"
    if "%" in text:
        return "percent"
    if re.search(r"[-+]?\d+(?:\.\d+)?\s*[kmbt]\b", text):
        return "scaled_count"
    if re.search(r"[-+]?\d+(?:\.\d+)?", text):
        return "number"
    return "unknown"


def _metric_compatible(calendar_row: dict[str, Any], fj_title: str, fj_actual: Any) -> bool:
    cal_title = _normalise_title(calendar_row.get("title"))
    other_title = _normalise_title(fj_title)
    if (" change" in f" {other_title}" or other_title.endswith(" change")) and "change" not in cal_title:
        return False
    if "rate" in other_title and "rate" not in cal_title and "unemployment" not in cal_title:
        return False

    expected_values = (calendar_row.get("forecast"), calendar_row.get("previous"))
    expected_families = {_unit_family(v) for v in expected_values if _valid_actual(v)}
    expected_families.discard("unknown")
    actual_family = _unit_family(fj_actual)
    if expected_families and actual_family != "unknown" and actual_family not in expected_families:
        return False
    return True


def _parse_fj_raw(row: dict[str, Any]) -> dict[str, Any]:
    raw = row.get("raw_json")
    if isinstance(raw, dict):
        return raw
    try:
        obj = json.loads(_as_text(raw))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _load_actual_sources(con: sqlite3.Connection) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    by_event_id: dict[str, dict[str, Any]] = {}
    candidates: list[dict[str, Any]] = []
    tables = _tables(con)

    if "v72436_macro_actual_updates" in tables:
        rows = con.execute(
            """
            SELECT * FROM v72436_macro_actual_updates
            ORDER BY id DESC LIMIT 500
            """
        ).fetchall()
        for item in rows:
            d = dict(item)
            event_id = _as_text(d.get("matched_event_id"))
            if event_id and _valid_actual(d.get("actual")) and event_id not in by_event_id:
                by_event_id[event_id] = {
                    "actual": d.get("actual"),
                    "forecast": d.get("forecast"),
                    "previous": d.get("previous"),
                    "source": "v72436_macro_actual_updates",
                    "match_quality": "event_id",
                }

    if "financialjuice_calendar_events" in tables:
        rows = con.execute(
            """
            SELECT * FROM financialjuice_calendar_events
            ORDER BY created_at DESC LIMIT 500
            """
        ).fetchall()
        for item in rows:
            d = dict(item)
            raw = _parse_fj_raw(d)
            actual = d.get("actual") or raw.get("Actual")
            if not _valid_actual(actual):
                continue
            event_id = _as_text(d.get("matched_calendar_event_id"))
            title = d.get("title") or raw.get("Title") or raw.get("FJTitle") or raw.get("TName")
            country = d.get("country") or raw.get("CountryCode")
            dt = _parse_iso(raw.get("RealDate") or d.get("date_published"))
            entry = {
                "actual": actual,
                "forecast": d.get("forecast") or raw.get("Forecast"),
                "previous": d.get("previous") or raw.get("Previous"),
                "source": "financialjuice_calendar_events",
                "title": title,
                "country": _currency_code(country),
                "event_time_utc": dt,
                "match_quality": "runtime",
            }
            if event_id and event_id not in by_event_id:
                by_event_id[event_id] = {**entry, "match_quality": "event_id"}
            candidates.append(entry)

    return by_event_id, candidates


def _resolve_actual(
    row: dict[str, Any],
    cfg: dict[str, Any],
    by_event_id: dict[str, dict[str, Any]],
    candidates: list[dict[str, Any]],
) -> dict[str, Any] | None:
    if _valid_actual(row.get("actual")):
        return {
            "actual": row.get("actual"),
            "forecast": row.get("forecast"),
            "previous": row.get("previous"),
            "source": "economic_calendar_events",
            "match_quality": "canonical",
        }

    event_id = _as_text(row.get("event_id") or row.get("id"))
    if event_id and event_id in by_event_id:
        return by_event_id[event_id]

    if not cfg.get("financialjuice_actual_runtime_match", True):
        return None

    event_dt = _parse_event_dt(row, cfg)
    currency = _currency_code(row.get("currency") or row.get("country"))
    title = _as_text(row.get("title") or row.get("event") or row.get("name"))
    tolerance = float(cfg.get("financialjuice_actual_match_tolerance_minutes", 5))
    min_score = float(cfg.get("financialjuice_actual_min_title_score", 0.72))

    best: tuple[float, dict[str, Any]] | None = None
    for candidate in candidates:
        if currency and candidate.get("country") and candidate.get("country") != currency:
            continue
        other_dt = candidate.get("event_time_utc")
        if event_dt and other_dt:
            diff = abs((event_dt - other_dt).total_seconds()) / 60.0
            if diff > tolerance:
                continue
        score = _title_score(title, candidate.get("title"))
        if score < min_score:
            continue
        if cfg.get("financialjuice_actual_reject_metric_mismatch", True) and not _metric_compatible(
            row, _as_text(candidate.get("title")), candidate.get("actual")
        ):
            continue
        if best is None or score > best[0]:
            best = (score, candidate)

    if best is None:
        return None
    return {**best[1], "match_quality": f"title_time:{best[0]:.3f}"}


def _actual_confirmed(row: dict[str, Any]) -> bool:
    return _valid_actual(row.get("_resolved_actual") or row.get("actual"))


def _calendar_rows(con: sqlite3.Connection, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    table = str(cfg.get("calendar_authority") or "economic_calendar_events")
    if table not in _tables(con):
        return []
    cols = _columns(con, table)
    order = _pick_col(cols, "event_time_utc", "ts", "event_time", "scheduled_at", "id") or cols[0]
    rows = [dict(r) for r in con.execute(
        f'SELECT * FROM "{table}" ORDER BY "{order}" DESC LIMIT 1000'
    ).fetchall()]

    by_event_id, candidates = _load_actual_sources(con)
    for row in rows:
        resolved = _resolve_actual(row, cfg, by_event_id, candidates)
        if resolved:
            row["_resolved_actual"] = resolved.get("actual")
            row["_resolved_forecast"] = resolved.get("forecast")
            row["_resolved_previous"] = resolved.get("previous")
            row["_actual_source"] = resolved.get("source")
            row["_actual_match_quality"] = resolved.get("match_quality")
    return rows


def _headline_rows(con: sqlite3.Connection, minutes: int) -> list[dict[str, Any]]:
    now = datetime.now(timezone.utc)
    results: list[dict[str, Any]] = []
    for table in ("financialjuice_messages", "financialjuice_news"):
        if table not in _tables(con):
            continue
        cols = _columns(con, table)
        time_col = _pick_col(cols, "created_at", "published_at", "timestamp", "ts", "received_at")
        text_col = _pick_col(cols, "text", "message", "headline", "title", "content")
        if not time_col or not text_col:
            continue
        try:
            rows = con.execute(
                f'SELECT "{time_col}" AS t, "{text_col}" AS text FROM "{table}" ORDER BY "{time_col}" DESC LIMIT 100'
            ).fetchall()
        except Exception:
            continue
        for row in rows:
            dt = _parse_iso(row["t"])
            if not dt or now - dt > timedelta(minutes=minutes):
                continue
            text = _as_text(row["text"])
            if text:
                results.append({"table": table, "time": dt.isoformat(), "text": text})
    return results


@dataclass
class WindowHit:
    title: str
    currency: str
    impact: str
    event_time_utc: str
    minutes_to_event: float
    pre_minutes: int
    post_minutes: int
    actual_confirmed: bool
    actual_value: str
    actual_source: str
    actual_match_quality: str
    hard_block: bool
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


def evaluate_news_window(market: str, now_utc: datetime | None = None) -> dict[str, Any]:
    cfg = _cfg()
    now = now_utc or datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    now = now.astimezone(timezone.utc)

    if not cfg.get("enabled", True):
        return {"version": VERSION, "enabled": False, "hard_block": False, "risk": "OFF", "events": []}

    currencies = _market_currencies(market)
    hits: list[WindowHit] = []
    headline_warnings: list[dict[str, Any]] = []
    try:
        con = _connect()
        for row in _calendar_rows(con, cfg):
            currency = _as_text(row.get("currency") or row.get("country")).upper()
            if currencies and currency and currency not in currencies:
                continue
            event_dt = _parse_event_dt(row, cfg)
            if not event_dt:
                continue
            title = _as_text(row.get("title") or row.get("event") or row.get("name") or "Unknown event")
            impact = _impact(row)
            confirmed = _actual_confirmed(row)
            tier1 = _is_tier1(title)
            if impact == "high":
                pre = int(cfg.get("high_pre_minutes", 15))
                post = int(cfg.get("tier1_post_minutes", 30) if tier1 else (cfg.get("high_post_minutes_confirmed", 15) if confirmed else cfg.get("high_post_minutes_unconfirmed", 30)))
                hard = True
            elif impact == "medium":
                pre = int(cfg.get("medium_pre_minutes", 10))
                post = int(cfg.get("medium_post_minutes", 10))
                hard = bool(cfg.get("medium_events_hard_block", False))
            else:
                pre = post = 0
                hard = bool(cfg.get("low_events_block", False))
            delta_min = (event_dt - now).total_seconds() / 60.0
            active = (-post <= delta_min <= pre)
            if not active:
                continue
            reason = "scheduled_high_window" if impact == "high" else "scheduled_medium_window" if impact == "medium" else "scheduled_low_window"
            if impact == "high" and delta_min < 0 and not confirmed:
                reason += "_actual_unconfirmed"
            hits.append(WindowHit(
                title=title,
                currency=currency,
                impact=impact,
                event_time_utc=event_dt.isoformat(),
                minutes_to_event=round(delta_min, 2),
                pre_minutes=pre,
                post_minutes=post,
                actual_confirmed=confirmed,
                actual_value=_as_text(row.get("_resolved_actual") or row.get("actual")),
                actual_source=_as_text(row.get("_actual_source") or ("economic_calendar_events" if confirmed else "")),
                actual_match_quality=_as_text(row.get("_actual_match_quality") or ("canonical" if confirmed else "")),
                hard_block=hard,
                reason=reason,
            ))

        for item in _headline_rows(con, int(cfg.get("financialjuice_headline_window_minutes", 15))):
            text_low = item["text"].lower()
            market_match = not currencies or any(c.lower() in text_low for c in currencies)
            extreme = any(term in text_low for term in EXTREME_HEADLINE_TERMS)
            if market_match or extreme:
                headline_warnings.append({**item, "extreme_keyword": extreme, "hard_block": bool(extreme and cfg.get("financialjuice_headlines_hard_block", False))})
    except Exception as exc:
        return {
            "version": VERSION, "enabled": True, "hard_block": False, "risk": "ERROR",
            "market": market, "currencies": sorted(currencies), "events": [], "headline_warnings": [], "error": str(exc),
            "observe_only": bool(cfg.get("observe_only", True)), "enforce": bool(cfg.get("enforce", False)),
        }
    finally:
        try:
            con.close()
        except Exception:
            pass

    raw_hard = any(h.hard_block for h in hits) or any(x.get("hard_block") for x in headline_warnings)
    enforce = bool(cfg.get("enforce", False)) and not bool(cfg.get("observe_only", True))
    risk = "HARD_BLOCK" if raw_hard else "REVIEW" if hits or headline_warnings else "LOW"
    return {
        "version": VERSION,
        "enabled": True,
        "market": market,
        "currencies": sorted(currencies),
        "generated_utc": now.isoformat(),
        "risk": risk,
        "would_hard_block": raw_hard,
        "hard_block": bool(raw_hard and enforce),
        "observe_only": bool(cfg.get("observe_only", True)),
        "enforce": enforce,
        "events": [h.as_dict() for h in sorted(hits, key=lambda x: abs(x.minutes_to_event))],
        "headline_warnings": headline_warnings[:20],
        "policy": {
            "high_pre_minutes": cfg.get("high_pre_minutes"),
            "high_post_minutes_confirmed": cfg.get("high_post_minutes_confirmed"),
            "high_post_minutes_unconfirmed": cfg.get("high_post_minutes_unconfirmed"),
            "tier1_post_minutes": cfg.get("tier1_post_minutes"),
            "calendar_authority": cfg.get("calendar_authority"),
            "actual_and_headline_authority": cfg.get("actual_and_headline_authority"),
            "secondary_calendar_mode": cfg.get("secondary_calendar_mode"),
            "prefer_event_time_utc": cfg.get("prefer_event_time_utc"),
            "raw_calendar_timezone": cfg.get("raw_calendar_timezone"),
            "canonical_impact_authoritative": cfg.get("canonical_impact_authoritative"),
            "financialjuice_actual_runtime_match": cfg.get("financialjuice_actual_runtime_match"),
        },
    }


def _token_ok(request: Request) -> bool:
    try:
        from app.v7200_event_risk import _token_ok as real_token_ok
        return bool(real_token_ok(request))
    except Exception:
        return bool(request.query_params.get("token"))


def _esc(x: Any) -> str:
    return html.escape(str(x))


def _html(report: dict[str, Any]) -> str:
    events = report.get("events") or []
    heads = report.get("headline_warnings") or []
    trs = "".join(
        f"<tr><td>{_esc(e.get('event_time_utc'))}</td><td>{_esc(e.get('currency'))}</td><td>{_esc(e.get('title'))}</td><td>{_esc(e.get('impact'))}</td><td>{_esc(e.get('minutes_to_event'))}</td><td>{_esc(e.get('pre_minutes'))}/{_esc(e.get('post_minutes'))}</td><td>{_esc(e.get('actual_confirmed'))}</td><td>{_esc(e.get('actual_value'))}</td><td>{_esc(e.get('actual_source'))}</td><td>{_esc(e.get('hard_block'))}</td></tr>"
        for e in events
    ) or "<tr><td colspan='10'>Kein aktives Eventfenster.</td></tr>"
    htrs = "".join(
        f"<tr><td>{_esc(h.get('time'))}</td><td>{_esc(h.get('table'))}</td><td style='white-space:normal'>{_esc(h.get('text'))}</td><td>{_esc(h.get('extreme_keyword'))}</td></tr>"
        for h in heads
    ) or "<tr><td colspan='4'>Keine aktuellen FJ-Headline-Warnungen.</td></tr>"
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>V8002 News Policy</title><style>body{{background:#07111e;color:#eef6ff;font-family:Arial;margin:0}}.w{{max-width:1450px;margin:auto;padding:14px}}.c{{background:#101d2e;border:1px solid #273a52;border-radius:15px;padding:14px;margin:10px 0;overflow:auto}}table{{width:100%;border-collapse:collapse;font-size:12px}}th,td{{padding:7px;border-bottom:1px solid #273a52;text-align:left;white-space:nowrap}}th{{color:#a5d8ff}}.ok{{color:#22c55e}}.warn{{color:#facc15}}.bad{{color:#f87171}}a{{color:#93c5fd}}</style></head><body><div class='w'>
<h1>V8002 News Window Policy</h1><div class='c'><b>Observe only:</b> {_esc(report.get('observe_only'))} · <b>Enforce:</b> {_esc(report.get('enforce'))} · <b>Risk:</b> {_esc(report.get('risk'))} · <b>Would block:</b> {_esc(report.get('would_hard_block'))}</div>
<div class='c'><h2>Aktive Kalenderfenster</h2><table><tr><th>Zeit UTC</th><th>CCY</th><th>Event</th><th>Impact</th><th>Minuten</th><th>Pre/Post</th><th>Actual bestätigt</th><th>Actual</th><th>Actual-Quelle</th><th>Hard</th></tr>{trs}</table></div>
<div class='c'><h2>FinancialJuice Headline-Warnungen</h2><table><tr><th>Zeit</th><th>Quelle</th><th>Headline</th><th>Extreme</th></tr>{htrs}</table></div>
<div class='c'><a href='/master'>Master</a> · <a href='/master-ai-review'>AI Review</a> · <a href='/v8001/pine-audit'>V8001 Pine Audit</a></div></div></body></html>"""


def install_v8002_news_window_policy(app) -> None:
    if getattr(app.state, "v8002_news_window_policy_installed", False):
        return

    @app.get("/v8002/news-policy", response_class=HTMLResponse)
    def v8002_news_policy_page(request: Request, market: str = "US100"):
        if not _token_ok(request):
            return HTMLResponse("unauthorized", status_code=401)
        return HTMLResponse(_html(evaluate_news_window(market)))

    @app.get("/v8002/news-policy.json")
    def v8002_news_policy_json(request: Request, market: str = "US100"):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(evaluate_news_window(market))

    @app.get("/v8002/news-policy-config.json")
    def v8002_news_policy_config_json(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(_cfg())

    app.state.v8002_news_window_policy_installed = True
    print("[V8002] News Window Policy installed (observe-only default)")
