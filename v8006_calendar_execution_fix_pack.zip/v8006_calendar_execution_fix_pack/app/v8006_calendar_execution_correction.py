from __future__ import annotations

import html
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

from app import v8002_news_window_policy as news
from app import v8004_quality_router as router

VERSION = "V8006-CALENDAR-EXECUTION-CORRECTION"


def _root() -> Path:
    for p in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        if (p / "data").exists():
            return p
    return Path.cwd()


def _db() -> Path:
    return _root() / "data" / "v7000_learning.sqlite3"


def _canonical_impact(value: Any) -> str:
    text = str(value or "").strip().lower()
    if "high" in text or text in {"3", "red", "major"}:
        return "high"
    if "medium" in text or text in {"2", "orange", "moderate"}:
        return "medium"
    return "low"


def audit_payload() -> dict[str, Any]:
    ncfg = news._cfg()
    rcfg = router.load_config()
    result: dict[str, Any] = {
        "ok": True,
        "version": VERSION,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "safety": {
            "v8001_observe_only": True,
            "v8002_observe_only": bool(ncfg.get("observe_only", True)),
            "v8002_enforce": bool(ncfg.get("enforce", False)),
            "v8004_quality_routing_enforced": bool(rcfg.get("enforce", True)),
            "broker_auto_execution": bool(rcfg.get("broker_auto_execution", False)),
            "db_writes": False,
        },
        "policy": {
            "calendar_authority": ncfg.get("calendar_authority"),
            "prefer_event_time_utc": ncfg.get("prefer_event_time_utc"),
            "raw_calendar_timezone": ncfg.get("raw_calendar_timezone"),
            "canonical_impact_authoritative": ncfg.get("canonical_impact_authoritative"),
            "financialjuice_actual_runtime_match": ncfg.get("financialjuice_actual_runtime_match"),
            "high_pre_minutes": ncfg.get("high_pre_minutes"),
            "high_post_minutes_confirmed": ncfg.get("high_post_minutes_confirmed"),
            "high_post_minutes_unconfirmed": ncfg.get("high_post_minutes_unconfirmed"),
            "tier1_post_minutes": ncfg.get("tier1_post_minutes"),
            "v8002_would_block_live_route": rcfg.get("v8002_would_block_live_route"),
            "server_confidence_live_mode": rcfg.get("server_confidence_live_mode"),
        },
        "summary": {},
        "examples": {
            "time_mismatches": [],
            "impact_mismatches": [],
            "runtime_actual_matches": [],
        },
    }

    con = None
    try:
        con = sqlite3.connect(f"file:{_db()}?mode=ro", uri=True, timeout=10)
        con.row_factory = sqlite3.Row
        quick = con.execute("PRAGMA quick_check").fetchone()[0]
        rows = news._calendar_rows(con, ncfg)
        time_mismatches = []
        impact_mismatches = []
        runtime_actual_matches = []

        for row in rows:
            stored = news._parse_iso(row.get("event_time_utc"))
            calculated = news._parse_event_dt(row, ncfg)
            if stored and calculated:
                diff = abs((stored - calculated).total_seconds()) / 60.0
                if diff > 1:
                    time_mismatches.append({
                        "country": row.get("country"),
                        "title": row.get("title"),
                        "difference_minutes": round(diff, 2),
                        "stored": stored.isoformat(),
                        "calculated": calculated.isoformat(),
                    })

            canonical = _canonical_impact(row.get("impact"))
            calculated_impact = news._impact(row)
            if canonical != calculated_impact:
                impact_mismatches.append({
                    "country": row.get("country"),
                    "title": row.get("title"),
                    "canonical": canonical,
                    "calculated": calculated_impact,
                })

            quality = str(row.get("_actual_match_quality") or "")
            if quality.startswith("title_time"):
                runtime_actual_matches.append({
                    "country": row.get("country"),
                    "title": row.get("title"),
                    "actual": row.get("_resolved_actual"),
                    "source": row.get("_actual_source"),
                    "match_quality": quality,
                })

        result["summary"] = {
            "db_quick_check": quick,
            "calendar_rows": len(rows),
            "event_time_mismatches": len(time_mismatches),
            "impact_mismatches": len(impact_mismatches),
            "runtime_actual_matches": len(runtime_actual_matches),
            "news_live_downgrade_enabled": (
                str(rcfg.get("v8002_would_block_live_route") or "").upper() == "SHADOW"
            ),
        }
        result["examples"] = {
            "time_mismatches": time_mismatches[:10],
            "impact_mismatches": impact_mismatches[:10],
            "runtime_actual_matches": runtime_actual_matches[:20],
        }
        result["ok"] = (
            quick == "ok"
            and not time_mismatches
            and not impact_mismatches
            and bool(ncfg.get("observe_only", True))
            and not bool(ncfg.get("enforce", False))
            and str(rcfg.get("v8002_would_block_live_route") or "").upper() == "SHADOW"
            and not bool(rcfg.get("broker_auto_execution", False))
        )
    except Exception as exc:
        result["ok"] = False
        result["error"] = str(exc)
    finally:
        try:
            if con is not None:
                con.close()
        except Exception:
            pass
    return result


def selftest_payload() -> dict[str, Any]:
    ncfg = news._cfg()
    event = {
        "country": "USD",
        "title": "Final Services PMI",
        "impact": "Low",
        "date_raw": "07-09-2026",
        "time_raw": "2:00pm",
        "event_time_utc": "2026-07-09T14:00:00+00:00",
        "forecast": "52.1",
        "previous": "52.0",
    }
    dt = news._parse_event_dt(event, ncfg)
    impact = news._impact(event)
    metric_ok = news._metric_compatible(
        {"title": "Existing Home Sales", "forecast": "4.2M", "previous": "4.17M"},
        "US Existing Home Sales Change",
        "-2.4%",
    )

    common = {
        "source": "tradingview_v8001_dual_playbook_zone_audit",
        "schema_version": "V8001_DUAL_PLAYBOOK_ZONE_AUDIT",
        "market": "US100",
        "direction": "LONG",
        "side": "BUY",
        "signal_timeframe": "15m",
        "timeframe": "15",
        "bar_confirmed": True,
        "is_fresh": True,
        "is_chase": False,
        "is_late_entry": False,
        "structure_event_id": 999,
        "session": "NEW_YORK",
        "bias_15m": "bullish",
        "tactical_layer_bias": "bullish",
        "htf_layer_bias": "bullish",
        "regime_bias": "bullish",
        "client_trade_id": "V8006_TEST_NEWS",
        "signal_event_id": "V8006_TEST_NEWS",
        "playbook": "PLAYBOOK_A_HTF_OB_REACTION",
        "setup_name": "BULL_OB_REACTION_CONFIRMED",
        "primary_trigger": "OB_REACTION_LONG",
        "confidence": 82,
        "zone_id": "US100_4H_DEMAND_V8006",
        "zone_touch_count": 1,
        "zone_first_touch": True,
        "reaction_confirmed": True,
        "confirmations_csv": "4H_DEMAND_TOUCH,SWEEP_LOW,MSS_BULL,VOLUME_SPIKE",
        "v8002_news_policy": {
            "observe_only": True,
            "enforce": False,
            "risk": "HARD_BLOCK",
            "would_hard_block": True,
            "hard_block": False,
        },
    }
    decision = router.evaluate_payload(
        common,
        {"allow_trade": True, "base_confidence": 82},
        router.load_config(),
        record=False,
    )

    tests = [
        {
            "name": "EVENT_TIME_USES_CANONICAL_UTC",
            "pass": bool(dt and dt.isoformat() == "2026-07-09T14:00:00+00:00"),
            "actual": dt.isoformat() if dt else None,
        },
        {
            "name": "CANONICAL_LOW_IMPACT_STAYS_LOW",
            "pass": impact == "low",
            "actual": impact,
        },
        {
            "name": "METRIC_MISMATCH_REJECTED",
            "pass": metric_ok is False,
            "actual": metric_ok,
        },
        {
            "name": "HIGH_IMPACT_LIVE_DOWNGRADES_TO_SHADOW",
            "pass": decision.get("route") == "SHADOW" and decision.get("final_allow") is False,
            "actual": decision.get("route"),
        },
        {
            "name": "BROKER_AUTO_EXECUTION_FALSE",
            "pass": decision.get("broker_auto_execution") is False,
            "actual": decision.get("broker_auto_execution"),
        },
    ]
    return {
        "ok": all(x["pass"] for x in tests),
        "version": VERSION,
        "tests": tests,
        "note": "Synthetic read-only tests. No signal or database row is written.",
    }


def _token_ok(request: Request) -> bool:
    try:
        from app.v7200_event_risk import _token_ok as real_token_ok
        return bool(real_token_ok(request))
    except Exception:
        return True


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _page(data: dict[str, Any]) -> str:
    s = data.get("summary", {})
    p = data.get("policy", {})
    safety = data.get("safety", {})
    return f"""<!doctype html><html><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>V8006 Calendar Execution Correction</title>
<style>body{{background:#07111e;color:#eef6ff;font-family:Arial;margin:0}}.w{{max-width:1250px;margin:auto;padding:16px}}.c{{background:#101d2e;border:1px solid #273a52;border-radius:15px;padding:14px;margin:10px 0}}.g{{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}}.v{{font-size:24px;font-weight:700}}.ok{{color:#22c55e}}.warn{{color:#facc15}}a{{color:#93c5fd}}</style></head>
<body><div class='w'><h1>V8006 Calendar + Execution Correction</h1>
<div class='c'><b>Status:</b> <span class='{"ok" if data.get("ok") else "warn"}'>{_esc(data.get("ok"))}</span> · V8002 bleibt observe-only · geplante High-Impact-Fenster stufen LIVE auf SHADOW zurück.</div>
<div class='g'>
<div class='c'><div>Calendar rows</div><div class='v'>{_esc(s.get("calendar_rows",0))}</div></div>
<div class='c'><div>Zeitfehler</div><div class='v'>{_esc(s.get("event_time_mismatches",0))}</div></div>
<div class='c'><div>Impact-Fehler</div><div class='v'>{_esc(s.get("impact_mismatches",0))}</div></div>
<div class='c'><div>FJ Runtime Actual Matches</div><div class='v'>{_esc(s.get("runtime_actual_matches",0))}</div></div>
</div>
<div class='c'><h2>Policy</h2>
<p>Eventzeit: {_esc(p.get("prefer_event_time_utc"))} / raw {_esc(p.get("raw_calendar_timezone"))}</p>
<p>Impact kanonisch: {_esc(p.get("canonical_impact_authoritative"))}</p>
<p>High Impact: {_esc(p.get("high_pre_minutes"))} Min vorher · {_esc(p.get("high_post_minutes_confirmed"))} Min nach bestätigtem Actual · {_esc(p.get("high_post_minutes_unconfirmed"))} Min bei fehlendem Actual · Tier 1 {_esc(p.get("tier1_post_minutes"))} Min.</p>
<p>News-Live-Downgrade: {_esc(p.get("v8002_would_block_live_route"))}</p>
</div>
<div class='c'><h2>Safety</h2><pre>{_esc(json.dumps(safety, ensure_ascii=False, indent=2))}</pre></div>
<div class='c'><a href='/master'>Master</a> · <a href='/master-ai-review'>AI Review</a> · <a href='/v8002/news-policy'>V8002</a> · <a href='/v8004/quality-router'>V8004</a></div>
</div></body></html>"""


def _master_card() -> str:
    data = audit_payload()
    s = data.get("summary", {})
    return f"""<section id='v8006-calendar-execution' style='background:#101d2e;border:1px solid #273a52;border-radius:15px;padding:14px;margin:12px 0'>
<h2>V8006 Calendar + Execution Correction</h2>
<p>Kanonische UTC-Eventzeiten · kanonischer Impact · FinancialJuice Actual-Matching · geplantes High-Impact-Fenster: LIVE → SHADOW.</p>
<p><b>Zeitfehler:</b> {_esc(s.get("event_time_mismatches",0))} · <b>Impact-Fehler:</b> {_esc(s.get("impact_mismatches",0))} · <b>Broker Auto Execution:</b> FALSE</p>
<a href='/v8006/calendar-execution-audit'>Audit öffnen</a>
</section>"""


class V8006MasterIntegrationMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http" or str(scope.get("method") or "GET").upper() != "GET":
            await self.app(scope, receive, send)
            return
        path = str(scope.get("path") or "")
        if path not in {"/master", "/master-ai-review"}:
            await self.app(scope, receive, send)
            return

        start = None
        chunks: list[bytes] = []

        async def capture(message):
            nonlocal start
            if message["type"] == "http.response.start":
                start = dict(message)
                return
            if message["type"] != "http.response.body":
                return
            chunks.append(message.get("body", b""))
            if message.get("more_body", False):
                return
            if start is None:
                return
            body = b"".join(chunks)
            headers = list(start.get("headers", []))
            ctype = next((v.decode("latin1") for k, v in headers if k.lower() == b"content-type"), "")
            if start.get("status") == 200 and "text/html" in ctype:
                text = body.decode("utf-8", errors="ignore")
                if "id='v8006-calendar-execution'" not in text:
                    card = _master_card()
                    if "</main>" in text:
                        text = text.replace("</main>", card + "</main>", 1)
                    elif "</body>" in text:
                        text = text.replace("</body>", card + "</body>", 1)
                    else:
                        text += card
                    body = text.encode("utf-8")
                    headers = [(k, v) for k, v in headers if k.lower() not in {b"content-length", b"content-encoding"}]
                    headers.append((b"content-length", str(len(body)).encode("ascii")))
                    start["headers"] = headers
            await send(start)
            await send({"type": "http.response.body", "body": body, "more_body": False})

        await self.app(scope, receive, capture)


def install_v8006_calendar_execution_correction(app) -> None:
    if getattr(app.state, "v8006_calendar_execution_installed", False):
        return

    @app.get("/v8006/calendar-execution-audit", response_class=HTMLResponse)
    def v8006_page(request: Request):
        if not _token_ok(request):
            return HTMLResponse("unauthorized", status_code=401)
        return HTMLResponse(_page(audit_payload()))

    @app.get("/v8006/calendar-execution-audit.json")
    def v8006_json(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(audit_payload())

    @app.get("/v8006/selftest.json")
    def v8006_selftest(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(selftest_payload())

    app.add_middleware(V8006MasterIntegrationMiddleware)
    app.state.v8006_calendar_execution_installed = True
    print("[V8006] Calendar and execution correction installed")
