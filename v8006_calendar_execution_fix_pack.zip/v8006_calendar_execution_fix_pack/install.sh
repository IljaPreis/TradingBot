#!/usr/bin/env bash
set -euo pipefail

PROJECT="${PROJECT:-/opt/tradingbot_v6000}"
CONTAINER="${CONTAINER:-tradingbot}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8006_before_${STAMP}"

MAIN="$PROJECT/app/main.py"
V8002_MODULE="$PROJECT/app/v8002_news_window_policy.py"
V8004_MODULE="$PROJECT/app/v8004_quality_router.py"
V8006_MODULE="$PROJECT/app/v8006_calendar_execution_correction.py"

V8002_CONFIG="$PROJECT/data/v8002_news_policy_config.json"
V8004_CONFIG="$PROJECT/data/v8004_quality_router_config.json"
V8006_CONFIG="$PROJECT/data/v8006_calendar_execution_config.json"

MARKER_BEGIN="# V8006_CALENDAR_EXECUTION_INSTALL_BEGIN"
MARKER_END="# V8006_CALENDAR_EXECUTION_INSTALL_END"

fail() {
  echo "FEHLER: $*" >&2
  exit 1
}

route_code() {
  curl --connect-timeout 3 --max-time 20 -sS -o /dev/null -w '%{http_code}' "http://127.0.0.1$1"
}

echo "=== V8006 CALENDAR + EXECUTION CORRECTION ==="

test -d "$PROJECT" || fail "Projektordner fehlt: $PROJECT"
test -f "$MAIN" || fail "main.py fehlt"
test -f "$V8002_MODULE" || fail "V8002 Modul fehlt"
test -f "$V8004_MODULE" || fail "V8004 Modul fehlt"
test -f "$V8002_CONFIG" || fail "V8002 Config fehlt"
test -f "$V8004_CONFIG" || fail "V8004 Config fehlt"

for FILE in \
  "$PACK_DIR/app/v8002_news_window_policy.py" \
  "$PACK_DIR/app/v8004_quality_router.py" \
  "$PACK_DIR/app/v8006_calendar_execution_correction.py" \
  "$PACK_DIR/data/v8002_news_policy_patch.json" \
  "$PACK_DIR/data/v8004_quality_router_patch.json" \
  "$PACK_DIR/data/v8006_calendar_execution_config.json"
do
  test -f "$FILE" || fail "Paketdatei fehlt: $FILE"
done

cd "$PROJECT"

echo "[1] Backup"
mkdir -p "$BACKUP/app" "$BACKUP/data"
cp -a "$MAIN" "$BACKUP/app/main.py"
cp -a "$V8002_MODULE" "$BACKUP/app/v8002_news_window_policy.py"
cp -a "$V8004_MODULE" "$BACKUP/app/v8004_quality_router.py"
cp -a "$V8002_CONFIG" "$BACKUP/data/v8002_news_policy_config.json"
cp -a "$V8004_CONFIG" "$BACKUP/data/v8004_quality_router_config.json"

if [ -f "$V8006_MODULE" ]; then
  cp -a "$V8006_MODULE" "$BACKUP/app/v8006_calendar_execution_correction.py"
  touch "$BACKUP/v8006_module_existed"
fi
if [ -f "$V8006_CONFIG" ]; then
  cp -a "$V8006_CONFIG" "$BACKUP/data/v8006_calendar_execution_config.json"
  touch "$BACKUP/v8006_config_existed"
fi

printf '%s\n' "$BACKUP" > /root/v8006_last_backup.txt
echo "Backup: $BACKUP"

echo "[2] Paket-Syntax"
python3 -m py_compile \
  "$PACK_DIR/app/v8002_news_window_policy.py" \
  "$PACK_DIR/app/v8004_quality_router.py" \
  "$PACK_DIR/app/v8006_calendar_execution_correction.py"

python3 -m json.tool "$PACK_DIR/data/v8002_news_policy_patch.json" >/dev/null
python3 -m json.tool "$PACK_DIR/data/v8004_quality_router_patch.json" >/dev/null
python3 -m json.tool "$PACK_DIR/data/v8006_calendar_execution_config.json" >/dev/null

echo "[3] Module installieren"
install -m 0644 "$PACK_DIR/app/v8002_news_window_policy.py" "$V8002_MODULE"
install -m 0644 "$PACK_DIR/app/v8004_quality_router.py" "$V8004_MODULE"
install -m 0644 "$PACK_DIR/app/v8006_calendar_execution_correction.py" "$V8006_MODULE"
install -m 0644 "$PACK_DIR/data/v8006_calendar_execution_config.json" "$V8006_CONFIG"

echo "[4] Configs sicher zusammenführen"
V8006_PACK_DIR="$PACK_DIR" python3 - <<'PY'
import json
import os
from pathlib import Path

pack = Path(os.environ["V8006_PACK_DIR"])
project = Path("/opt/tradingbot_v6000")

def merge(path: Path, patch_path: Path) -> dict:
    current = {}
    if path.exists():
        current = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(current, dict):
            current = {}
    patch = json.loads(patch_path.read_text(encoding="utf-8"))
    current.update(patch)
    path.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return current

v8002 = merge(
    project / "data/v8002_news_policy_config.json",
    pack / "data/v8002_news_policy_patch.json",
)
v8004 = merge(
    project / "data/v8004_quality_router_config.json",
    pack / "data/v8004_quality_router_patch.json",
)

# Hard safety locks agreed for the data sources and broker layer.
v8002.update({
    "observe_only": True,
    "enforce": False,
    "financialjuice_headlines_hard_block": False,
})
(project / "data/v8002_news_policy_config.json").write_text(
    json.dumps(v8002, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)

v8004.update({
    "enabled": True,
    "enforce": True,
    "apply_only_to_v8001": True,
    "require_existing_gate_allow_for_live": True,
    "broker_auto_execution": False,
    "v8001_observe_only": True,
    "v8002_observe_only": True,
    "v8002_would_block_live_route": "SHADOW",
    "v8002_would_block_applies_to_live_only": True,
    "server_confidence_live_mode": "existing_gate_only",
})
(project / "data/v8004_quality_router_config.json").write_text(
    json.dumps(v8004, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)

print("V8002:", {
    "version": v8002.get("version"),
    "observe_only": v8002.get("observe_only"),
    "enforce": v8002.get("enforce"),
    "prefer_event_time_utc": v8002.get("prefer_event_time_utc"),
    "raw_calendar_timezone": v8002.get("raw_calendar_timezone"),
    "canonical_impact_authoritative": v8002.get("canonical_impact_authoritative"),
    "financialjuice_actual_runtime_match": v8002.get("financialjuice_actual_runtime_match"),
})
print("V8004:", {
    "version": v8004.get("version"),
    "enforce": v8004.get("enforce"),
    "require_existing_gate_allow_for_live": v8004.get("require_existing_gate_allow_for_live"),
    "v8002_would_block_live_route": v8004.get("v8002_would_block_live_route"),
    "server_confidence_live_mode": v8004.get("server_confidence_live_mode"),
    "broker_auto_execution": v8004.get("broker_auto_execution"),
})
PY

echo "[5] V8006-Routen in main.py registrieren"
python3 - <<'PY'
from pathlib import Path

path = Path("/opt/tradingbot_v6000/app/main.py")
text = path.read_text(encoding="utf-8")
begin = "# V8006_CALENDAR_EXECUTION_INSTALL_BEGIN"
end = "# V8006_CALENDAR_EXECUTION_INSTALL_END"

if text.count(begin) > 1 or text.count(end) > 1:
    raise SystemExit("FEHLER: V8006-Marker mehrfach vorhanden")

if begin not in text:
    text += """

# V8006_CALENDAR_EXECUTION_INSTALL_BEGIN
try:
    from app.v8006_calendar_execution_correction import (
        install_v8006_calendar_execution_correction,
    )
    install_v8006_calendar_execution_correction(app)
except Exception as _v8006_install_error:
    print(f"[V8006] install error: {_v8006_install_error}")
# V8006_CALENDAR_EXECUTION_INSTALL_END
"""
    path.write_text(text, encoding="utf-8")
    print("V8006 Installblock angehängt.")
else:
    print("V8006 Installblock bereits vorhanden.")

assert path.read_text(encoding="utf-8").count(begin) == 1
assert path.read_text(encoding="utf-8").count(end) == 1
PY

echo "[6] Host-Syntaxcheck"
python3 -m py_compile \
  "$MAIN" \
  "$V8002_MODULE" \
  "$V8004_MODULE" \
  "$V8006_MODULE"

echo "[7] Docker neu bauen"
docker compose up -d --build

echo "[8] Auf Health warten"
READY=0
for _ in $(seq 1 60); do
  if curl -fsS --max-time 3 http://127.0.0.1/health >/dev/null 2>&1; then
    READY=1
    break
  fi
  sleep 2
done
if [ "$READY" -ne 1 ]; then
  docker logs --tail 180 "$CONTAINER" || true
  fail "Server wurde nicht gesund"
fi

echo "[9] Container-Syntax und Routen"
docker exec "$CONTAINER" python -m py_compile \
  /app/app/main.py \
  /app/app/v8002_news_window_policy.py \
  /app/app/v8004_quality_router.py \
  /app/app/v8006_calendar_execution_correction.py

for ROUTE in \
  /health \
  /master \
  /master-ai-review \
  /v8002/news-policy \
  /v8002/news-policy.json \
  /v8002/news-policy-config.json \
  /v8004/quality-router \
  /v8004/quality-router.json \
  /v8004/quality-router-config.json \
  /v8004/selftest.json \
  /v8006/calendar-execution-audit \
  /v8006/calendar-execution-audit.json \
  /v8006/selftest.json \
  /v8005/performance.json
do
  CODE="$(route_code "$ROUTE")"
  echo "$ROUTE -> $CODE"
  [ "$CODE" = "200" ] || fail "Route $ROUTE liefert $CODE"
done

echo "[10] V8006 Selftest"
curl -fsS http://127.0.0.1/v8006/selftest.json > /tmp/v8006_selftest.json
python3 - <<'PY'
import json
data = json.load(open("/tmp/v8006_selftest.json", encoding="utf-8"))
print("Selftest OK:", data.get("ok"))
for test in data.get("tests", []):
    print(test.get("name"), "PASS=" + str(test.get("pass")), "actual=" + str(test.get("actual")))
assert data.get("ok") is True
PY

echo "[11] V8004 Selftest inklusive News-Downgrade"
curl -fsS http://127.0.0.1/v8004/selftest.json > /tmp/v8004_selftest_v8006.json
python3 - <<'PY'
import json
data = json.load(open("/tmp/v8004_selftest_v8006.json", encoding="utf-8"))
tests = {x.get("name"): x for x in data.get("tests", [])}
print("V8004 Selftest OK:", data.get("ok"))
for name, item in tests.items():
    print(name, "expected=" + str(item.get("expected_route")), "actual=" + str(item.get("actual_route")), "PASS=" + str(item.get("pass")))
assert data.get("ok") is True
assert tests["NEWS_WINDOW_DOWNGRADE"]["actual_route"] == "SHADOW"
PY

echo "[12] Echte Kalenderdaten read-only prüfen"
curl -fsS http://127.0.0.1/v8006/calendar-execution-audit.json > /tmp/v8006_audit.json
python3 - <<'PY'
import json
data = json.load(open("/tmp/v8006_audit.json", encoding="utf-8"))
summary = data.get("summary", {})
print("Audit OK:", data.get("ok"))
print("DB:", summary.get("db_quick_check"))
print("Calendar rows:", summary.get("calendar_rows"))
print("Event time mismatches:", summary.get("event_time_mismatches"))
print("Impact mismatches:", summary.get("impact_mismatches"))
print("Runtime Actual matches:", summary.get("runtime_actual_matches"))
print("News live downgrade enabled:", summary.get("news_live_downgrade_enabled"))
assert data.get("ok") is True
assert summary.get("db_quick_check") == "ok"
assert summary.get("event_time_mismatches") == 0
assert summary.get("impact_mismatches") == 0
assert summary.get("news_live_downgrade_enabled") is True
PY

echo "[13] Safetycheck"
curl -fsS http://127.0.0.1/v8002/news-policy-config.json > /tmp/v8002_v8006.json
curl -fsS http://127.0.0.1/v8004/quality-router-config.json > /tmp/v8004_v8006.json
python3 - <<'PY'
import json
v2 = json.load(open("/tmp/v8002_v8006.json", encoding="utf-8"))
v4_payload = json.load(open("/tmp/v8004_v8006.json", encoding="utf-8"))
v4 = v4_payload.get("config", {})

assert v2.get("observe_only") is True
assert v2.get("enforce") is False
assert v2.get("financialjuice_headlines_hard_block") is False
assert v2.get("prefer_event_time_utc") is True
assert v2.get("raw_calendar_timezone") == "UTC"
assert v2.get("canonical_impact_authoritative") is True
assert v2.get("financialjuice_actual_runtime_match") is True

assert v4.get("enforce") is True
assert v4.get("apply_only_to_v8001") is True
assert v4.get("require_existing_gate_allow_for_live") is True
assert v4.get("v8002_would_block_live_route") == "SHADOW"
assert v4.get("broker_auto_execution") is False

print("V8002 observe_only:", v2.get("observe_only"))
print("V8002 enforce:", v2.get("enforce"))
print("V8004 enforce:", v4.get("enforce"))
print("High-impact LIVE route:", v4.get("v8002_would_block_live_route"))
print("Broker Auto Execution:", v4.get("broker_auto_execution"))
PY

echo "[14] Master-Integration"
curl -fsS http://127.0.0.1/master | grep -q "V8006 Calendar" || fail "/master enthält V8006 nicht"
curl -fsS http://127.0.0.1/master-ai-review | grep -q "V8006 Calendar" || fail "/master-ai-review enthält V8006 nicht"
echo "/master enthält V8006"
echo "/master-ai-review enthält V8006"

echo "[15] Status und Logs"
docker ps --filter name="$CONTAINER"
ERRORS="$(docker logs --since 10m "$CONTAINER" 2>&1 | grep -Eic 'traceback|exception|internal server error|HTTP/1.1" 500' || true)"
echo "Aktuelle Fehler-Muster: $ERRORS"
[ "$ERRORS" -eq 0 ] || docker logs --since 10m "$CONTAINER" 2>&1 | grep -Ei 'traceback|exception|internal server error|HTTP/1.1" 500' | tail -80

echo ""
echo "=== V8006 INSTALLATION FERTIG ==="
echo "Backup: $BACKUP"
echo "Eventzeit: event_time_utc kanonisch"
echo "Impact: Kalender-Impact kanonisch"
echo "FinancialJuice: Actual runtime read-only gematcht; keine Pre-News-Zeitquelle"
echo "Geplantes High Impact: bestehendes LIVE wird zu SHADOW"
echo "Medium/Low: keine neue Live-Herabstufung"
echo "V8002 observe_only: TRUE"
echo "V8002 enforce: FALSE"
echo "Broker Auto Execution: FALSE"
