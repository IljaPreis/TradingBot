#!/usr/bin/env bash
set -u
BASE="http://127.0.0.1"

echo "=== V8006 CHECK ==="
for ROUTE in \
  /health \
  /master \
  /master-ai-review \
  /v8002/news-policy-config.json \
  /v8004/quality-router-config.json \
  /v8004/selftest.json \
  /v8006/calendar-execution-audit.json \
  /v8006/selftest.json
do
  CODE="$(curl --connect-timeout 3 --max-time 20 -sS -o /dev/null -w '%{http_code}' "$BASE$ROUTE" 2>&1)"
  echo "$ROUTE -> $CODE"
done

curl -fsS "$BASE/v8006/calendar-execution-audit.json" | python3 -m json.tool
echo "=== V8006 CHECK FERTIG ==="
