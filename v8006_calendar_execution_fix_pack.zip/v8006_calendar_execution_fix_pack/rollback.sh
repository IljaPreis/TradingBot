#!/usr/bin/env bash
set -euo pipefail

PROJECT="${PROJECT:-/opt/tradingbot_v6000}"
CONTAINER="${CONTAINER:-tradingbot}"
BACKUP="${1:-$(cat /root/v8006_last_backup.txt 2>/dev/null || true)}"

[ -n "$BACKUP" ] || { echo "FEHLER: Kein V8006-Backup angegeben"; exit 1; }
[ -d "$BACKUP" ] || { echo "FEHLER: Backup fehlt: $BACKUP"; exit 1; }

echo "=== V8006 ROLLBACK ==="
echo "Backup: $BACKUP"

cp -a "$BACKUP/app/main.py" "$PROJECT/app/main.py"
cp -a "$BACKUP/app/v8002_news_window_policy.py" "$PROJECT/app/v8002_news_window_policy.py"
cp -a "$BACKUP/app/v8004_quality_router.py" "$PROJECT/app/v8004_quality_router.py"
cp -a "$BACKUP/data/v8002_news_policy_config.json" "$PROJECT/data/v8002_news_policy_config.json"
cp -a "$BACKUP/data/v8004_quality_router_config.json" "$PROJECT/data/v8004_quality_router_config.json"

if [ -f "$BACKUP/v8006_module_existed" ]; then
  cp -a "$BACKUP/app/v8006_calendar_execution_correction.py" "$PROJECT/app/v8006_calendar_execution_correction.py"
else
  rm -f "$PROJECT/app/v8006_calendar_execution_correction.py"
fi

if [ -f "$BACKUP/v8006_config_existed" ]; then
  cp -a "$BACKUP/data/v8006_calendar_execution_config.json" "$PROJECT/data/v8006_calendar_execution_config.json"
else
  rm -f "$PROJECT/data/v8006_calendar_execution_config.json"
fi

cd "$PROJECT"
python3 -m py_compile app/main.py app/v8002_news_window_policy.py app/v8004_quality_router.py
docker compose up -d --build

for _ in $(seq 1 60); do
  curl -fsS --max-time 3 http://127.0.0.1/health >/dev/null 2>&1 && break
  sleep 2
done

curl -fsS http://127.0.0.1/health >/dev/null
echo "=== V8006 ROLLBACK FERTIG ==="
