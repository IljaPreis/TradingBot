# V8007 V8001 Gate Bridge

## Befund
Neue V8001-Signale werden vom alten V6000/V7000-Scoring mit 10–15 Confidence bewertet, weil die neuen Pine-Felder nicht in die alten SMC/VP/Delta-Felder abgebildet werden. V7243.7 markiert diesen reinen Low-Confidence-Zustand als `hard_block=true`. Dadurch wurden selbst V8004 A/A+ Signale immer Shadow.

## Änderung
Nur für erkannte V8001-Payloads:

- A/A+ und vollständige V8001-Prüfung bestanden -> LIVE, wenn kein echter externer Hard Block besteht.
- Der alte Confidence-only-Veto (`LOW_CONFIDENCE`, `CONFIDENCE_TOO_LOW`, `WAIT_GRADE_SOFT_ONLY`) wird nicht mehr als Veto verwendet.
- Explizite News-, Event-, Positions-, Duplicate-, Stale-, Chase-, Exposure-, Cluster-, Cooldown-, Risk-Limit- und Konfliktblocker bleiben aktiv.
- Geplantes High Impact bleibt LIVE -> SHADOW.
- B/Review bleibt SHADOW.
- 5m, ungültig und Duplikat bleiben NO_TRADE.
- Nicht-V8001-Signale bleiben vollständig unverändert.
- Broker Auto Execution bleibt aus.

## Sicherheit

- V8002: `observe_only=true`, `enforce=false`
- V8004/V8007: nur Server-/Telegram-Routing
- Broker Auto Execution: `false`
- Keine Änderung am Broker
- Keine Datenbank-Schemaänderung
- Bestehende V8004-Logs/Shadow-Speicherung bleiben erhalten
