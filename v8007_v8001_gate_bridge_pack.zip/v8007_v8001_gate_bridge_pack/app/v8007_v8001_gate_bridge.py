from __future__ import annotations

import html
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

from app import v8004_quality_router as router

VERSION = "V8007-V8001-GATE-BRIDGE"


def _root() -> Path:
    for path in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        if (path / "data").exists():
            return path
    return Path.cwd()


def _db() -> Path:
    return _root() / "data" / "v7000_learning.sqlite3"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read_json(value: Any, default: Any) -> Any:
    if isinstance(value, (dict, list)):
        return value
    if not isinstance(value, str) or not value.strip():
        return default
    try:
        parsed = json.loads(value)
        return parsed
    except Exception:
        return default


def _token_ok(request: Request) -> bool:
    try:
        from app.v7200_event_risk import _token_ok as real_token_ok
        return bool(real_token_ok(request))
    except Exception:
        return True


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def audit_payload(limit: int = 100) -> dict[str, Any]:
    cfg = router.load_config()
    result: dict[str, Any] = {
        "ok": True,
        "version": VERSION,
        "generated_utc": _now(),
        "mode": "v8001_quality_primary_external_hard_blocks_preserved",
        "safety": {
            "applies_only_to_v8001": bool(cfg.get("apply_only_to_v8001", True)),
            "quality_routing_enforced": bool(cfg.get("enforce", True)),
            "legacy_confidence_only_veto_ignored": bool(
                cfg.get("ignore_legacy_low_confidence_veto_for_v8001", True)
            ),
            "external_hard_blocks_preserved": bool(cfg.get("preserve_external_hard_blocks", True)),
            "high_impact_news_downgrades_live_to_shadow": (
                str(cfg.get("v8002_would_block_live_route") or "").upper() == "SHADOW"
            ),
            "broker_auto_execution": bool(cfg.get("broker_auto_execution", False)),
            "v8002_observe_only": bool(cfg.get("v8002_observe_only", True)),
        },
        "policy": {
            "live_grades": cfg.get("live_grades"),
            "shadow_grades": cfg.get("shadow_grades"),
            "watch_grades": cfg.get("watch_grades"),
            "existing_gate_policy": cfg.get("v8001_existing_gate_policy"),
            "require_existing_gate_allow_for_live": cfg.get("require_existing_gate_allow_for_live"),
            "server_confidence_live_mode": cfg.get("server_confidence_live_mode"),
        },
        "summary": {
            "evaluated": 0,
            "strong_total": 0,
            "strong_live": 0,
            "strong_shadow": 0,
            "legacy_confidence_downgrades_historical": 0,
            "external_hard_block_downgrades": 0,
        },
        "latest_strong": [],
        "selftest": router.selftest_payload(),
    }

    con = None
    try:
        con = sqlite3.connect(f"file:{_db()}?mode=ro", uri=True, timeout=10)
        con.row_factory = sqlite3.Row
        quick = con.execute("PRAGMA quick_check").fetchone()[0]
        exists = con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='v8004_quality_router_log'"
        ).fetchone()
        result["db_quick_check"] = quick
        if exists:
            counts = con.execute(
                """
                SELECT
                  COUNT(*) AS evaluated,
                  SUM(CASE WHEN grade IN ('A_PLUS','A') THEN 1 ELSE 0 END) AS strong_total,
                  SUM(CASE WHEN grade IN ('A_PLUS','A') AND route='LIVE' THEN 1 ELSE 0 END) AS strong_live,
                  SUM(CASE WHEN grade IN ('A_PLUS','A') AND route='SHADOW' THEN 1 ELSE 0 END) AS strong_shadow,
                  SUM(CASE WHEN grade IN ('A_PLUS','A') AND reasons_json LIKE '%STRONG_SIGNAL_DOWNGRADED_BY_EXISTING_SAFETY_GATE%' THEN 1 ELSE 0 END) AS legacy_confidence_downgrades_historical,
                  SUM(CASE WHEN grade IN ('A_PLUS','A') AND reasons_json LIKE '%V8007_EXTERNAL_HARD_BLOCK_PRESERVED%' THEN 1 ELSE 0 END) AS external_hard_block_downgrades
                FROM v8004_quality_router_log
                """
            ).fetchone()
            result["summary"] = {key: int(counts[key] or 0) for key in counts.keys()}

            rows = con.execute(
                """
                SELECT id, created_at, signal_event_id, market, direction, setup_name,
                       playbook, pine_score, server_confidence, grade, route,
                       base_allow, final_allow, reasons_json, blockers_json, raw_json
                FROM v8004_quality_router_log
                WHERE grade IN ('A_PLUS','A')
                ORDER BY id DESC LIMIT ?
                """,
                (max(1, min(int(limit), 300)),),
            ).fetchall()
            latest = []
            for row in rows:
                item = dict(row)
                item["reasons"] = _read_json(item.pop("reasons_json"), [])
                item["blockers"] = _read_json(item.pop("blockers_json"), [])
                raw = _read_json(item.pop("raw_json"), {})
                decision = raw.get("decision") if isinstance(raw, dict) else {}
                if isinstance(decision, dict):
                    item["legacy_gate"] = decision.get("legacy_gate")
                    item["effective_live_score"] = decision.get("effective_live_score")
                latest.append(item)
            result["latest_strong"] = latest
        result["ok"] = (
            quick == "ok"
            and result["selftest"].get("ok") is True
            and bool(cfg.get("enforce", True))
            and bool(cfg.get("apply_only_to_v8001", True))
            and not bool(cfg.get("require_existing_gate_allow_for_live", False))
            and bool(cfg.get("ignore_legacy_low_confidence_veto_for_v8001", True))
            and bool(cfg.get("preserve_external_hard_blocks", True))
            and not bool(cfg.get("broker_auto_execution", False))
        )
    except Exception as exc:
        result["ok"] = False
        result["error"] = str(exc)
    finally:
        if con is not None:
            con.close()
    return result


def _page(data: dict[str, Any]) -> str:
    s = data.get("summary", {})
    safety = data.get("safety", {})
    rows = "".join(
        "<tr>" + "".join(
            f"<td>{_esc(row.get(key, ''))}</td>"
            for key in (
                "created_at", "market", "direction", "setup_name", "pine_score",
                "server_confidence", "grade", "route", "base_allow", "final_allow",
            )
        ) + f"<td>{_esc(', '.join(row.get('reasons') or []))}</td></tr>"
        for row in data.get("latest_strong", [])[:60]
    ) or "<tr><td colspan='11'>Noch keine starken V8001-Signale vorhanden.</td></tr>"
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>V8007 V8001 Gate Bridge</title><style>
body{{background:#07111e;color:#edf6ff;font-family:Arial;margin:0}}.w{{max-width:1250px;margin:auto;padding:16px}}.c{{background:#101d2e;border:1px solid #273a52;border-radius:15px;padding:14px;margin:10px 0;overflow:auto}}.g{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}}.v{{font-size:26px;font-weight:800}}.ok{{color:#22c55e}}.warn{{color:#facc15}}a{{color:#93c5fd}}table{{width:100%;border-collapse:collapse;font-size:11px}}th,td{{padding:7px;border-bottom:1px solid #273a52;text-align:left;white-space:nowrap}}</style></head>
<body><div class='w'><h1>V8007 V8001 Gate Bridge</h1>
<div class='c'><b>Status:</b> <span class='{'ok' if data.get('ok') else 'warn'}'>{_esc(data.get('ok'))}</span> · A/A+ nutzt V8001-Pine-Qualität. Der alte Confidence-Only-Veto wird für V8001 ignoriert. Echte Hard Blocks und High-Impact-News bleiben aktiv.</div>
<div class='g'><div class='c'><div>Evaluated</div><div class='v'>{_esc(s.get('evaluated',0))}</div></div><div class='c'><div>Strong total</div><div class='v'>{_esc(s.get('strong_total',0))}</div></div><div class='c'><div>Strong live</div><div class='v ok'>{_esc(s.get('strong_live',0))}</div></div><div class='c'><div>Strong shadow</div><div class='v warn'>{_esc(s.get('strong_shadow',0))}</div></div></div>
<div class='c'>V8001 only: {_esc(safety.get('applies_only_to_v8001'))} · Hard blocks preserved: {_esc(safety.get('external_hard_blocks_preserved'))} · News → Shadow: {_esc(safety.get('high_impact_news_downgrades_live_to_shadow'))} · Broker auto execution: {_esc(safety.get('broker_auto_execution'))}</div>
<div class='c'><a href='/master'>Master</a> · <a href='/master-ai-review'>AI Review</a> · <a href='/v8007/gate-bridge-audit.json'>JSON</a> · <a href='/v8007/selftest.json'>Selftest</a> · <a href='/v8004/quality-router'>V8004 Router</a></div>
<div class='c'><table><tr><th>Zeit</th><th>Markt</th><th>Dir</th><th>Setup</th><th>Pine</th><th>Legacy Conf</th><th>Grade</th><th>Route</th><th>Base</th><th>Final</th><th>Gründe</th></tr>{rows}</table></div></div></body></html>"""


def _master_card(token: str) -> str:
    suffix = f"?token={quote(token)}" if token else ""
    return f"""
<section id='v8007-gate-bridge' class='section'>
  <div class='sectionhead'><div><h2>V8007 V8001 Gate Bridge</h2><p>A/A+ nutzt die neue V8001-Pine-Qualität. Nur der alte Confidence-Only-Veto wird überbrückt; echte Safety-Blocks und High Impact bleiben Shadow.</p></div></div>
  <div class='cards'>
    <a class='card' href='/v8007/gate-bridge-audit{suffix}'><div class='icon'>🌉</div><div class='cardbody'><div class='cardtop'><h3>Gate Bridge Audit</h3><span class='status ok'>V8001 ONLY</span></div><p>Live-/Shadow-Entscheidung und externe Hard Blocks nachvollziehbar.</p><code>/v8007/gate-bridge-audit</code></div><div class='arrow'>›</div></a>
    <a class='card' href='/v8007/selftest.json{suffix}'><div class='icon'>🧪</div><div class='cardbody'><div class='cardtop'><h3>Bridge Selftest</h3><span class='status ok'>BROKER OFF</span></div><p>Low-confidence bridge, Hard Block, News, B-Shadow und 5m-No-Trade.</p><code>/v8007/selftest.json</code></div><div class='arrow'>›</div></a>
  </div>
</section>
"""


def _integrate(text: str, token: str, ai: bool) -> str:
    if "id='v8007-gate-bridge'" in text:
        return text
    marker = "<section id='current-inputs' class='section'>" if ai else "<section id='current' class='section'>"
    card = _master_card(token)
    if marker in text:
        return text.replace(marker, card + marker, 1)
    if "</body>" in text:
        return text.replace("</body>", card + "</body>", 1)
    return text + card


class V8007MasterIntegrationMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http" or str(scope.get("method") or "GET").upper() != "GET":
            await self.app(scope, receive, send)
            return
        path = str(scope.get("path") or "")
        if path not in {"/master", "/master-ai-review"}:
            await self.app(scope, receive, send)
            return
        start = None
        chunks: list[bytes] = []

        async def capture(message):
            nonlocal start
            if message["type"] == "http.response.start":
                start = dict(message)
                return
            if message["type"] == "http.response.body":
                chunks.append(message.get("body", b""))
                if message.get("more_body", False):
                    return
                if start is None:
                    return
                body = b"".join(chunks)
                headers = list(start.get("headers", []))
                ctype = next((v.decode("latin1") for k, v in headers if k.lower() == b"content-type"), "")
                if start.get("status") == 200 and "text/html" in ctype:
                    query = parse_qs((scope.get("query_string") or b"").decode("utf-8", errors="ignore"))
                    token = (query.get("token") or [""])[0]
                    text = body.decode("utf-8", errors="ignore")
                    body = _integrate(text, token, ai=(path == "/master-ai-review")).encode("utf-8")
                headers = [(k, v) for k, v in headers if k.lower() not in {b"content-length", b"content-encoding"}]
                headers.append((b"content-length", str(len(body)).encode("ascii")))
                start["headers"] = headers
                await send(start)
                await send({"type": "http.response.body", "body": body, "more_body": False})

        await self.app(scope, receive, capture)


def install_v8007_v8001_gate_bridge(app) -> None:
    if getattr(app.state, "v8007_v8001_gate_bridge_installed", False):
        return

    @app.get("/v8007/gate-bridge-audit", response_class=HTMLResponse)
    def page(request: Request, limit: int = 100):
        if not _token_ok(request):
            return HTMLResponse("unauthorized", status_code=401)
        return HTMLResponse(_page(audit_payload(limit)))

    @app.get("/v8007/gate-bridge-audit.json")
    def audit_json(request: Request, limit: int = 100):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(audit_payload(limit))

    @app.get("/v8007/gate-bridge-config.json")
    def config_json(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        cfg = router.load_config()
        return JSONResponse({"ok": True, "version": VERSION, "config": cfg, "safety": audit_payload(1).get("safety")})

    @app.get("/v8007/selftest.json")
    def selftest_json(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(router.selftest_payload())

    app.add_middleware(V8007MasterIntegrationMiddleware)
    app.state.v8007_v8001_gate_bridge_installed = True
    print("[V8007] V8001 gate bridge installed; legacy confidence-only veto ignored, external hard blocks preserved")
