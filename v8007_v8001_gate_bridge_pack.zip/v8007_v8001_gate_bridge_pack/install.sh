#!/usr/bin/env bash
set -euo pipefail

PROJECT="${PROJECT:-/opt/tradingbot_v6000}"
CONTAINER="${CONTAINER:-tradingbot}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8007_before_${STAMP}"

MAIN="$PROJECT/app/main.py"
V8004_MODULE="$PROJECT/app/v8004_quality_router.py"
V8007_MODULE="$PROJECT/app/v8007_v8001_gate_bridge.py"
V8004_CONFIG="$PROJECT/data/v8004_quality_router_config.json"
V8007_CONFIG="$PROJECT/data/v8007_gate_bridge_config.json"

fail() { echo "FEHLER: $*" >&2; exit 1; }
route_code() { curl --connect-timeout 3 --max-time 20 -sS -o /dev/null -w '%{http_code}' "http://127.0.0.1$1"; }

echo "=== V8007 V8001 GATE BRIDGE ==="

test -d "$PROJECT" || fail "Projektordner fehlt"
test -f "$MAIN" || fail "main.py fehlt"
test -f "$V8004_MODULE" || fail "V8004 Modul fehlt"
test -f "$V8004_CONFIG" || fail "V8004 Config fehlt"

for FILE in \
  "$PACK_DIR/app/v8004_quality_router.py" \
  "$PACK_DIR/app/v8007_v8001_gate_bridge.py" \
  "$PACK_DIR/data/v8004_quality_router_patch.json" \
  "$PACK_DIR/data/v8007_gate_bridge_config.json"
do
  test -f "$FILE" || fail "Paketdatei fehlt: $FILE"
done

cd "$PROJECT"

echo "[1] Backup"
mkdir -p "$BACKUP/app" "$BACKUP/data"
cp -a "$MAIN" "$BACKUP/app/main.py"
cp -a "$V8004_MODULE" "$BACKUP/app/v8004_quality_router.py"
cp -a "$V8004_CONFIG" "$BACKUP/data/v8004_quality_router_config.json"
if [ -f "$V8007_MODULE" ]; then cp -a "$V8007_MODULE" "$BACKUP/app/"; touch "$BACKUP/v8007_module_existed"; fi
if [ -f "$V8007_CONFIG" ]; then cp -a "$V8007_CONFIG" "$BACKUP/data/"; touch "$BACKUP/v8007_config_existed"; fi
printf '%s\n' "$BACKUP" > /root/v8007_last_backup.txt
echo "Backup: $BACKUP"

echo "[2] Paket prüfen"
python3 -m py_compile "$PACK_DIR/app/v8004_quality_router.py" "$PACK_DIR/app/v8007_v8001_gate_bridge.py"
python3 -m json.tool "$PACK_DIR/data/v8004_quality_router_patch.json" >/dev/null
python3 -m json.tool "$PACK_DIR/data/v8007_gate_bridge_config.json" >/dev/null

echo "[3] Module installieren"
install -m 0644 "$PACK_DIR/app/v8004_quality_router.py" "$V8004_MODULE"
install -m 0644 "$PACK_DIR/app/v8007_v8001_gate_bridge.py" "$V8007_MODULE"
install -m 0644 "$PACK_DIR/data/v8007_gate_bridge_config.json" "$V8007_CONFIG"

echo "[4] V8004 Config sicher zusammenführen"
V8007_PACK_DIR="$PACK_DIR" python3 - <<'PY'
import json, os
from pathlib import Path
pack = Path(os.environ["V8007_PACK_DIR"])
path = Path("/opt/tradingbot_v6000/data/v8004_quality_router_config.json")
current = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
patch = json.loads((pack / "data/v8004_quality_router_patch.json").read_text(encoding="utf-8"))
if not isinstance(current, dict): current = {}
current.update(patch)
# Hard safety locks.
current.update({
    "enabled": True,
    "enforce": True,
    "apply_only_to_v8001": True,
    "non_v8001_behavior": "KEEP_EXISTING",
    "require_existing_gate_allow_for_live": False,
    "v8001_existing_gate_policy": "HARD_BLOCKS_ONLY",
    "ignore_legacy_low_confidence_veto_for_v8001": True,
    "preserve_external_hard_blocks": True,
    "v8002_would_block_live_route": "SHADOW",
    "v8002_would_block_applies_to_live_only": True,
    "broker_auto_execution": False,
    "v8001_observe_only": True,
    "v8002_observe_only": True,
})
path.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print({k: current.get(k) for k in (
    "version", "enforce", "apply_only_to_v8001", "require_existing_gate_allow_for_live",
    "v8001_existing_gate_policy", "ignore_legacy_low_confidence_veto_for_v8001",
    "preserve_external_hard_blocks", "v8002_would_block_live_route", "broker_auto_execution"
)})
PY

echo "[5] V8007-Routen in main.py registrieren"
python3 - <<'PY'
from pathlib import Path
path = Path("/opt/tradingbot_v6000/app/main.py")
text = path.read_text(encoding="utf-8")
begin = "# V8007_V8001_GATE_BRIDGE_INSTALL_BEGIN"
end = "# V8007_V8001_GATE_BRIDGE_INSTALL_END"
if text.count(begin) > 1 or text.count(end) > 1:
    raise SystemExit("FEHLER: V8007 Marker mehrfach vorhanden")
if begin not in text:
    text += """

# V8007_V8001_GATE_BRIDGE_INSTALL_BEGIN
try:
    from app.v8007_v8001_gate_bridge import install_v8007_v8001_gate_bridge
    install_v8007_v8001_gate_bridge(app)
except Exception as _v8007_install_error:
    print(f"[V8007] install error: {_v8007_install_error}")
# V8007_V8001_GATE_BRIDGE_INSTALL_END
"""
    path.write_text(text, encoding="utf-8")
    print("V8007 Installblock angehängt.")
else:
    print("V8007 Installblock bereits vorhanden.")
assert path.read_text(encoding="utf-8").count(begin) == 1
assert path.read_text(encoding="utf-8").count(end) == 1
PY

echo "[6] Host-Syntaxcheck"
python3 -m py_compile "$MAIN" "$V8004_MODULE" "$V8007_MODULE"

echo "[7] Docker neu bauen"
docker compose up -d --build

echo "[8] Auf Health warten"
READY=0
for _ in $(seq 1 60); do
  if curl -fsS --max-time 3 http://127.0.0.1/health >/dev/null 2>&1; then READY=1; break; fi
  sleep 2
done
if [ "$READY" -ne 1 ]; then docker logs --tail 180 "$CONTAINER" || true; fail "Server wurde nicht gesund"; fi

echo "[9] Container-Syntax und Routen"
docker exec "$CONTAINER" python -m py_compile \
  /app/app/main.py /app/app/v8004_quality_router.py /app/app/v8007_v8001_gate_bridge.py

for ROUTE in \
  /health \
  /master \
  /master-ai-review \
  /v8004/quality-router \
  /v8004/quality-router.json \
  /v8004/quality-router-config.json \
  /v8004/selftest.json \
  /v8006/calendar-execution-audit.json \
  /v8007/gate-bridge-audit \
  /v8007/gate-bridge-audit.json \
  /v8007/gate-bridge-config.json \
  /v8007/selftest.json \
  /v8005/performance.json
 do
  CODE="$(route_code "$ROUTE")"
  echo "$ROUTE -> $CODE"
  [ "$CODE" = "200" ] || fail "Route $ROUTE liefert $CODE"
 done

echo "[10] V8007 Selftest"
curl -fsS http://127.0.0.1/v8007/selftest.json > /tmp/v8007_selftest.json
python3 - <<'PY'
import json
data=json.load(open('/tmp/v8007_selftest.json', encoding='utf-8'))
print('Selftest OK:', data.get('ok'))
tests={x.get('name'):x for x in data.get('tests',[])}
for name,item in tests.items():
    print(name, 'expected='+str(item.get('expected_route')), 'actual='+str(item.get('actual_route')), 'PASS='+str(item.get('pass')))
assert data.get('ok') is True
assert tests['A_LEGACY_LOW_CONFIDENCE_BRIDGES_TO_LIVE']['actual_route']=='LIVE'
assert tests['A_EXISTING_GATE_PASS_LIVE']['actual_route']=='LIVE'
assert tests['A_EXTERNAL_OPEN_POSITION_STAYS_SHADOW']['actual_route']=='SHADOW'
assert tests['NEWS_WINDOW_DOWNGRADE']['actual_route']=='SHADOW'
assert tests['B_SHADOW']['actual_route']=='SHADOW'
assert tests['INVALID_5M']['actual_route']=='NO_TRADE'
PY

echo "[11] Kalenderfix weiterhin korrekt"
curl -fsS http://127.0.0.1/v8006/calendar-execution-audit.json > /tmp/v8006_after_v8007.json
python3 - <<'PY'
import json
data=json.load(open('/tmp/v8006_after_v8007.json', encoding='utf-8'))
s=data.get('summary',{})
print('V8006 OK:',data.get('ok'),'time mismatches:',s.get('event_time_mismatches'),'impact mismatches:',s.get('impact_mismatches'))
assert data.get('ok') is True
assert s.get('event_time_mismatches')==0
assert s.get('impact_mismatches')==0
PY

echo "[12] Safetycheck"
curl -fsS http://127.0.0.1/v8007/gate-bridge-config.json > /tmp/v8007_config.json
curl -fsS http://127.0.0.1/v8002/news-policy-config.json > /tmp/v8002_after_v8007.json
python3 - <<'PY'
import json
v7=json.load(open('/tmp/v8007_config.json', encoding='utf-8'))
cfg=v7.get('config',{})
s=v7.get('safety',{})
v2=json.load(open('/tmp/v8002_after_v8007.json', encoding='utf-8'))
assert cfg.get('enforce') is True
assert cfg.get('apply_only_to_v8001') is True
assert cfg.get('require_existing_gate_allow_for_live') is False
assert cfg.get('ignore_legacy_low_confidence_veto_for_v8001') is True
assert cfg.get('preserve_external_hard_blocks') is True
assert cfg.get('v8002_would_block_live_route') == 'SHADOW'
assert cfg.get('broker_auto_execution') is False
assert v2.get('observe_only') is True
assert v2.get('enforce') is False
print('V8001 only:',cfg.get('apply_only_to_v8001'))
print('Legacy confidence-only veto ignored:',cfg.get('ignore_legacy_low_confidence_veto_for_v8001'))
print('External hard blocks preserved:',cfg.get('preserve_external_hard_blocks'))
print('High-impact LIVE route:',cfg.get('v8002_would_block_live_route'))
print('V8002 observe_only/enforce:',v2.get('observe_only'),v2.get('enforce'))
print('Broker Auto Execution:',cfg.get('broker_auto_execution'))
PY

echo "[13] Master-Integration"
curl -fsS http://127.0.0.1/master | grep -q "V8007 V8001 Gate Bridge" || fail "/master enthält V8007 nicht"
curl -fsS http://127.0.0.1/master-ai-review | grep -q "V8007 V8001 Gate Bridge" || fail "/master-ai-review enthält V8007 nicht"
echo "/master enthält V8007"
echo "/master-ai-review enthält V8007"

echo "[14] Status und Logs"
docker ps --filter name="$CONTAINER"
ERRORS="$(docker logs --since 10m "$CONTAINER" 2>&1 | grep -Eic 'traceback|exception|internal server error|HTTP/1.1" 500' || true)"
echo "Aktuelle Fehler-Muster: $ERRORS"
[ "$ERRORS" -eq 0 ] || docker logs --since 10m "$CONTAINER" 2>&1 | grep -Ei 'traceback|exception|internal server error|HTTP/1.1" 500' | tail -80

echo ""
echo "=== V8007 INSTALLATION FERTIG ==="
echo "Backup: $BACKUP"
echo "A/A+ + vollständiger V8001-Pass + kein echter Hard Block -> LIVE"
echo "Legacy Confidence-only Veto für V8001 -> ignoriert"
echo "Echter Safety/Risk/Position/Conflict Block -> SHADOW"
echo "High-Impact-Newsfenster -> SHADOW"
echo "B/Review -> SHADOW"
echo "5m/ungültig/Duplikat -> NO TRADE"
echo "V8002 observe_only: TRUE"
echo "V8002 enforce: FALSE"
echo "Broker Auto Execution: FALSE"
