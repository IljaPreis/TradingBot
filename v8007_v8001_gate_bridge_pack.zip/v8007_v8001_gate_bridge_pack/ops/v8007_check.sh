#!/usr/bin/env bash
set -euo pipefail
for R in /health /v8004/selftest.json /v8006/calendar-execution-audit.json /v8007/gate-bridge-audit.json /v8007/selftest.json /master /master-ai-review; do
  C=$(curl -sS --max-time 20 -o /dev/null -w '%{http_code}' "http://127.0.0.1$R")
  echo "$R -> $C"
  [ "$C" = 200 ]
done
curl -sS http://127.0.0.1/v8007/selftest.json | python3 -m json.tool
