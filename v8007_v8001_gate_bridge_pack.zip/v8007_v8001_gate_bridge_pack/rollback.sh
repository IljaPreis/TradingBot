#!/usr/bin/env bash
set -euo pipefail
PROJECT="${PROJECT:-/opt/tradingbot_v6000}"
BACKUP="${1:-$(cat /root/v8007_last_backup.txt 2>/dev/null || true)}"
[ -n "$BACKUP" ] && [ -d "$BACKUP" ] || { echo "Backup fehlt"; exit 1; }
cp -a "$BACKUP/app/main.py" "$PROJECT/app/main.py"
cp -a "$BACKUP/app/v8004_quality_router.py" "$PROJECT/app/v8004_quality_router.py"
cp -a "$BACKUP/data/v8004_quality_router_config.json" "$PROJECT/data/v8004_quality_router_config.json"
if [ -f "$BACKUP/v8007_module_existed" ]; then cp -a "$BACKUP/app/v8007_v8001_gate_bridge.py" "$PROJECT/app/"; else rm -f "$PROJECT/app/v8007_v8001_gate_bridge.py"; fi
if [ -f "$BACKUP/v8007_config_existed" ]; then cp -a "$BACKUP/data/v8007_gate_bridge_config.json" "$PROJECT/data/"; else rm -f "$PROJECT/data/v8007_gate_bridge_config.json"; fi
cd "$PROJECT"
docker compose up -d --build
echo "Rollback fertig: $BACKUP"
