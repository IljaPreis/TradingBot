# V8008A Context Capture

V8008A ergänzt ausschließlich Kontext-Metadaten in den bestehenden V8001-Pine-Payload und installiert ein read-only Review-Dashboard.

## Neue Payload-Felder

- `weekly_bias` (klare Bezeichnung für den bisherigen 1W-Bias)
- `market_regime`: `TREND_UP`, `TREND_DOWN`, `RANGE`, `TRANSITION`
- `external_structure_state`
- `structure_scope`: `EXTERNAL`, `INTERNAL`, `STATE_ONLY`
- `range_high`, `range_low`, `range_mid`, `range_position`
- `range_location` / `premium_discount_state`
- `zone_location`, `distance_to_zone_atr`
- `entry_quality`: `FRESH`, `VALID`, `LATE`
- `impulse_state`: `STRONG`, `NORMAL`, `WEAK`
- `distance_to_mean_atr`
- `context_capture_version`

## Sicherheit

- keine Score-Änderung
- keine Candidate-/Trigger-Änderung
- keine V8004/V8006/V8007-Routing-Änderung
- kein Auto-Blocking oder Auto-Filtering
- keine zusätzlichen Datenbank-Schreibvorgänge durch das V8008A-Modul
- bestehende V8001-Audit-Speicherung läuft unverändert weiter
- Broker Auto Execution bleibt `false`

## Routen

- `/v8008a/context-capture`
- `/v8008a/context-capture.json`
- `/v8008a/context-capture-config.json`
- `/v8008a/selftest.json`

## TradingView

Die Serverinstallation aktualisiert die kanonische Pine-Datei auf dem VPS. TradingView aktualisiert Scripts und Alerts nicht automatisch. Nach der Installation muss die Datei `pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine` in TradingView ersetzt und jeder bestehende V8001-Alert neu erstellt werden.
