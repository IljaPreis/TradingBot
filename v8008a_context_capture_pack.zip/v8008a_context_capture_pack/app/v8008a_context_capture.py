from __future__ import annotations

import html
import json
import sqlite3
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse, Response

VERSION = "V8008A-CONTEXT-CAPTURE"
DB_PATH = Path("data/v7000_learning.sqlite3")

SAFETY = {
    "observe_only": True,
    "enforce": False,
    "live_rule_changes": False,
    "auto_blocking": False,
    "auto_filtering": False,
    "additional_db_writes": False,
    "broker_auto_execution": False,
    "routing_changed": False,
}

FIELDS = (
    "context_capture_version",
    "weekly_bias",
    "market_regime",
    "regime_source",
    "external_structure_state",
    "internal_structure_state",
    "structure_scope",
    "liquidity_state",
    "range_high",
    "range_low",
    "range_mid",
    "range_position",
    "range_location",
    "premium_discount_state",
    "zone_location",
    "distance_to_zone_atr",
    "entry_quality",
    "impulse_state",
    "distance_to_mean_atr",
    "is_chase",
    "is_late_entry",
)


def _parse_json(value: Any) -> Any:
    if isinstance(value, (dict, list)):
        return value
    if not isinstance(value, str) or not value.strip():
        return {}
    try:
        return json.loads(value)
    except Exception:
        return {}


def _find_first(data: Any, key: str) -> Tuple[bool, Any]:
    if isinstance(data, dict):
        if key in data:
            return True, data.get(key)
        for value in data.values():
            found, result = _find_first(value, key)
            if found:
                return True, result
    elif isinstance(data, list):
        for value in data:
            found, result = _find_first(value, key)
            if found:
                return True, result
    return False, None


def _value(data: Any, key: str, default: Any = None) -> Any:
    found, result = _find_first(data, key)
    return result if found else default


def _present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip().lower() not in {"", "null", "unknown", "n/a"}
    return True


def _ro_connection() -> sqlite3.Connection:
    con = sqlite3.connect(
        f"file:{DB_PATH}?mode=ro",
        uri=True,
        timeout=10,
    )
    con.row_factory = sqlite3.Row
    return con


def _load_rows(limit: int = 500) -> List[Dict[str, Any]]:
    if not DB_PATH.exists():
        return []
    con = _ro_connection()
    try:
        tables = {
            row[0]
            for row in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        if "v8001_pine_enriched_signals" not in tables:
            return []
        rows = con.execute(
            """
            SELECT id, received_at, signal_event_id, client_trade_id,
                   market, direction, setup_name, playbook, session,
                   confidence, raw_json
            FROM v8001_pine_enriched_signals
            ORDER BY id DESC
            LIMIT ?
            """,
            (max(1, min(int(limit), 5000)),),
        ).fetchall()
        return [dict(row) for row in rows]
    finally:
        con.close()


def build_report(limit: int = 500) -> Dict[str, Any]:
    rows = _load_rows(limit)
    contexts: List[Dict[str, Any]] = []
    coverage: Dict[str, int] = {field: 0 for field in FIELDS}
    distributions: Dict[str, Counter] = {
        key: Counter()
        for key in (
            "market_regime",
            "structure_scope",
            "range_location",
            "zone_location",
            "entry_quality",
            "impulse_state",
            "liquidity_state",
        )
    }

    for row in rows:
        raw = _parse_json(row.get("raw_json"))
        context: Dict[str, Any] = {
            "id": row.get("id"),
            "received_at": row.get("received_at"),
            "signal_event_id": row.get("signal_event_id"),
            "client_trade_id": row.get("client_trade_id"),
            "market": row.get("market"),
            "direction": row.get("direction"),
            "setup_name": row.get("setup_name"),
            "playbook": row.get("playbook"),
            "session": row.get("session"),
            "pine_score": row.get("confidence"),
        }
        for field in FIELDS:
            value = _value(raw, field)
            context[field] = value
            if _present(value):
                coverage[field] += 1
        if context.get("context_capture_version") == VERSION:
            contexts.append(context)
        for key, counter in distributions.items():
            value = context.get(key)
            counter[str(value if _present(value) else "MISSING")] += 1

    total = len(rows)
    capture_rows = len(contexts)
    coverage_pct = {
        key: round(value * 100.0 / total, 1) if total else 0.0
        for key, value in coverage.items()
    }
    capture_coverage_pct = {
        key: round(
            sum(1 for item in contexts if _present(item.get(key)))
            * 100.0
            / capture_rows,
            1,
        )
        if capture_rows
        else 0.0
        for key in FIELDS
    }

    quick_check = "missing_db"
    v8001_outcomes = 0
    v8008a_context_outcomes = 0
    if DB_PATH.exists():
        con = _ro_connection()
        try:
            quick_check = con.execute("PRAGMA quick_check").fetchone()[0]
            tables = {
                row[0]
                for row in con.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            if {"shadow_trades", "shadow_outcomes"}.issubset(tables):
                v8001_outcomes = con.execute(
                    """
                    SELECT COUNT(DISTINCT so.shadow_id)
                    FROM shadow_trades st
                    JOIN shadow_outcomes so ON so.shadow_id = st.shadow_id
                    WHERE st.client_trade_id LIKE 'V8001_%'
                    """
                ).fetchone()[0]
                context_ids = sorted({
                    str(item.get("client_trade_id"))
                    for item in contexts
                    if item.get("client_trade_id")
                })
                if context_ids:
                    placeholders = ",".join("?" for _ in context_ids)
                    v8008a_context_outcomes = con.execute(
                        f"""
                        SELECT COUNT(DISTINCT so.shadow_id)
                        FROM shadow_trades st
                        JOIN shadow_outcomes so ON so.shadow_id = st.shadow_id
                        WHERE st.client_trade_id IN ({placeholders})
                        """,
                        context_ids,
                    ).fetchone()[0]
        finally:
            con.close()

    return {
        "ok": quick_check == "ok",
        "version": VERSION,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "safety": SAFETY,
        "mode": "observe_only_context_capture_report",
        "summary": {
            "db_quick_check": quick_check,
            "rows_scanned": total,
            "v8008a_context_rows": capture_rows,
            "v8001_shadow_outcomes": v8001_outcomes,
            "v8008a_context_outcomes": v8008a_context_outcomes,
            "ready_for_context_rating": v8008a_context_outcomes >= 30,
            "minimum_context_outcomes_before_rating": 30,
        },
        "coverage_all_rows": coverage,
        "coverage_all_rows_pct": coverage_pct,
        "coverage_v8008a_rows_pct": capture_coverage_pct,
        "distributions": {
            key: dict(counter.most_common(20))
            for key, counter in distributions.items()
        },
        "latest_v8008a": contexts[:50],
        "note": (
            "This module only reads existing V8001 audit rows. The Pine payload "
            "adds context metadata but does not change scores, routing, gates, "
            "Telegram behavior, orders, or broker execution."
        ),
    }


def _selftest() -> Dict[str, Any]:
    sample = {
        "context_capture_version": VERSION,
        "weekly_bias": "bullish",
        "market_regime": "RANGE",
        "external_structure_state": "bullish",
        "internal_structure_state": "internal_mss_bull",
        "structure_scope": "INTERNAL",
        "liquidity_state": "sweep_low",
        "range_location": "DISCOUNT",
        "zone_location": "NO_ZONE",
        "entry_quality": "FRESH",
        "impulse_state": "STRONG",
        "is_chase": False,
        "is_late_entry": False,
    }
    tests = []
    for key in (
        "context_capture_version",
        "market_regime",
        "structure_scope",
        "range_location",
        "entry_quality",
        "impulse_state",
    ):
        tests.append(
            {
                "name": f"FIELD_{key.upper()}",
                "pass": _value(sample, key) is not None,
                "actual": _value(sample, key),
            }
        )
    tests.extend(
        [
            {
                "name": "OBSERVE_ONLY",
                "pass": SAFETY["observe_only"] and not SAFETY["enforce"],
                "actual": SAFETY,
            },
            {
                "name": "NO_ROUTING_CHANGE",
                "pass": not SAFETY["routing_changed"],
                "actual": SAFETY["routing_changed"],
            },
            {
                "name": "BROKER_AUTO_EXECUTION_FALSE",
                "pass": not SAFETY["broker_auto_execution"],
                "actual": SAFETY["broker_auto_execution"],
            },
        ]
    )
    return {
        "ok": all(item["pass"] for item in tests),
        "version": VERSION,
        "tests": tests,
    }


def _html_report(report: Dict[str, Any]) -> str:
    summary = report["summary"]
    latest = report.get("latest_v8008a", [])
    rows = []
    for item in latest[:30]:
        rows.append(
            "<tr>"
            f"<td>{html.escape(str(item.get('received_at') or ''))}</td>"
            f"<td><b>{html.escape(str(item.get('market') or ''))}</b></td>"
            f"<td>{html.escape(str(item.get('direction') or ''))}</td>"
            f"<td>{html.escape(str(item.get('setup_name') or ''))}</td>"
            f"<td>{html.escape(str(item.get('market_regime') or ''))}</td>"
            f"<td>{html.escape(str(item.get('structure_scope') or ''))}</td>"
            f"<td>{html.escape(str(item.get('range_location') or ''))}</td>"
            f"<td>{html.escape(str(item.get('zone_location') or ''))}</td>"
            f"<td>{html.escape(str(item.get('entry_quality') or ''))}</td>"
            f"<td>{html.escape(str(item.get('impulse_state') or ''))}</td>"
            "</tr>"
        )
    body = "".join(rows) or "<tr><td colspan='10'>Noch keine V8008A-Payloads empfangen. TradingView-Script und Alerts aktualisieren.</td></tr>"
    coverage_rows = "".join(
        "<tr>"
        f"<td>{html.escape(key)}</td>"
        f"<td>{value}%</td>"
        "</tr>"
        for key, value in report.get("coverage_v8008a_rows_pct", {}).items()
    )
    return f"""<!doctype html>
<html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>V8008A Context Capture</title>
<style>
body{{font-family:Arial,sans-serif;background:#07111f;color:#e5eefb;margin:0;padding:18px}}
.card{{background:#101c2d;border:1px solid #29415f;border-radius:14px;padding:14px;margin-bottom:14px;overflow:auto}}
h1,h2{{margin:0 0 10px}} .ok{{color:#86efac}} .warn{{color:#fde68a}}
table{{border-collapse:collapse;width:100%;min-width:900px}} th,td{{border-bottom:1px solid #29415f;padding:8px;text-align:left;font-size:13px}}
code{{color:#bfdbfe}}
a{{color:#93c5fd}}
</style></head><body>
<div class='card'><h1>V8008A Context Capture</h1>
<p>Mode: <b>Observe-only</b> · Routing unverändert · Broker Auto Execution: <b>FALSE</b></p>
<p>DB: <span class='ok'>{html.escape(str(summary.get('db_quick_check')))}</span> · gescannt: {summary.get('rows_scanned')} · neue V8008A-Kontexte: {summary.get('v8008a_context_rows')} · V8001 Outcomes: {summary.get('v8001_shadow_outcomes')}</p>
<p>Context-Rating erst ab mindestens <b>{summary.get('minimum_context_outcomes_before_rating')}</b> geschlossenen V8008A-Kontext-Outcomes. Aktuell: <b>{summary.get('v8008a_context_outcomes')}</b>.</p>
<p><a href='/v8008a/context-capture.json'>JSON</a> · <a href='/v8008a/context-capture-config.json'>Safety Config</a> · <a href='/v8008a/selftest.json'>Selftest</a></p></div>
<div class='card'><h2>Feldabdeckung neuer V8008A-Payloads</h2><table><tr><th>Feld</th><th>Abdeckung</th></tr>{coverage_rows}</table></div>
<div class='card'><h2>Letzte Kontexte</h2><table><tr><th>Zeit</th><th>Market</th><th>Richtung</th><th>Setup</th><th>Regime</th><th>Scope</th><th>Range</th><th>Zone</th><th>Entry</th><th>Impulse</th></tr>{body}</table></div>
</body></html>"""


def install_v8008a_context_capture(app: Any) -> None:
    existing = {getattr(route, "path", "") for route in getattr(app, "routes", [])}

    if "/v8008a/context-capture.json" not in existing:
        @app.get("/v8008a/context-capture.json")
        def v8008a_context_capture_json(limit: int = 500):
            return JSONResponse(build_report(limit))

    if "/v8008a/context-capture-config.json" not in existing:
        @app.get("/v8008a/context-capture-config.json")
        def v8008a_context_capture_config_json():
            return JSONResponse({"version": VERSION, "safety": SAFETY, "fields": FIELDS})

    if "/v8008a/selftest.json" not in existing:
        @app.get("/v8008a/selftest.json")
        def v8008a_selftest_json():
            return JSONResponse(_selftest())

    if "/v8008a/context-capture" not in existing:
        @app.get("/v8008a/context-capture", response_class=HTMLResponse)
        def v8008a_context_capture_page(limit: int = 500):
            return HTMLResponse(_html_report(build_report(limit)))

    # Narrow HTML link injector for the two master pages only.
    marker = "V8008A Context Capture"

    @app.middleware("http")
    async def v8008a_master_link_injector(request: Request, call_next):
        response = await call_next(request)
        if request.url.path not in {"/master", "/master-ai-review"}:
            return response
        content_type = str(response.headers.get("content-type", ""))
        if "text/html" not in content_type.lower():
            return response
        try:
            body = b""
            async for chunk in response.body_iterator:
                body += chunk
            text = body.decode("utf-8", errors="replace")
            if marker not in text:
                card = (
                    "<div style='background:#101c2d;border:1px solid #29415f;"
                    "border-radius:14px;padding:14px;margin:14px 0;color:#e5eefb'>"
                    "<b>V8008A Context Capture</b><br>"
                    "Observe-only Kontextfelder für Regime, Range, Struktur, Entry und Impuls. "
                    "<a style='color:#93c5fd' href='/v8008a/context-capture'>Öffnen</a>"
                    "</div>"
                )
                text = text.replace("</body>", card + "</body>") if "</body>" in text else text + card
            headers = dict(response.headers)
            headers.pop("content-length", None)
            headers.pop("content-encoding", None)
            return HTMLResponse(
                content=text,
                status_code=response.status_code,
                headers=headers,
            )
        except Exception:
            return response
