from __future__ import annotations

import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

VERSION = "V8008A-CONTEXT-CAPTURE"


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly 1 anchor, found {count}")
    return text.replace(old, new, 1)


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: apply_pine_patch.py <pine-file>", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        raise FileNotFoundError(path)
    original = path.read_text(encoding="utf-8")
    if '"context_capture_version":' in original or "V8008A_CONTEXT_CAPTURE_BEGIN" in original:
        print("Pine patch already present; no change.")
        return 0

    text = original

    bias_anchor = "string regimeBias = bias1w\n"
    bias_insert = """string regimeBias = bias1w  // Legacy compatibility: this is the 1W bias, not the market regime.\nstring weeklyBias = bias1w\n"""
    text = replace_once(text, bias_anchor, bias_insert, "weekly bias anchor")

    liquidity_anchor = 'string liquidityState = sweepLow ? "sweep_low" : sweepHigh ? "sweep_high" : "none"\n'
    context_block = r'''string liquidityState = sweepLow ? "sweep_low" : sweepHigh ? "sweep_high" : "none"

// V8008A_CONTEXT_CAPTURE_BEGIN
// Observe-only metadata. These fields do not change candidates, scores or routing.
int contextRangeLookback = 64
float contextRangeHigh = ta.highest(high[1], contextRangeLookback)
float contextRangeLow = ta.lowest(low[1], contextRangeLookback)
float contextRangeMid = not na(contextRangeHigh) and not na(contextRangeLow) ? (contextRangeHigh + contextRangeLow) / 2.0 : na
float contextRangeWidth = not na(contextRangeHigh) and not na(contextRangeLow) ? contextRangeHigh - contextRangeLow : na
float contextRangePosition = not na(contextRangeWidth) and contextRangeWidth > 0 ? f_clamp((close - contextRangeLow) / contextRangeWidth, 0.0, 1.0) : na
string rangeLocation = na(contextRangePosition) ? "UNKNOWN" : contextRangePosition <= 0.35 ? "DISCOUNT" : contextRangePosition >= 0.65 ? "PREMIUM" : "MIDRANGE"

bool contextEmaTrendUp = ema20 > ema50 and ema50 > ema200 and ema20 > ema20[5] and ema50 >= ema50[5]
bool contextEmaTrendDown = ema20 < ema50 and ema50 < ema200 and ema20 < ema20[5] and ema50 <= ema50[5]
int contextBarsSinceExternalBreak = nz(ta.barssince(bullishBreak or bearishBreak), 10000)
bool contextBiasMixed = tacticalLayerBias == "mixed" or htfLayerBias == "mixed"
string marketRegime = contextEmaTrendUp and structureDir == 1 and not contextBiasMixed ? "TREND_UP" : contextEmaTrendDown and structureDir == -1 and not contextBiasMixed ? "TREND_DOWN" : contextBarsSinceExternalBreak <= 3 or contextBiasMixed ? "TRANSITION" : "RANGE"
string externalStructureState = structureState
string structureScopeNow = bullishBreak or bearishBreak ? "EXTERNAL" : iBullBreak or iBearBreak ? "INTERNAL" : "STATE_ONLY"
string impulseState = candleRangeAtr >= 1.00 and bodyAtr >= 0.60 ? "STRONG" : candleRangeAtr < 0.45 or bodyAtr < 0.20 ? "WEAK" : "NORMAL"
string entryQuality = meanDistAtr <= 0.50 ? "FRESH" : meanDistAtr <= 1.00 ? "VALID" : "LATE"
// V8008A_CONTEXT_CAPTURE_END
'''
    text = replace_once(text, liquidity_anchor, context_block, "context calculation anchor")

    function_anchor = '''    string tradeBias = direction == "LONG" ? (structureDir == 1 ? "structure_long" : "reaction_long") : (structureDir == -1 ? "structure_short" : "reaction_short")\n'''
    function_insert = '''    string tradeBias = direction == "LONG" ? (structureDir == 1 ? "structure_long" : "reaction_long") : (structureDir == -1 ? "structure_short" : "reaction_short")\n    bool insideSignalZone = not na(zoneTop) and not na(zoneBot) and close >= zoneBot and close <= zoneTop\n    float zoneDistanceAtr = na(zoneTop) or na(zoneBot) or atr <= 0 ? na : insideSignalZone ? 0.0 : close < zoneBot ? (zoneBot - close) / atr : (close - zoneTop) / atr\n    string zoneLocation = na(zoneTop) or na(zoneBot) ? "NO_ZONE" : insideSignalZone ? "INSIDE_ZONE" : zoneDistanceAtr <= 0.25 ? "NEAR_ZONE" : "OUTSIDE_ZONE"\n'''
    text = replace_once(text, function_anchor, function_insert, "payload local context anchor")

    payload_anchor = '''     "\\\"regime_bias\\\":" + f_q(regimeBias) + "," +\n     "\\\"structure_state\\\":" + f_q(structureState) + "," +\n'''
    payload_insert = '''     "\\\"regime_bias\\\":" + f_q(regimeBias) + "," +\n     "\\\"weekly_bias\\\":" + f_q(weeklyBias) + "," +\n     "\\\"market_regime\\\":" + f_q(marketRegime) + "," +\n     "\\\"regime_source\\\":\\\"EMA_STRUCTURE_V8008A\\\"," +\n     "\\\"external_structure_state\\\":" + f_q(externalStructureState) + "," +\n     "\\\"structure_scope\\\":" + f_q(structureScopeNow) + "," +\n     "\\\"range_high\\\":" + f_num(contextRangeHigh) + "," +\n     "\\\"range_low\\\":" + f_num(contextRangeLow) + "," +\n     "\\\"range_mid\\\":" + f_num(contextRangeMid) + "," +\n     "\\\"range_position\\\":" + f_num(contextRangePosition) + "," +\n     "\\\"range_location\\\":" + f_q(rangeLocation) + "," +\n     "\\\"premium_discount_state\\\":" + f_q(rangeLocation) + "," +\n     "\\\"zone_location\\\":" + f_q(zoneLocation) + "," +\n     "\\\"distance_to_zone_atr\\\":" + f_num(zoneDistanceAtr) + "," +\n     "\\\"entry_quality\\\":" + f_q(entryQuality) + "," +\n     "\\\"impulse_state\\\":" + f_q(impulseState) + "," +\n     "\\\"distance_to_mean_atr\\\":" + f_num(meanDistAtr) + "," +\n     "\\\"context_capture_version\\\":\\\"V8008A-CONTEXT-CAPTURE\\\"," +\n     "\\\"structure_state\\\":" + f_q(structureState) + "," +\n'''
    text = replace_once(text, payload_anchor, payload_insert, "payload field anchor")

    text = text.replace('table.cell(dash, 0, 4, "1W Regime")', 'table.cell(dash, 0, 4, "1W Bias")')

    required = (
        "V8008A_CONTEXT_CAPTURE_BEGIN",
        '\\"market_regime\\"',
        '\\"external_structure_state\\"',
        '\\"structure_scope\\"',
        '\\"range_location\\"',
        '\\"entry_quality\\"',
        '\\"impulse_state\\"',
        '\\"context_capture_version\\"',
    )
    missing = [needle for needle in required if needle not in text]
    if missing:
        raise RuntimeError(f"post-patch verification failed: {missing}")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(path.name + f".bak_v8008a_{stamp}")
    shutil.copy2(path, backup)
    path.write_text(text, encoding="utf-8")
    print(f"Patched: {path}")
    print(f"Backup:  {backup}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
