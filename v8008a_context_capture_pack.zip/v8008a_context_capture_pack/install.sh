#!/usr/bin/env bash
set -euo pipefail

PROJECT="/opt/tradingbot_v6000"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PINE="$PROJECT/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8008a_before_${STAMP}"

cd "$PROJECT"
echo "=== V8008A CONTEXT CAPTURE INSTALL ==="

mkdir -p "$BACKUP/app" "$BACKUP/pine"
cp -a app/main.py "$BACKUP/app/main.py"
[ -f app/v8008a_context_capture.py ] && cp -a app/v8008a_context_capture.py "$BACKUP/app/" || true
cp -a "$PINE" "$BACKUP/pine/"

echo "[1] Pine Context-Payload patchen"
python3 "$PACK_DIR/apply_pine_patch.py" "$PINE"

echo "[2] Observe-only Servermodul installieren"
cp -a "$PACK_DIR/app/v8008a_context_capture.py" app/v8008a_context_capture.py

MARK_BEGIN="# V8008A_CONTEXT_CAPTURE_INSTALL_BEGIN"
MARK_END="# V8008A_CONTEXT_CAPTURE_INSTALL_END"
if ! grep -qF "$MARK_BEGIN" app/main.py; then
cat >> app/main.py <<'PY'

# V8008A_CONTEXT_CAPTURE_INSTALL_BEGIN
try:
    from app.v8008a_context_capture import install_v8008a_context_capture
    install_v8008a_context_capture(app)
    print("[V8008A] Context Capture routes installed (observe-only; routing unchanged).")
except Exception as _v8008a_error:
    print("[V8008A] install error:", _v8008a_error)
# V8008A_CONTEXT_CAPTURE_INSTALL_END
PY
fi

echo "[3] Statische Prüfungen"
python3 -m py_compile app/v8008a_context_capture.py app/main.py
python3 - <<'PY'
from pathlib import Path
p = Path('pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine')
t = p.read_text(encoding='utf-8')
needles = [
    'V8008A_CONTEXT_CAPTURE_BEGIN',
    '\\"market_regime\\"',
    '\\"external_structure_state\\"',
    '\\"structure_scope\\"',
    '\\"range_location\\"',
    '\\"entry_quality\\"',
    '\\"impulse_state\\"',
    '\\"context_capture_version\\"',
]
missing = [x for x in needles if x not in t]
if missing:
    raise SystemExit('Missing Pine markers: ' + repr(missing))
assert t.count('V8008A_CONTEXT_CAPTURE_BEGIN') == 1
assert t.count('V8008A_CONTEXT_CAPTURE_END') == 1
assert 'table.cell(dash, 0, 4, "1W Bias")' in t
print('Pine structural check: PASS')
PY

echo "[4] Docker neu bauen und starten"
docker compose up -d --build

echo "[5] Auf Health warten"
for i in $(seq 1 90); do
  code="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/health || true)"
  if [ "$code" = "200" ]; then break; fi
  sleep 1
done

if [ "$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/health || true)" != "200" ]; then
  echo "FEHLER: /health nicht 200"
  docker logs --tail 150 tradingbot || true
  exit 1
fi

echo "[6] Routen"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8008a/context-capture \
  /v8008a/context-capture.json \
  /v8008a/context-capture-config.json \
  /v8008a/selftest.json \
  /v8004/selftest.json \
  /v8006/calendar-execution-audit.json \
  /v8007/selftest.json
do
  printf '%s -> ' "$route"
  curl -sS -o /dev/null -w '%{http_code}\n' "http://127.0.0.1$route"
done

echo "[7] V8008A Selftest"
curl -sS http://127.0.0.1/v8008a/selftest.json | python3 -m json.tool

echo "[8] Bestehende Router-/Kalender-Selftests"
python3 - <<'PY'
import json, urllib.request
for url in (
    'http://127.0.0.1/v8004/selftest.json',
    'http://127.0.0.1/v8006/calendar-execution-audit.json',
    'http://127.0.0.1/v8007/selftest.json',
):
    with urllib.request.urlopen(url, timeout=20) as r:
        d=json.load(r)
    print(url, 'OK=', d.get('ok'))
    if not d.get('ok'):
        raise SystemExit(1)
PY

echo "[9] Safetycheck"
python3 - <<'PY'
import json, urllib.request
with urllib.request.urlopen('http://127.0.0.1/v8008a/context-capture-config.json', timeout=20) as r:
    d=json.load(r)
s=d['safety']
assert s['observe_only'] is True
assert s['enforce'] is False
assert s['live_rule_changes'] is False
assert s['auto_blocking'] is False
assert s['auto_filtering'] is False
assert s['additional_db_writes'] is False
assert s['broker_auto_execution'] is False
assert s['routing_changed'] is False
print('Observe-only:', s['observe_only'])
print('Routing changed:', s['routing_changed'])
print('Additional DB writes:', s['additional_db_writes'])
print('Broker Auto Execution:', s['broker_auto_execution'])
PY

echo "[10] Master-Integration"
curl -sS http://127.0.0.1/master | grep -qF 'V8008A Context Capture' && echo '/master enthält V8008A'
curl -sS http://127.0.0.1/master-ai-review | grep -qF 'V8008A Context Capture' && echo '/master-ai-review enthält V8008A'

echo "[11] Fehlercheck"
ERR_COUNT="$(docker logs --since 10m tradingbot 2>&1 | grep -Eic 'Traceback|Exception|Internal Server Error|HTTP/1\.[01]" 500|install error' || true)"
echo "Aktuelle Fehler-Muster: $ERR_COUNT"
if [ "$ERR_COUNT" -ne 0 ]; then
  docker logs --since 10m tradingbot 2>&1 | grep -Ei 'Traceback|Exception|Internal Server Error|HTTP/1\.[01]" 500|install error' | tail -80 || true
  exit 1
fi

echo "=== V8008A INSTALLATION FERTIG ==="
echo "Backup: $BACKUP"
echo "Pine-Payload erweitert: market_regime, external/internal scope, range location, zone location, entry quality, impulse state"
echo "V8004/V8006/V8007 Routing: UNVERÄNDERT"
echo "Observe-only: TRUE"
echo "Auto Blocking/Filtering: FALSE"
echo "Broker Auto Execution: FALSE"
echo "WICHTIG: Das aktualisierte Pine-Script muss noch in TradingView eingefügt und die Alerts neu erstellt werden."
