# V8011.1 Ingress Monitoring + Dead Letter

Transport-only update for the existing V8011 ingress.

Adds:
- GREEN/YELLOW/RED queue monitor with configurable thresholds.
- Dead-letter status for terminal delivery failures.
- No automatic dead-letter requeue.
- Stale PROCESSING recovery every 60 seconds.
- Worker and cleanup heartbeat timestamps.
- 24-hour endpoint/status and backend latency summaries.
- Corrected diagnostic script that does not report HTTP 200 webhook lines as errors.

Unchanged:
- `app/main.py`
- V8004, V8006, V8007
- Canonical Pine V8001.4D
- Existing trading database schema
- Broker auto execution remains false
- Webhook token enforcement remains off until a separate controlled cutover

New endpoints:
- `/v8011/monitor.json`
- `/v8011/dead-letter.json`

The ingress queue remains:
- `/opt/tradingbot_v6000/data/v8011_ingress.sqlite3`
