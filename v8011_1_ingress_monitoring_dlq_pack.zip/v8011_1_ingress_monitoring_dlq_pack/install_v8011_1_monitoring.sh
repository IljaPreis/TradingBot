#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="V8011.1-INGRESS-MONITORING-DLQ-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8011_1_before_${TS}"
LOG="/root/v8011_1_install_${TS}.log"

EXPECTED_MAIN_SHA="eed627822505f0f3b77cc23b2b34afc1bcfd73fbb2abb66372373c9d61463582"
EXPECTED_V8004_SHA="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006_SHA="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007_SHA="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE_SHA="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"
EXPECTED_V8011_OLD_INGRESS_SHA="833d522b9b2d3aaa87f0bb0f6fe2c4e9dd948b5b2c23b2b16fa0b9d1ee468b7a"
EXPECTED_V8011_OLD_COMPOSE_SHA="e067b157f5718e7b569c4d6fd6cf93dd40bff48d261194f842cbf7d4a71ce04c"

ROLLBACK_ARMED=0
exec > >(tee -a "$LOG") 2>&1

sha() { sha256sum "$1" | awk '{print $1}'; }
die() { echo "FATAL: $*" >&2; exit 1; }

wait_http_200() {
  local url="$1" attempts="${2:-75}" sleep_s="${3:-2}" i code
  for i in $(seq 1 "$attempts"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    echo "WAIT [$i/$attempts] $url status=${code:-none}"
    sleep "$sleep_s"
  done
  return 1
}

rollback() {
  local rc=$?
  trap - ERR
  if [[ "$ROLLBACK_ARMED" != "1" ]]; then exit "$rc"; fi
  echo
  echo "=== V8011.1 ROLLBACK START ==="
  cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml" || true
  cp -a "$BACKUP/v8011_ingress.py" "$BASE/app/v8011_ingress.py" || true
  if [[ -f "$BACKUP/v8011_ingress_check.sh" ]]; then
    cp -a "$BACKUP/v8011_ingress_check.sh" "$BASE/ops/v8011_ingress_check.sh" || true
  fi
  if [[ -f "$BACKUP/README_V8011.md" ]]; then
    cp -a "$BACKUP/README_V8011.md" "$BASE/README_V8011.md" || true
  fi
  rm -f "$BASE/README_V8011_1.md"
  cd "$BASE"
  docker compose config >/dev/null 2>&1 || true
  docker compose up -d --build --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8011.1 ROLLBACK ENDE ==="
  exit "$rc"
}
trap rollback ERR

cat <<EOF
================================================================================
$VERSION INSTALL
================================================================================
Generated UTC: $(date -u --iso-8601=seconds)
Project: $BASE
Package: $PACKAGE_DIR

Safety:
  Transport / monitoring update only: YES
  Existing trading DB schema changes: 0
  V8004/V8006/V8007 changes: 0
  Pine changes: 0
  Live scoring/routing changes: 0
  Webhook token cutover: 0
  Broker auto execution: FALSE
EOF

[[ -d "$BASE" ]] || die "Project not found"
for f in \
  "$BASE/app/main.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/docker-compose.yml" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"
do
  [[ -f "$f" ]] || die "Missing production file: $f"
done

for f in \
  "$PACKAGE_DIR/app/v8011_ingress.py" \
  "$PACKAGE_DIR/docker-compose.v8011_1.yml" \
  "$PACKAGE_DIR/ops/v8011_ingress_check.sh" \
  "$PACKAGE_DIR/README_V8011_1.md" \
  "$PACKAGE_DIR/MANIFEST.sha256"
do
  [[ -f "$f" ]] || die "Missing package file: $f"
done

echo
echo "[1] Verify package hashes"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)

NEW_INGRESS_SHA="$(sha "$PACKAGE_DIR/app/v8011_ingress.py")"
NEW_COMPOSE_SHA="$(sha "$PACKAGE_DIR/docker-compose.v8011_1.yml")"

echo
echo "[2] Verify protected production baseline"
MAIN_SHA="$(sha "$BASE/app/main.py")"
V8004_SHA="$(sha "$BASE/app/v8004_quality_router.py")"
V8006_SHA="$(sha "$BASE/app/v8006_calendar_execution_correction.py")"
V8007_SHA="$(sha "$BASE/app/v8007_v8001_gate_bridge.py")"
PINE_SHA="$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")"
CURRENT_INGRESS_SHA="$(sha "$BASE/app/v8011_ingress.py")"
CURRENT_COMPOSE_SHA="$(sha "$BASE/docker-compose.yml")"

printf 'main.py: %s\nV8004: %s\nV8006: %s\nV8007: %s\nPine: %s\nIngress current: %s\nCompose current: %s\n' \
  "$MAIN_SHA" "$V8004_SHA" "$V8006_SHA" "$V8007_SHA" "$PINE_SHA" \
  "$CURRENT_INGRESS_SHA" "$CURRENT_COMPOSE_SHA"

[[ "$MAIN_SHA" == "$EXPECTED_MAIN_SHA" ]] || die "main.py mismatch"
[[ "$V8004_SHA" == "$EXPECTED_V8004_SHA" ]] || die "V8004 mismatch"
[[ "$V8006_SHA" == "$EXPECTED_V8006_SHA" ]] || die "V8006 mismatch"
[[ "$V8007_SHA" == "$EXPECTED_V8007_SHA" ]] || die "V8007 mismatch"
[[ "$PINE_SHA" == "$EXPECTED_PINE_SHA" ]] || die "Pine mismatch"

if [[ "$CURRENT_INGRESS_SHA" != "$EXPECTED_V8011_OLD_INGRESS_SHA" && "$CURRENT_INGRESS_SHA" != "$NEW_INGRESS_SHA" ]]; then
  die "Unexpected V8011 ingress baseline"
fi
if [[ "$CURRENT_COMPOSE_SHA" != "$EXPECTED_V8011_OLD_COMPOSE_SHA" && "$CURRENT_COMPOSE_SHA" != "$NEW_COMPOSE_SHA" ]]; then
  die "Unexpected V8011 compose baseline"
fi

echo
echo "[3] Queue DB precheck and rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/app/v8011_ingress.py" "$BACKUP/v8011_ingress.py"
[[ -f "$BASE/ops/v8011_ingress_check.sh" ]] && cp -a "$BASE/ops/v8011_ingress_check.sh" "$BACKUP/v8011_ingress_check.sh"
[[ -f "$BASE/README_V8011.md" ]] && cp -a "$BASE/README_V8011.md" "$BACKUP/README_V8011.md"

python3 - "$BASE/data/v8011_ingress.sqlite3" "$BACKUP/v8011_ingress.sqlite3" <<'PY'
import sqlite3, sys
src, dst = sys.argv[1:3]
with sqlite3.connect(src) as source, sqlite3.connect(dst) as target:
    source.backup(target)
    qc=target.execute("PRAGMA quick_check").fetchone()[0]
    print("queue_backup:", dst)
    print("quick_check:", qc)
    assert str(qc).lower()=="ok"
PY

ROLLBACK_ARMED=1

echo
echo "[4] Install V8011.1 files"
install -m 0644 "$PACKAGE_DIR/app/v8011_ingress.py" "$BASE/app/v8011_ingress.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8011_1.yml" "$BASE/docker-compose.yml"
install -m 0755 "$PACKAGE_DIR/ops/v8011_ingress_check.sh" "$BASE/ops/v8011_ingress_check.sh"
install -m 0644 "$PACKAGE_DIR/README_V8011_1.md" "$BASE/README_V8011_1.md"

cd "$BASE"
python3 -m py_compile app/v8011_ingress.py
bash -n ops/v8011_ingress_check.sh
docker compose config >/dev/null

echo
echo "[5] Protected hashes remain unchanged"
[[ "$(sha app/main.py)" == "$MAIN_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]

echo
echo "[6] Build shared V8011.1 image"
docker compose build tradingbot

echo
echo "[7] Start backend + ingress"
docker compose up -d --remove-orphans

wait_http_200 "http://127.0.0.1/health" 75 2 || die "Public health did not recover"
wait_http_200 "http://127.0.0.1/v8011/selftest.json" 75 2 || die "Selftest did not recover"

echo
echo "[8] Validate selftest and monitor schema"
curl -fsS --max-time 20 http://127.0.0.1/v8011/selftest.json > "/tmp/v8011_1_selftest_${TS}.json"
curl -fsS --max-time 20 http://127.0.0.1/v8011/monitor.json > "/tmp/v8011_1_monitor_${TS}.json"
curl -fsS --max-time 20 http://127.0.0.1/v8011/dead-letter.json > "/tmp/v8011_1_dlq_${TS}.json"

python3 - "/tmp/v8011_1_selftest_${TS}.json" "/tmp/v8011_1_monitor_${TS}.json" "/tmp/v8011_1_dlq_${TS}.json" <<'PY'
import json, sys
selftest=json.load(open(sys.argv[1]))
monitor=json.load(open(sys.argv[2]))
dlq=json.load(open(sys.argv[3]))
assert selftest.get("ok") is True, selftest
assert selftest.get("version")=="V8011.1-INGRESS-MONITORING-DLQ-V1", selftest
assert selftest.get("queue_db_quick_check") is True, selftest
assert selftest.get("backend_ok") is True, selftest
assert selftest.get("worker_alive") is True, selftest
assert selftest.get("cleanup_alive") is True, selftest
assert monitor.get("monitor",{}).get("status") in {"GREEN","YELLOW","RED"}, monitor
assert "dead_letter_24h" in monitor.get("summary",{}), monitor
assert dlq.get("automatic_requeue") is False, dlq
for doc in (selftest, monitor):
    safety=doc.get("safety") or {}
    assert safety.get("v8004_changed") is False
    assert safety.get("v8006_changed") is False
    assert safety.get("v8007_changed") is False
    assert safety.get("pine_changed") is False
    assert safety.get("broker_auto_execution") is False
print(json.dumps({
    "selftest": selftest,
    "monitor": monitor.get("monitor"),
    "summary": monitor.get("summary"),
    "dead_letter": {
        "total": dlq.get("dead_letter_total"),
        "last_24h": dlq.get("dead_letter_24h"),
    },
}, indent=2, ensure_ascii=False))
PY

echo
echo "[9] Critical route status"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/ingress.json \
  /v8011/monitor.json \
  /v8011/dead-letter.json \
  /v8011/selftest.json
do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 30 "http://127.0.0.1${route}" || true)"
  printf '%-48s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || false
done

echo
echo "[10] Fast rejection path"
RESULT="$(curl -sS -o "/tmp/v8011_1_invalid_${TS}.json" -w 'status=%{http_code} total=%{time_total}' --max-time 5 -H 'Content-Type: application/json' --data-binary '{invalid-json' http://127.0.0.1/webhook/price || true)"
echo "$RESULT"
grep -q 'status=400' <<< "$RESULT"

echo
echo "[11] Queue DB final quick check"
docker exec tradingbot_ingress python - <<'PY'
import sqlite3
p="/app/data/v8011_ingress.sqlite3"
with sqlite3.connect(p) as con:
    qc=con.execute("PRAGMA quick_check").fetchone()[0]
    print("quick_check:", qc)
    print("status_counts:", dict(con.execute("SELECT status,COUNT(*) FROM v8011_ingress_queue GROUP BY status")))
    assert str(qc).lower()=="ok"
PY

echo
echo "[12] Final protected hashes"
[[ "$(sha app/main.py)" == "$MAIN_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]
[[ "$(sha app/v8011_ingress.py)" == "$NEW_INGRESS_SHA" ]]
[[ "$(sha docker-compose.yml)" == "$NEW_COMPOSE_SHA" ]]

docker compose ps

cat > "$BACKUP/V8011_1_INSTALL_MANIFEST.txt" <<EOF
Version: $VERSION
Installed UTC: $(date -u --iso-8601=seconds)
Backup: $BACKUP
Install log: $LOG
app/main.py: $MAIN_SHA
V8004: $V8004_SHA
V8006: $V8006_SHA
V8007: $V8007_SHA
Pine: $PINE_SHA
V8011.1 ingress: $NEW_INGRESS_SHA
V8011.1 compose: $NEW_COMPOSE_SHA
Existing trading DB schema changed: FALSE
Live scoring/routing changed: FALSE
Webhook token cutover: FALSE
Broker auto execution: FALSE
EOF

ROLLBACK_ARMED=0
trap - ERR

echo
cat <<EOF
================================================================================
V8011.1 INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Dashboard:   http://91.107.237.214/v8011/ingress
Monitor:     http://91.107.237.214/v8011/monitor.json
Dead Letter: http://91.107.237.214/v8011/dead-letter.json
Selftest:    http://91.107.237.214/v8011/selftest.json

Added:
  Queue warning thresholds
  GREEN/YELLOW/RED monitor
  Dead-letter protection
  Stale PROCESSING recovery
  Worker/cleanup heartbeats
  Corrected diagnostic log filtering

UNCHANGED:
  app/main.py
  V8004 / V8006 / V8007
  Canonical Pine
  Existing trading DB schema
  Webhook token enforcement remains OFF
  Broker auto execution FALSE
EOF
