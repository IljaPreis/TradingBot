#!/usr/bin/env bash
set -euo pipefail

BASE="/opt/tradingbot_v6000"
cd "$BASE"

json_get() {
  curl -fsS --max-time 20 "http://127.0.0.1$1"
}

echo "=== V8011.1 INGRESS MONITORING CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"
echo

echo "[1] Containers"
docker compose ps
echo

echo "[2] Public health"
json_get /health | python3 -m json.tool
echo

echo "[3] Infrastructure selftest"
json_get /v8011/selftest.json | python3 -m json.tool
echo

echo "[4] Operational monitor"
json_get /v8011/monitor.json | python3 -c '
import json, sys
d=json.load(sys.stdin)
print(json.dumps({
  "version": d.get("version"),
  "monitor": d.get("monitor"),
  "summary": d.get("summary"),
  "runtime": d.get("runtime"),
  "safety": d.get("safety"),
}, indent=2, ensure_ascii=False))
'
echo

echo "[5] Dead-letter summary"
json_get /v8011/dead-letter.json | python3 -c '
import json, sys
d=json.load(sys.stdin)
print(json.dumps({
  "version": d.get("version"),
  "dead_letter_total": d.get("dead_letter_total"),
  "dead_letter_24h": d.get("dead_letter_24h"),
  "latest": (d.get("items") or [])[:5],
  "automatic_requeue": d.get("automatic_requeue"),
}, indent=2, ensure_ascii=False))
'
echo

echo "[6] Critical routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/ingress.json \
  /v8011/monitor.json \
  /v8011/dead-letter.json \
  /v8011/selftest.json
do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 30 "http://127.0.0.1${route}" || true)"
  printf '%-42s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || exit 1
done
echo

echo "[7] Queue DB"
docker exec tradingbot_ingress python - <<'PY'
import os, sqlite3
p="/app/data/v8011_ingress.sqlite3"
with sqlite3.connect(p) as con:
    qc=con.execute("PRAGMA quick_check").fetchone()[0]
    print("path:", p)
    print("size_bytes:", os.path.getsize(p))
    print("quick_check:", qc)
    assert str(qc).lower()=="ok"
    print("status_counts:")
    for status, n in con.execute("""
        SELECT status, COUNT(*)
        FROM v8011_ingress_queue
        GROUP BY status
        ORDER BY status
    ""):
        print(" ", status, n)
PY
echo

echo "[8] Actual ingress errors, last 2h"
docker logs --since 2h tradingbot_ingress 2>&1 \
  | grep -Ei 'V8011_(QUEUE_ERROR|DISPATCH_HTTP_ERROR|DISPATCH_EXCEPTION)|Traceback|CRITICAL|database is locked' \
  | tail -n 100 || true
echo

echo "[9] Actual backend errors, last 2h"
docker logs --since 2h tradingbot 2>&1 \
  | grep -Ei 'Traceback|CRITICAL|database is locked|OperationalError|IntegrityError|HTTP/[0-9.]+" (4|5)[0-9][0-9]' \
  | tail -n 100 || true
echo

echo "[10] Fast rejection latency"
curl -sS -o /tmp/v8011_1_invalid.json \
  -w 'status=%{http_code} total=%{time_total}s\n' \
  --max-time 5 \
  -H 'Content-Type: application/json' \
  --data-binary '{invalid-json' \
  http://127.0.0.1/webhook/price
cat /tmp/v8011_1_invalid.json
echo
echo

echo "[11] Host resources"
uptime
free -h
df -h "$BASE"
echo

echo "=== V8011.1 CHECK FERTIG ==="
