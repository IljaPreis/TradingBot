# V8011.2 Token Observe Cutover

Version: `V8011.2-TOKEN-OBSERVE-CUTOVER-V1`

## Zweck

Bereitet die Webhook-Authentifizierung kontrolliert vor, ohne bestehende
TradingView-Alerts zu unterbrechen.

Der Installer:

- erzeugt einen kryptografisch zufälligen Webhook-Token, falls noch keiner existiert,
- speichert ihn ausschließlich in `/opt/tradingbot_v6000/.env`,
- setzt `V8011_TOKEN_MODE=observe`,
- akzeptiert weiterhin Alerts mit und ohne Token,
- misst Token-Abdeckung nach Endpoint und Price-Markt,
- aktiviert **keine** Token-Erzwingung.

## Neue Routen

- `/v8011/token-readiness.json`
- `/v8011/token-probe`

## TradingView-Migration

Nach Installation kann der Token lokal auf dem Server ausgegeben werden:

```bash
cd /opt/tradingbot_v6000
TOKEN="$(sed -n 's/^V8011_WEBHOOK_TOKEN=//p' .env | tail -n 1)"
printf '?token=%s\n' "$TOKEN"
unset TOKEN
```

Für bestehende Alerts wird der Suffix an die Webhook-URL angehängt:

- Signal: `/webhook/tradingview?token=...`
- Heartbeat: `/webhook/price?token=...`

Während `observe` werden alte Alerts weiterhin angenommen. Enforcement erfolgt
später separat und nur nach vollständiger Readiness-Prüfung.

## Unverändert

- V8004, V8006, V8007
- kanonisches Pine V8001.4D
- `app/main.py`
- bestehende Trading-Datenbank
- Broker Auto Execution bleibt `FALSE`
