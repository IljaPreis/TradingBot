#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="V8011.2-TOKEN-OBSERVE-CUTOVER-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8011_2_before_${TS}"
LOG="/root/v8011_2_install_${TS}.log"

EXPECTED_MAIN_SHA="eed627822505f0f3b77cc23b2b34afc1bcfd73fbb2abb66372373c9d61463582"
EXPECTED_V8004_SHA="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006_SHA="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007_SHA="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE_SHA="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"
EXPECTED_V8011_1_INGRESS_SHA="42fb0fb1a5ac8895c7225c6f88904a226cc6e8620cbfaf3cef243e666960f05e"
EXPECTED_V8011_1_COMPOSE_SHA="967085c02af40bc826b708f49f8ce35f215f7818ef5a7af5236f249874b92853"
NEW_INGRESS_EXPECTED_SHA="0b50a8dcce8e0f2ef71dead1d5489bdd1c915b932acefa166eec656828806c8b"
NEW_COMPOSE_EXPECTED_SHA="966b45a9ae207d9225ee662a71543325a941137e857e65fd3d7a69dd38a24b43"

ROLLBACK_ARMED=0
exec > >(tee -a "$LOG") 2>&1

sha() { sha256sum "$1" | awk '{print $1}'; }
die() { echo "FATAL: $*" >&2; exit 1; }

wait_http_200() {
  local url="$1" attempts="${2:-75}" sleep_s="${3:-2}" i code
  for i in $(seq 1 "$attempts"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    echo "WAIT [$i/$attempts] $url status=${code:-none}"
    sleep "$sleep_s"
  done
  return 1
}

rollback() {
  local rc=$?
  trap - ERR
  if [[ "$ROLLBACK_ARMED" != "1" ]]; then exit "$rc"; fi
  echo
  echo "=== V8011.2 ROLLBACK START ==="
  cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml" || true
  cp -a "$BACKUP/v8011_ingress.py" "$BASE/app/v8011_ingress.py" || true
  cp -a "$BACKUP/v8011_ingress_check.sh" "$BASE/ops/v8011_ingress_check.sh" || true
  if [[ -f "$BACKUP/.env" ]]; then
    cp -a "$BACKUP/.env" "$BASE/.env" || true
    chmod 600 "$BASE/.env" || true
  fi
  rm -f "$BASE/README_V8011_2.md"
  cd "$BASE"
  docker compose config >/dev/null 2>&1 || true
  docker compose up -d --build --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8011.2 ROLLBACK ENDE ==="
  exit "$rc"
}
trap rollback ERR

cat <<EOF
================================================================================
$VERSION INSTALL
================================================================================
Generated UTC: $(date -u --iso-8601=seconds)
Project: $BASE
Package: $PACKAGE_DIR

Safety:
  Token mode after install: OBSERVE
  Existing alerts without token remain accepted: YES
  Token enforcement after install: FALSE
  Existing trading DB schema changes: 0
  Ingress queue schema extension: token audit only
  V8004/V8006/V8007 changes: 0
  Canonical Pine changes: 0
  Live scoring/routing changes: 0
  Broker auto execution: FALSE
EOF

[[ -d "$BASE" ]] || die "Project not found"
for f in \
  "$BASE/app/main.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/docker-compose.yml" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine" \
  "$BASE/.env"
do
  [[ -f "$f" ]] || die "Missing production file: $f"
done

for f in \
  "$PACKAGE_DIR/app/v8011_ingress.py" \
  "$PACKAGE_DIR/docker-compose.v8011_2.yml" \
  "$PACKAGE_DIR/ops/v8011_ingress_check.sh" \
  "$PACKAGE_DIR/README_V8011_2.md" \
  "$PACKAGE_DIR/MANIFEST.sha256"
do
  [[ -f "$f" ]] || die "Missing package file: $f"
done

echo
echo "[1] Verify package hashes"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)

NEW_INGRESS_SHA="$(sha "$PACKAGE_DIR/app/v8011_ingress.py")"
NEW_COMPOSE_SHA="$(sha "$PACKAGE_DIR/docker-compose.v8011_2.yml")"
[[ "$NEW_INGRESS_SHA" == "$NEW_INGRESS_EXPECTED_SHA" ]] || die "New ingress package SHA mismatch"
[[ "$NEW_COMPOSE_SHA" == "$NEW_COMPOSE_EXPECTED_SHA" ]] || die "New compose package SHA mismatch"

echo
echo "[2] Verify protected production baseline"
MAIN_SHA="$(sha "$BASE/app/main.py")"
V8004_SHA="$(sha "$BASE/app/v8004_quality_router.py")"
V8006_SHA="$(sha "$BASE/app/v8006_calendar_execution_correction.py")"
V8007_SHA="$(sha "$BASE/app/v8007_v8001_gate_bridge.py")"
PINE_SHA="$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")"
CURRENT_INGRESS_SHA="$(sha "$BASE/app/v8011_ingress.py")"
CURRENT_COMPOSE_SHA="$(sha "$BASE/docker-compose.yml")"

printf 'main.py: %s\nV8004: %s\nV8006: %s\nV8007: %s\nPine: %s\nIngress current: %s\nCompose current: %s\n' \
  "$MAIN_SHA" "$V8004_SHA" "$V8006_SHA" "$V8007_SHA" "$PINE_SHA" \
  "$CURRENT_INGRESS_SHA" "$CURRENT_COMPOSE_SHA"

[[ "$MAIN_SHA" == "$EXPECTED_MAIN_SHA" ]] || die "main.py mismatch"
[[ "$V8004_SHA" == "$EXPECTED_V8004_SHA" ]] || die "V8004 mismatch"
[[ "$V8006_SHA" == "$EXPECTED_V8006_SHA" ]] || die "V8006 mismatch"
[[ "$V8007_SHA" == "$EXPECTED_V8007_SHA" ]] || die "V8007 mismatch"
[[ "$PINE_SHA" == "$EXPECTED_PINE_SHA" ]] || die "Pine mismatch"

if [[ "$CURRENT_INGRESS_SHA" != "$EXPECTED_V8011_1_INGRESS_SHA" && "$CURRENT_INGRESS_SHA" != "$NEW_INGRESS_SHA" ]]; then
  die "Unexpected V8011 ingress baseline"
fi
if [[ "$CURRENT_COMPOSE_SHA" != "$EXPECTED_V8011_1_COMPOSE_SHA" && "$CURRENT_COMPOSE_SHA" != "$NEW_COMPOSE_SHA" ]]; then
  die "Unexpected V8011 compose baseline"
fi

echo
echo "[3] Queue DB precheck and rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/app/v8011_ingress.py" "$BACKUP/v8011_ingress.py"
cp -a "$BASE/ops/v8011_ingress_check.sh" "$BACKUP/v8011_ingress_check.sh"
cp -a "$BASE/.env" "$BACKUP/.env"
chmod 600 "$BACKUP/.env"

python3 - "$BASE/data/v8011_ingress.sqlite3" "$BACKUP/v8011_ingress.sqlite3" <<'PY'
import sqlite3, sys
src, dst = sys.argv[1:3]
with sqlite3.connect(src) as source, sqlite3.connect(dst) as target:
    source.backup(target)
    qc=target.execute("PRAGMA quick_check").fetchone()[0]
    print("queue_backup:", dst)
    print("quick_check:", qc)
    assert str(qc).lower()=="ok"
PY

ROLLBACK_ARMED=1

echo
echo "[4] Configure secure token in OBSERVE mode"
python3 - "$BASE/.env" <<'PY'
from pathlib import Path
import secrets, sys

p=Path(sys.argv[1])
raw=p.read_text(encoding='utf-8', errors='replace') if p.exists() else ''
lines=raw.splitlines()
values={}
order=[]
for line in lines:
    if not line or line.lstrip().startswith('#') or '=' not in line:
        order.append((None,line))
        continue
    key,val=line.split('=',1)
    key=key.strip()
    values[key]=val
    order.append((key,None))

token=values.get('V8011_WEBHOOK_TOKEN','').strip().strip('"').strip("'")
if len(token) < 32:
    token=secrets.token_urlsafe(32)
values['V8011_WEBHOOK_TOKEN']=token
values['V8011_TOKEN_MODE']='observe'
values['V8011_ENFORCE_TOKEN']='false'
values.setdefault('V8011_TOKEN_AUDIT_RETENTION_DAYS','30')

seen=set()
out=[]
for key,literal in order:
    if key is None:
        out.append(literal)
        continue
    if key in seen:
        continue
    seen.add(key)
    out.append(f'{key}={values[key]}')
for key in ['V8011_WEBHOOK_TOKEN','V8011_TOKEN_MODE','V8011_ENFORCE_TOKEN','V8011_TOKEN_AUDIT_RETENTION_DAYS']:
    if key not in seen:
        out.append(f'{key}={values[key]}')
        seen.add(key)
p.write_text('\n'.join(out).rstrip()+'\n', encoding='utf-8')
print('token_configured: true')
print('token_mode: observe')
print('token_value_printed: false')
PY
chmod 600 "$BASE/.env"

echo
echo "[5] Install V8011.2 files"
install -m 0644 "$PACKAGE_DIR/app/v8011_ingress.py" "$BASE/app/v8011_ingress.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8011_2.yml" "$BASE/docker-compose.yml"
install -m 0755 "$PACKAGE_DIR/ops/v8011_ingress_check.sh" "$BASE/ops/v8011_ingress_check.sh"
install -m 0644 "$PACKAGE_DIR/README_V8011_2.md" "$BASE/README_V8011_2.md"

cd "$BASE"
python3 -m py_compile app/v8011_ingress.py
bash -n ops/v8011_ingress_check.sh
docker compose config >/dev/null

echo
echo "[6] Protected hashes remain unchanged"
[[ "$(sha app/main.py)" == "$MAIN_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]

echo
echo "[7] Build shared V8011.2 image"
docker compose build tradingbot

echo
echo "[8] Start backend + ingress"
docker compose up -d --remove-orphans

wait_http_200 "http://127.0.0.1/health" 75 2 || die "Public health did not recover"
wait_http_200 "http://127.0.0.1/v8011/selftest.json" 75 2 || die "Selftest did not recover"

echo
echo "[9] Validate selftest and token mode"
curl -fsS --max-time 20 http://127.0.0.1/v8011/selftest.json > "/tmp/v8011_2_selftest_${TS}.json"
curl -fsS --max-time 20 http://127.0.0.1/v8011/token-readiness.json > "/tmp/v8011_2_token_${TS}.json"

python3 - "/tmp/v8011_2_selftest_${TS}.json" "/tmp/v8011_2_token_${TS}.json" <<'PY'
import json, sys
selftest=json.load(open(sys.argv[1]))
token=json.load(open(sys.argv[2]))
assert selftest.get('ok') is True, selftest
assert selftest.get('version')=='V8011.2-TOKEN-OBSERVE-CUTOVER-V1', selftest
assert selftest.get('token_mode')=='observe', selftest
assert selftest.get('token_configured') is True, selftest
assert selftest.get('token_enforced') is False, selftest
r=token.get('token_readiness') or {}
assert r.get('mode')=='observe', token
assert r.get('configured') is True, token
assert r.get('enforced') is False, token
assert r.get('enforcement_is_manual') is True, token
for doc in (selftest, token):
    safety=doc.get('safety') or {}
    assert safety.get('v8004_changed') is False
    assert safety.get('v8006_changed') is False
    assert safety.get('v8007_changed') is False
    assert safety.get('pine_changed') is False
    assert safety.get('broker_auto_execution') is False
print(json.dumps({
    'selftest_ok': selftest.get('ok'),
    'version': selftest.get('version'),
    'token_mode': selftest.get('token_mode'),
    'token_configured': selftest.get('token_configured'),
    'token_enforced': selftest.get('token_enforced'),
    'ready_for_enforcement': r.get('ready_for_enforcement'),
}, indent=2))
PY

echo
echo "[10] Token probe tests without printing secret"
NO_TOKEN="$(curl -fsS --max-time 10 -H 'Content-Type: application/json' --data '{}' http://127.0.0.1/v8011/token-probe)"
BAD_TOKEN="$(curl -fsS --max-time 10 -H 'Content-Type: application/json' -H 'X-Webhook-Token: definitely-wrong' --data '{}' http://127.0.0.1/v8011/token-probe)"
TOKEN_VALUE="$(sed -n 's/^V8011_WEBHOOK_TOKEN=//p' "$BASE/.env" | tail -n 1)"
[[ -n "$TOKEN_VALUE" ]] || die "Token missing after configuration"
GOOD_TOKEN="$(curl -fsS --max-time 10 -H 'Content-Type: application/json' -H "X-Webhook-Token: $TOKEN_VALUE" --data '{}' http://127.0.0.1/v8011/token-probe)"
unset TOKEN_VALUE
python3 - "$NO_TOKEN" "$BAD_TOKEN" "$GOOD_TOKEN" <<'PY'
import json, sys
missing=json.loads(sys.argv[1])
invalid=json.loads(sys.argv[2])
valid=json.loads(sys.argv[3])
assert missing.get('token_status')=='MISSING', missing
assert invalid.get('token_status')=='INVALID', invalid
assert valid.get('token_status')=='VALID', valid
assert missing.get('would_be_accepted') is True
assert invalid.get('would_be_accepted') is True
assert valid.get('would_be_accepted') is True
print('missing_token_in_observe: ACCEPTED')
print('invalid_token_in_observe: ACCEPTED')
print('valid_token_in_observe: ACCEPTED')
print('secret_printed: FALSE')
PY

echo
echo "[11] Critical route status"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/ingress.json \
  /v8011/monitor.json \
  /v8011/dead-letter.json \
  /v8011/token-readiness.json \
  /v8011/selftest.json
do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 30 "http://127.0.0.1${route}" || true)"
  printf '%-48s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || false
done

echo
echo "[12] Queue DB token table and quick check"
docker exec tradingbot_ingress python - <<'PY'
import sqlite3
p='/app/data/v8011_ingress.sqlite3'
with sqlite3.connect(p) as con:
    qc=con.execute('PRAGMA quick_check').fetchone()[0]
    tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    print('quick_check:', qc)
    print('token_audit_table:', 'v8011_ingress_token_audit' in tables)
    assert str(qc).lower()=='ok'
    assert 'v8011_ingress_token_audit' in tables
PY

echo
echo "[13] Final protected hashes"
[[ "$(sha app/main.py)" == "$MAIN_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]
[[ "$(sha app/v8011_ingress.py)" == "$NEW_INGRESS_SHA" ]]
[[ "$(sha docker-compose.yml)" == "$NEW_COMPOSE_SHA" ]]
[[ "$(stat -c '%a' .env)" == "600" ]]

docker compose ps

cat > "$BACKUP/V8011_2_INSTALL_MANIFEST.txt" <<EOF
Version: $VERSION
Installed UTC: $(date -u --iso-8601=seconds)
Backup: $BACKUP
Install log: $LOG
app/main.py: $MAIN_SHA
V8004: $V8004_SHA
V8006: $V8006_SHA
V8007: $V8007_SHA
Pine: $PINE_SHA
V8011.2 ingress: $NEW_INGRESS_SHA
V8011.2 compose: $NEW_COMPOSE_SHA
Token configured: TRUE
Token mode: OBSERVE
Token enforced: FALSE
Secret printed to log: FALSE
Existing trading DB schema changed: FALSE
Live scoring/routing changed: FALSE
Broker auto execution: FALSE
EOF

ROLLBACK_ARMED=0
trap - ERR

echo
cat <<EOF
================================================================================
V8011.2 INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Dashboard:       http://91.107.237.214/v8011/ingress
Token readiness: http://91.107.237.214/v8011/token-readiness.json
Selftest:        http://91.107.237.214/v8011/selftest.json

Token:
  Configured: TRUE
  Mode: OBSERVE
  Enforcement: FALSE
  Existing alerts without token remain accepted: TRUE
  Token value was not printed to the install log.

UNCHANGED:
  app/main.py
  V8004 / V8006 / V8007
  Canonical Pine
  Existing trading DB schema
  Live scoring/routing
  Broker auto execution FALSE

NEXT:
  Add the token suffix to TradingView webhook URLs in controlled batches.
  Do not enable enforcement until token-readiness reports TRUE.
EOF
