#!/usr/bin/env bash
set -euo pipefail

BASE="/opt/tradingbot_v6000"
cd "$BASE"

json_get() {
  curl -fsS --max-time 20 "http://127.0.0.1$1"
}

echo "=== V8011.2 TOKEN OBSERVE CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"
echo

echo "[1] Containers"
docker compose ps
echo

echo "[2] Public health"
json_get /health | python3 -m json.tool
echo

echo "[3] Infrastructure selftest"
json_get /v8011/selftest.json | python3 -m json.tool
echo

echo "[4] Operational monitor"
json_get /v8011/monitor.json | python3 -c '
import json, sys
d=json.load(sys.stdin)
print(json.dumps({
  "version": d.get("version"),
  "monitor": d.get("monitor"),
  "summary": d.get("summary"),
  "runtime": d.get("runtime"),
  "safety": d.get("safety"),
}, indent=2, ensure_ascii=False))
'
echo

echo "[5] Token readiness – no secret printed"
json_get /v8011/token-readiness.json | python3 -c '
import json, sys
d=json.load(sys.stdin)
r=d.get("token_readiness") or {}
print(json.dumps({
  "version": d.get("version"),
  "mode": r.get("mode"),
  "configured": r.get("configured"),
  "enforced": r.get("enforced"),
  "counts_15m": r.get("counts_15m"),
  "price_active_markets": r.get("price_active_markets"),
  "price_valid_markets": r.get("price_valid_markets"),
  "price_nonvalid_markets": r.get("price_nonvalid_markets"),
  "price_ready": r.get("price_ready"),
  "signal_latest": r.get("signal_latest"),
  "signal_ready": r.get("signal_ready"),
  "ready_for_enforcement": r.get("ready_for_enforcement"),
  "enforcement_is_manual": r.get("enforcement_is_manual"),
}, indent=2, ensure_ascii=False))
'
echo

echo "[6] Dead-letter summary"
json_get /v8011/dead-letter.json | python3 -c '
import json, sys
d=json.load(sys.stdin)
print(json.dumps({
  "version": d.get("version"),
  "dead_letter_total": d.get("dead_letter_total"),
  "dead_letter_24h": d.get("dead_letter_24h"),
  "latest": (d.get("items") or [])[:5],
  "automatic_requeue": d.get("automatic_requeue"),
}, indent=2, ensure_ascii=False))
'
echo

echo "[7] Critical routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/ingress.json \
  /v8011/monitor.json \
  /v8011/dead-letter.json \
  /v8011/token-readiness.json \
  /v8011/selftest.json
do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 30 "http://127.0.0.1${route}" || true)"
  printf '%-42s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || exit 1
done
echo

echo "[8] Queue DB and token audit"
docker exec tradingbot_ingress python - <<'PY'
import os, sqlite3
p="/app/data/v8011_ingress.sqlite3"
with sqlite3.connect(p) as con:
    qc=con.execute("PRAGMA quick_check").fetchone()[0]
    print("path:", p)
    print("size_bytes:", os.path.getsize(p))
    print("quick_check:", qc)
    assert str(qc).lower()=="ok"
    tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert "v8011_ingress_token_audit" in tables
    print("status_counts:")
    for status, n in con.execute("""
        SELECT status, COUNT(*)
        FROM v8011_ingress_queue
        GROUP BY status
        ORDER BY status
    """):
        print(" ", status, n)
    print("token_counts:")
    for endpoint, status, n in con.execute("""
        SELECT endpoint, token_status, COUNT(*)
        FROM v8011_ingress_token_audit
        GROUP BY endpoint, token_status
        ORDER BY endpoint, token_status
    """):
        print(" ", endpoint, status, n)
PY
echo

echo "[9] Actual ingress errors, last 2h"
docker logs --since 2h tradingbot_ingress 2>&1 \
  | grep -Ei 'V8011_(QUEUE_ERROR|DISPATCH_HTTP_ERROR|DISPATCH_EXCEPTION|TOKEN_AUDIT_ERROR)|Traceback|CRITICAL|database is locked' \
  | tail -n 100 || true
echo

echo "[10] Actual backend errors, last 2h"
docker logs --since 2h tradingbot 2>&1 \
  | grep -Ei 'Traceback|CRITICAL|database is locked|OperationalError|IntegrityError|HTTP/[0-9.]+" (4|5)[0-9][0-9]' \
  | tail -n 100 || true
echo

echo "[11] Fast rejection latency"
curl -sS -o /tmp/v8011_2_invalid.json \
  -w 'status=%{http_code} total=%{time_total}s\n' \
  --max-time 5 \
  -H 'Content-Type: application/json' \
  --data-binary '{invalid-json' \
  http://127.0.0.1/webhook/price
cat /tmp/v8011_2_invalid.json
echo
echo

echo "[12] Host resources"
uptime
free -h
df -h "$BASE"
echo

echo "=== V8011.2 CHECK FERTIG ==="
