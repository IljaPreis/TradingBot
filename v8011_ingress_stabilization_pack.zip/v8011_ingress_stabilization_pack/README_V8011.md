# V8011 Ingress Stabilization

## Ziel

TradingView-Webhooks werden nicht mehr direkt durch die große monolithische
FastAPI-Anwendung beantwortet. Ein leichter Ingress speichert jedes gültige
Event zuerst in einer persistenten SQLite-Warteschlange und bestätigt den
Webhook sofort. Ein einzelner Dispatcher leitet die Events anschließend
priorisiert an den unveränderten Backend-Pfad weiter.

## Datenfluss

```text
TradingView
  -> tradingbot_ingress:80
  -> /app/data/v8011_ingress.sqlite3
  -> Dispatcher
  -> tradingbot:80
  -> bestehende V8001/V8004/V8006/V8007-Logik
```

Prioritäten:

- Outcome/Exit: 120
- Tradesignal: 100
- Price Heartbeat: 50

## Unverändert

- `app/main.py`
- V8004 Quality Router
- V8006 Calendar Execution Correction
- V8007 Gate Bridge
- Canonical Pine
- bestehende Trading-Datenbankstruktur
- Broker Auto Execution bleibt `FALSE`

## Neu

- `app/v8011_ingress.py`
- zweiter Container `tradingbot_ingress`
- persistente Queue `data/v8011_ingress.sqlite3`
- Idempotency/Duplikatschutz
- Retry mit Backoff
- Ingress-Dashboard `/v8011/ingress`
- Selftest `/v8011/selftest.json`
- Link-Injektion in `/master` und `/master-ai-review`

## Sicherheitsmodus

Token-Unterstützung ist vorhanden, aber standardmäßig nicht erzwungen, damit
bestehende TradingView-Alerts ohne Änderung weiterlaufen.

Spätere Aktivierung über `.env`:

```env
V8011_ENFORCE_TOKEN=true
V8011_WEBHOOK_TOKEN=<neuer geheimer Wert>
```

Danach müssten alle TradingView-Alerts den Token mitsenden. Dieser Schritt ist
nicht Bestandteil der Erstinstallation.

## Installation

Das ZIP wird im GitHub-Repo abgelegt und über Termius auf dem VPS installiert.
Der Installer prüft Paket- und Produktions-Hashes, erstellt ein Rollback-Backup,
baut die Container neu und führt die kritischen Selftests aus.

```bash
bash install_v8011_ingress_stabilization.sh
```

## Prüfung

```bash
bash /opt/tradingbot_v6000/ops/v8011_ingress_check.sh
```

## Rollback

Bei einem Installationsfehler erfolgt der Rollback automatisch. Der Backup-Pfad
wird in der Installationsausgabe angezeigt.
