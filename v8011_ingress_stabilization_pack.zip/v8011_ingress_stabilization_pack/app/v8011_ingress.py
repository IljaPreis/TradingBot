from __future__ import annotations

import asyncio
import hashlib
import hmac
import html
import json
import os
import sqlite3
import time
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response


VERSION = "V8011-INGRESS-STABILIZATION-V1"
BACKEND_URL = os.getenv("V8011_BACKEND_URL", "http://tradingbot:80").rstrip("/")
QUEUE_DB = Path(os.getenv("V8011_QUEUE_DB", "/app/data/v8011_ingress.sqlite3"))
ENFORCE_TOKEN = os.getenv("V8011_ENFORCE_TOKEN", "false").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}
WEBHOOK_TOKEN = os.getenv("V8011_WEBHOOK_TOKEN", "").strip()
MAX_BODY_BYTES = max(
    16_384,
    int(os.getenv("V8011_MAX_BODY_BYTES", "524288")),
)
MAX_ATTEMPTS = max(
    1,
    int(os.getenv("V8011_MAX_ATTEMPTS", "8")),
)
RETENTION_DAYS = max(
    1,
    int(os.getenv("V8011_QUEUE_RETENTION_DAYS", "7")),
)
DEDUPE_RETENTION_DAYS = max(
    RETENTION_DAYS,
    int(os.getenv("V8011_DEDUPE_RETENTION_DAYS", "30")),
)
BACKEND_TIMEOUT_SECONDS = max(
    10.0,
    float(os.getenv("V8011_BACKEND_TIMEOUT_SECONDS", "120")),
)
PROXY_TIMEOUT_SECONDS = max(
    10.0,
    float(os.getenv("V8011_PROXY_TIMEOUT_SECONDS", "120")),
)

_HOP_BY_HOP = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
    "content-length",
    "host",
    "content-encoding",
}
_MASTER_LINK_PATHS = {
    "/master",
    "/master-ai-review",
    "/master-fast",
    "/master-mobile",
}

_http_client: httpx.AsyncClient | None = None
_worker_task: asyncio.Task | None = None
_cleanup_task: asyncio.Task | None = None
_stop_event: asyncio.Event | None = None
_proxy_semaphore = asyncio.Semaphore(2)

_RUNTIME: dict[str, Any] = {
    "started_at": None,
    "last_dispatch_at": None,
    "last_dispatch_ok": None,
    "last_dispatch_event_id": None,
    "last_dispatch_endpoint": None,
    "last_dispatch_status": None,
    "last_dispatch_error": None,
    "last_backend_latency_ms": None,
    "worker_alive": False,
    "cleanup_alive": False,
}


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime | None = None) -> str:
    return (dt or _utc_now()).isoformat()


def _connect() -> sqlite3.Connection:
    QUEUE_DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(
        str(QUEUE_DB),
        timeout=5.0,
        isolation_level=None,
    )
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=5000")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con




@contextmanager
def _db():
    con = _connect()
    try:
        yield con
    finally:
        con.close()

def _init_db() -> None:
    with _db() as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS v8011_ingress_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT NOT NULL UNIQUE,
                endpoint TEXT NOT NULL,
                priority INTEGER NOT NULL,
                payload_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'PENDING',
                attempts INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                available_at TEXT NOT NULL,
                started_at TEXT,
                processed_at TEXT,
                backend_status INTEGER,
                backend_latency_ms REAL,
                last_error TEXT,
                response_preview TEXT
            );

            CREATE INDEX IF NOT EXISTS ix_v8011_queue_dispatch
            ON v8011_ingress_queue(status, available_at, priority DESC, id ASC);

            CREATE INDEX IF NOT EXISTS ix_v8011_queue_created
            ON v8011_ingress_queue(created_at DESC);

            CREATE TABLE IF NOT EXISTS v8011_ingress_dedupe (
                event_id TEXT PRIMARY KEY,
                endpoint TEXT NOT NULL,
                first_seen_at TEXT NOT NULL,
                last_seen_at TEXT NOT NULL,
                hit_count INTEGER NOT NULL DEFAULT 1
            );

            CREATE INDEX IF NOT EXISTS ix_v8011_dedupe_last_seen
            ON v8011_ingress_dedupe(last_seen_at DESC);
            """
        )
        stale_cutoff = _iso(_utc_now() - timedelta(minutes=5))
        con.execute(
            """
            UPDATE v8011_ingress_queue
            SET status='PENDING',
                available_at=?,
                last_error=COALESCE(last_error || '; ', '') || 'startup_recovery_stale_processing'
            WHERE status='PROCESSING'
              AND COALESCE(started_at, created_at) < ?
            """,
            (_iso(), stale_cutoff),
        )


def _canonical_json(payload: dict[str, Any]) -> str:
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )


def _payload_type(payload: dict[str, Any]) -> str:
    return str(
        payload.get("type")
        or payload.get("event_type")
        or payload.get("alert_type")
        or "signal"
    ).strip().lower()


def _priority(endpoint: str, payload: dict[str, Any]) -> int:
    if endpoint == "/webhook/tradingview":
        kind = _payload_type(payload)
        if kind in {"outcome", "exit", "close", "result"}:
            return 120
        return 100
    return 50


def _event_id(endpoint: str, payload: dict[str, Any]) -> str:
    kind = _payload_type(payload)

    if endpoint == "/webhook/tradingview":
        explicit = (
            payload.get("signal_event_id")
            or payload.get("event_id")
            or payload.get("client_trade_id")
            or payload.get("trade_id")
            or payload.get("id")
        )
        if explicit:
            raw = f"{endpoint}|{kind}|{explicit}"
        else:
            raw = f"{endpoint}|{kind}|{_canonical_json(payload)}"
        return "tv_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()

    market = str(payload.get("market") or payload.get("symbol") or "").upper().strip()
    timeframe = str(payload.get("timeframe") or payload.get("tf") or "").strip()
    bar_time = (
        payload.get("bar_time")
        or payload.get("bar_time_utc")
        or payload.get("time")
        or payload.get("timestamp")
        or payload.get("timenow")
    )
    if bar_time is None:
        bar_time = _utc_now().strftime("%Y-%m-%dT%H:%MZ")

    ohlc = {
        "open": payload.get("open"),
        "high": payload.get("high"),
        "low": payload.get("low"),
        "close": payload.get("close", payload.get("price")),
    }
    raw = f"{endpoint}|{market}|{timeframe}|{bar_time}|{_canonical_json(ohlc)}"
    return "px_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _queue_depth() -> int:
    with _db() as con:
        row = con.execute(
            """
            SELECT COUNT(*) n
            FROM v8011_ingress_queue
            WHERE status IN ('PENDING','PROCESSING')
            """
        ).fetchone()
        return int(row["n"] if row else 0)


def _enqueue(
    endpoint: str,
    payload: dict[str, Any],
) -> tuple[str, bool, str]:
    event_id = _event_id(endpoint, payload)
    now = _iso()
    payload_json = _canonical_json(payload)
    priority = _priority(endpoint, payload)

    with _db() as con:
        con.execute("BEGIN IMMEDIATE")
        existing = con.execute(
            """
            SELECT q.status
            FROM v8011_ingress_dedupe d
            LEFT JOIN v8011_ingress_queue q ON q.event_id=d.event_id
            WHERE d.event_id=?
            """,
            (event_id,),
        ).fetchone()

        if existing is not None:
            con.execute(
                """
                UPDATE v8011_ingress_dedupe
                SET last_seen_at=?,
                    hit_count=hit_count+1
                WHERE event_id=?
                """,
                (now, event_id),
            )
            con.execute("COMMIT")
            return event_id, True, str(existing["status"] or "DEDUPED")

        con.execute(
            """
            INSERT INTO v8011_ingress_dedupe (
                event_id, endpoint, first_seen_at, last_seen_at, hit_count
            ) VALUES (?, ?, ?, ?, 1)
            """,
            (event_id, endpoint, now, now),
        )
        con.execute(
            """
            INSERT INTO v8011_ingress_queue (
                event_id, endpoint, priority, payload_json,
                status, attempts, created_at, available_at
            ) VALUES (?, ?, ?, ?, 'PENDING', 0, ?, ?)
            """,
            (event_id, endpoint, priority, payload_json, now, now),
        )
        con.execute("COMMIT")

    return event_id, False, "PENDING"


def _claim_next() -> dict[str, Any] | None:
    now = _iso()
    with _db() as con:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute(
            """
            SELECT *
            FROM v8011_ingress_queue
            WHERE status='PENDING'
              AND available_at <= ?
            ORDER BY priority DESC, id ASC
            LIMIT 1
            """,
            (now,),
        ).fetchone()

        if row is None:
            con.execute("COMMIT")
            return None

        con.execute(
            """
            UPDATE v8011_ingress_queue
            SET status='PROCESSING',
                attempts=attempts+1,
                started_at=?,
                last_error=NULL
            WHERE id=?
            """,
            (now, row["id"]),
        )
        con.execute("COMMIT")

        item = dict(row)
        item["attempts"] = int(item.get("attempts") or 0) + 1
        item["started_at"] = now
        return item


def _mark_done(
    item_id: int,
    status_code: int,
    latency_ms: float,
    preview: str,
) -> None:
    with _db() as con:
        con.execute(
            """
            UPDATE v8011_ingress_queue
            SET status='DONE',
                processed_at=?,
                backend_status=?,
                backend_latency_ms=?,
                response_preview=?,
                last_error=NULL
            WHERE id=?
            """,
            (
                _iso(),
                int(status_code),
                round(latency_ms, 2),
                preview[:2000],
                int(item_id),
            ),
        )


def _mark_retry(
    item: dict[str, Any],
    error: str,
    status_code: int | None,
    latency_ms: float | None,
    preview: str,
) -> None:
    attempts = int(item.get("attempts") or 1)
    terminal = attempts >= MAX_ATTEMPTS
    delay_seconds = min(300, 2 ** min(attempts, 8))
    available_at = _iso(_utc_now() + timedelta(seconds=delay_seconds))
    status = "FAILED" if terminal else "PENDING"

    with _db() as con:
        con.execute(
            """
            UPDATE v8011_ingress_queue
            SET status=?,
                available_at=?,
                processed_at=CASE WHEN ?='FAILED' THEN ? ELSE processed_at END,
                backend_status=?,
                backend_latency_ms=?,
                response_preview=?,
                last_error=?
            WHERE id=?
            """,
            (
                status,
                available_at,
                status,
                _iso(),
                status_code,
                round(latency_ms, 2) if latency_ms is not None else None,
                preview[:2000],
                error[:4000],
                int(item["id"]),
            ),
        )


def _token_from_request(
    request: Request,
    payload: dict[str, Any],
) -> str:
    return str(
        request.headers.get("x-webhook-token")
        or request.headers.get("x-tradingview-token")
        or request.query_params.get("token")
        or payload.get("webhook_token")
        or ""
    ).strip()


def _token_allowed(
    request: Request,
    payload: dict[str, Any],
) -> bool:
    if not ENFORCE_TOKEN:
        return True
    if not WEBHOOK_TOKEN:
        return False
    candidate = _token_from_request(request, payload)
    return bool(candidate) and hmac.compare_digest(candidate, WEBHOOK_TOKEN)


async def _read_json_body(request: Request) -> tuple[dict[str, Any] | None, Response | None]:
    body = await request.body()
    if len(body) > MAX_BODY_BYTES:
        return None, JSONResponse(
            status_code=413,
            content={
                "accepted": False,
                "error": "payload_too_large",
                "max_body_bytes": MAX_BODY_BYTES,
                "version": VERSION,
            },
        )
    try:
        payload = json.loads(body.decode("utf-8") or "{}")
    except Exception:
        return None, JSONResponse(
            status_code=400,
            content={
                "accepted": False,
                "error": "invalid_json",
                "version": VERSION,
            },
        )
    if not isinstance(payload, dict):
        return None, JSONResponse(
            status_code=400,
            content={
                "accepted": False,
                "error": "json_object_required",
                "version": VERSION,
            },
        )
    return payload, None


def _validate_webhook(
    endpoint: str,
    payload: dict[str, Any],
) -> str | None:
    if endpoint == "/webhook/price":
        market = str(payload.get("market") or payload.get("symbol") or "").strip()
        high = payload.get("high")
        low = payload.get("low")
        close = payload.get("close", payload.get("price"))
        if not market:
            return "missing_market"
        if high is None and close is None:
            return "missing_high_or_close"
        if low is None and close is None:
            return "missing_low_or_close"
    return None


async def _accept_webhook(
    request: Request,
    endpoint: str,
) -> Response:
    payload, error_response = await _read_json_body(request)
    if error_response is not None:
        return error_response
    assert payload is not None

    if not _token_allowed(request, payload):
        return JSONResponse(
            status_code=403,
            content={
                "accepted": False,
                "error": "invalid_webhook_token",
                "version": VERSION,
            },
        )

    validation_error = _validate_webhook(endpoint, payload)
    if validation_error:
        return JSONResponse(
            status_code=400,
            content={
                "accepted": False,
                "error": validation_error,
                "version": VERSION,
            },
        )

    started = time.perf_counter()
    try:
        event_id, duplicate, queue_status = _enqueue(endpoint, payload)
        elapsed_ms = round((time.perf_counter() - started) * 1000, 2)
        return JSONResponse(
            status_code=200,
            content={
                "accepted": True,
                "queued": not duplicate,
                "duplicate": duplicate,
                "event_id": event_id,
                "queue_status": queue_status,
                "ack_ms": elapsed_ms,
                "version": VERSION,
                "routing": "persistent_queue_then_existing_backend",
                "broker_auto_execution": False,
            },
        )
    except Exception as exc:
        print(
            f"V8011_QUEUE_ERROR endpoint={endpoint} error={type(exc).__name__}:{exc}",
            flush=True,
        )
        return JSONResponse(
            status_code=503,
            content={
                "accepted": False,
                "queued": False,
                "error": f"queue_unavailable:{type(exc).__name__}",
                "version": VERSION,
            },
        )


async def _dispatch_loop() -> None:
    assert _stop_event is not None
    assert _http_client is not None
    _RUNTIME["worker_alive"] = True

    try:
        while not _stop_event.is_set():
            item = _claim_next()
            if item is None:
                try:
                    await asyncio.wait_for(_stop_event.wait(), timeout=0.15)
                except asyncio.TimeoutError:
                    pass
                continue

            endpoint = str(item["endpoint"])
            event_id = str(item["event_id"])
            payload = json.loads(str(item["payload_json"]))
            started = time.perf_counter()
            status_code: int | None = None
            preview = ""

            _RUNTIME.update(
                {
                    "last_dispatch_at": _iso(),
                    "last_dispatch_event_id": event_id,
                    "last_dispatch_endpoint": endpoint,
                    "last_dispatch_error": None,
                }
            )

            try:
                response = await _http_client.post(
                    BACKEND_URL + endpoint,
                    json=payload,
                    headers={
                        "X-V8011-Ingress-Event-ID": event_id,
                        "X-V8011-Ingress-Version": VERSION,
                    },
                    timeout=BACKEND_TIMEOUT_SECONDS,
                )
                latency_ms = (time.perf_counter() - started) * 1000
                status_code = int(response.status_code)
                preview = response.text[:2000]

                if 200 <= status_code < 300:
                    _mark_done(
                        int(item["id"]),
                        status_code,
                        latency_ms,
                        preview,
                    )
                    _RUNTIME.update(
                        {
                            "last_dispatch_ok": True,
                            "last_dispatch_status": status_code,
                            "last_backend_latency_ms": round(latency_ms, 2),
                        }
                    )
                else:
                    retryable = status_code in {408, 425, 429} or status_code >= 500
                    error = f"backend_http_{status_code}"
                    if retryable:
                        _mark_retry(
                            item,
                            error,
                            status_code,
                            latency_ms,
                            preview,
                        )
                    else:
                        terminal_item = dict(item)
                        terminal_item["attempts"] = MAX_ATTEMPTS
                        _mark_retry(
                            terminal_item,
                            error,
                            status_code,
                            latency_ms,
                            preview,
                        )
                    _RUNTIME.update(
                        {
                            "last_dispatch_ok": False,
                            "last_dispatch_status": status_code,
                            "last_dispatch_error": error,
                            "last_backend_latency_ms": round(latency_ms, 2),
                        }
                    )
                    print(
                        f"V8011_DISPATCH_HTTP_ERROR event_id={event_id} "
                        f"endpoint={endpoint} status={status_code} attempts={item.get('attempts')}",
                        flush=True,
                    )

            except Exception as exc:
                latency_ms = (time.perf_counter() - started) * 1000
                error = f"{type(exc).__name__}:{exc}"
                _mark_retry(
                    item,
                    error,
                    status_code,
                    latency_ms,
                    preview,
                )
                _RUNTIME.update(
                    {
                        "last_dispatch_ok": False,
                        "last_dispatch_status": status_code,
                        "last_dispatch_error": error[:1000],
                        "last_backend_latency_ms": round(latency_ms, 2),
                    }
                )
                print(
                    f"V8011_DISPATCH_EXCEPTION event_id={event_id} "
                    f"endpoint={endpoint} attempts={item.get('attempts')} "
                    f"error={error[:500]}",
                    flush=True,
                )
    finally:
        _RUNTIME["worker_alive"] = False


def _cleanup_db() -> dict[str, int]:
    queue_cutoff = _iso(_utc_now() - timedelta(days=RETENTION_DAYS))
    dedupe_cutoff = _iso(_utc_now() - timedelta(days=DEDUPE_RETENTION_DAYS))
    with _db() as con:
        done = con.execute(
            """
            DELETE FROM v8011_ingress_queue
            WHERE status='DONE'
              AND processed_at < ?
            """,
            (queue_cutoff,),
        ).rowcount
        failed = con.execute(
            """
            DELETE FROM v8011_ingress_queue
            WHERE status='FAILED'
              AND processed_at < ?
            """,
            (dedupe_cutoff,),
        ).rowcount
        dedupe = con.execute(
            """
            DELETE FROM v8011_ingress_dedupe
            WHERE last_seen_at < ?
            """,
            (dedupe_cutoff,),
        ).rowcount
    return {
        "done_deleted": int(done or 0),
        "failed_deleted": int(failed or 0),
        "dedupe_deleted": int(dedupe or 0),
    }


async def _cleanup_loop() -> None:
    assert _stop_event is not None
    _RUNTIME["cleanup_alive"] = True
    try:
        while not _stop_event.is_set():
            try:
                _cleanup_db()
            except Exception:
                pass
            try:
                await asyncio.wait_for(_stop_event.wait(), timeout=3600)
            except asyncio.TimeoutError:
                pass
    finally:
        _RUNTIME["cleanup_alive"] = False


def _queue_snapshot(limit: int = 30) -> dict[str, Any]:
    now = _utc_now()
    with _db() as con:
        status_rows = con.execute(
            """
            SELECT status, COUNT(*) n
            FROM v8011_ingress_queue
            GROUP BY status
            ORDER BY status
            """
        ).fetchall()
        endpoint_rows = con.execute(
            """
            SELECT endpoint, status, COUNT(*) n
            FROM v8011_ingress_queue
            GROUP BY endpoint, status
            ORDER BY endpoint, status
            """
        ).fetchall()
        duplicate_rows = con.execute(
            """
            SELECT
                COUNT(*) events_seen,
                COALESCE(SUM(hit_count - 1), 0) duplicates_blocked
            FROM v8011_ingress_dedupe
            """
        ).fetchone()
        oldest = con.execute(
            """
            SELECT created_at
            FROM v8011_ingress_queue
            WHERE status IN ('PENDING','PROCESSING')
            ORDER BY created_at ASC
            LIMIT 1
            """
        ).fetchone()
        recent = con.execute(
            """
            SELECT
                id, event_id, endpoint, priority, status, attempts,
                created_at, available_at, started_at, processed_at,
                backend_status, backend_latency_ms, last_error
            FROM v8011_ingress_queue
            ORDER BY id DESC
            LIMIT ?
            """,
            (max(1, min(limit, 200)),),
        ).fetchall()
        timing = con.execute(
            """
            SELECT
                COUNT(*) n,
                ROUND(AVG(backend_latency_ms), 2) avg_backend_latency_ms,
                ROUND(MAX(backend_latency_ms), 2) max_backend_latency_ms
            FROM v8011_ingress_queue
            WHERE status='DONE'
              AND processed_at >= ?
            """,
            (_iso(now - timedelta(hours=24)),),
        ).fetchone()

    oldest_age = None
    if oldest and oldest["created_at"]:
        try:
            created = datetime.fromisoformat(str(oldest["created_at"]))
            oldest_age = max(0.0, (now - created).total_seconds())
        except Exception:
            oldest_age = None

    status_counts = {str(r["status"]): int(r["n"]) for r in status_rows}
    return {
        "ok": True,
        "version": VERSION,
        "generated_utc": _iso(now),
        "mode": "persistent_fast_ack_ingress",
        "safety": {
            "existing_trading_db_schema_changed": False,
            "v8004_changed": False,
            "v8006_changed": False,
            "v8007_changed": False,
            "pine_changed": False,
            "broker_auto_execution": False,
            "webhook_token_enforced": ENFORCE_TOKEN,
            "webhook_token_configured": bool(WEBHOOK_TOKEN),
        },
        "config": {
            "backend_url": BACKEND_URL,
            "queue_db": str(QUEUE_DB),
            "max_attempts": MAX_ATTEMPTS,
            "retention_days": RETENTION_DAYS,
            "dedupe_retention_days": DEDUPE_RETENTION_DAYS,
            "backend_timeout_seconds": BACKEND_TIMEOUT_SECONDS,
            "proxy_concurrency": 2,
        },
        "runtime": dict(_RUNTIME),
        "summary": {
            "queue_depth": int(
                status_counts.get("PENDING", 0)
                + status_counts.get("PROCESSING", 0)
            ),
            "oldest_pending_age_seconds": (
                round(oldest_age, 2) if oldest_age is not None else None
            ),
            "status_counts": status_counts,
            "events_seen": int(duplicate_rows["events_seen"] or 0),
            "duplicates_blocked": int(
                duplicate_rows["duplicates_blocked"] or 0
            ),
            "last_24h_done": int(timing["n"] or 0),
            "avg_backend_latency_ms": timing["avg_backend_latency_ms"],
            "max_backend_latency_ms": timing["max_backend_latency_ms"],
        },
        "by_endpoint_status": [dict(r) for r in endpoint_rows],
        "recent": [dict(r) for r in recent],
    }


def _ingress_html(snapshot: dict[str, Any]) -> str:
    summary = snapshot["summary"]
    runtime = snapshot["runtime"]
    safety = snapshot["safety"]
    rows = []
    for item in snapshot["recent"]:
        error = html.escape(str(item.get("last_error") or ""))
        rows.append(
            "<tr>"
            f"<td>{item.get('id')}</td>"
            f"<td>{html.escape(str(item.get('endpoint') or ''))}</td>"
            f"<td>{html.escape(str(item.get('status') or ''))}</td>"
            f"<td>{item.get('priority')}</td>"
            f"<td>{item.get('attempts')}</td>"
            f"<td>{html.escape(str(item.get('backend_status') or ''))}</td>"
            f"<td>{html.escape(str(item.get('backend_latency_ms') or ''))}</td>"
            f"<td>{html.escape(str(item.get('created_at') or ''))}</td>"
            f"<td class='err'>{error}</td>"
            "</tr>"
        )

    token_label = (
        "ENFORCED"
        if safety["webhook_token_enforced"]
        else "OFF (compatibility mode)"
    )
    return f"""
    <!doctype html>
    <html lang="de">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <meta http-equiv="refresh" content="10">
      <title>V8011 Ingress</title>
      <style>
        body{{background:#07111f;color:#e7eef8;font-family:Arial,sans-serif;margin:20px}}
        a{{color:#72b7ff;text-decoration:none}}
        .grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:16px 0}}
        .card{{background:#0d1b2d;border:1px solid #24405f;border-radius:12px;padding:14px}}
        .value{{font-size:24px;font-weight:bold;margin-top:6px}}
        .ok{{color:#48df8b}} .warn{{color:#ffcc66}} .bad{{color:#ff7474}}
        table{{width:100%;border-collapse:collapse;font-size:12px;background:#0d1b2d}}
        th,td{{padding:8px;border-bottom:1px solid #263b55;text-align:left;vertical-align:top}}
        th{{color:#9ed0ff;position:sticky;top:0;background:#0d1b2d}}
        .err{{max-width:380px;word-break:break-word;color:#ff9d9d}}
        pre{{white-space:pre-wrap;word-break:break-word}}
      </style>
    </head>
    <body>
      <p><a href="/master">Master</a> ·
         <a href="/master-ai-review">AI Review</a> ·
         <a href="/v8011/ingress.json">JSON</a> ·
         <a href="/v8011/selftest.json">Selftest</a></p>
      <h1>V8011 Ingress Stabilization</h1>
      <p>Fast ACK → persistente Queue → bestehender V8004/V8006/V8007-Backendpfad.</p>

      <div class="grid">
        <div class="card">Queue Depth<div class="value">{summary['queue_depth']}</div></div>
        <div class="card">Oldest Pending<div class="value">{summary['oldest_pending_age_seconds'] or 0}s</div></div>
        <div class="card">Done 24h<div class="value">{summary['last_24h_done']}</div></div>
        <div class="card">Duplikate blockiert<div class="value">{summary['duplicates_blocked']}</div></div>
        <div class="card">Ø Backend<div class="value">{summary['avg_backend_latency_ms'] or 0}ms</div></div>
        <div class="card">Worker<div class="value {'ok' if runtime.get('worker_alive') else 'bad'}">{'RUNNING' if runtime.get('worker_alive') else 'DOWN'}</div></div>
      </div>

      <div class="card">
        <b>Safety:</b>
        V8004 unverändert · V8006 unverändert · V8007 unverändert ·
        Pine unverändert · Broker Auto Execution FALSE · Token {token_label}
      </div>

      <h2>Letzte Events</h2>
      <div style="overflow:auto">
      <table>
        <thead><tr>
          <th>ID</th><th>Endpoint</th><th>Status</th><th>Prio</th>
          <th>Versuche</th><th>Backend</th><th>ms</th><th>Zeit</th><th>Fehler</th>
        </tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table>
      </div>
    </body>
    </html>
    """


def _inject_master_link(content: bytes, content_type: str) -> bytes:
    if "text/html" not in content_type.lower():
        return content
    try:
        text = content.decode("utf-8")
    except Exception:
        return content

    if 'href="/v8011/ingress"' in text:
        return content

    badge = """
    <div style="position:fixed;right:12px;bottom:12px;z-index:99999;
                background:#10243b;border:1px solid #3d6f9f;border-radius:10px;
                padding:9px 12px;font-family:Arial,sans-serif;font-size:13px">
      <a href="/v8011/ingress" style="color:#8dcbff;text-decoration:none">
        V8011 Ingress / Queue
      </a>
    </div>
    """
    if "</body>" in text.lower():
        index = text.lower().rfind("</body>")
        text = text[:index] + badge + text[index:]
    else:
        text += badge
    return text.encode("utf-8")


async def _proxy_request(request: Request, path: str) -> Response:
    assert _http_client is not None
    target = BACKEND_URL + "/" + path
    if request.url.query:
        target += "?" + request.url.query

    body = await request.body()
    headers = {
        key: value
        for key, value in request.headers.items()
        if key.lower() not in _HOP_BY_HOP
    }
    client_host = request.client.host if request.client else ""
    if client_host:
        headers["x-forwarded-for"] = client_host
    headers["x-forwarded-proto"] = request.url.scheme
    headers["x-v8011-proxy"] = VERSION

    async with _proxy_semaphore:
        try:
            backend_response = await _http_client.request(
                request.method,
                target,
                content=body,
                headers=headers,
                timeout=PROXY_TIMEOUT_SECONDS,
                follow_redirects=False,
            )
        except Exception as exc:
            return JSONResponse(
                status_code=503,
                content={
                    "ok": False,
                    "error": f"backend_unavailable:{type(exc).__name__}",
                    "version": VERSION,
                },
            )

    response_headers = {
        key: value
        for key, value in backend_response.headers.items()
        if key.lower() not in _HOP_BY_HOP
    }
    content_type = backend_response.headers.get("content-type", "")
    content = backend_response.content
    request_path = "/" + path
    if request_path in _MASTER_LINK_PATHS:
        content = _inject_master_link(content, content_type)

    return Response(
        content=content,
        status_code=backend_response.status_code,
        headers=response_headers,
        media_type=None,
    )


@asynccontextmanager
async def lifespan(_: FastAPI):
    global _http_client, _worker_task, _cleanup_task, _stop_event

    _init_db()
    _stop_event = asyncio.Event()
    _http_client = httpx.AsyncClient(
        trust_env=False,
        limits=httpx.Limits(
            max_connections=20,
            max_keepalive_connections=10,
        ),
    )
    _RUNTIME["started_at"] = _iso()
    print(
        f"V8011_INGRESS_START version={VERSION} backend={BACKEND_URL} "
        f"queue_db={QUEUE_DB} token_enforced={ENFORCE_TOKEN}",
        flush=True,
    )
    _worker_task = asyncio.create_task(
        _dispatch_loop(),
        name="v8011_dispatch_worker",
    )
    _cleanup_task = asyncio.create_task(
        _cleanup_loop(),
        name="v8011_cleanup_worker",
    )

    try:
        yield
    finally:
        if _stop_event is not None:
            _stop_event.set()
        tasks = [
            task
            for task in (_worker_task, _cleanup_task)
            if task is not None
        ]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        if _http_client is not None:
            await _http_client.aclose()


app = FastAPI(
    title="TradingBot V8011 Fast Ingress",
    version=VERSION,
    lifespan=lifespan,
)


@app.post("/webhook/tradingview")
async def tradingview_ingress(request: Request) -> Response:
    return await _accept_webhook(
        request,
        "/webhook/tradingview",
    )


@app.post("/webhook/price")
async def price_ingress(request: Request) -> Response:
    return await _accept_webhook(
        request,
        "/webhook/price",
    )


@app.get("/v8011/ingress.json")
def ingress_json() -> dict[str, Any]:
    return _queue_snapshot()


@app.get("/v8011/ingress", response_class=HTMLResponse)
def ingress_page() -> HTMLResponse:
    return HTMLResponse(_ingress_html(_queue_snapshot()))


@app.get("/v8011/ingress-config.json")
def ingress_config() -> dict[str, Any]:
    return {
        "ok": True,
        "version": VERSION,
        "backend_url": BACKEND_URL,
        "queue_db": str(QUEUE_DB),
        "token_enforced": ENFORCE_TOKEN,
        "token_configured": bool(WEBHOOK_TOKEN),
        "max_attempts": MAX_ATTEMPTS,
        "retention_days": RETENTION_DAYS,
        "dedupe_retention_days": DEDUPE_RETENTION_DAYS,
        "broker_auto_execution": False,
        "v8004_changed": False,
        "v8006_changed": False,
        "v8007_changed": False,
    }


@app.get("/v8011/selftest.json")
async def selftest() -> dict[str, Any]:
    queue_ok = False
    queue_error = None
    backend_ok = False
    backend_status = None
    backend_error = None

    try:
        with _db() as con:
            row = con.execute("PRAGMA quick_check").fetchone()
            queue_ok = bool(row and str(row[0]).lower() == "ok")
    except Exception as exc:
        queue_error = f"{type(exc).__name__}:{exc}"

    try:
        assert _http_client is not None
        response = await _http_client.get(
            BACKEND_URL + "/health",
            timeout=5.0,
        )
        backend_status = int(response.status_code)
        backend_ok = 200 <= backend_status < 300
    except Exception as exc:
        backend_error = f"{type(exc).__name__}:{exc}"

    return {
        "ok": bool(
            queue_ok
            and backend_ok
            and _RUNTIME.get("worker_alive")
            and _RUNTIME.get("cleanup_alive")
        ),
        "version": VERSION,
        "queue_db_quick_check": queue_ok,
        "queue_error": queue_error,
        "backend_ok": backend_ok,
        "backend_status": backend_status,
        "backend_error": backend_error,
        "worker_alive": _RUNTIME.get("worker_alive"),
        "cleanup_alive": _RUNTIME.get("cleanup_alive"),
        "queue_depth": _queue_depth() if queue_ok else None,
        "safety": {
            "transport_change_only": True,
            "existing_trading_db_schema_changed": False,
            "v8004_changed": False,
            "v8006_changed": False,
            "v8007_changed": False,
            "pine_changed": False,
            "broker_auto_execution": False,
        },
    }


@app.api_route(
    "/{path:path}",
    methods=[
        "GET",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "OPTIONS",
        "HEAD",
    ],
)
async def backend_proxy(request: Request, path: str) -> Response:
    return await _proxy_request(request, path)
