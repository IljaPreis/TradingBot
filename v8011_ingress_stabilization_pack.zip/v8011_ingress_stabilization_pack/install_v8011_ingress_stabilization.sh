#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="V8011-INGRESS-STABILIZATION-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8011_before_${TS}"
LOG="/root/v8011_install_${TS}.log"

EXPECTED_MAIN_SHA="eed627822505f0f3b77cc23b2b34afc1bcfd73fbb2abb66372373c9d61463582"
EXPECTED_OLD_COMPOSE_SHA="84ce2ecf4f912cbe0e01e5ca7fc85e30081e273b91581428fe4c817628d89ee5"
EXPECTED_V8004_SHA="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006_SHA="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007_SHA="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE_SHA="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

ROLLBACK_ARMED=0
MODULE_EXISTED=0
CHECK_EXISTED=0
README_EXISTED=0

exec > >(tee -a "$LOG") 2>&1

sha() {
  sha256sum "$1" | awk '{print $1}'
}

die() {
  echo "FATAL: $*" >&2
  exit 1
}

wait_http_200() {
  local url="$1"
  local attempts="${2:-60}"
  local sleep_s="${3:-2}"
  local i code
  for i in $(seq 1 "$attempts"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then
      return 0
    fi
    echo "WAIT [$i/$attempts] $url status=${code:-none}"
    sleep "$sleep_s"
  done
  return 1
}

rollback() {
  local rc=$?
  trap - ERR
  if [[ "$ROLLBACK_ARMED" != "1" ]]; then
    exit "$rc"
  fi

  echo
  echo "=== V8011 ROLLBACK START ==="

  if [[ -f "$BACKUP/docker-compose.yml" ]]; then
    cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml"
  fi

  if [[ "$MODULE_EXISTED" == "1" && -f "$BACKUP/v8011_ingress.py" ]]; then
    cp -a "$BACKUP/v8011_ingress.py" "$BASE/app/v8011_ingress.py"
  elif [[ "$MODULE_EXISTED" == "0" ]]; then
    rm -f "$BASE/app/v8011_ingress.py"
  fi

  if [[ "$CHECK_EXISTED" == "1" && -f "$BACKUP/v8011_ingress_check.sh" ]]; then
    cp -a "$BACKUP/v8011_ingress_check.sh" "$BASE/ops/v8011_ingress_check.sh"
  elif [[ "$CHECK_EXISTED" == "0" ]]; then
    rm -f "$BASE/ops/v8011_ingress_check.sh"
  fi

  if [[ "$README_EXISTED" == "1" && -f "$BACKUP/README_V8011.md" ]]; then
    cp -a "$BACKUP/README_V8011.md" "$BASE/README_V8011.md"
  elif [[ "$README_EXISTED" == "0" ]]; then
    rm -f "$BASE/README_V8011.md"
  fi

  cd "$BASE"
  docker compose config >/dev/null 2>&1 || true
  docker compose up -d --build --remove-orphans || true

  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8011 ROLLBACK ENDE ==="
  exit "$rc"
}
trap rollback ERR

echo "================================================================================"
echo "$VERSION INSTALL"
echo "================================================================================"
echo "Generated UTC: $(date -u --iso-8601=seconds)"
echo "Project: $BASE"
echo "Package: $PACKAGE_DIR"
echo
echo "Safety:"
echo "  V8004 logic changes: 0"
echo "  V8006 logic changes: 0"
echo "  V8007 logic changes: 0"
echo "  Pine changes: 0"
echo "  Existing trading DB schema changes: 0"
echo "  New persistent ingress queue DB: YES"
echo "  Broker auto execution: FALSE"
echo

[[ -d "$BASE" ]] || die "Project not found: $BASE"
[[ -f "$BASE/app/main.py" ]] || die "app/main.py missing"
[[ -f "$BASE/docker-compose.yml" ]] || die "docker-compose.yml missing"
[[ -f "$BASE/app/v8004_quality_router.py" ]] || die "V8004 file missing"
[[ -f "$BASE/app/v8006_calendar_execution_correction.py" ]] || die "V8006 file missing"
[[ -f "$BASE/app/v8007_v8001_gate_bridge.py" ]] || die "V8007 file missing"
[[ -f "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine" ]] || die "Canonical Pine missing"

[[ -f "$PACKAGE_DIR/app/v8011_ingress.py" ]] || die "Package module missing"
[[ -f "$PACKAGE_DIR/docker-compose.v8011.yml" ]] || die "Package compose missing"
[[ -f "$PACKAGE_DIR/ops/v8011_ingress_check.sh" ]] || die "Package check script missing"
[[ -f "$PACKAGE_DIR/README_V8011.md" ]] || die "Package README missing"
[[ -f "$PACKAGE_DIR/MANIFEST.sha256" ]] || die "Package manifest missing"

echo "[1] Verify package files"
(
  cd "$PACKAGE_DIR"
  sha256sum -c MANIFEST.sha256
)

echo
echo "[2] Verify production baseline"

MAIN_SHA="$(sha "$BASE/app/main.py")"
COMPOSE_SHA="$(sha "$BASE/docker-compose.yml")"
V8004_SHA="$(sha "$BASE/app/v8004_quality_router.py")"
V8006_SHA="$(sha "$BASE/app/v8006_calendar_execution_correction.py")"
V8007_SHA="$(sha "$BASE/app/v8007_v8001_gate_bridge.py")"
PINE_SHA="$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")"

echo "main.py: $MAIN_SHA"
echo "compose: $COMPOSE_SHA"
echo "V8004: $V8004_SHA"
echo "V8006: $V8006_SHA"
echo "V8007: $V8007_SHA"
echo "Pine: $PINE_SHA"

[[ "$MAIN_SHA" == "$EXPECTED_MAIN_SHA" ]] \
  || die "main.py baseline mismatch; no files changed"

[[ "$V8004_SHA" == "$EXPECTED_V8004_SHA" ]] \
  || die "V8004 baseline mismatch; no files changed"

[[ "$V8006_SHA" == "$EXPECTED_V8006_SHA" ]] \
  || die "V8006 baseline mismatch; no files changed"

[[ "$V8007_SHA" == "$EXPECTED_V8007_SHA" ]] \
  || die "V8007 baseline mismatch; no files changed"

[[ "$PINE_SHA" == "$EXPECTED_PINE_SHA" ]] \
  || die "Canonical Pine baseline mismatch; no files changed"

if [[ "$COMPOSE_SHA" != "$EXPECTED_OLD_COMPOSE_SHA" ]]; then
  if ! grep -q "tradingbot_ingress" "$BASE/docker-compose.yml"; then
    die "Unexpected docker-compose.yml baseline; no files changed"
  fi
  echo "Existing V8011-style compose detected; safe reinstall mode"
fi

echo
echo "[3] Create rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/app/main.py" "$BACKUP/main.py"
cp -a "$BASE/app/v8004_quality_router.py" "$BACKUP/v8004_quality_router.py"
cp -a "$BASE/app/v8006_calendar_execution_correction.py" "$BACKUP/v8006_calendar_execution_correction.py"
cp -a "$BASE/app/v8007_v8001_gate_bridge.py" "$BACKUP/v8007_v8001_gate_bridge.py"
cp -a "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine" "$BACKUP/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"

if [[ -f "$BASE/app/v8011_ingress.py" ]]; then
  MODULE_EXISTED=1
  cp -a "$BASE/app/v8011_ingress.py" "$BACKUP/v8011_ingress.py"
fi

if [[ -f "$BASE/ops/v8011_ingress_check.sh" ]]; then
  CHECK_EXISTED=1
  cp -a "$BASE/ops/v8011_ingress_check.sh" "$BACKUP/v8011_ingress_check.sh"
fi

if [[ -f "$BASE/README_V8011.md" ]]; then
  README_EXISTED=1
  cp -a "$BASE/README_V8011.md" "$BACKUP/README_V8011.md"
fi

{
  echo "Generated UTC: $(date -u --iso-8601=seconds)"
  echo "main.py $MAIN_SHA"
  echo "docker-compose.yml $COMPOSE_SHA"
  echo "V8004 $V8004_SHA"
  echo "V8006 $V8006_SHA"
  echo "V8007 $V8007_SHA"
  echo "Pine $PINE_SHA"
  echo
  docker ps --no-trunc
} > "$BACKUP/preinstall_state.txt"

ROLLBACK_ARMED=1

echo
echo "[4] Install ingress module and compose"
install -m 0644 \
  "$PACKAGE_DIR/app/v8011_ingress.py" \
  "$BASE/app/v8011_ingress.py"

install -m 0644 \
  "$PACKAGE_DIR/docker-compose.v8011.yml" \
  "$BASE/docker-compose.yml"

if [[ -f "$BASE/.env" ]]; then
  chmod 600 "$BASE/.env"
fi

cd "$BASE"

python3 -m py_compile app/v8011_ingress.py
docker compose config >/dev/null

echo
echo "[5] Verify protected source hashes remain unchanged"
[[ "$(sha app/main.py)" == "$MAIN_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]

echo
echo "[6] Build shared image"
docker compose build tradingbot

echo
echo "[7] Start backend + fast ingress"
docker compose up -d --remove-orphans

echo
echo "[8] Wait for public ingress"
wait_http_200 "http://127.0.0.1/health" 75 2 \
  || { echo "Public /health did not recover"; false; }

wait_http_200 "http://127.0.0.1/v8011/selftest.json" 75 2 \
  || { echo "V8011 selftest route did not recover"; false; }

echo
echo "[9] Validate V8011 selftest"
curl -fsS --max-time 20 \
  "http://127.0.0.1/v8011/selftest.json" \
  > "/tmp/v8011_selftest_${TS}.json"

python3 - "/tmp/v8011_selftest_${TS}.json" <<'PY'
import json
import sys

data = json.load(open(sys.argv[1], encoding="utf-8"))
assert data.get("ok") is True, data
assert data.get("queue_db_quick_check") is True, data
assert data.get("backend_ok") is True, data
assert data.get("worker_alive") is True, data
assert data.get("cleanup_alive") is True, data
safety = data.get("safety") or {}
assert safety.get("v8004_changed") is False, data
assert safety.get("v8006_changed") is False, data
assert safety.get("v8007_changed") is False, data
assert safety.get("pine_changed") is False, data
assert safety.get("broker_auto_execution") is False, data
print(json.dumps(data, indent=2, ensure_ascii=False))
PY

echo
echo "[10] Critical route status"
CRITICAL_ROUTES=(
  "/health"
  "/master"
  "/master-ai-review"
  "/v8004/selftest.json"
  "/v8006/selftest.json"
  "/v8006/calendar-execution-audit.json"
  "/v8007/selftest.json"
  "/v8008a/selftest.json"
  "/v8009/selftest.json"
  "/v8009/pine-14d.json"
  "/v8011/ingress.json"
  "/v8011/selftest.json"
)

for route in "${CRITICAL_ROUTES[@]}"; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 35 "http://127.0.0.1${route}" || true)"
  printf '%-50s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || false
done

echo
echo "[11] Fast rejection path test"
FAST_RESULT="$(
  curl -sS \
    -o "/tmp/v8011_invalid_${TS}.json" \
    -w 'status=%{http_code} total=%{time_total}' \
    --max-time 5 \
    -H 'Content-Type: application/json' \
    --data-binary '{invalid-json' \
    "http://127.0.0.1/webhook/price" \
    || true
)"
echo "$FAST_RESULT"
grep -q 'status=400' <<< "$FAST_RESULT"

echo
echo "[12] Master link injection"
curl -fsS --max-time 35 "http://127.0.0.1/master" \
  | grep -q 'href="/v8011/ingress"'

curl -fsS --max-time 35 "http://127.0.0.1/master-ai-review" \
  | grep -q 'href="/v8011/ingress"'

echo "Master links: PASS"

echo
echo "[13] Queue database quick check"
docker exec tradingbot_ingress python - <<'PY'
import sqlite3
db = "/app/data/v8011_ingress.sqlite3"
with sqlite3.connect(db) as con:
    result = con.execute("PRAGMA quick_check").fetchone()[0]
    print("queue_db:", db)
    print("quick_check:", result)
    assert str(result).lower() == "ok"
PY

echo
echo "[14] Containers"
docker compose ps
docker ps --filter name=tradingbot --no-trunc

echo
echo "[15] Final protected hashes"
FINAL_MAIN_SHA="$(sha app/main.py)"
FINAL_V8004_SHA="$(sha app/v8004_quality_router.py)"
FINAL_V8006_SHA="$(sha app/v8006_calendar_execution_correction.py)"
FINAL_V8007_SHA="$(sha app/v8007_v8001_gate_bridge.py)"
FINAL_PINE_SHA="$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)"
FINAL_INGRESS_SHA="$(sha app/v8011_ingress.py)"
FINAL_COMPOSE_SHA="$(sha docker-compose.yml)"

[[ "$FINAL_MAIN_SHA" == "$MAIN_SHA" ]]
[[ "$FINAL_V8004_SHA" == "$V8004_SHA" ]]
[[ "$FINAL_V8006_SHA" == "$V8006_SHA" ]]
[[ "$FINAL_V8007_SHA" == "$V8007_SHA" ]]
[[ "$FINAL_PINE_SHA" == "$PINE_SHA" ]]

cat > "$BACKUP/V8011_INSTALL_MANIFEST.txt" <<EOF
Version: $VERSION
Installed UTC: $(date -u --iso-8601=seconds)
Backup: $BACKUP
Install log: $LOG

Protected hashes:
app/main.py: $FINAL_MAIN_SHA
app/v8004_quality_router.py: $FINAL_V8004_SHA
app/v8006_calendar_execution_correction.py: $FINAL_V8006_SHA
app/v8007_v8001_gate_bridge.py: $FINAL_V8007_SHA
pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine: $FINAL_PINE_SHA

New transport files:
app/v8011_ingress.py: $FINAL_INGRESS_SHA
docker-compose.yml: $FINAL_COMPOSE_SHA

Safety:
V8004 changed: FALSE
V8006 changed: FALSE
V8007 changed: FALSE
Pine changed: FALSE
Existing trading DB schema changed: FALSE
New ingress queue DB: /opt/tradingbot_v6000/data/v8011_ingress.sqlite3
Broker auto execution: FALSE
Webhook token enforcement: FALSE by default
EOF

ROLLBACK_ARMED=0
trap - ERR

echo
echo "================================================================================"
echo "V8011 INSTALLATION FERTIG"
echo "================================================================================"
echo "Backup: $BACKUP"
echo "Install log: $LOG"
echo "Ingress dashboard: http://91.107.237.214/v8011/ingress"
echo "Ingress JSON:      http://91.107.237.214/v8011/ingress.json"
echo "Selftest:          http://91.107.237.214/v8011/selftest.json"
echo
echo "Transport:"
echo "  TradingView -> fast ingress -> persistent queue -> existing backend"
echo "  Signal priority: outcomes 120, signals 100, price heartbeats 50"
echo "  Duplicate protection: active"
echo "  Retry: active, max $VERSION defaults"
echo
echo "UNCHANGED:"
echo "  app/main.py"
echo "  V8004"
echo "  V8006"
echo "  V8007"
echo "  Canonical Pine"
echo "  Broker auto execution FALSE"
echo
echo "NOTE:"
echo "  New queue DB writes are limited to data/v8011_ingress.sqlite3."
echo "  Existing trading database schema was not changed."
