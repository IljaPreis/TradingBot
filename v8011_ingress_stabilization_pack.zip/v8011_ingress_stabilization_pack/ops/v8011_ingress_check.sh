#!/usr/bin/env bash
set -euo pipefail

BASE="/opt/tradingbot_v6000"
cd "$BASE"

echo "=== V8011 INGRESS CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"
echo

echo "[1] Containers"
docker compose ps
echo

echo "[2] Public health"
curl -sS --max-time 20 http://127.0.0.1/health | python3 -m json.tool
echo

echo "[3] V8011 selftest"
curl -sS --max-time 20 http://127.0.0.1/v8011/selftest.json | python3 -m json.tool
echo

echo "[4] Queue summary"
curl -sS --max-time 20 http://127.0.0.1/v8011/ingress.json \
  | python3 -c '
import json, sys
d=json.load(sys.stdin)
print(json.dumps({
  "version": d.get("version"),
  "summary": d.get("summary"),
  "runtime": d.get("runtime"),
  "safety": d.get("safety")
}, indent=2, ensure_ascii=False))
'
echo

echo "[5] Critical routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/ingress.json \
  /v8011/selftest.json
do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 30 "http://127.0.0.1${route}" || true)"
  printf '%-42s %s\n' "$route" "$code"
done
echo

echo "[6] Queue DB"
docker exec tradingbot_ingress python - <<'PY'
import sqlite3
db="/app/data/v8011_ingress.sqlite3"
with sqlite3.connect(db) as con:
    print("quick_check:", con.execute("PRAGMA quick_check").fetchone()[0])
    print("status_counts:")
    for row in con.execute("""
        SELECT status, COUNT(*)
        FROM v8011_ingress_queue
        GROUP BY status
        ORDER BY status
    """):
        print(" ", row[0], row[1])
PY
echo

echo "[7] Recent ingress errors"
docker logs --since 2h tradingbot_ingress 2>&1 \
  | grep -Ei 'V8011_.*ERROR|EXCEPTION|Traceback|ERROR|CRITICAL' \
  | tail -n 100 || true
echo

echo "[8] Recent backend webhook errors"
docker logs --since 2h tradingbot 2>&1 \
  | grep -Ei 'webhook|database is locked|Traceback|ERROR|CRITICAL' \
  | tail -n 150 || true
echo

echo "[9] Host resources"
uptime
free -h
df -h "$BASE"
echo

echo "=== V8011 CHECK FERTIG ==="
