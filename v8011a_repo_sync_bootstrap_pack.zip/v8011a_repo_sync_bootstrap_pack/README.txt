V8011A Repo Baseline Sync

Zweck:
- Erstellt einen bereinigten Snapshot des aktuell laufenden Server-Quellcodes.
- Keine .env, keine Datenbank, keine Logs, keine Backups, keine Tokens.
- Keine Live-Regeln, keine DB-Daten und kein Container werden verändert.

GitHub-Ziel:
https://github.com/IljaPreis/TradingBot

Server:
91.107.237.214
Projekt:
 /opt/tradingbot_v6000

Installation über Termius:
1. ZIP in das Hauptverzeichnis des GitHub-Branches main hochladen.
2. In Termius den Download- und Startblock ausführen.
3. Danach /root/v8011a_server_source_latest.tar.gz auf den PC laden.
4. Das Archiv hier im Chat hochladen oder als bereinigten Baseline-Stand in GitHub ablegen.
