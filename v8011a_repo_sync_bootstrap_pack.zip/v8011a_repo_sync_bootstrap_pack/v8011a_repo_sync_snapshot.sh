#!/usr/bin/env bash
set -euo pipefail
umask 077

BASE="/opt/tradingbot_v6000"
TS="$(date -u +%Y%m%d_%H%M%S)"
OUT="/root/v8011a_server_source_${TS}"
ARCHIVE="/root/v8011a_server_source_${TS}.tar.gz"
MANIFEST="/root/v8011a_server_source_${TS}.manifest.txt"
LATEST="/root/v8011a_server_source_latest.tar.gz"
LATEST_MANIFEST="/root/v8011a_server_source_latest.manifest.txt"

echo "=== V8011A REPO BASELINE SNAPSHOT ==="
echo "Source: $BASE"
echo "Output: $OUT"
echo "Mode: READ ONLY / NO LIVE CHANGES"

test -d "$BASE"
mkdir -p "$OUT"

copy_if_exists() {
  local src="$1"
  local dst="$2"
  if [[ -e "$src" ]]; then
    mkdir -p "$(dirname "$dst")"
    cp -a "$src" "$dst"
  fi
}

echo "[1] Current source files copy"

copy_if_exists "$BASE/app" "$OUT/app"
copy_if_exists "$BASE/pine" "$OUT/pine"
copy_if_exists "$BASE/ops" "$OUT/ops"
copy_if_exists "$BASE/scripts" "$OUT/scripts"
copy_if_exists "$BASE/schema" "$OUT/schema"
copy_if_exists "$BASE/tradingbot_v7000" "$OUT/tradingbot_v7000"
copy_if_exists "$BASE/Dockerfile" "$OUT/Dockerfile"
copy_if_exists "$BASE/docker-compose.yml" "$OUT/docker-compose.yml"
copy_if_exists "$BASE/requirements.txt" "$OUT/requirements.txt"
copy_if_exists "$BASE/requirements-v7000-patch.txt" "$OUT/requirements-v7000-patch.txt"
copy_if_exists "$BASE/config.v7000.yaml" "$OUT/config.v7000.yaml"
copy_if_exists "$BASE/.env.example" "$OUT/.env.example"
copy_if_exists "$BASE/README_V8001_V8002.md" "$OUT/README_V8001_V8002.md"

echo "[2] Remove generated / secret / runtime material"

find "$OUT" -type d \
  \( -name '__pycache__' -o -name '.pytest_cache' -o -name '.mypy_cache' \) \
  -prune -exec rm -rf {} + 2>/dev/null || true

find "$OUT" -type f \
  \( -name '*.pyc' -o -name '*.pyo' -o -name '*.sqlite' -o -name '*.sqlite3' \
     -o -name '*.db' -o -name '*.wal' -o -name '*.shm' -o -name '*.log' \
     -o -name '.env' -o -name '*token*' -o -name '*secret*' \) \
  -delete 2>/dev/null || true

echo "[3] Secret-pattern safety scan"

SECRET_HITS="$OUT/SECRET_SCAN_REVIEW.txt"

grep -RInE \
  '(TELEGRAM_BOT_TOKEN|WEBHOOK_TOKEN|API[_-]?KEY|PASSWORD|SECRET|PRIVATE[_-]?KEY)[[:space:]]*=[[:space:]]*[^[:space:]#]+' \
  "$OUT" \
  --exclude='SECRET_SCAN_REVIEW.txt' \
  > "$SECRET_HITS" || true

python3 - "$SECRET_HITS" <<'PY'
from pathlib import Path
import re, sys

p = Path(sys.argv[1])
text = p.read_text(encoding="utf-8", errors="replace") if p.exists() else ""
safe = []
for line in text.splitlines():
    line = re.sub(
        r'((?:TOKEN|PASSWORD|SECRET|API[_-]?KEY|PRIVATE[_-]?KEY)[^=]*=)\s*.*',
        r'\1 [REDACTED]',
        line,
        flags=re.I,
    )
    safe.append(line)
p.write_text("\n".join(safe) + ("\n" if safe else ""), encoding="utf-8")
print("Potential secret-name references:", len(safe))
PY

echo "[4] Build manifest"

{
  echo "V8011A SERVER SOURCE BASELINE"
  echo "Generated UTC: $(date -u --iso-8601=seconds)"
  echo "Server: $(hostname)"
  echo "Project: $BASE"
  echo
  echo "Docker:"
  docker ps --filter name=tradingbot --no-trunc || true
  echo
  echo "Key SHA256:"
  for f in \
    "$OUT/app/main.py" \
    "$OUT/docker-compose.yml" \
    "$OUT/Dockerfile" \
    "$OUT/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"; do
    if [[ -f "$f" ]]; then
      sha256sum "$f"
    fi
  done
  echo
  echo "Files:"
  find "$OUT" -type f -printf '%P\t%s bytes\n' | sort
} | tee "$MANIFEST"

cp "$MANIFEST" "$OUT/V8011A_MANIFEST.txt"

echo "[5] Create archive"

tar -czf "$ARCHIVE" -C /root "$(basename "$OUT")"
sha256sum "$ARCHIVE" | tee "${ARCHIVE}.sha256"

cp "$ARCHIVE" "$LATEST"
cp "$MANIFEST" "$LATEST_MANIFEST"
cp "${ARCHIVE}.sha256" "${LATEST}.sha256"

echo
echo "=== V8011A SNAPSHOT READY ==="
echo "Archive:  $ARCHIVE"
echo "Latest:   $LATEST"
echo "Manifest: $LATEST_MANIFEST"
echo "SHA file: ${LATEST}.sha256"
echo
echo "NO LIVE RULES CHANGED"
echo "NO DB WRITES"
echo "NO CONTAINER RESTART"
