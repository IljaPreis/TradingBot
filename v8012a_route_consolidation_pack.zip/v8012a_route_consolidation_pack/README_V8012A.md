# V8012A Route Consolidation

Zweck:
- Entfernt nur exakte, zur Laufzeit unerreichbare Routenduplikate.
- Behält immer die erste Route, die FastAPI bisher tatsächlich gematcht hat.
- Verändert keine eindeutige Route und keine Handelslogik.
- Fügt einen kanonischen Architekturbericht hinzu.
- Verlinkt den Bericht in Master und AI Review.

Neue Endpunkte:
- /v8012/route-consolidation
- /v8012/route-consolidation.json
- /v8012/selftest.json

Unverändert:
- V8004, V8006, V8007
- Pine V8001.4D
- V8011 Queue/Ingress/Dead Letter
- bestehende Trading-Datenbank
- Broker Auto Execution FALSE

V8012B ist erst nach diesem verhaltensgleichen Fundament vorgesehen:
- main.py in Router-Module teilen
- sichere Legacy-Aliase zu Redirects machen
- AI-Review-Berechnungen zentral cachen
- schreibende GET-Endpunkte auf POST umstellen
