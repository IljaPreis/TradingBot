from __future__ import annotations

import html
from datetime import datetime, timezone
from typing import Any

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8012A-ROUTE-CONSOLIDATION-V1"
MODE = "behavior_preserving_exact_route_deduplication"

SAFETY = {
    "route_behavior_preserved": True,
    "keeps_first_runtime_match": True,
    "removes_only_unreachable_exact_duplicates": True,
    "unique_routes_changed": False,
    "webhook_logic_changed": False,
    "signal_logic_changed": False,
    "v8004_changed": False,
    "v8006_changed": False,
    "v8007_changed": False,
    "pine_changed": False,
    "trading_db_writes": False,
    "trading_db_schema_changes": False,
    "broker_auto_execution": False,
}

PROTECTED_PATHS = {
    "/health",
    "/webhook",
    "/webhook/price",
    "/webhook/tradingview",
    "/v8004/selftest.json",
    "/v8006/selftest.json",
    "/v8007/selftest.json",
    "/v8008a/selftest.json",
    "/v8009/selftest.json",
}

CANONICAL_GROUPS = {
    "operations": [
        "/health",
        "/master",
        "/master-ai-review",
        "/v8011/ingress",
        "/v8011/monitor.json",
        "/v8012/route-consolidation",
    ],
    "signals": [
        "/v8000/master",
        "/v8001/pine-audit",
        "/v8004/quality-router",
        "/v8007/gate-bridge-audit",
        "/v8009/pine-14d",
    ],
    "news_calendar": [
        "/calendar",
        "/event-risk",
        "/pre-news-manager",
        "/financialjuice-impact-v7243",
        "/macro-actual-v7243",
        "/v8002/news-policy",
        "/v8006/calendar-execution-audit",
    ],
    "risk_performance": [
        "/position-overview",
        "/open-trade-risk",
        "/sl-tp-review",
        "/performance-learning",
        "/setup-performance",
        "/shadow-edge",
    ],
    "ai_review": [
        "/master-ai-review",
        "/v7601-deep-intelligence",
        "/v7612-warning-dashboard",
        "/v8012/route-consolidation",
    ],
}

LEGACY_FAMILIES = {
    "master_variants": [
        "/master",
        "/master-fast",
        "/master-mobile",
        "/master-full",
        "/master-clean",
        "/master-integration",
        "/v8000/master",
    ],
    "decision_views": [
        "/decisions",
        "/decisions2",
        "/decision-suite",
        "/decision-explain",
        "/decision-playbook",
        "/decision-review",
    ],
    "optimizer_views": [
        "/setup-optimizer",
        "/entry-bias-optimizer",
        "/v7244d-next-live",
        "/v7244e-threshold-sim",
        "/v7244f-recommended-preset",
        "/v7245b-tp-optimizer",
        "/v7245c-recommendations",
        "/v7246e-entry-upgrade-sim",
        "/v7246f-clean-upgrade-candidates",
        "/v7246g-entry-guard",
    ],
    "ai_review_chain": [
        "/v7602-weakness-audit",
        "/v7603-candidate-blocklist-review",
        "/v7604-derived-session-audit",
        "/v7605-cross-check-matrix",
        "/v7606-proposed-filter-report",
        "/v7607-top-cluster-trade-detail",
        "/v7608-root-cause-summary",
        "/v7609-v7601-confirmation-bridge",
        "/v7610-disabled-rule-draft-board",
        "/v7611-warning-only-simulation-board",
        "/v7612-warning-dashboard",
    ],
}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _route_methods(route: Any) -> tuple[str, ...]:
    methods = getattr(route, "methods", None)
    if not methods:
        return ()
    return tuple(sorted(str(m).upper() for m in methods))


def _route_signature(route: Any) -> tuple[str, tuple[str, ...]] | None:
    path = getattr(route, "path", None)
    methods = _route_methods(route)
    if not path or not methods:
        return None
    return str(path), methods


def _route_info(route: Any, index: int) -> dict[str, Any]:
    endpoint = getattr(route, "endpoint", None)
    return {
        "index": index,
        "path": str(getattr(route, "path", "") or ""),
        "methods": list(_route_methods(route)),
        "name": str(getattr(route, "name", "") or ""),
        "endpoint_module": str(getattr(endpoint, "__module__", "") or ""),
        "endpoint_qualname": str(getattr(endpoint, "__qualname__", "") or ""),
    }


def _scan_exact_duplicates(routes: list[Any]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, tuple[str, ...]], list[dict[str, Any]]] = {}
    for index, route in enumerate(routes):
        signature = _route_signature(route)
        if signature is None:
            continue
        grouped.setdefault(signature, []).append(_route_info(route, index))
    result = []
    for (path, methods), items in grouped.items():
        if len(items) > 1:
            result.append({
                "path": path,
                "methods": list(methods),
                "count": len(items),
                "routes": items,
            })
    return sorted(result, key=lambda x: (x["path"], x["methods"]))


def _dedupe_exact_routes(app: Any) -> dict[str, Any]:
    original = list(app.router.routes)
    seen: dict[tuple[str, tuple[str, ...]], Any] = {}
    kept: list[Any] = []
    removed: list[dict[str, Any]] = []
    protected_duplicates: list[dict[str, Any]] = []

    for index, route in enumerate(original):
        signature = _route_signature(route)
        if signature is None:
            kept.append(route)
            continue

        path, methods = signature
        if signature not in seen:
            seen[signature] = route
            kept.append(route)
            continue

        duplicate = {
            "path": path,
            "methods": list(methods),
            "kept": _route_info(seen[signature], original.index(seen[signature])),
            "removed": _route_info(route, index),
            "reason": "unreachable_exact_duplicate_after_first_runtime_match",
        }

        if path in PROTECTED_PATHS:
            kept.append(route)
            protected_duplicates.append(duplicate)
        else:
            removed.append(duplicate)

    app.router.routes[:] = kept
    app.openapi_schema = None

    return {
        "route_count_before": len(original),
        "route_count_after_dedupe": len(kept),
        "exact_duplicates_before": len(_scan_exact_duplicates(original)),
        "removed_exact_duplicate_routes": len(removed),
        "protected_duplicate_routes_not_removed": len(protected_duplicates),
        "removed": removed,
        "protected_duplicates": protected_duplicates,
    }


def _available_paths(app: Any) -> set[str]:
    return {
        str(getattr(route, "path", "") or "")
        for route in app.router.routes
        if getattr(route, "path", None)
    }


def _payload(app: Any) -> dict[str, Any]:
    state = getattr(app.state, "v8012a_report", {}) or {}
    paths = _available_paths(app)
    duplicates_after = _scan_exact_duplicates(list(app.router.routes))
    nonprotected_after = [
        item for item in duplicates_after if item.get("path") not in PROTECTED_PATHS
    ]
    groups = {
        group: {
            "configured": entries,
            "available": [path for path in entries if path in paths],
            "missing": [path for path in entries if path not in paths],
        }
        for group, entries in CANONICAL_GROUPS.items()
    }
    legacy = {
        family: {
            "routes": entries,
            "available": [path for path in entries if path in paths],
            "count_available": len([path for path in entries if path in paths]),
            "future_action": "retain_as_legacy_then_redirect_in_later_phase",
        }
        for family, entries in LEGACY_FAMILIES.items()
    }
    return {
        "ok": len(nonprotected_after) == 0,
        "version": VERSION,
        "mode": MODE,
        "generated_utc": _utcnow(),
        "summary": {
            **state,
            "current_route_count": len(app.router.routes),
            "exact_duplicate_groups_after": len(duplicates_after),
            "nonprotected_exact_duplicate_groups_after": len(nonprotected_after),
            "canonical_groups": len(groups),
            "legacy_families": len(legacy),
        },
        "duplicates_after": duplicates_after,
        "canonical_groups": groups,
        "legacy_families": legacy,
        "next_phase": {
            "version": "V8012B",
            "scope": [
                "split main.py registration into APIRouter modules",
                "replace safe legacy aliases with redirects",
                "merge AI review pages behind one cached service",
                "convert side-effect GET routes to authenticated POST",
            ],
            "automatic_live_rule_changes": False,
        },
        "safety": dict(SAFETY),
    }


def _html_page(data: dict[str, Any]) -> str:
    summary = data.get("summary") or {}
    removed = summary.get("removed_exact_duplicate_routes", 0)
    before = summary.get("route_count_before", "-")
    after = summary.get("route_count_after_dedupe", "-")
    rows = []
    for item in (summary and data.get("canonical_groups") or {}).items():
        name, group = item
        rows.append(
            "<tr>"
            f"<td>{html.escape(name)}</td>"
            f"<td>{len(group.get('available') or [])}</td>"
            f"<td>{len(group.get('missing') or [])}</td>"
            "</tr>"
        )
    legacy_rows = []
    for name, family in (data.get("legacy_families") or {}).items():
        legacy_rows.append(
            "<tr>"
            f"<td>{html.escape(name)}</td>"
            f"<td>{family.get('count_available', 0)}</td>"
            "<td>Legacy behalten; Redirect erst in V8012B</td>"
            "</tr>"
        )
    status = "PASS" if data.get("ok") else "REVIEW"
    color = "#22c55e" if data.get("ok") else "#f59e0b"
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>V8012 Route Consolidation</title>
<style>
body{{margin:0;background:#07111e;color:#eef6ff;font-family:Arial,sans-serif}}
.wrap{{max-width:1100px;margin:auto;padding:16px}}
.card{{background:#101d2e;border:1px solid #273a52;border-radius:14px;padding:14px;margin:12px 0}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}}
.k{{color:#9caec4;font-size:12px}} .v{{font-size:25px;font-weight:800;margin-top:4px}}
table{{width:100%;border-collapse:collapse}} th,td{{padding:9px;border-bottom:1px solid #273a52;text-align:left}}
a{{color:#7dd3fc}} .status{{color:{color};font-weight:800}}
</style></head><body><div class="wrap">
<h1>V8012A Route Consolidation</h1>
<p>Verhaltensgleiche Entfernung unerreichbarer exakter Routenduplikate. Keine Handelslogik geändert.</p>
<div class="grid">
<div class="card"><div class="k">Status</div><div class="v status">{status}</div></div>
<div class="card"><div class="k">Routen vorher</div><div class="v">{before}</div></div>
<div class="card"><div class="k">Routen nachher</div><div class="v">{after}</div></div>
<div class="card"><div class="k">Duplikate entfernt</div><div class="v">{removed}</div></div>
</div>
<div class="card"><h2>Kanonische Bereiche</h2><table><tr><th>Bereich</th><th>Vorhanden</th><th>Fehlt</th></tr>{''.join(rows)}</table></div>
<div class="card"><h2>Legacy-Familien</h2><table><tr><th>Familie</th><th>Routen</th><th>Aktion</th></tr>{''.join(legacy_rows)}</table></div>
<div class="card"><a href="/v8012/route-consolidation.json">JSON-Detailbericht</a> · <a href="/v8012/selftest.json">Selftest</a> · <a href="/master-ai-review">AI Review</a></div>
</div></body></html>"""


def install_v8012a_route_consolidation(app: Any) -> None:
    if getattr(app.state, "v8012a_route_consolidation_installed", False):
        return

    report = _dedupe_exact_routes(app)
    app.state.v8012a_report = report

    @app.get("/v8012/route-consolidation.json")
    def v8012a_route_consolidation_json(request: Request):
        return JSONResponse(_payload(app))

    @app.get("/v8012/selftest.json")
    def v8012a_selftest_json(request: Request):
        data = _payload(app)
        return JSONResponse({
            "ok": data.get("ok"),
            "version": VERSION,
            "mode": MODE,
            "route_count_before": report.get("route_count_before"),
            "route_count_after_dedupe": report.get("route_count_after_dedupe"),
            "removed_exact_duplicate_routes": report.get("removed_exact_duplicate_routes"),
            "nonprotected_exact_duplicate_groups_after": (
                data.get("summary") or {}
            ).get("nonprotected_exact_duplicate_groups_after"),
            "safety": dict(SAFETY),
        })

    @app.get("/v8012/route-consolidation", response_class=HTMLResponse)
    def v8012a_route_consolidation_page(request: Request):
        return HTMLResponse(_html_page(_payload(app)))

    app.state.v8012a_route_consolidation_installed = True
    app.openapi_schema = None
    print(
        "[V8012A] Route consolidation installed: "
        f"before={report.get('route_count_before')} "
        f"after_dedupe={report.get('route_count_after_dedupe')} "
        f"removed={report.get('removed_exact_duplicate_routes')}"
    )
