#!/usr/bin/env bash
set -u

BASE="/opt/tradingbot_v6000"

echo "=== V8012A SERVER CONSOLIDATION CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"

echo "[1] Containers"
cd "$BASE" || exit 1
docker compose ps

echo "[2] V8012A selftest"
curl -fsS --max-time 20 http://127.0.0.1/v8012/selftest.json | python3 -m json.tool

echo "[3] Consolidation summary"
curl -fsS --max-time 30 http://127.0.0.1/v8012/route-consolidation.json | python3 - <<'PY'
import json, sys
d=json.load(sys.stdin)
s=d.get("summary") or {}
print(json.dumps({
  "ok": d.get("ok"),
  "version": d.get("version"),
  "route_count_before": s.get("route_count_before"),
  "route_count_after_dedupe": s.get("route_count_after_dedupe"),
  "removed_exact_duplicate_routes": s.get("removed_exact_duplicate_routes"),
  "exact_duplicate_groups_after": s.get("exact_duplicate_groups_after"),
  "nonprotected_exact_duplicate_groups_after": s.get("nonprotected_exact_duplicate_groups_after"),
  "canonical_groups": s.get("canonical_groups"),
  "legacy_families": s.get("legacy_families"),
}, indent=2))
PY

echo "[4] Ingress health and token mode"
curl -fsS --max-time 20 http://127.0.0.1/v8011/selftest.json | python3 - <<'PY'
import json, sys
d=json.load(sys.stdin)
print(json.dumps({
  "ok": d.get("ok"),
  "version": d.get("version"),
  "operational_status": d.get("operational_status"),
  "queue_depth": d.get("queue_depth"),
  "backend_ok": d.get("backend_ok"),
  "worker_alive": d.get("worker_alive"),
  "token_mode": d.get("token_mode"),
  "token_configured": d.get("token_configured"),
  "token_enforced": d.get("token_enforced"),
}, indent=2))
PY

echo "[5] Critical routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/route-consolidation.json \
  /v8012/selftest.json
do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 "http://127.0.0.1${route}" || true)"
  printf '%-48s %s\n' "$route" "$code"
done

echo "[6] Protected hashes"
sha256sum \
  app/v8004_quality_router.py \
  app/v8006_calendar_execution_correction.py \
  app/v8007_v8001_gate_bridge.py \
  pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine

echo "[7] Errors last 30m"
docker logs --since 30m tradingbot 2>&1 \
  | grep -Ei 'Traceback|ERROR|Exception|FATAL|V8012A.*error' \
  | tail -n 100 || true

echo "[8] Host resources"
uptime
free -h
df -h "$BASE"

echo "=== V8012A CHECK FERTIG ==="
