# V8012B.1 – Consolidation Hub Validation Fix

V8012B.1 installs the same behavior-preserving consolidation hub and browser-only redirects planned for V8012B, but fixes the installer and diagnostic validation.

## Why V8012B rolled back

The previous installer rendered every legacy master page during installation. One legacy route exceeded the 20-second curl limit. The application itself had passed its selftests, but the strict heavy-page probe triggered the automatic rollback.

The old V8012A diagnostic script also used `curl | python3 - <<'PY'`, which sends the Python program and JSON through the same stdin. This caused `curl: (23)` and JSON decode errors.

## V8012B.1 changes

- Browser redirects are verified only through their fast 307 response.
- Legacy/API compatibility is verified through route metadata and the redirect registry; heavy legacy pages are not rendered by the installer.
- The consolidation check stores JSON in temporary files before parsing.
- Four aliases redirect browser HTML traffic to `/master`.
- Existing API behavior remains untouched.
- `?legacy=1` remains registered as the bypass.
- Side-effect GET routes remain audit-only.

## Safety

No changes to V8004, V8006, V8007, Pine, ingress queue logic, trading DB, signal scoring, routing or broker execution. Token mode remains off.
