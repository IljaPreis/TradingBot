#!/usr/bin/env bash
set -u

BASE="/opt/tradingbot_v6000"
TMP_DIR="$(mktemp -d /tmp/v8012_check.XXXXXX)"
trap 'rm -rf "$TMP_DIR"' EXIT

fetch_json() {
  local url="$1" out="$2" timeout="${3:-30}"
  curl -fsS --max-time "$timeout" "$url" -o "$out"
}

status_code() {
  curl -sS -o /dev/null -w '%{http_code}' --max-time "${2:-20}" "$1" 2>/dev/null || true
}

echo "=== V8012B.1 CONSOLIDATION CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"
cd "$BASE" || exit 1

FAIL=0

echo "[1] Containers"
docker compose ps

echo "[2] V8012A + V8012B.1 selftests"
fetch_json http://127.0.0.1/v8012/selftest.json "$TMP_DIR/v8012a.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-b.json "$TMP_DIR/v8012b.json" || FAIL=1
if [[ "$FAIL" == "0" ]]; then
  python3 - "$TMP_DIR/v8012a.json" "$TMP_DIR/v8012b.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: a=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f: b=json.load(f)
print(json.dumps({
  'v8012a_ok': a.get('ok'),
  'removed_exact_duplicate_routes': a.get('removed_exact_duplicate_routes'),
  'duplicates_after': a.get('nonprotected_exact_duplicate_groups_after'),
  'v8012b_ok': b.get('ok'),
  'version': b.get('version'),
  'required_routes_present': b.get('required_routes_present'),
  'browser_alias_redirects_added': b.get('browser_alias_redirect_count_added'),
  'canonical_html_aliases_total': b.get('canonical_html_aliases_total'),
  'side_effect_get_candidates': b.get('side_effect_get_candidates'),
}, indent=2))
assert a.get('ok') is True
assert int(a.get('nonprotected_exact_duplicate_groups_after') or 0)==0
assert b.get('ok') is True
assert b.get('version')=='V8012B.1-CONSOLIDATION-HUB-VALIDATION-FIX-V1'
assert b.get('required_routes_present') is True
PY
fi

echo "[3] Browser redirects – fast path only"
for route in /master-fast /master-mobile /master-full /master-integration; do
  headers="$(curl -sS -D - -o /dev/null --max-time 10 -H 'Accept: text/html' "http://127.0.0.1${route}" 2>/dev/null || true)"
  code="$(printf '%s\n' "$headers" | awk 'toupper($1) ~ /^HTTP\// {c=$2} END {print c}')"
  location="$(printf '%s\n' "$headers" | awk 'BEGIN{IGNORECASE=1} /^location:/ {gsub("\r",""); print $2}' | tail -n 1)"
  printf '%-24s browser=%s location=%s\n' "$route" "${code:-none}" "${location:-none}"
  [[ "$code" == "307" && "$location" == "/master" ]] || FAIL=1
done

echo "[4] Compatibility registry – no heavy legacy render"
fetch_json http://127.0.0.1/v8012/redirects.json "$TMP_DIR/redirects.json" || FAIL=1
if [[ -s "$TMP_DIR/redirects.json" ]]; then
  python3 - "$TMP_DIR/redirects.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: d=json.load(f)
rows=d.get('redirects') or []
print(json.dumps({
  'ok': d.get('ok'),
  'version': d.get('version'),
  'redirect_count': len(rows),
  'sources': [x.get('source') for x in rows],
  'legacy_bypass_registered': all(bool(x.get('legacy_bypass')) for x in rows),
  'json_routes_unchanged': all(x.get('json_routes_unchanged') is True for x in rows),
}, indent=2))
assert d.get('ok') is True
assert len(rows)==4
assert all(bool(x.get('legacy_bypass')) for x in rows)
assert all(x.get('json_routes_unchanged') is True for x in rows)
PY
fi

echo "[5] Hub + side-effect audit"
fetch_json http://127.0.0.1/v8012/hub.json "$TMP_DIR/hub.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/side-effect-audit.json "$TMP_DIR/sideeffects.json" || FAIL=1
if [[ -s "$TMP_DIR/hub.json" && -s "$TMP_DIR/sideeffects.json" ]]; then
  python3 - "$TMP_DIR/hub.json" "$TMP_DIR/sideeffects.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: h=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f: s=json.load(f)
summary=h.get('summary') or {}
print(json.dumps({
  'hub_ok': h.get('ok'),
  'route_count': summary.get('route_count'),
  'canonical_groups': summary.get('canonical_groups'),
  'cache_ttl_seconds': summary.get('cache_ttl_seconds'),
  'side_effect_audit_ok': s.get('ok'),
  'candidate_count': len(s.get('candidates') or []),
  'automatic_changes': s.get('automatic_changes'),
}, indent=2))
assert h.get('ok') is True
assert s.get('ok') is True
assert s.get('automatic_changes') is False
PY
fi

echo "[6] Ingress health and token OFF"
fetch_json http://127.0.0.1/v8011/selftest.json "$TMP_DIR/ingress.json" || FAIL=1
if [[ -s "$TMP_DIR/ingress.json" ]]; then
  python3 - "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: d=json.load(f)
print(json.dumps({
  'ok': d.get('ok'),
  'operational_status': d.get('operational_status'),
  'queue_depth': d.get('queue_depth'),
  'backend_ok': d.get('backend_ok'),
  'worker_alive': d.get('worker_alive'),
  'token_mode': d.get('token_mode'),
  'token_configured': d.get('token_configured'),
  'token_enforced': d.get('token_enforced'),
}, indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY
fi

echo "[7] Critical lightweight routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/route-consolidation.json \
  /v8012/selftest.json \
  /v8012/hub \
  /v8012/hub.json \
  /v8012/redirects.json \
  /v8012/side-effect-audit.json \
  /v8012/selftest-b.json
 do
  code="$(status_code "http://127.0.0.1${route}" 25)"
  printf '%-48s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || FAIL=1
 done

echo "[8] Navigation"
if curl -fsS --max-time 30 http://127.0.0.1/master | grep -q "V8012 Consolidation Hub"; then
  echo "Master link: PASS"
else
  echo "Master link: FAIL"; FAIL=1
fi
if curl -fsS --max-time 30 http://127.0.0.1/master-ai-review | grep -q "V8012 Consolidation Hub"; then
  echo "AI Review link: PASS"
else
  echo "AI Review link: FAIL"; FAIL=1
fi

echo "[9] Protected hashes"
sha256sum \
  app/v8011_ingress.py \
  app/v8004_quality_router.py \
  app/v8006_calendar_execution_correction.py \
  app/v8007_v8001_gate_bridge.py \
  pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine

echo "[10] Actual errors last 30m"
docker logs --since 30m tradingbot 2>&1 \
  | grep -Ei 'Traceback|ERROR|Exception|FATAL|V8012B\.1.*error' \
  | tail -n 100 || true

echo "[11] Host resources"
uptime
free -h
df -h "$BASE"

if [[ "$FAIL" != "0" ]]; then
  echo "=== V8012B.1 CHECK FEHLER ==="
  exit 1
fi

echo "=== V8012B.1 CHECK FERTIG ==="
