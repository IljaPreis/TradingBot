# V8012B Consolidation Hub + Safe Browser Redirects

Version: `V8012B-CONSOLIDATION-HUB-REDIRECTS-V1`

## Zweck

V8012B führt die erste echte, verhaltensschonende Konsolidierungsphase ein:

- neue V8012-Routen werden über einen separaten `APIRouter` registriert,
- ein kanonischer Consolidation Hub fasst Operations, Signals, News, Risk/Performance und AI Review zusammen,
- fünf alte Master-HTML-Varianten werden nur für Browseraufrufe auf `/master` weitergeleitet,
- JSON- und API-Routen bleiben unverändert,
- mit `?legacy=1` bleibt jede alte HTML-Seite direkt erreichbar,
- potenziell schreibende GET-Routen werden nur auditiert, nicht verändert,
- die Architekturübersicht wird für 30 Sekunden im Speicher gecacht.

## Sichere Browser-Redirects

- `/master-fast` → `/master`
- `/master-mobile` → `/master`
- `/master-full` → `/master`
- `/master-integration` → `/master`

Die vier neu hinzugefügten Weiterleitungen greifen nur bei `Accept: text/html`. Curl/API-Aufrufe und JSON-Routen werden nicht umgeleitet. `/master-clean` wurde bereits vor V8012B systemweit nach `/master` umgeleitet und wird nur als bestehender Alias dokumentiert.

Originalseite weiterhin erreichbar:

```text
/master-fast?legacy=1
```

## Neue Routen

- `/v8012/hub`
- `/v8012/hub.json`
- `/v8012/redirects.json`
- `/v8012/side-effect-audit.json`
- `/v8012/selftest-b.json`

## Unverändert

- V8004 Quality Router
- V8006 Kalenderkorrektur
- V8007 Gate Bridge
- V8011 Ingress, Queue und Dead Letter
- Pine V8001.4D
- Trading-Datenbank
- Live-Scoring und Routing
- Webhook-Token bleibt OFF
- Broker Auto Execution bleibt FALSE

## Nächste Phase

V8012C soll sichere POST-Ersatzrouten für Side-Effect-GETs, einen gecachten AI-Review-Snapshot und weitere APIRouter-Extraktion ergänzen. Alte URLs werden dabei zunächst kompatibel weitergeführt.
