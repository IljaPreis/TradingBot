from __future__ import annotations

import html
import threading
import time
from datetime import datetime, timezone
from typing import Any
from urllib.parse import parse_qs

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from starlette.types import ASGIApp, Receive, Scope, Send

VERSION = "V8012B-CONSOLIDATION-HUB-REDIRECTS-V1"
MODE = "behavior_preserving_html_alias_consolidation"
CACHE_TTL_SECONDS = 30.0

SAFETY = {
    "transport_changed": False,
    "webhook_logic_changed": False,
    "signal_logic_changed": False,
    "v8004_changed": False,
    "v8006_changed": False,
    "v8007_changed": False,
    "pine_changed": False,
    "trading_db_writes": False,
    "trading_db_schema_changes": False,
    "live_scoring_changed": False,
    "live_routing_changed": False,
    "token_mode_forced_off": True,
    "broker_auto_execution": False,
}

# Browser-only aliases. JSON/API routes remain untouched.
LEGACY_HTML_REDIRECTS: dict[str, str] = {
    "/master-fast": "/master",
    "/master-mobile": "/master",
    "/master-full": "/master",
    "/master-integration": "/master",
}

PREEXISTING_HTML_REDIRECTS: dict[str, str] = {
    "/master-clean": "/master",
}

CANONICAL_GROUPS: dict[str, list[tuple[str, str, str]]] = {
    "operations": [
        ("Master", "/master", "Primäre Betriebsübersicht"),
        ("Ingress", "/v8011/ingress", "Queue, Latenz und Dead Letter"),
        ("Route Architecture", "/v8012/route-consolidation", "Exakte Routenduplikate und Architektur"),
        ("Consolidation Hub", "/v8012/hub", "Kanonische Bereiche und Legacy-Status"),
    ],
    "signals": [
        ("V8000 Master", "/v8000/master", "Dual-Playbook-Auswertung"),
        ("Pine Audit", "/v8001/pine-audit", "Pine-Schema und Kontextfelder"),
        ("Quality Router", "/v8004/quality-router", "LIVE/SHADOW/NO_TRADE-Routing"),
        ("Gate Bridge", "/v8007/gate-bridge-audit", "V8001 Gate-Bridge"),
        ("Pine 1.4D", "/v8009/pine-14d", "Finale V8001.4D-Kompatibilität"),
    ],
    "news_calendar": [
        ("Calendar", "/calendar", "Kanonischer Wirtschaftskalender"),
        ("Event Risk", "/event-risk", "Aktuelles Event-Risiko"),
        ("Pre-News", "/pre-news-manager", "Pre-/Post-News-Kontext"),
        ("News Policy", "/v8002/news-policy", "V8002 Newsfenster"),
        ("Calendar Audit", "/v8006/calendar-execution-audit", "V8006 Kalenderkorrektur"),
    ],
    "risk_performance": [
        ("Position Overview", "/position-overview", "Offene Positionen"),
        ("Open Trade Risk", "/open-trade-risk", "Risiko offener Trades"),
        ("SL/TP Review", "/sl-tp-review", "SL-/TP-Auswertung"),
        ("Performance", "/performance-learning", "Performance und Learning"),
        ("Shadow Edge", "/shadow-edge", "Shadow-Ergebnisse"),
    ],
    "ai_review": [
        ("AI Review", "/master-ai-review", "Primäre AI-Review-Seite"),
        ("Deep Intelligence", "/v7601-deep-intelligence", "Cluster- und Schwächenanalyse"),
        ("Warning Dashboard", "/v7612-warning-dashboard", "Observe-only Warnregeln"),
        ("Consolidation Hub", "/v8012/hub", "Architektur- und Legacy-Übersicht"),
    ],
}

SIDE_EFFECT_GET_PATTERNS = (
    "/pause/on",
    "/pause/off",
    "/sync",
    "/rescore",
    "/update",
    "/warmup",
    "/repair",
    "/apply",
    "/set",
    "/toggle",
    "/backfill",
)

_cache_lock = threading.Lock()
_cache: dict[str, Any] = {"created": 0.0, "payload": None}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _methods(route: Any) -> list[str]:
    return sorted(str(x).upper() for x in (getattr(route, "methods", None) or []))


def _paths(app: Any) -> set[str]:
    return {
        str(getattr(route, "path", "") or "")
        for route in app.router.routes
        if getattr(route, "path", None)
    }


def _route_inventory(app: Any) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for route in app.router.routes:
        path = str(getattr(route, "path", "") or "")
        methods = _methods(route)
        if not path or not methods:
            continue
        endpoint = getattr(route, "endpoint", None)
        result.append({
            "path": path,
            "methods": methods,
            "name": str(getattr(route, "name", "") or ""),
            "endpoint_module": str(getattr(endpoint, "__module__", "") or ""),
        })
    return sorted(result, key=lambda item: (item["path"], item["methods"]))


def _side_effect_get_audit(inventory: list[dict[str, Any]]) -> list[dict[str, Any]]:
    hits: list[dict[str, Any]] = []
    for item in inventory:
        path = item["path"]
        if "GET" not in item["methods"]:
            continue
        matched = [pattern for pattern in SIDE_EFFECT_GET_PATTERNS if pattern in path]
        if matched:
            hits.append({
                "path": path,
                "methods": item["methods"],
                "matched_patterns": matched,
                "recommendation": "retain_for_compatibility_then_migrate_to_authenticated_post",
            })
    return hits


def _build_payload(app: Any) -> dict[str, Any]:
    paths = _paths(app)
    inventory = _route_inventory(app)
    groups: dict[str, Any] = {}
    for group, entries in CANONICAL_GROUPS.items():
        groups[group] = {
            "items": [
                {
                    "title": title,
                    "path": path,
                    "description": description,
                    "available": path in paths,
                }
                for title, path, description in entries
            ]
        }
    side_effects = _side_effect_get_audit(inventory)
    return {
        "ok": True,
        "version": VERSION,
        "mode": MODE,
        "generated_utc": _utcnow(),
        "summary": {
            "route_count": len(inventory),
            "canonical_groups": len(groups),
            "browser_alias_redirects_added": len(LEGACY_HTML_REDIRECTS),
            "preexisting_html_redirects": len(PREEXISTING_HTML_REDIRECTS),
            "canonical_html_aliases_total": len(LEGACY_HTML_REDIRECTS) + len(PREEXISTING_HTML_REDIRECTS),
            "side_effect_get_candidates": len(side_effects),
            "cache_ttl_seconds": CACHE_TTL_SECONDS,
            "legacy_bypass_query": "legacy=1",
        },
        "canonical_groups": groups,
        "legacy_html_redirects": [
            {
                "source": source,
                "target": target,
                "browser_only": True,
                "json_routes_unchanged": True,
                "legacy_bypass": f"{source}?legacy=1",
            }
            for source, target in LEGACY_HTML_REDIRECTS.items()
        ],
        "preexisting_html_redirects": [
            {
                "source": source,
                "target": target,
                "browser_only": False,
                "json_routes_unchanged": False,
                "legacy_bypass": None,
                "note": "preexisting_redirect_before_v8012b",
            }
            for source, target in PREEXISTING_HTML_REDIRECTS.items()
        ],
        "side_effect_get_audit": side_effects,
        "next_phase": {
            "version": "V8012C",
            "scope": [
                "cached AI review snapshot service",
                "safe POST replacements for side-effect GET routes",
                "legacy GET compatibility wrappers without removing old URLs",
                "continue APIRouter extraction from main.py",
            ],
            "automatic_live_rule_changes": False,
        },
        "safety": dict(SAFETY),
    }


def _payload(app: Any, force: bool = False) -> dict[str, Any]:
    now = time.monotonic()
    with _cache_lock:
        if (
            not force
            and _cache.get("payload") is not None
            and now - float(_cache.get("created") or 0.0) < CACHE_TTL_SECONDS
        ):
            return _cache["payload"]
        data = _build_payload(app)
        _cache["created"] = now
        _cache["payload"] = data
        return data


def _html_page(data: dict[str, Any]) -> str:
    cards: list[str] = []
    for group_name, group in (data.get("canonical_groups") or {}).items():
        links = []
        for item in group.get("items") or []:
            state = "OK" if item.get("available") else "FEHLT"
            links.append(
                "<li>"
                f'<a href="{html.escape(item["path"])}">{html.escape(item["title"])}</a>'
                f' <span class="state">{state}</span><br>'
                f'<span class="desc">{html.escape(item["description"])}</span>'
                "</li>"
            )
        cards.append(
            f'<section class="card"><h2>{html.escape(group_name.replace("_", " ").title())}</h2>'
            f'<ul>{"".join(links)}</ul></section>'
        )
    redirects = "".join(
        "<tr>"
        f'<td>{html.escape(item["source"])}</td>'
        f'<td>{html.escape(item["target"])}</td>'
        f'<td>{html.escape(item["legacy_bypass"])}</td>'
        "</tr>"
        for item in (data.get("legacy_html_redirects") or [])
    )
    summary = data.get("summary") or {}
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>V8012 Consolidation Hub</title>
<style>
body{{margin:0;background:#07111e;color:#eff7ff;font-family:Arial,sans-serif}}
.wrap{{max-width:1180px;margin:auto;padding:16px}} .grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:12px}}
.card{{background:#101d2e;border:1px solid #2b405b;border-radius:14px;padding:14px}} a{{color:#7dd3fc}}
ul{{padding-left:20px}} li{{margin:10px 0}} .desc{{color:#9fb1c7;font-size:13px}} .state{{font-size:11px;color:#86efac}}
table{{width:100%;border-collapse:collapse}} th,td{{padding:9px;border-bottom:1px solid #2b405b;text-align:left;font-size:13px}}
.badge{{display:inline-block;padding:5px 9px;border-radius:999px;background:#123222;color:#86efac;font-weight:700}}
</style></head><body><div class="wrap">
<h1>V8012B Consolidation Hub</h1><p><span class="badge">PASS</span> Browser-Aliase konsolidiert; APIs und Handelslogik unverändert.</p>
<p>Routen: {summary.get("route_count", "-")} · neue Browser-Redirects: {summary.get("browser_alias_redirects_added", "-")} · kanonische HTML-Aliase gesamt: {summary.get("canonical_html_aliases_total", "-")} · mögliche Side-Effect-GETs: {summary.get("side_effect_get_candidates", "-")}</p>
<div class="grid">{''.join(cards)}</div>
<section class="card" style="margin-top:12px"><h2>Browser-Alias-Redirects</h2><table><tr><th>Alt</th><th>Kanonisch</th><th>Original weiterhin erreichbar</th></tr>{redirects}</table></section>
<section class="card" style="margin-top:12px"><a href="/v8012/hub.json">Hub JSON</a> · <a href="/v8012/redirects.json">Redirect JSON</a> · <a href="/v8012/side-effect-audit.json">Side-Effect-Audit</a> · <a href="/v8012/selftest-b.json">Selftest</a></section>
</div></body></html>"""


router = APIRouter(prefix="/v8012", tags=["V8012 Consolidation"])


@router.get("/hub.json")
def v8012b_hub_json(request: Request, refresh: bool = False):
    return JSONResponse(_payload(request.app, force=refresh))


@router.get("/hub", response_class=HTMLResponse)
def v8012b_hub_page(request: Request):
    return HTMLResponse(_html_page(_payload(request.app)))


@router.get("/redirects.json")
def v8012b_redirects_json(request: Request):
    data = _payload(request.app)
    return JSONResponse({
        "ok": True,
        "version": VERSION,
        "redirects": data.get("legacy_html_redirects") or [],
        "safety": dict(SAFETY),
    })


@router.get("/side-effect-audit.json")
def v8012b_side_effect_audit_json(request: Request, refresh: bool = False):
    data = _payload(request.app, force=refresh)
    return JSONResponse({
        "ok": True,
        "version": VERSION,
        "candidates": data.get("side_effect_get_audit") or [],
        "automatic_changes": False,
        "safety": dict(SAFETY),
    })


@router.get("/selftest-b.json")
def v8012b_selftest_json(request: Request):
    data = _payload(request.app, force=True)
    routes = _paths(request.app)
    required = {
        "/v8012/hub",
        "/v8012/hub.json",
        "/v8012/redirects.json",
        "/v8012/side-effect-audit.json",
        "/v8012/selftest-b.json",
    }
    return JSONResponse({
        "ok": required.issubset(routes),
        "version": VERSION,
        "mode": MODE,
        "required_routes_present": required.issubset(routes),
        "browser_alias_redirect_count_added": len(LEGACY_HTML_REDIRECTS),
        "preexisting_redirect_count": len(PREEXISTING_HTML_REDIRECTS),
        "canonical_html_aliases_total": len(LEGACY_HTML_REDIRECTS) + len(PREEXISTING_HTML_REDIRECTS),
        "side_effect_get_candidates": (data.get("summary") or {}).get("side_effect_get_candidates"),
        "cache_ttl_seconds": CACHE_TTL_SECONDS,
        "safety": dict(SAFETY),
    })


class LegacyHtmlRedirectMiddleware:
    def __init__(self, app: ASGIApp):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") != "http" or scope.get("method") != "GET":
            await self.app(scope, receive, send)
            return

        path = str(scope.get("path") or "")
        target = LEGACY_HTML_REDIRECTS.get(path)
        if not target:
            await self.app(scope, receive, send)
            return

        query = parse_qs((scope.get("query_string") or b"").decode("utf-8", errors="ignore"))
        if str((query.get("legacy") or [""])[0]).lower() in {"1", "true", "yes", "on"}:
            await self.app(scope, receive, send)
            return

        headers = {
            key.decode("latin-1").lower(): value.decode("latin-1")
            for key, value in (scope.get("headers") or [])
        }
        accept = headers.get("accept", "")
        if "text/html" not in accept.lower():
            await self.app(scope, receive, send)
            return

        response = RedirectResponse(url=target, status_code=307)
        response.headers["X-V8012-Legacy-Alias"] = path
        response.headers["X-V8012-Canonical"] = target
        await response(scope, receive, send)


def install_v8012b_consolidation(app: Any) -> None:
    if getattr(app.state, "v8012b_consolidation_installed", False):
        return
    app.include_router(router)
    app.add_middleware(LegacyHtmlRedirectMiddleware)
    app.state.v8012b_consolidation_installed = True
    app.openapi_schema = None
    print(
        "[V8012B] Consolidation hub + browser alias redirects installed: "
        f"redirects={len(LEGACY_HTML_REDIRECTS)} cache_ttl={CACHE_TTL_SECONDS}s"
    )
