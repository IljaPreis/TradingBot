#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="V8012B-CONSOLIDATION-HUB-REDIRECTS-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8012b_before_${TS}"
LOG="/root/v8012b_install_${TS}.log"

EXPECTED_MAIN_OLD="ea4c03a4c5e38b90621ba5ab8ffffdfbade9a1070dbe3e8498d8e7d7c77346f6"
EXPECTED_MAIN_NEW="65681fee3129cb33be230144502df6ec1aeb4cd4f402e35dc4178ac3c491946a"
EXPECTED_NAV_OLD="39540bb5a89acdb59d092d62f309185522339d9923ea3630274a76a392379f16"
EXPECTED_NAV_NEW="60d8c19b4ea9b7cbee23b5976f6fe37f7c2b9c971839210b4e9061b00534c864"
EXPECTED_V8012A="30e36a321e9c41810d766aaa7c857637e2c15d2f11fbc504c9b5969c27390af9"
EXPECTED_ROUTER_NEW="5ed8233fd9df808cfc4fdc2ee1c2b131574a26cd1f0899edafe986bd54b38a42"
EXPECTED_COMPOSE_OLD="d4f3ae2325dfea1a4587afec5a132f6af1a37b1e260b8a28fd1b89db7e817a56"
EXPECTED_COMPOSE_NEW="b9db7882f07f27f0e94558e1f9f39cf0e173d0ba0b38b514044af9f27e67752c"
EXPECTED_INGRESS="0b50a8dcce8e0f2ef71dead1d5489bdd1c915b932acefa166eec656828806c8b"
EXPECTED_V8004="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

ROLLBACK_ARMED=0
exec > >(tee -a "$LOG") 2>&1

sha() { sha256sum "$1" | awk '{print $1}'; }
die() { echo "FATAL: $*" >&2; exit 1; }

wait_http_200() {
  local url="$1" attempts="${2:-75}" sleep_s="${3:-2}" i code
  for i in $(seq 1 "$attempts"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    echo "WAIT [$i/$attempts] $url status=${code:-none}"
    sleep "$sleep_s"
  done
  return 1
}

rollback() {
  local rc=$?
  trap - ERR
  if [[ "$ROLLBACK_ARMED" != "1" ]]; then exit "$rc"; fi
  echo
  echo "=== V8012B ROLLBACK START ==="
  cp -a "$BACKUP/main.py" "$BASE/app/main.py" || true
  cp -a "$BACKUP/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py" || true
  cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml" || true
  cp -a "$BACKUP/.env" "$BASE/.env" || true
  chmod 600 "$BASE/.env" || true
  if [[ -f "$BACKUP/v8012b_consolidation_router.py" ]]; then
    mkdir -p "$BASE/app/routes"
    cp -a "$BACKUP/v8012b_consolidation_router.py" "$BASE/app/routes/v8012b_consolidation_router.py" || true
  else
    rm -f "$BASE/app/routes/v8012b_consolidation_router.py"
  fi
  if [[ -f "$BACKUP/v8012_consolidation_check.sh" ]]; then
    cp -a "$BACKUP/v8012_consolidation_check.sh" "$BASE/ops/v8012_consolidation_check.sh" || true
  fi
  if [[ -f "$BACKUP/README_V8012B.md" ]]; then
    cp -a "$BACKUP/README_V8012B.md" "$BASE/README_V8012B.md" || true
  else
    rm -f "$BASE/README_V8012B.md"
  fi
  cd "$BASE"
  docker compose config >/dev/null 2>&1 || true
  docker compose up -d --build --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8012B ROLLBACK ENDE ==="
  exit "$rc"
}
trap rollback ERR

cat <<EOF
================================================================================
$VERSION INSTALL
================================================================================
Generated UTC: $(date -u --iso-8601=seconds)
Project: $BASE
Package: $PACKAGE_DIR

Scope:
  First APIRouter modular extraction: ADD
  Canonical V8012 consolidation hub: ADD
  Browser-only master alias redirects: ADD
  Legacy HTML bypass with ?legacy=1: ADD
  JSON/API routes: UNCHANGED
  Side-effect GET routes: AUDIT ONLY, no automatic changes

Safety:
  V8004/V8006/V8007 changes: 0
  Canonical Pine changes: 0
  V8011 ingress/queue/dead-letter changes: 0
  Trading DB schema/writes: 0
  Live scoring/routing changes: 0
  Token mode: OFF
  Broker auto execution: FALSE
EOF

[[ -d "$BASE" ]] || die "Project not found: $BASE"

for f in \
  "$BASE/app/main.py" \
  "$BASE/app/v8003_master_navigation.py" \
  "$BASE/app/v8012a_route_consolidation.py" \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/docker-compose.yml" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine" \
  "$BASE/.env"
 do
  [[ -f "$f" ]] || die "Missing production file: $f"
 done

for f in \
  "$PACKAGE_DIR/app/main.py" \
  "$PACKAGE_DIR/app/v8003_master_navigation.py" \
  "$PACKAGE_DIR/app/routes/v8012b_consolidation_router.py" \
  "$PACKAGE_DIR/docker-compose.v8012b.yml" \
  "$PACKAGE_DIR/ops/v8012_consolidation_check.sh" \
  "$PACKAGE_DIR/README_V8012B.md" \
  "$PACKAGE_DIR/MANIFEST.sha256"
 do
  [[ -f "$f" ]] || die "Missing package file: $f"
 done

echo
echo "[1] Verify package hashes"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)

[[ "$(sha "$PACKAGE_DIR/app/main.py")" == "$EXPECTED_MAIN_NEW" ]] || die "Package main SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/v8003_master_navigation.py")" == "$EXPECTED_NAV_NEW" ]] || die "Package navigation SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/routes/v8012b_consolidation_router.py")" == "$EXPECTED_ROUTER_NEW" ]] || die "Package router SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/docker-compose.v8012b.yml")" == "$EXPECTED_COMPOSE_NEW" ]] || die "Package compose SHA mismatch"

echo
echo "[2] Verify production baseline"
MAIN_SHA="$(sha "$BASE/app/main.py")"
NAV_SHA="$(sha "$BASE/app/v8003_master_navigation.py")"
V8012A_SHA="$(sha "$BASE/app/v8012a_route_consolidation.py")"
COMPOSE_SHA="$(sha "$BASE/docker-compose.yml")"
INGRESS_SHA="$(sha "$BASE/app/v8011_ingress.py")"
V8004_SHA="$(sha "$BASE/app/v8004_quality_router.py")"
V8006_SHA="$(sha "$BASE/app/v8006_calendar_execution_correction.py")"
V8007_SHA="$(sha "$BASE/app/v8007_v8001_gate_bridge.py")"
PINE_SHA="$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")"

printf 'main.py: %s\nV8003 nav: %s\nV8012A: %s\ncompose: %s\ningress: %s\nV8004: %s\nV8006: %s\nV8007: %s\nPine: %s\n' \
  "$MAIN_SHA" "$NAV_SHA" "$V8012A_SHA" "$COMPOSE_SHA" "$INGRESS_SHA" \
  "$V8004_SHA" "$V8006_SHA" "$V8007_SHA" "$PINE_SHA"

[[ "$MAIN_SHA" == "$EXPECTED_MAIN_OLD" || "$MAIN_SHA" == "$EXPECTED_MAIN_NEW" ]] || die "Unexpected main.py baseline"
[[ "$NAV_SHA" == "$EXPECTED_NAV_OLD" || "$NAV_SHA" == "$EXPECTED_NAV_NEW" ]] || die "Unexpected V8003 baseline"
[[ "$V8012A_SHA" == "$EXPECTED_V8012A" ]] || die "Unexpected V8012A baseline"
[[ "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_OLD" || "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_NEW" ]] || die "Unexpected compose baseline"
[[ "$INGRESS_SHA" == "$EXPECTED_INGRESS" ]] || die "Unexpected V8011 ingress baseline"
[[ "$V8004_SHA" == "$EXPECTED_V8004" ]] || die "V8004 mismatch"
[[ "$V8006_SHA" == "$EXPECTED_V8006" ]] || die "V8006 mismatch"
[[ "$V8007_SHA" == "$EXPECTED_V8007" ]] || die "V8007 mismatch"
[[ "$PINE_SHA" == "$EXPECTED_PINE" ]] || die "Pine mismatch"

echo
echo "[3] Create rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/app/main.py" "$BACKUP/main.py"
cp -a "$BASE/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/.env" "$BACKUP/.env"
chmod 600 "$BACKUP/.env"
[[ ! -f "$BASE/app/routes/v8012b_consolidation_router.py" ]] || cp -a "$BASE/app/routes/v8012b_consolidation_router.py" "$BACKUP/v8012b_consolidation_router.py"
[[ ! -f "$BASE/ops/v8012_consolidation_check.sh" ]] || cp -a "$BASE/ops/v8012_consolidation_check.sh" "$BACKUP/v8012_consolidation_check.sh"
[[ ! -f "$BASE/README_V8012B.md" ]] || cp -a "$BASE/README_V8012B.md" "$BACKUP/README_V8012B.md"
ROLLBACK_ARMED=1

echo
echo "[4] Keep webhook token fully OFF"
python3 - "$BASE/.env" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
lines=p.read_text(encoding="utf-8", errors="replace").splitlines()
changes={"V8011_TOKEN_MODE":"off","V8011_ENFORCE_TOKEN":"false","V8011_WEBHOOK_TOKEN":""}
out=[]; seen=set()
for line in lines:
    if "=" not in line or line.lstrip().startswith("#"):
        out.append(line); continue
    key=line.split("=",1)[0].strip()
    if key in changes:
        if key not in seen:
            out.append(f"{key}={changes[key]}"); seen.add(key)
    else:
        out.append(line)
for key,val in changes.items():
    if key not in seen: out.append(f"{key}={val}")
p.write_text("\n".join(out).rstrip()+"\n", encoding="utf-8")
print("token_mode: off")
print("token_configured: false")
print("token_enforced: false")
PY
chmod 600 "$BASE/.env"

echo
echo "[5] Install V8012B files"
mkdir -p "$BASE/app/routes" "$BASE/ops"
install -m 0644 "$PACKAGE_DIR/app/main.py" "$BASE/app/main.py"
install -m 0644 "$PACKAGE_DIR/app/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
install -m 0644 "$PACKAGE_DIR/app/routes/v8012b_consolidation_router.py" "$BASE/app/routes/v8012b_consolidation_router.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8012b.yml" "$BASE/docker-compose.yml"
install -m 0755 "$PACKAGE_DIR/ops/v8012_consolidation_check.sh" "$BASE/ops/v8012_consolidation_check.sh"
install -m 0644 "$PACKAGE_DIR/README_V8012B.md" "$BASE/README_V8012B.md"

cd "$BASE"
python3 -m py_compile \
  app/main.py \
  app/v8003_master_navigation.py \
  app/v8012a_route_consolidation.py \
  app/routes/v8012b_consolidation_router.py
bash -n ops/v8012_consolidation_check.sh
docker compose config >/dev/null

echo
echo "[6] Verify protected hashes remain unchanged"
[[ "$(sha app/v8011_ingress.py)" == "$INGRESS_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]

echo
echo "[7] Build shared V8012B image"
docker compose build tradingbot

echo
echo "[8] Start backend + ingress"
docker compose up -d --remove-orphans

wait_http_200 "http://127.0.0.1/health" 75 2 || die "Public health did not recover"
wait_http_200 "http://127.0.0.1/v8012/selftest-b.json" 75 2 || die "V8012B selftest did not recover"

echo
echo "[9] Validate V8012A + V8012B"
curl -fsS --max-time 20 http://127.0.0.1/v8012/selftest.json > "/tmp/v8012a_${TS}.json"
curl -fsS --max-time 20 http://127.0.0.1/v8012/selftest-b.json > "/tmp/v8012b_${TS}.json"
curl -fsS --max-time 20 http://127.0.0.1/v8012/hub.json > "/tmp/v8012b_hub_${TS}.json"
curl -fsS --max-time 20 http://127.0.0.1/v8011/selftest.json > "/tmp/v8012b_ingress_${TS}.json"

python3 - "/tmp/v8012a_${TS}.json" "/tmp/v8012b_${TS}.json" "/tmp/v8012b_hub_${TS}.json" "/tmp/v8012b_ingress_${TS}.json" <<'PY'
import json,sys
v12a=json.load(open(sys.argv[1]))
v12b=json.load(open(sys.argv[2]))
hub=json.load(open(sys.argv[3]))
ing=json.load(open(sys.argv[4]))
assert v12a.get("ok") is True, v12a
assert int(v12a.get("nonprotected_exact_duplicate_groups_after") or 0)==0, v12a
assert v12b.get("ok") is True, v12b
assert v12b.get("version")=="V8012B-CONSOLIDATION-HUB-REDIRECTS-V1", v12b
assert v12b.get("required_routes_present") is True, v12b
assert int(v12b.get("browser_alias_redirect_count_added") or 0)==4, v12b
assert int(v12b.get("preexisting_redirect_count") or 0)==1, v12b
assert int(v12b.get("canonical_html_aliases_total") or 0)==5, v12b
assert hub.get("ok") is True, hub
assert ing.get("ok") is True, ing
assert ing.get("backend_ok") is True, ing
assert ing.get("worker_alive") is True, ing
assert ing.get("token_mode")=="off", ing
assert ing.get("token_configured") is False, ing
assert ing.get("token_enforced") is False, ing
print(json.dumps({
  "v8012a_ok": v12a.get("ok"),
  "v8012b_ok": v12b.get("ok"),
  "browser_alias_redirects_added": v12b.get("browser_alias_redirect_count_added"),
  "preexisting_redirects": v12b.get("preexisting_redirect_count"),
  "canonical_html_aliases_total": v12b.get("canonical_html_aliases_total"),
  "side_effect_get_candidates": v12b.get("side_effect_get_candidates"),
  "ingress_ok": ing.get("ok"),
  "token_mode": ing.get("token_mode"),
}, indent=2))
PY

echo
echo "[10] Validate browser redirects and bypass"
for route in /master-fast /master-mobile /master-full /master-integration; do
  headers="$(curl -sS -D - -o /dev/null --max-time 15 -H 'Accept: text/html' "http://127.0.0.1${route}")"
  code="$(printf '%s\n' "$headers" | awk 'toupper($1) ~ /^HTTP\// {c=$2} END {print c}')"
  location="$(printf '%s\n' "$headers" | awk 'BEGIN{IGNORECASE=1} /^location:/ {gsub("\r",""); print $2}' | tail -n 1)"
  api_code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 -H 'Accept: application/json' "http://127.0.0.1${route}")"
  legacy_code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 -H 'Accept: text/html' "http://127.0.0.1${route}?legacy=1")"
  printf '%-24s browser=%s location=%s api=%s legacy=%s\n' "$route" "$code" "$location" "$api_code" "$legacy_code"
  [[ "$code" == "307" && "$location" == "/master" && "$api_code" == "200" && "$legacy_code" == "200" ]] || die "Redirect validation failed: $route"
done

echo "Pre-existing /master-clean redirect"
headers="$(curl -sS -D - -o /dev/null --max-time 15 "http://127.0.0.1/master-clean")"
code="$(printf '%s\n' "$headers" | awk 'toupper($1) ~ /^HTTP\// {c=$2} END {print c}')"
location="$(printf '%s\n' "$headers" | awk 'BEGIN{IGNORECASE=1} /^location:/ {gsub("\r",""); print $2}' | tail -n 1)"
[[ "$code" == "307" && "$location" == "/master" ]] || die "Pre-existing /master-clean redirect failed"

echo
echo "[11] Critical routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/route-consolidation.json \
  /v8012/selftest.json \
  /v8012/hub \
  /v8012/hub.json \
  /v8012/redirects.json \
  /v8012/side-effect-audit.json \
  /v8012/selftest-b.json
 do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 "http://127.0.0.1${route}" || true)"
  printf '%-48s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Critical route failed: $route"
 done

echo
echo "[12] Navigation"
curl -fsS --max-time 20 http://127.0.0.1/master | grep -q "V8012 Consolidation Hub"
curl -fsS --max-time 20 http://127.0.0.1/master-ai-review | grep -q "V8012 Consolidation Hub"
echo "Master link: PASS"
echo "AI Review link: PASS"

echo
echo "[13] Final protected hashes"
[[ "$(sha app/v8011_ingress.py)" == "$INGRESS_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]

echo
echo "[14] Containers"
docker compose ps

ROLLBACK_ARMED=0

cat <<EOF
================================================================================
V8012B INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Hub:              http://91.107.237.214/v8012/hub
Hub JSON:         http://91.107.237.214/v8012/hub.json
Redirect map:     http://91.107.237.214/v8012/redirects.json
Side-effect audit:http://91.107.237.214/v8012/side-effect-audit.json
Selftest:         http://91.107.237.214/v8012/selftest-b.json

COMPLETED:
  First V8012 APIRouter module installed
  Canonical five-area hub installed
  Four new browser-only master aliases redirect to /master
  Existing /master-clean redirect documented and verified
  API/JSON behavior preserved
  Original legacy HTML remains available with ?legacy=1
  Side-effect GET routes audited only

UNCHANGED:
  V8004 / V8006 / V8007
  Canonical Pine
  V8011 ingress/queue/dead-letter
  Existing trading DB
  Live scoring/routing
  Token OFF
  Broker auto execution FALSE
EOF
