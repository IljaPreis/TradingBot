#!/usr/bin/env bash
set -u

BASE="/opt/tradingbot_v6000"

echo "=== V8012B CONSOLIDATION HUB CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"

cd "$BASE" || exit 1

echo "[1] Containers"
docker compose ps

echo "[2] V8012A route dedupe"
curl -fsS --max-time 20 http://127.0.0.1/v8012/selftest.json | python3 -m json.tool

echo "[3] V8012B selftest"
curl -fsS --max-time 20 http://127.0.0.1/v8012/selftest-b.json | python3 -m json.tool

echo "[4] Consolidation hub summary"
curl -fsS --max-time 20 http://127.0.0.1/v8012/hub.json | python3 -c '
import json,sys
d=json.load(sys.stdin)
s=d.get("summary") or {}
print(json.dumps({
  "ok": d.get("ok"),
  "version": d.get("version"),
  "route_count": s.get("route_count"),
  "canonical_groups": s.get("canonical_groups"),
  "browser_alias_redirects": s.get("browser_alias_redirects"),
  "side_effect_get_candidates": s.get("side_effect_get_candidates"),
  "cache_ttl_seconds": s.get("cache_ttl_seconds"),
  "legacy_bypass_query": s.get("legacy_bypass_query"),
}, indent=2))
'

echo "[5] Browser-only redirect tests"
for route in /master-fast /master-mobile /master-full /master-integration; do
  headers="$(curl -sS -D - -o /dev/null --max-time 15 -H 'Accept: text/html' "http://127.0.0.1${route}" || true)"
  code="$(printf '%s\n' "$headers" | awk 'toupper($1) ~ /^HTTP\// {c=$2} END {print c}')"
  location="$(printf '%s\n' "$headers" | awk 'BEGIN{IGNORECASE=1} /^location:/ {gsub("\r",""); print $2}' | tail -n 1)"
  printf '%-24s browser=%s location=%s\n' "$route" "${code:-none}" "${location:-none}"
  [[ "$code" == "307" && "$location" == "/master" ]] || exit 1

done

echo "[6] API and legacy bypass remain reachable"
for route in /master-fast /master-mobile /master-full /master-integration; do
  api_code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 -H 'Accept: application/json' "http://127.0.0.1${route}" || true)"
  legacy_code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 -H 'Accept: text/html' "http://127.0.0.1${route}?legacy=1" || true)"
  printf '%-24s api=%s legacy=%s\n' "$route" "$api_code" "$legacy_code"
  [[ "$api_code" == "200" ]] || exit 1
  [[ "$legacy_code" == "200" ]] || exit 1
done


echo "[6a] Pre-existing /master-clean redirect"
headers="$(curl -sS -D - -o /dev/null --max-time 15 "http://127.0.0.1/master-clean" || true)"
code="$(printf '%s\n' "$headers" | awk 'toupper($1) ~ /^HTTP\// {c=$2} END {print c}')"
location="$(printf '%s\n' "$headers" | awk 'BEGIN{IGNORECASE=1} /^location:/ {gsub("\r",""); print $2}' | tail -n 1)"
printf '%-24s status=%s location=%s\n' "/master-clean" "${code:-none}" "${location:-none}"
[[ "$code" == "307" && "$location" == "/master" ]] || exit 1

echo "[7] Side-effect GET audit – observe only"
curl -fsS --max-time 20 http://127.0.0.1/v8012/side-effect-audit.json | python3 -c '
import json,sys
d=json.load(sys.stdin)
print(json.dumps({
  "ok": d.get("ok"),
  "version": d.get("version"),
  "candidate_count": len(d.get("candidates") or []),
  "automatic_changes": d.get("automatic_changes"),
}, indent=2))
'

echo "[8] Ingress health and token OFF"
curl -fsS --max-time 20 http://127.0.0.1/v8011/selftest.json | python3 -c '
import json,sys
d=json.load(sys.stdin)
print(json.dumps({
  "ok": d.get("ok"),
  "operational_status": d.get("operational_status"),
  "queue_depth": d.get("queue_depth"),
  "backend_ok": d.get("backend_ok"),
  "worker_alive": d.get("worker_alive"),
  "token_mode": d.get("token_mode"),
  "token_configured": d.get("token_configured"),
  "token_enforced": d.get("token_enforced"),
}, indent=2))
'

echo "[9] Critical routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/route-consolidation.json \
  /v8012/selftest.json \
  /v8012/hub \
  /v8012/hub.json \
  /v8012/redirects.json \
  /v8012/side-effect-audit.json \
  /v8012/selftest-b.json
 do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 "http://127.0.0.1${route}" || true)"
  printf '%-48s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || exit 1
 done

echo "[10] Navigation links"
curl -fsS --max-time 20 http://127.0.0.1/master | grep -q "V8012 Consolidation Hub"
curl -fsS --max-time 20 http://127.0.0.1/master-ai-review | grep -q "V8012 Consolidation Hub"
echo "Master link: PASS"
echo "AI Review link: PASS"

echo "[11] Protected hashes"
sha256sum \
  app/v8011_ingress.py \
  app/v8004_quality_router.py \
  app/v8006_calendar_execution_correction.py \
  app/v8007_v8001_gate_bridge.py \
  pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine

echo "[12] Errors last 30m"
docker logs --since 30m tradingbot 2>&1 \
  | grep -Ei 'Traceback|ERROR|Exception|FATAL|V8012B.*error' \
  | tail -n 100 || true

echo "[13] Host resources"
uptime
free -h
df -h "$BASE"

echo "=== V8012B CHECK FERTIG ==="
