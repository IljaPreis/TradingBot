# V8012C.1 Side-Effect Route Duplicate Fix

Version: `V8012C.1-SIDE-EFFECT-ROUTE-DUPLICATE-FIX-V1`

## Ursache des fehlgeschlagenen V8012C-Laufs

`/calendar-v7243/sync` besaß bereits eine registrierte POST-Route. V8012C versuchte zusätzlich eine zweite POST-Route mit exakt demselben Pfad und derselben Methode zu registrieren. Die V8012A-Duplikatprüfung erkannte das korrekt und löste den automatischen Rollback aus.

## Korrektur

V8012C.1 prüft vor jeder Registrierung die bereits vorhandenen Methoden:

- 10 echte oder bedingte Side-Effect-Pfade
- 9 neue bestätigungspflichtige POST-Alternativen
- 1 vorhandene POST-Route wird unverändert wiederverwendet: `/calendar-v7243/sync`
- 4 read-only False Positives
- 14 Legacy-GET-Routen bleiben erhalten
- 0 neue exakte Routenduplikate

Die neun neu ergänzten POST-Alternativen benötigen:

```text
X-V8012C-Confirm: yes
```

Ohne diesen Header antworten sie mit HTTP `428`, ohne die ursprüngliche GET-Funktion auszuführen.

Die bereits vorhandene POST-Route `/calendar-v7243/sync` wird nicht verändert und nicht doppelt registriert.

## Sicherheit

Unverändert bleiben:

- V8004 Quality Router
- V8006 Calendar Execution Correction
- V8007 Gate Bridge
- Pine V8001.4D
- V8011 Ingress, Queue und Dead Letter
- bestehende Trading-Datenbank
- Live-Scoring und Routing
- Webhook-Token OFF
- Broker Auto Execution FALSE
