from __future__ import annotations

import html
import inspect
import json
import threading
from collections import Counter
from datetime import datetime, timezone
from typing import Any, Callable

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
from starlette.datastructures import MutableHeaders
from starlette.types import ASGIApp, Receive, Scope, Send

VERSION = "V8012C.1-SIDE-EFFECT-ROUTE-DUPLICATE-FIX-V1"
MODE = "compatibility_get_plus_confirmed_post_without_duplicate_registration"
CONFIRM_HEADER = "X-V8012C-Confirm"
CONFIRM_VALUES = {"1", "true", "yes", "on", "confirm"}

SAFETY = {
    "legacy_get_routes_removed": False,
    "legacy_get_behavior_changed": False,
    "post_alternatives_call_existing_endpoints": True,
    "confirmation_header_required_for_added_post_alternatives": True,
    "preexisting_post_routes_changed": False,
    "new_token_introduced": False,
    "webhook_token_mode_forced_off": True,
    "v8004_changed": False,
    "v8006_changed": False,
    "v8007_changed": False,
    "pine_changed": False,
    "live_scoring_changed": False,
    "live_routing_changed": False,
    "v8011_ingress_changed": False,
    "v8012c_db_writes": False,
    "broker_auto_execution": False,
}

# The previous V8012B path-only audit returned 14 candidates. Four were false
# positives because the pattern '/set' also matches '/setup-*'.
CLASSIFICATIONS: dict[str, dict[str, Any]] = {
    "/calendar-v7243/sync": {
        "classification": "side_effect",
        "category": "calendar_sync",
        "effect": "calendar/news data synchronization",
        "legacy_auth": "existing route token check",
        "post_alternative": True,
        "risk": "high",
    },
    "/financialjuice-impact-v7243/rescore": {
        "classification": "side_effect",
        "category": "news_rescore",
        "effect": "recalculates FinancialJuice impact data",
        "legacy_auth": "existing route token check",
        "post_alternative": True,
        "risk": "medium",
    },
    "/macro-actual-v7243/rescore": {
        "classification": "side_effect",
        "category": "macro_rescore",
        "effect": "recalculates macro actual mappings",
        "legacy_auth": "existing route token check",
        "post_alternative": True,
        "risk": "medium",
    },
    "/pause/off": {
        "classification": "side_effect",
        "category": "emergency_switch",
        "effect": "removes PAUSE_TRADING state",
        "legacy_auth": "existing mobile token check",
        "post_alternative": True,
        "risk": "critical",
    },
    "/pause/on": {
        "classification": "side_effect",
        "category": "emergency_switch",
        "effect": "creates PAUSE_TRADING state",
        "legacy_auth": "existing mobile token check",
        "post_alternative": True,
        "risk": "critical",
    },
    "/setup-optimizer": {
        "classification": "side_effect",
        "category": "report_snapshot_write",
        "effect": "renders optimizer page and writes report snapshot",
        "legacy_auth": "existing route token check",
        "post_alternative": True,
        "risk": "low",
    },
    "/setup-optimizer.json": {
        "classification": "conditional_side_effect",
        "category": "report_snapshot_write",
        "effect": "write defaults to enabled; write=0 is read-only",
        "legacy_auth": "existing route token check",
        "post_alternative": True,
        "risk": "low",
    },
    "/v7245-excursion/update": {
        "classification": "side_effect",
        "category": "excursion_update",
        "effect": "updates MFE/MAE excursion records",
        "legacy_auth": "legacy endpoint currently has no effective token validation",
        "post_alternative": True,
        "risk": "high",
    },
    "/v7302-news-quality/update": {
        "classification": "side_effect",
        "category": "news_repair_update",
        "effect": "runs news-quality update with apply=true",
        "legacy_auth": "legacy endpoint currently has no effective token validation",
        "post_alternative": True,
        "risk": "high",
    },
    "/v8005/warmup": {
        "classification": "side_effect",
        "category": "cache_warmup",
        "effect": "starts background dashboard cache refreshes",
        "legacy_auth": "legacy endpoint currently has no token validation",
        "post_alternative": True,
        "risk": "low",
    },
    "/setup-optimizer-config.json": {
        "classification": "read_only_false_positive",
        "category": "configuration_read",
        "effect": "returns configuration only",
        "legacy_auth": "existing route token check",
        "post_alternative": False,
        "risk": "none",
    },
    "/setup-optimizer-rules.json": {
        "classification": "read_only_false_positive",
        "category": "rules_read",
        "effect": "returns optimizer rules only",
        "legacy_auth": "existing route token check",
        "post_alternative": False,
        "risk": "none",
    },
    "/setup-performance": {
        "classification": "read_only_false_positive",
        "category": "performance_read",
        "effect": "renders setup performance only",
        "legacy_auth": "existing route behavior unchanged",
        "post_alternative": False,
        "risk": "none",
    },
    "/setup-performance.json": {
        "classification": "read_only_false_positive",
        "category": "performance_read",
        "effect": "returns setup performance only",
        "legacy_auth": "existing route token check",
        "post_alternative": False,
        "risk": "none",
    },
}

POST_PATHS = tuple(
    path for path, item in CLASSIFICATIONS.items() if item.get("post_alternative") is True
)
FALSE_POSITIVE_PATHS = tuple(
    path
    for path, item in CLASSIFICATIONS.items()
    if item.get("classification") == "read_only_false_positive"
)

_usage_lock = threading.Lock()
_usage_get = Counter()
_usage_post = Counter()
_usage_last: dict[str, dict[str, str]] = {}
_original_endpoints: dict[str, Callable[..., Any]] = {}
_original_endpoint_metadata: dict[str, dict[str, str]] = {}
_added_post_paths: set[str] = set()
_preexisting_post_paths: set[str] = set()


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _record(path: str, method: str) -> None:
    now = _utcnow()
    with _usage_lock:
        if method == "GET":
            _usage_get[path] += 1
        elif method == "POST":
            _usage_post[path] += 1
        _usage_last.setdefault(path, {})[method] = now


def _usage_snapshot() -> dict[str, Any]:
    with _usage_lock:
        rows = []
        for path in POST_PATHS:
            rows.append({
                "path": path,
                "legacy_get_calls_since_start": int(_usage_get.get(path, 0)),
                "confirmed_post_calls_since_start": int(_usage_post.get(path, 0)),
                "last_legacy_get_at": (_usage_last.get(path) or {}).get("GET"),
                "last_confirmed_post_at": (_usage_last.get(path) or {}).get("POST"),
            })
        return {
            "process_local_only": True,
            "persistent_db_writes": False,
            "rows": rows,
            "legacy_get_calls_total": sum(int(x) for x in _usage_get.values()),
            "confirmed_post_calls_total": sum(int(x) for x in _usage_post.values()),
        }


def _route_methods(app: Any) -> dict[str, set[str]]:
    result: dict[str, set[str]] = {}
    for route in app.router.routes:
        path = str(getattr(route, "path", "") or "")
        if not path:
            continue
        methods = {str(x).upper() for x in (getattr(route, "methods", None) or set())}
        result.setdefault(path, set()).update(methods)
    return result


def _find_original_get_endpoints(app: Any) -> None:
    for path in POST_PATHS:
        endpoint = None
        for route in app.router.routes:
            if str(getattr(route, "path", "") or "") != path:
                continue
            methods = {str(x).upper() for x in (getattr(route, "methods", None) or set())}
            if "GET" not in methods:
                continue
            endpoint = getattr(route, "endpoint", None)
            if endpoint is not None:
                break
        if endpoint is None:
            continue
        _original_endpoints[path] = endpoint
        _original_endpoint_metadata[path] = {
            "name": str(getattr(endpoint, "__name__", "") or ""),
            "qualname": str(getattr(endpoint, "__qualname__", "") or ""),
            "module": str(getattr(endpoint, "__module__", "") or ""),
        }


def _body_params(raw: Any) -> dict[str, Any]:
    return raw if isinstance(raw, dict) else {}


def _convert_parameter(value: Any, parameter: inspect.Parameter) -> Any:
    if value is None:
        return None
    default = parameter.default
    annotation = parameter.annotation
    text = str(annotation).lower()
    target: Any = None
    if default is not inspect.Parameter.empty and default is not None:
        target = type(default)
    elif annotation in {int, float, bool, str}:
        target = annotation
    elif "int" in text:
        target = int
    elif "float" in text:
        target = float
    elif "bool" in text:
        target = bool
    if target is bool:
        return str(value).strip().lower() in {"1", "true", "yes", "on"}
    if target in {int, float, str}:
        return target(value)
    return value


async def _invoke_original(endpoint: Callable[..., Any], request: Request) -> Response:
    params: dict[str, Any] = dict(request.query_params)
    content_type = str(request.headers.get("content-type") or "").lower()
    if "application/json" in content_type:
        try:
            params.update(_body_params(await request.json()))
        except Exception:
            return JSONResponse(
                {"ok": False, "error": "invalid_json_body"}, status_code=400
            )

    kwargs: dict[str, Any] = {}
    signature = inspect.signature(endpoint)
    for name, parameter in signature.parameters.items():
        if name == "request":
            kwargs[name] = request
            continue
        if name in params:
            try:
                kwargs[name] = _convert_parameter(params[name], parameter)
            except Exception:
                return JSONResponse(
                    {
                        "ok": False,
                        "error": "invalid_parameter",
                        "parameter": name,
                    },
                    status_code=422,
                )

    result = endpoint(**kwargs)
    if inspect.isawaitable(result):
        result = await result
    if isinstance(result, Response):
        response = result
    else:
        response = JSONResponse(result)
    response.headers["X-V8012C-Canonical-Method"] = "POST"
    response.headers["X-V8012C-Original-Endpoint-Reused"] = "true"
    response.headers["Cache-Control"] = "no-store"
    return response


def _post_wrapper(path: str, endpoint: Callable[..., Any]) -> Callable[..., Any]:
    async def wrapper(request: Request) -> Response:
        confirmation = str(request.headers.get(CONFIRM_HEADER) or "").strip().lower()
        if confirmation not in CONFIRM_VALUES:
            return JSONResponse(
                {
                    "ok": False,
                    "error": "confirmation_header_required",
                    "required_header": f"{CONFIRM_HEADER}: yes",
                    "path": path,
                    "legacy_get_still_available": True,
                },
                status_code=428,
                headers={"Cache-Control": "no-store"},
            )
        _record(path, "POST")
        return await _invoke_original(endpoint, request)

    wrapper.__name__ = "v8012c_post_" + path.strip("/").replace("/", "_").replace("-", "_").replace(".", "_")
    wrapper.__qualname__ = wrapper.__name__
    wrapper.__doc__ = f"Confirmed POST alternative for legacy GET {path}."
    return wrapper


def _classification_rows() -> list[dict[str, Any]]:
    rows = []
    for path, item in CLASSIFICATIONS.items():
        row = {"path": path, **item}
        row["preferred_method"] = "POST" if item.get("post_alternative") else "GET"
        row["legacy_get_retained"] = True
        if path in _added_post_paths:
            row["post_registration"] = "v8012c_confirmed_alternative"
            row["confirmation_header"] = f"{CONFIRM_HEADER}: yes"
        elif path in _preexisting_post_paths:
            row["post_registration"] = "preexisting_post_route_reused"
            row["confirmation_header"] = None
        else:
            row["post_registration"] = None
            row["confirmation_header"] = None
        row["original_endpoint"] = _original_endpoint_metadata.get(path)
        rows.append(row)
    return rows


def _payload(app: Any) -> dict[str, Any]:
    methods = _route_methods(app)
    missing_get = [path for path in CLASSIFICATIONS if "GET" not in methods.get(path, set())]
    missing_post = [path for path in POST_PATHS if "POST" not in methods.get(path, set())]
    false_positive_post_routes = [
        path for path in FALSE_POSITIVE_PATHS if "POST" in methods.get(path, set())
    ]
    return {
        "ok": not missing_get and not missing_post and not false_positive_post_routes,
        "version": VERSION,
        "mode": MODE,
        "generated_utc": _utcnow(),
        "summary": {
            "heuristic_candidates_from_v8012b": len(CLASSIFICATIONS),
            "true_or_conditional_side_effects": len(POST_PATHS),
            "read_only_false_positives": len(FALSE_POSITIVE_PATHS),
            "effective_post_routes_registered": len(POST_PATHS) - len(missing_post),
            "confirmed_post_alternatives_added": len(_added_post_paths),
            "preexisting_post_routes_reused": len(_preexisting_post_paths),
            "legacy_get_routes_retained": len(CLASSIFICATIONS) - len(missing_get),
            "confirmation_header_required_for_added_alternatives": True,
            "automatic_get_removal": False,
            "new_token_introduced": False,
        },
        "classifications": _classification_rows(),
        "validation": {
            "missing_get_routes": missing_get,
            "missing_post_alternatives": missing_post,
            "false_positive_post_routes": false_positive_post_routes,
            "original_get_endpoints_found": len(_original_endpoints),
            "confirmed_post_paths_added": sorted(_added_post_paths),
            "preexisting_post_paths_reused": sorted(_preexisting_post_paths),
        },
        "usage": _usage_snapshot(),
        "safety": dict(SAFETY),
    }


def _html_page(data: dict[str, Any]) -> str:
    rows = []
    for item in data.get("classifications") or []:
        cls = str(item.get("classification") or "")
        state = ("POST vorhanden + GET kompatibel" if item.get("post_alternative") else "GET read-only")
        rows.append(
            "<tr>"
            f"<td><code>{html.escape(str(item.get('path') or ''))}</code></td>"
            f"<td>{html.escape(cls)}</td>"
            f"<td>{html.escape(str(item.get('category') or ''))}</td>"
            f"<td>{html.escape(state)}</td>"
            f"<td>{html.escape(str(item.get('risk') or ''))}</td>"
            "</tr>"
        )
    summary = data.get("summary") or {}
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>V8012C Side-Effect Hardening</title>
<style>
body{{margin:0;background:#07111e;color:#eef6ff;font-family:Arial,sans-serif}}.wrap{{max-width:1250px;margin:auto;padding:16px}}
.card{{background:#101d2e;border:1px solid #2b405b;border-radius:14px;padding:14px;margin:12px 0}}table{{width:100%;border-collapse:collapse}}
th,td{{padding:9px;border-bottom:1px solid #2b405b;text-align:left;font-size:13px}}code,a{{color:#7dd3fc}}
.ok{{display:inline-block;padding:5px 9px;border-radius:999px;background:#123222;color:#86efac;font-weight:800}}
</style></head><body><div class="wrap">
<h1>V8012C Side-Effect GET Hardening</h1>
<p><span class="ok">PASS</span> Alte GET-Aufrufe bleiben kompatibel. Schreibende Aktionen besitzen zusätzlich bestätigungspflichtige POST-Alternativen.</p>
<div class="card">Kandidaten: {summary.get('heuristic_candidates_from_v8012b')} · echte/bedingte Side-Effects: {summary.get('true_or_conditional_side_effects')} · False Positives: {summary.get('read_only_false_positives')} · bestätigte POST-Alternativen neu: {summary.get('confirmed_post_alternatives_added')} · bestehende POST-Routen wiederverwendet: {summary.get('preexisting_post_routes_reused')}</div>
<div class="card"><b>POST-Schutz:</b> Neu ergänzte POST-Alternativen verlangen <code>{CONFIRM_HEADER}: yes</code>. Bereits vorhandene POST-Routen bleiben unverändert und werden nicht doppelt registriert.</div>
<div class="card"><table><tr><th>Route</th><th>Klassifikation</th><th>Kategorie</th><th>Status</th><th>Risiko</th></tr>{''.join(rows)}</table></div>
<div class="card"><a href="/v8012/side-effect-hardening.json">JSON</a> · <a href="/v8012/post-alternatives.json">POST Map</a> · <a href="/v8012/side-effect-usage.json">Usage</a> · <a href="/v8012/selftest-c.json">Selftest</a></div>
</div></body></html>"""


class SideEffectCompatibilityMiddleware:
    def __init__(self, app: ASGIApp):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return
        method = str(scope.get("method") or "").upper()
        path = str(scope.get("path") or "")
        is_legacy_get = method == "GET" and path in POST_PATHS
        if is_legacy_get:
            _record(path, "GET")
            print(f"[V8012C.1] legacy side-effect GET used: {path}")

        async def send_wrapper(message: dict[str, Any]) -> None:
            if is_legacy_get and message.get("type") == "http.response.start":
                headers = MutableHeaders(scope=message)
                headers["X-V8012C-Legacy-GET"] = "true"
                headers["X-V8012C-Preferred-Method"] = "POST"
                headers["X-V8012C-Confirmation-Header"] = f"{CONFIRM_HEADER}: yes"
                headers["Cache-Control"] = "no-store"
            await send(message)

        await self.app(scope, receive, send_wrapper)


def install_v8012c_side_effect_hardening(app: Any) -> None:
    if getattr(app.state, "v8012c_side_effect_hardening_installed", False):
        return

    _find_original_get_endpoints(app)
    missing_originals = [path for path in POST_PATHS if path not in _original_endpoints]
    if missing_originals:
        raise RuntimeError(f"missing original GET endpoints: {missing_originals}")

    methods_before = _route_methods(app)
    for path in POST_PATHS:
        if "POST" in methods_before.get(path, set()):
            _preexisting_post_paths.add(path)
            continue
        app.add_api_route(
            path,
            _post_wrapper(path, _original_endpoints[path]),
            methods=["POST"],
            name="v8012c_post_" + path.strip("/").replace("/", "_").replace("-", "_").replace(".", "_"),
            include_in_schema=False,
        )
        _added_post_paths.add(path)

    @app.get("/v8012/side-effect-hardening.json")
    def v8012c_hardening_json(request: Request):
        return JSONResponse(_payload(request.app))

    @app.get("/v8012/side-effect-hardening", response_class=HTMLResponse)
    def v8012c_hardening_page(request: Request):
        return HTMLResponse(_html_page(_payload(request.app)))

    @app.get("/v8012/post-alternatives.json")
    def v8012c_post_alternatives(request: Request):
        data = _payload(request.app)
        return JSONResponse({
            "ok": data.get("ok"),
            "version": VERSION,
            "confirmation_header": f"{CONFIRM_HEADER}: yes",
            "alternatives": [
                item for item in data.get("classifications") or [] if item.get("post_alternative")
            ],
            "legacy_get_routes_retained": True,
            "new_token_introduced": False,
        })

    @app.get("/v8012/side-effect-usage.json")
    def v8012c_usage_json():
        return JSONResponse({
            "ok": True,
            "version": VERSION,
            "usage": _usage_snapshot(),
            "query_strings_or_tokens_recorded": False,
        })

    @app.get("/v8012/selftest-c.json")
    def v8012c_selftest(request: Request):
        data = _payload(request.app)
        return JSONResponse({
            "ok": data.get("ok"),
            "version": VERSION,
            "mode": MODE,
            "heuristic_candidates": (data.get("summary") or {}).get("heuristic_candidates_from_v8012b"),
            "true_or_conditional_side_effects": (data.get("summary") or {}).get("true_or_conditional_side_effects"),
            "read_only_false_positives": (data.get("summary") or {}).get("read_only_false_positives"),
            "effective_post_routes_registered": (data.get("summary") or {}).get("effective_post_routes_registered"),
            "confirmed_post_alternatives_added": (data.get("summary") or {}).get("confirmed_post_alternatives_added"),
            "preexisting_post_routes_reused": (data.get("summary") or {}).get("preexisting_post_routes_reused"),
            "legacy_get_routes_retained": (data.get("summary") or {}).get("legacy_get_routes_retained"),
            "confirmation_header_required_for_added_alternatives": True,
            "missing_get_routes": (data.get("validation") or {}).get("missing_get_routes"),
            "missing_post_alternatives": (data.get("validation") or {}).get("missing_post_alternatives"),
            "false_positive_post_routes": (data.get("validation") or {}).get("false_positive_post_routes"),
            "confirmed_post_paths_added": (data.get("validation") or {}).get("confirmed_post_paths_added"),
            "preexisting_post_paths_reused": (data.get("validation") or {}).get("preexisting_post_paths_reused"),
            "safety": dict(SAFETY),
        })

    app.add_middleware(SideEffectCompatibilityMiddleware)
    app.state.v8012c_side_effect_hardening_installed = True
    print(
        f"[V8012C.1] Side-effect GET hardening installed: "
        f"classified={len(CLASSIFICATIONS)} effective_post_routes={len(POST_PATHS)} "
        f"added_post_alternatives={len(_added_post_paths)} preexisting_post_routes={len(_preexisting_post_paths)} "
        f"false_positives={len(FALSE_POSITIVE_PATHS)}"
    )
