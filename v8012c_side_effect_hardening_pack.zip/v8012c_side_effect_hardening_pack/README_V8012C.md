# V8012C Side-Effect GET Hardening

Version: `V8012C-SIDE-EFFECT-GET-HARDENING-V1`

## Scope

V8012B identified 14 GET paths by a name-based heuristic. V8012C classifies them using the actual registered endpoint behavior:

- 10 true or conditional side-effect routes
- 4 read-only false positives caused by `/set` matching `/setup-*`
- 10 additional POST alternatives
- all legacy GET routes remain registered and behavior-compatible

No GET route is deleted in this phase.

## POST safety

Every V8012C POST alternative requires:

```text
X-V8012C-Confirm: yes
```

Without this header the request returns HTTP `428` and the original endpoint is not called.

After the confirmation check, V8012C calls the existing endpoint function. Existing mobile/admin token checks therefore remain active where they already existed. No new token is introduced.

## Classified side effects

- `/calendar-v7243/sync`
- `/financialjuice-impact-v7243/rescore`
- `/macro-actual-v7243/rescore`
- `/pause/on`
- `/pause/off`
- `/setup-optimizer`
- `/setup-optimizer.json`
- `/v7245-excursion/update`
- `/v7302-news-quality/update`
- `/v8005/warmup`

## Read-only false positives

- `/setup-optimizer-config.json`
- `/setup-optimizer-rules.json`
- `/setup-performance`
- `/setup-performance.json`

## Compatibility audit

Legacy side-effect GET usage is counted only in process memory. Query strings, tokens, request bodies, IP addresses and user identifiers are not stored by V8012C. No V8012C database writes are performed.

## Routes

- `/v8012/side-effect-hardening`
- `/v8012/side-effect-hardening.json`
- `/v8012/post-alternatives.json`
- `/v8012/side-effect-usage.json`
- `/v8012/selftest-c.json`

## Safety

Unchanged:

- V8004 quality routing
- V8006 calendar execution correction
- V8007 gate bridge
- canonical V8001.4D Pine
- V8011 ingress, queue and dead-letter logic
- live scoring and routing
- existing trading database schema
- webhook token mode remains OFF
- broker auto execution remains FALSE
