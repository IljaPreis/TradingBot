#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="V8012C-SIDE-EFFECT-GET-HARDENING-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8012c_before_${TS}"
LOG="/root/v8012c_install_${TS}.log"
TMP_DIR="$(mktemp -d /tmp/v8012c_install.XXXXXX)"

EXPECTED_MAIN_OLD="65681fee3129cb33be230144502df6ec1aeb4cd4f402e35dc4178ac3c491946a"
EXPECTED_MAIN_NEW="ffa0aaa095faf438cda227d41fbf582e9f747d4582b8fd2adc2a94ab9ff50896"
EXPECTED_NAV_OLD="60d8c19b4ea9b7cbee23b5976f6fe37f7c2b9c971839210b4e9061b00534c864"
EXPECTED_NAV_NEW="b02b4206cca4ede59a412e7777e48086f8a9aa02b4cac9135aeeebf0a7f84e15"
EXPECTED_V8012A="30e36a321e9c41810d766aaa7c857637e2c15d2f11fbc504c9b5969c27390af9"
EXPECTED_V8012B="2c4ae0955b8888650834f9f332ef5267d9f75bdb9d8bb1fbd5662b525c3c006b"
EXPECTED_V8012C="6414e3bc143e53c9f9f6c8ac02806a5d5803abc6c35966c72431328634f9edf6"
EXPECTED_COMPOSE_OLD="7f111c4cce4abf013cb9d30fbbde1ce6652664f6f7afbfdcfd806674939af799"
EXPECTED_COMPOSE_NEW="5ef00ee6362ad8c9658169aab357ff73973769667ba96d6701c31bb4a37808a0"
EXPECTED_INGRESS="0b50a8dcce8e0f2ef71dead1d5489bdd1c915b932acefa166eec656828806c8b"
EXPECTED_V8004="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

ROLLBACK_ARMED=0
exec > >(tee -a "$LOG") 2>&1

sha() { sha256sum "$1" | awk '{print $1}'; }
die() { echo "FATAL: $*" >&2; exit 1; }

wait_http_200() {
  local url="$1" attempts="${2:-75}" sleep_s="${3:-2}" i code
  for i in $(seq 1 "$attempts"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    echo "WAIT [$i/$attempts] $url status=${code:-none}"
    sleep "$sleep_s"
  done
  return 1
}

rollback() {
  local rc=$?
  trap - ERR
  rm -rf "$TMP_DIR" || true
  if [[ "$ROLLBACK_ARMED" != "1" ]]; then exit "$rc"; fi
  echo
  echo "=== V8012C ROLLBACK START ==="
  cp -a "$BACKUP/main.py" "$BASE/app/main.py" || true
  cp -a "$BACKUP/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py" || true
  cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml" || true
  cp -a "$BACKUP/.env" "$BASE/.env" || true
  chmod 600 "$BASE/.env" || true
  if [[ -f "$BACKUP/v8012c_side_effect_hardening.py" ]]; then
    mkdir -p "$BASE/app/routes"
    cp -a "$BACKUP/v8012c_side_effect_hardening.py" "$BASE/app/routes/v8012c_side_effect_hardening.py" || true
  else
    rm -f "$BASE/app/routes/v8012c_side_effect_hardening.py"
  fi
  if [[ -f "$BACKUP/v8012_consolidation_check.sh" ]]; then
    cp -a "$BACKUP/v8012_consolidation_check.sh" "$BASE/ops/v8012_consolidation_check.sh" || true
  fi
  if [[ -f "$BACKUP/README_V8012C.md" ]]; then
    cp -a "$BACKUP/README_V8012C.md" "$BASE/README_V8012C.md" || true
  else
    rm -f "$BASE/README_V8012C.md"
  fi
  cd "$BASE"
  docker compose config >/dev/null 2>&1 || true
  docker compose up -d --build --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8012C ROLLBACK ENDE ==="
  exit "$rc"
}
trap rollback ERR

cat <<EOF2
================================================================================
$VERSION INSTALL
================================================================================
Generated UTC: $(date -u --iso-8601=seconds)
Project: $BASE
Package: $PACKAGE_DIR

Scope:
  14 V8012B heuristic GET candidates: classify using actual endpoints
  True/conditional side effects: 10
  Read-only false positives: 4
  Confirmed POST alternatives: 10
  Legacy GET routes: retained unchanged
  Legacy GET usage: process-memory audit only

POST safety:
  Required header: X-V8012C-Confirm: yes
  Missing confirmation: HTTP 428, original endpoint is not called
  Existing endpoint token checks remain active
  New token introduced: NO

Safety:
  V8004/V8006/V8007 changes: 0
  Canonical Pine changes: 0
  V8011 ingress/queue/dead-letter changes: 0
  Existing trading DB schema changes: 0
  Live scoring/routing changes: 0
  Token mode: OFF
  Broker auto execution: FALSE
EOF2

[[ -d "$BASE" ]] || die "Project not found: $BASE"

for f in \
  "$BASE/app/main.py" \
  "$BASE/app/v8003_master_navigation.py" \
  "$BASE/app/v8012a_route_consolidation.py" \
  "$BASE/app/routes/v8012b_consolidation_router.py" \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/docker-compose.yml" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine" \
  "$BASE/.env"
 do
  [[ -f "$f" ]] || die "Missing production file: $f"
 done

for f in \
  "$PACKAGE_DIR/app/main.py" \
  "$PACKAGE_DIR/app/v8003_master_navigation.py" \
  "$PACKAGE_DIR/app/routes/v8012c_side_effect_hardening.py" \
  "$PACKAGE_DIR/docker-compose.v8012c.yml" \
  "$PACKAGE_DIR/ops/v8012_consolidation_check.sh" \
  "$PACKAGE_DIR/README_V8012C.md" \
  "$PACKAGE_DIR/MANIFEST.sha256"
 do
  [[ -f "$f" ]] || die "Missing package file: $f"
 done

echo
echo "[1] Verify package hashes"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)

[[ "$(sha "$PACKAGE_DIR/app/main.py")" == "$EXPECTED_MAIN_NEW" ]] || die "Package main SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/v8003_master_navigation.py")" == "$EXPECTED_NAV_NEW" ]] || die "Package navigation SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/routes/v8012c_side_effect_hardening.py")" == "$EXPECTED_V8012C" ]] || die "Package V8012C SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/docker-compose.v8012c.yml")" == "$EXPECTED_COMPOSE_NEW" ]] || die "Package compose SHA mismatch"

echo
echo "[2] Verify production baseline"
MAIN_SHA="$(sha "$BASE/app/main.py")"
NAV_SHA="$(sha "$BASE/app/v8003_master_navigation.py")"
V8012A_SHA="$(sha "$BASE/app/v8012a_route_consolidation.py")"
V8012B_SHA="$(sha "$BASE/app/routes/v8012b_consolidation_router.py")"
COMPOSE_SHA="$(sha "$BASE/docker-compose.yml")"
INGRESS_SHA="$(sha "$BASE/app/v8011_ingress.py")"
V8004_SHA="$(sha "$BASE/app/v8004_quality_router.py")"
V8006_SHA="$(sha "$BASE/app/v8006_calendar_execution_correction.py")"
V8007_SHA="$(sha "$BASE/app/v8007_v8001_gate_bridge.py")"
PINE_SHA="$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")"

printf 'main.py: %s\nV8003 nav: %s\nV8012A: %s\nV8012B.1: %s\ncompose: %s\ningress: %s\nV8004: %s\nV8006: %s\nV8007: %s\nPine: %s\n' \
  "$MAIN_SHA" "$NAV_SHA" "$V8012A_SHA" "$V8012B_SHA" "$COMPOSE_SHA" \
  "$INGRESS_SHA" "$V8004_SHA" "$V8006_SHA" "$V8007_SHA" "$PINE_SHA"

[[ "$MAIN_SHA" == "$EXPECTED_MAIN_OLD" || "$MAIN_SHA" == "$EXPECTED_MAIN_NEW" ]] || die "Unexpected main.py baseline"
[[ "$NAV_SHA" == "$EXPECTED_NAV_OLD" || "$NAV_SHA" == "$EXPECTED_NAV_NEW" ]] || die "Unexpected V8003 baseline"
[[ "$V8012A_SHA" == "$EXPECTED_V8012A" ]] || die "Unexpected V8012A baseline"
[[ "$V8012B_SHA" == "$EXPECTED_V8012B" ]] || die "Unexpected V8012B.1 baseline"
[[ "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_OLD" || "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_NEW" ]] || die "Unexpected compose baseline"
[[ "$INGRESS_SHA" == "$EXPECTED_INGRESS" ]] || die "Unexpected V8011 ingress baseline"
[[ "$V8004_SHA" == "$EXPECTED_V8004" ]] || die "V8004 mismatch"
[[ "$V8006_SHA" == "$EXPECTED_V8006" ]] || die "V8006 mismatch"
[[ "$V8007_SHA" == "$EXPECTED_V8007" ]] || die "V8007 mismatch"
[[ "$PINE_SHA" == "$EXPECTED_PINE" ]] || die "Pine mismatch"

if [[ -f "$BASE/app/routes/v8012c_side_effect_hardening.py" ]]; then
  [[ "$(sha "$BASE/app/routes/v8012c_side_effect_hardening.py")" == "$EXPECTED_V8012C" ]] || die "Unexpected existing V8012C file"
fi

echo
echo "[3] Create rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/app/main.py" "$BACKUP/main.py"
cp -a "$BASE/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/.env" "$BACKUP/.env"
chmod 600 "$BACKUP/.env"
[[ ! -f "$BASE/app/routes/v8012c_side_effect_hardening.py" ]] || cp -a "$BASE/app/routes/v8012c_side_effect_hardening.py" "$BACKUP/v8012c_side_effect_hardening.py"
[[ ! -f "$BASE/ops/v8012_consolidation_check.sh" ]] || cp -a "$BASE/ops/v8012_consolidation_check.sh" "$BACKUP/v8012_consolidation_check.sh"
[[ ! -f "$BASE/README_V8012C.md" ]] || cp -a "$BASE/README_V8012C.md" "$BACKUP/README_V8012C.md"
ROLLBACK_ARMED=1

echo
echo "[4] Keep webhook token fully OFF"
python3 - "$BASE/.env" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
lines=p.read_text(encoding='utf-8', errors='replace').splitlines()
changes={'V8011_TOKEN_MODE':'off','V8011_ENFORCE_TOKEN':'false','V8011_WEBHOOK_TOKEN':''}
out=[]; seen=set()
for line in lines:
    if '=' not in line or line.lstrip().startswith('#'):
        out.append(line); continue
    key=line.split('=',1)[0].strip()
    if key in changes:
        if key not in seen:
            out.append(f'{key}={changes[key]}'); seen.add(key)
    else:
        out.append(line)
for key,val in changes.items():
    if key not in seen: out.append(f'{key}={val}')
p.write_text('\n'.join(out).rstrip()+'\n', encoding='utf-8')
print('token_mode: off')
print('token_configured: false')
print('token_enforced: false')
PY
chmod 600 "$BASE/.env"

echo
echo "[5] Install V8012C files"
mkdir -p "$BASE/app/routes" "$BASE/ops"
install -m 0644 "$PACKAGE_DIR/app/main.py" "$BASE/app/main.py"
install -m 0644 "$PACKAGE_DIR/app/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
install -m 0644 "$PACKAGE_DIR/app/routes/v8012c_side_effect_hardening.py" "$BASE/app/routes/v8012c_side_effect_hardening.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8012c.yml" "$BASE/docker-compose.yml"
install -m 0755 "$PACKAGE_DIR/ops/v8012_consolidation_check.sh" "$BASE/ops/v8012_consolidation_check.sh"
install -m 0644 "$PACKAGE_DIR/README_V8012C.md" "$BASE/README_V8012C.md"

cd "$BASE"
python3 -m py_compile \
  app/main.py \
  app/v8003_master_navigation.py \
  app/v8012a_route_consolidation.py \
  app/routes/v8012b_consolidation_router.py \
  app/routes/v8012c_side_effect_hardening.py
bash -n ops/v8012_consolidation_check.sh
docker compose config >/dev/null

echo
echo "[6] Verify protected hashes remain unchanged"
[[ "$(sha app/v8011_ingress.py)" == "$INGRESS_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha app/routes/v8012b_consolidation_router.py)" == "$V8012B_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]

echo
echo "[7] Build shared V8012C image"
docker compose build tradingbot

echo
echo "[8] Start backend + ingress"
docker compose up -d --force-recreate --remove-orphans
wait_http_200 http://127.0.0.1/health 75 2 || die "Public health did not recover"
wait_http_200 http://127.0.0.1/v8012/selftest-c.json 75 2 || die "V8012C selftest did not become ready"

echo
echo "[9] Validate V8012A + B.1 + C and ingress"
curl -fsS --max-time 30 http://127.0.0.1/v8012/selftest.json -o "$TMP_DIR/a.json"
curl -fsS --max-time 30 http://127.0.0.1/v8012/selftest-b.json -o "$TMP_DIR/b.json"
curl -fsS --max-time 30 http://127.0.0.1/v8012/selftest-c.json -o "$TMP_DIR/c.json"
curl -fsS --max-time 30 http://127.0.0.1/v8011/selftest.json -o "$TMP_DIR/ingress.json"
python3 - "$TMP_DIR/a.json" "$TMP_DIR/b.json" "$TMP_DIR/c.json" "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: a=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f: b=json.load(f)
with open(sys.argv[3],encoding='utf-8') as f: c=json.load(f)
with open(sys.argv[4],encoding='utf-8') as f: ing=json.load(f)
assert a.get('ok') is True, a
assert int(a.get('nonprotected_exact_duplicate_groups_after') or 0)==0, a
assert b.get('ok') is True, b
assert c.get('ok') is True, c
assert c.get('version')=='V8012C-SIDE-EFFECT-GET-HARDENING-V1', c
assert int(c.get('heuristic_candidates') or 0)==14, c
assert int(c.get('true_or_conditional_side_effects') or 0)==10, c
assert int(c.get('read_only_false_positives') or 0)==4, c
assert int(c.get('post_alternatives_registered') or 0)==10, c
assert int(c.get('legacy_get_routes_retained') or 0)==14, c
assert not (c.get('missing_get_routes') or []), c
assert not (c.get('missing_post_alternatives') or []), c
assert not (c.get('false_positive_post_routes') or []), c
assert ing.get('ok') is True, ing
assert ing.get('backend_ok') is True, ing
assert ing.get('worker_alive') is True, ing
assert ing.get('token_mode')=='off', ing
assert ing.get('token_configured') is False, ing
assert ing.get('token_enforced') is False, ing
print(json.dumps({
  'v8012a_ok': a.get('ok'),
  'v8012b_ok': b.get('ok'),
  'v8012c_ok': c.get('ok'),
  'classified_candidates': c.get('heuristic_candidates'),
  'side_effects': c.get('true_or_conditional_side_effects'),
  'false_positives': c.get('read_only_false_positives'),
  'post_alternatives': c.get('post_alternatives_registered'),
  'legacy_get_routes_retained': c.get('legacy_get_routes_retained'),
  'ingress_ok': ing.get('ok'),
  'token_mode': ing.get('token_mode'),
}, indent=2))
PY

echo
echo "[10] Validate POST confirmation guard without executing side effect"
GUARD_CODE="$(curl -sS -o "$TMP_DIR/guard.json" -w '%{http_code}' --max-time 15 -X POST http://127.0.0.1/pause/on)"
printf 'POST /pause/on without confirmation: %s\n' "$GUARD_CODE"
cat "$TMP_DIR/guard.json"; echo
[[ "$GUARD_CODE" == "428" ]] || die "POST confirmation guard failed"
python3 - "$TMP_DIR/guard.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: d=json.load(f)
assert d.get('error')=='confirmation_header_required', d
assert d.get('legacy_get_still_available') is True, d
PY

echo
echo "[11] Critical lightweight routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/selftest.json \
  /v8012/selftest-b.json \
  /v8012/selftest-c.json \
  /v8012/hub \
  /v8012/side-effect-hardening \
  /v8012/side-effect-hardening.json \
  /v8012/post-alternatives.json \
  /v8012/side-effect-usage.json
 do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 25 "http://127.0.0.1${route}" || true)"
  printf '%-52s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Critical route failed: $route"
 done

echo
echo "[12] Navigation"
curl -fsS --max-time 30 http://127.0.0.1/master | grep -q "V8012 Side-Effect Hardening"
curl -fsS --max-time 30 http://127.0.0.1/master-ai-review | grep -q "V8012 Side-Effect Hardening"
echo "Master link: PASS"
echo "AI Review link: PASS"

echo
echo "[13] Final protected hashes"
[[ "$(sha app/v8011_ingress.py)" == "$INGRESS_SHA" ]]
[[ "$(sha app/v8004_quality_router.py)" == "$V8004_SHA" ]]
[[ "$(sha app/v8006_calendar_execution_correction.py)" == "$V8006_SHA" ]]
[[ "$(sha app/v8007_v8001_gate_bridge.py)" == "$V8007_SHA" ]]
[[ "$(sha app/routes/v8012b_consolidation_router.py)" == "$V8012B_SHA" ]]
[[ "$(sha pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine)" == "$PINE_SHA" ]]

echo
echo "[14] Containers"
docker compose ps

ROLLBACK_ARMED=0
rm -rf "$TMP_DIR"

cat <<EOF2
================================================================================
V8012C INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Hardening:     http://91.107.237.214/v8012/side-effect-hardening
Hardening JSON:http://91.107.237.214/v8012/side-effect-hardening.json
POST map:      http://91.107.237.214/v8012/post-alternatives.json
Usage audit:   http://91.107.237.214/v8012/side-effect-usage.json
Selftest:      http://91.107.237.214/v8012/selftest-c.json

COMPLETED:
  14 heuristic GET candidates classified
  10 true/conditional side effects identified
  4 read-only false positives identified
  10 confirmed POST alternatives registered
  Legacy GET routes retained unchanged
  Legacy GET usage audited in memory without query strings or tokens

POST SAFETY:
  Header required: X-V8012C-Confirm: yes
  Existing endpoint token checks remain active
  No new token introduced

UNCHANGED:
  V8004 / V8006 / V8007
  Canonical Pine
  V8011 ingress/queue/dead-letter
  Existing trading DB schema
  Live scoring/routing
  Token OFF
  Broker auto execution FALSE
EOF2
