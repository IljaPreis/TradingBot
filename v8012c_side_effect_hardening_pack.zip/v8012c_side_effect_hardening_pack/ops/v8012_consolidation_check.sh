#!/usr/bin/env bash
set -u

BASE="/opt/tradingbot_v6000"
TMP_DIR="$(mktemp -d /tmp/v8012c_check.XXXXXX)"
trap 'rm -rf "$TMP_DIR"' EXIT
FAIL=0

fetch_json() {
  local url="$1" out="$2" timeout="${3:-30}"
  curl -fsS --max-time "$timeout" "$url" -o "$out"
}

status_code() {
  curl -sS -o /dev/null -w '%{http_code}' --max-time "${2:-20}" "$1" 2>/dev/null || true
}

echo "=== V8012C SIDE-EFFECT HARDENING CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"
cd "$BASE" || exit 1

echo "[1] Containers"
docker compose ps

echo "[2] V8012A / B.1 / C selftests"
fetch_json http://127.0.0.1/v8012/selftest.json "$TMP_DIR/a.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-b.json "$TMP_DIR/b.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-c.json "$TMP_DIR/c.json" || FAIL=1
if [[ -s "$TMP_DIR/a.json" && -s "$TMP_DIR/b.json" && -s "$TMP_DIR/c.json" ]]; then
  python3 - "$TMP_DIR/a.json" "$TMP_DIR/b.json" "$TMP_DIR/c.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: a=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f: b=json.load(f)
with open(sys.argv[3],encoding='utf-8') as f: c=json.load(f)
print(json.dumps({
  'v8012a_ok': a.get('ok'),
  'duplicates_after': a.get('nonprotected_exact_duplicate_groups_after'),
  'v8012b_ok': b.get('ok'),
  'v8012c_ok': c.get('ok'),
  'version': c.get('version'),
  'heuristic_candidates': c.get('heuristic_candidates'),
  'true_or_conditional_side_effects': c.get('true_or_conditional_side_effects'),
  'read_only_false_positives': c.get('read_only_false_positives'),
  'post_alternatives_registered': c.get('post_alternatives_registered'),
  'legacy_get_routes_retained': c.get('legacy_get_routes_retained'),
  'confirmation_header_required': c.get('confirmation_header_required'),
}, indent=2))
assert a.get('ok') is True
assert int(a.get('nonprotected_exact_duplicate_groups_after') or 0)==0
assert b.get('ok') is True
assert c.get('ok') is True
assert c.get('version')=='V8012C-SIDE-EFFECT-GET-HARDENING-V1'
assert int(c.get('heuristic_candidates') or 0)==14
assert int(c.get('true_or_conditional_side_effects') or 0)==10
assert int(c.get('read_only_false_positives') or 0)==4
assert int(c.get('post_alternatives_registered') or 0)==10
assert int(c.get('legacy_get_routes_retained') or 0)==14
assert c.get('confirmation_header_required') is True
assert not (c.get('missing_get_routes') or [])
assert not (c.get('missing_post_alternatives') or [])
assert not (c.get('false_positive_post_routes') or [])
PY
else
  FAIL=1
fi

echo "[3] POST confirmation guard – no side effect executed"
BODY_FILE="$TMP_DIR/post_guard.json"
CODE="$(curl -sS -o "$BODY_FILE" -w '%{http_code}' --max-time 15 -X POST http://127.0.0.1/pause/on 2>/dev/null || true)"
printf 'POST /pause/on without confirmation: %s\n' "$CODE"
cat "$BODY_FILE" 2>/dev/null || true
echo
[[ "$CODE" == "428" ]] || FAIL=1
if [[ -s "$BODY_FILE" ]]; then
  python3 - "$BODY_FILE" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: d=json.load(f)
assert d.get('error')=='confirmation_header_required'
assert d.get('legacy_get_still_available') is True
PY
else
  FAIL=1
fi

echo "[4] Classification map"
fetch_json http://127.0.0.1/v8012/side-effect-hardening.json "$TMP_DIR/hardening.json" || FAIL=1
if [[ -s "$TMP_DIR/hardening.json" ]]; then
  python3 - "$TMP_DIR/hardening.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: d=json.load(f)
s=d.get('summary') or {}
v=d.get('validation') or {}
print(json.dumps({
  'ok': d.get('ok'),
  'classified': s.get('heuristic_candidates_from_v8012b'),
  'side_effects': s.get('true_or_conditional_side_effects'),
  'false_positives': s.get('read_only_false_positives'),
  'post_alternatives': s.get('post_alternatives_registered'),
  'missing_get_routes': v.get('missing_get_routes'),
  'missing_post_alternatives': v.get('missing_post_alternatives'),
  'new_token_introduced': s.get('new_token_introduced'),
}, indent=2))
assert d.get('ok') is True
assert s.get('new_token_introduced') is False
PY
fi

echo "[5] Ingress health and token OFF"
fetch_json http://127.0.0.1/v8011/selftest.json "$TMP_DIR/ingress.json" || FAIL=1
if [[ -s "$TMP_DIR/ingress.json" ]]; then
  python3 - "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f: d=json.load(f)
print(json.dumps({
  'ok': d.get('ok'),
  'operational_status': d.get('operational_status'),
  'queue_depth': d.get('queue_depth'),
  'backend_ok': d.get('backend_ok'),
  'worker_alive': d.get('worker_alive'),
  'token_mode': d.get('token_mode'),
  'token_configured': d.get('token_configured'),
  'token_enforced': d.get('token_enforced'),
}, indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY
fi

echo "[6] Critical lightweight routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/selftest.json \
  /v8012/selftest-b.json \
  /v8012/selftest-c.json \
  /v8012/hub \
  /v8012/side-effect-hardening \
  /v8012/side-effect-hardening.json \
  /v8012/post-alternatives.json \
  /v8012/side-effect-usage.json
 do
  code="$(status_code "http://127.0.0.1${route}" 25)"
  printf '%-52s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || FAIL=1
 done

echo "[7] Navigation"
if curl -fsS --max-time 30 http://127.0.0.1/master | grep -q "V8012 Side-Effect Hardening"; then
  echo "Master link: PASS"
else
  echo "Master link: FAIL"; FAIL=1
fi
if curl -fsS --max-time 30 http://127.0.0.1/master-ai-review | grep -q "V8012 Side-Effect Hardening"; then
  echo "AI Review link: PASS"
else
  echo "AI Review link: FAIL"; FAIL=1
fi

echo "[8] Protected hashes"
sha256sum \
  app/v8011_ingress.py \
  app/v8004_quality_router.py \
  app/v8006_calendar_execution_correction.py \
  app/v8007_v8001_gate_bridge.py \
  pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine

echo "[9] Actual errors last 30m"
docker logs --since 30m tradingbot 2>&1 \
  | grep -Ei 'Traceback|ERROR|Exception|FATAL|V8012C.*error' \
  | tail -n 100 || true

echo "[10] Host resources"
uptime
free -h
df -h "$BASE"

if [[ "$FAIL" != "0" ]]; then
  echo "=== V8012C CHECK FEHLER ==="
  exit 1
fi

echo "=== V8012C CHECK FERTIG ==="
