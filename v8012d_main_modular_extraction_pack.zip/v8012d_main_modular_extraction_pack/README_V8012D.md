# V8012D Main.py Modular Extraction

Version: `V8012D-MAIN-MODULAR-EXTRACTION-V1`

## Zweck

V8012D ist der erste echte, verhaltensgleiche Ausbau aus `app/main.py` in einen separaten FastAPI-`APIRouter`.

Ausgelagert werden ausschließlich 16 read-only Dashboard-Wrapper aus vier Gruppen:

- V7246E Entry Upgrade Simulator: 2 Routen
- V7246F Clean Upgrade Candidates: 2 Routen
- V7246G Entry Guard: 2 Routen
- V8000 Dual Playbook: 10 Routen

Die eigentlichen Payload-, Bewertungs- und HTML-Funktionen bleiben in ihren bestehenden Modulen unverändert. Nur die Route-Registrierung wird aus `main.py` entfernt und in `app/routes/v8012d_dashboard_extraction.py` registriert.

## Source-Reduktion

- `main.py` vorher: 16.113 Zeilen / 561.354 Bytes
- `main.py` danach: 16.005 Zeilen / 557.390 Bytes
- entfernt: 108 Zeilen / 3.964 Bytes

## Kompatibilität

Unverändert bleiben:

- alle 16 bestehenden URLs
- HTTP-Methode GET
- Query-Parameter und Defaults
- JSON- und HTML-Response-Wrapper
- V7246E/F/G Payload-Funktionen
- V8000 Payload- und HTML-Funktionen

## Neue Diagnose-Routen

- `/v8012/modular-extraction`
- `/v8012/modular-extraction.json`
- `/v8012/selftest-d.json`
- `/v8012/startup-metrics.json`

Der Installer misst die Zeit bis zum öffentlichen Health-Status und schreibt nur die operative Datei `data/v8012d_startup_metrics.json`. Es gibt keine Trading-Datenbankmigration und keine Trading-Datenbank-Schreibvorgänge durch V8012D.

## Sicherheit

- V8004/V8006/V8007 unverändert
- Canonical Pine unverändert
- V8011 Ingress/Queue/Dead Letter unverändert
- bestehende Trading-Datenbank unverändert
- Live-Scoring und Routing unverändert
- Webhook-Token bleibt OFF
- Broker Auto Execution bleibt FALSE

## Route-Kompatibilitätsnachweis

`ROUTE_COMPATIBILITY.json` vergleicht alle 16 Routen vor und nach der Extraktion. Methoden, Routennamen, Response-Klassen sowie Query-Parameter, Defaults und Typen sind identisch.
