from __future__ import annotations

import html
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8012D-MAIN-MODULAR-EXTRACTION-V1"
MODE = "behavior_preserving_read_only_dashboard_route_extraction"

BASELINE_MAIN_LINES = 16113
CURRENT_MAIN_LINES = 16005
BASELINE_MAIN_BYTES = 561354
CURRENT_MAIN_BYTES = 557390

EXTRACTED_GROUPS = {
    "v7246e_entry_upgrade_sim": (
        "/v7246e-entry-upgrade-sim.json",
        "/v7246e-entry-upgrade-sim",
    ),
    "v7246f_clean_upgrade_candidates": (
        "/v7246f-clean-upgrade-candidates.json",
        "/v7246f-clean-upgrade-candidates",
    ),
    "v7246g_entry_guard": (
        "/v7246g-entry-guard.json",
        "/v7246g-entry-guard",
    ),
    "v8000_dual_playbook": (
        "/v8000/master.json",
        "/v8000/master",
        "/v8000.json",
        "/v8000",
        "/v8000/portfolio.json",
        "/v8000/portfolio",
        "/v8000/playbooks.json",
        "/v8000/playbooks",
        "/v8000/a-plus.json",
        "/v8000/a-plus",
    ),
}
EXTRACTED_PATHS = tuple(path for paths in EXTRACTED_GROUPS.values() for path in paths)

SAFETY = {
    "path_changes": False,
    "method_changes": False,
    "query_parameter_changes": False,
    "response_wrapper_changes": False,
    "payload_function_changes": False,
    "v8004_changed": False,
    "v8006_changed": False,
    "v8007_changed": False,
    "pine_changed": False,
    "v8011_ingress_changed": False,
    "trading_db_schema_changes": False,
    "trading_db_writes": False,
    "live_scoring_changed": False,
    "live_routing_changed": False,
    "webhook_token_mode": "off",
    "broker_auto_execution": False,
}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _root() -> Path:
    for candidate in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        if (candidate / "app").exists():
            return candidate
    return Path.cwd()


def _startup_file() -> Path:
    return _root() / "data" / "v8012d_startup_metrics.json"


def _read_startup_metrics() -> dict[str, Any]:
    try:
        value = json.loads(_startup_file().read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _route_inventory(app: Any) -> dict[str, Any]:
    signatures: dict[tuple[str, str], int] = {}
    paths: dict[str, set[str]] = {}
    endpoint_modules: dict[str, set[str]] = {}
    for route in app.router.routes:
        path = str(getattr(route, "path", "") or "")
        if not path:
            continue
        methods = {str(x).upper() for x in (getattr(route, "methods", None) or set())}
        endpoint = getattr(route, "endpoint", None)
        module = str(getattr(endpoint, "__module__", "") or "")
        for method in methods:
            signatures[(path, method)] = signatures.get((path, method), 0) + 1
        paths.setdefault(path, set()).update(methods)
        if module:
            endpoint_modules.setdefault(path, set()).add(module)
    missing = [path for path in EXTRACTED_PATHS if "GET" not in paths.get(path, set())]
    duplicates = [
        {"path": path, "method": method, "count": count}
        for (path, method), count in sorted(signatures.items())
        if path in EXTRACTED_PATHS and count > 1
    ]
    wrong_module = [
        {"path": path, "modules": sorted(endpoint_modules.get(path, set()))}
        for path in EXTRACTED_PATHS
        if "app.routes.v8012d_dashboard_extraction" not in endpoint_modules.get(path, set())
    ]
    return {
        "expected_paths": len(EXTRACTED_PATHS),
        "registered_paths": len(EXTRACTED_PATHS) - len(missing),
        "missing_paths": missing,
        "duplicate_signatures": duplicates,
        "wrong_endpoint_module": wrong_module,
        "groups": {
            name: {
                "expected": len(group_paths),
                "present": sum(1 for path in group_paths if "GET" in paths.get(path, set())),
            }
            for name, group_paths in EXTRACTED_GROUPS.items()
        },
    }


def _payload(app: Any) -> dict[str, Any]:
    inventory = _route_inventory(app)
    install_metrics = dict(getattr(app.state, "v8012d_install_metrics", {}) or {})
    ok = (
        not install_metrics.get("group_errors")
        and not inventory["missing_paths"]
        and not inventory["duplicate_signatures"]
        and not inventory["wrong_endpoint_module"]
    )
    return {
        "ok": bool(ok),
        "version": VERSION,
        "mode": MODE,
        "generated_utc": _utcnow(),
        "summary": {
            "extracted_route_wrappers": len(EXTRACTED_PATHS),
            "extracted_groups": len(EXTRACTED_GROUPS),
            "main_lines_before": BASELINE_MAIN_LINES,
            "main_lines_after": CURRENT_MAIN_LINES,
            "main_lines_removed": BASELINE_MAIN_LINES - CURRENT_MAIN_LINES,
            "main_bytes_before": BASELINE_MAIN_BYTES,
            "main_bytes_after": CURRENT_MAIN_BYTES,
            "main_bytes_removed": BASELINE_MAIN_BYTES - CURRENT_MAIN_BYTES,
            "payload_modules_changed": 0,
            "legacy_paths_changed": 0,
        },
        "inventory": inventory,
        "runtime": install_metrics,
        "startup": _read_startup_metrics(),
        "safety": dict(SAFETY),
    }


def _page(app: Any) -> str:
    data = _payload(app)
    summary = data["summary"]
    inventory = data["inventory"]
    runtime = data["runtime"]
    status = "GREEN" if data["ok"] else "RED"
    rows = "".join(
        f"<tr><td>{html.escape(name)}</td><td>{item['present']} / {item['expected']}</td></tr>"
        for name, item in inventory["groups"].items()
    )
    return f"""<!doctype html><html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>V8012D Modular Extraction</title><style>
body{{background:#07111e;color:#eef6ff;font-family:Arial,sans-serif;margin:0}}.wrap{{max-width:1100px;margin:auto;padding:18px}}.card{{background:#101d2e;border:1px solid #273a52;border-radius:16px;padding:16px;margin:12px 0}}.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}}.metric{{background:#0b1728;border:1px solid #273a52;border-radius:12px;padding:12px}}.label{{color:#9caec4;font-size:12px}}.value{{font-size:26px;font-weight:900;margin-top:4px}}.good{{color:#86efac}}table{{width:100%;border-collapse:collapse}}td,th{{padding:9px;border-bottom:1px solid #273a52;text-align:left}}code{{color:#a5d8ff}}@media(max-width:760px){{.grid{{grid-template-columns:repeat(2,1fr)}}}}
</style></head><body><div class='wrap'><div class='card'><h1>V8012D Main.py Modular Extraction</h1><p>Status: <b class='good'>{status}</b> · Read-only Dashboard-Wrapper wurden in einen APIRouter ausgelagert.</p></div>
<div class='grid'><div class='metric'><div class='label'>Routen ausgelagert</div><div class='value'>{summary['extracted_route_wrappers']}</div></div><div class='metric'><div class='label'>Gruppen</div><div class='value'>{summary['extracted_groups']}</div></div><div class='metric'><div class='label'>Zeilen entfernt</div><div class='value'>{summary['main_lines_removed']}</div></div><div class='metric'><div class='label'>Registrierung ms</div><div class='value'>{runtime.get('registration_ms','-')}</div></div></div>
<div class='card'><h2>Extraktionsgruppen</h2><table><tr><th>Gruppe</th><th>Registriert</th></tr>{rows}</table></div>
<div class='card'><h2>Sicherheit</h2><p>URLs, Methoden, Parameter, Response-Wrapper und Payload-Funktionen bleiben unverändert. Keine Trading-DB-Schreibvorgänge, keine Live-Regeländerungen, Token OFF, Broker Auto Execution FALSE.</p><code>/v8012/selftest-d.json</code></div>
</div></body></html>"""


def install_v8012d_dashboard_extraction(app: Any) -> None:
    if getattr(app.state, "v8012d_dashboard_extraction_installed", False):
        return

    started = time.perf_counter()
    router = APIRouter()
    group_errors: dict[str, str] = {}
    installed_groups: list[str] = []

    try:
        from app.v7246e_entry_upgrade_simulator import v7246e_payload, v7246e_html

        @router.get("/v7246e-entry-upgrade-sim.json")
        def v7246e_entry_upgrade_sim_json(token: str = "", limit: int = 100):
            return JSONResponse(v7246e_payload(limit=limit))

        @router.get("/v7246e-entry-upgrade-sim", response_class=HTMLResponse)
        def v7246e_entry_upgrade_sim_page(token: str = ""):
            return HTMLResponse(v7246e_html())

        installed_groups.append("v7246e_entry_upgrade_sim")
    except Exception as exc:
        group_errors["v7246e_entry_upgrade_sim"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7246f_clean_upgrade_candidates import v7246f_payload, v7246f_html

        @router.get("/v7246f-clean-upgrade-candidates.json")
        def v7246f_clean_upgrade_candidates_json(token: str = "", limit: int = 160):
            return JSONResponse(v7246f_payload(limit=limit))

        @router.get("/v7246f-clean-upgrade-candidates", response_class=HTMLResponse)
        def v7246f_clean_upgrade_candidates_page(token: str = ""):
            return HTMLResponse(v7246f_html())

        installed_groups.append("v7246f_clean_upgrade_candidates")
    except Exception as exc:
        group_errors["v7246f_clean_upgrade_candidates"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7246g_entry_guard_recommendation import v7246g_payload, v7246g_html

        @router.get("/v7246g-entry-guard.json")
        def v7246g_entry_guard_json(token: str = "", limit: int = 220):
            return JSONResponse(v7246g_payload(limit=limit))

        @router.get("/v7246g-entry-guard", response_class=HTMLResponse)
        def v7246g_entry_guard_page(token: str = ""):
            return HTMLResponse(v7246g_html())

        installed_groups.append("v7246g_entry_guard")
    except Exception as exc:
        group_errors["v7246g_entry_guard"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v8000_dual_playbook_engine import (
            v8000_master_payload,
            v8000_master_html,
            v8000_portfolio_payload,
            v8000_portfolio_html,
            v8000_playbooks_payload,
            v8000_playbooks_html,
            v8000_a_plus_payload,
            v8000_a_plus_html,
        )

        @router.get("/v8000/master.json")
        def v8000_master_json(token: str = "", limit: int = 220):
            return JSONResponse(v8000_master_payload(limit=limit))

        @router.get("/v8000/master", response_class=HTMLResponse)
        def v8000_master_page(token: str = ""):
            return HTMLResponse(v8000_master_html())

        @router.get("/v8000.json")
        def v8000_short_json(token: str = "", limit: int = 220):
            return JSONResponse(v8000_master_payload(limit=limit))

        @router.get("/v8000", response_class=HTMLResponse)
        def v8000_short_page(token: str = ""):
            return HTMLResponse(v8000_master_html())

        @router.get("/v8000/portfolio.json")
        def v8000_portfolio_json(token: str = "", limit: int = 220):
            return JSONResponse(v8000_portfolio_payload(limit=limit))

        @router.get("/v8000/portfolio", response_class=HTMLResponse)
        def v8000_portfolio_page(token: str = ""):
            return HTMLResponse(v8000_portfolio_html())

        @router.get("/v8000/playbooks.json")
        def v8000_playbooks_json(token: str = "", limit: int = 220):
            return JSONResponse(v8000_playbooks_payload(limit=limit))

        @router.get("/v8000/playbooks", response_class=HTMLResponse)
        def v8000_playbooks_page(token: str = ""):
            return HTMLResponse(v8000_playbooks_html())

        @router.get("/v8000/a-plus.json")
        def v8000_a_plus_json(token: str = "", limit: int = 220):
            return JSONResponse(v8000_a_plus_payload(limit=limit))

        @router.get("/v8000/a-plus", response_class=HTMLResponse)
        def v8000_a_plus_page(token: str = ""):
            return HTMLResponse(v8000_a_plus_html())

        installed_groups.append("v8000_dual_playbook")
    except Exception as exc:
        group_errors["v8000_dual_playbook"] = f"{type(exc).__name__}: {exc}"

    @router.get("/v8012/modular-extraction.json")
    def v8012d_modular_extraction_json():
        return JSONResponse(_payload(app))

    @router.get("/v8012/modular-extraction", response_class=HTMLResponse)
    def v8012d_modular_extraction_page():
        return HTMLResponse(_page(app))

    @router.get("/v8012/selftest-d.json")
    def v8012d_selftest():
        return JSONResponse(_payload(app))

    @router.get("/v8012/startup-metrics.json")
    def v8012d_startup_metrics():
        data = _payload(app)
        return JSONResponse({
            "ok": data["ok"],
            "version": VERSION,
            "runtime": data["runtime"],
            "startup": data["startup"],
            "source_reduction": data["summary"],
        })

    app.include_router(router)
    elapsed_ms = round((time.perf_counter() - started) * 1000.0, 3)
    app.state.v8012d_install_metrics = {
        "installed_at": _utcnow(),
        "registration_ms": elapsed_ms,
        "groups_expected": len(EXTRACTED_GROUPS),
        "groups_installed": len(installed_groups),
        "installed_groups": installed_groups,
        "group_errors": group_errors,
        "router_module": "app.routes.v8012d_dashboard_extraction",
    }
    app.state.v8012d_dashboard_extraction_installed = True
    print(
        "[V8012D] Modular dashboard extraction installed: "
        f"groups={len(installed_groups)} routes={len(EXTRACTED_PATHS)} "
        f"registration_ms={elapsed_ms} errors={len(group_errors)}"
    )
