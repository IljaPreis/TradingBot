#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="V8012D-MAIN-MODULAR-EXTRACTION-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8012d_before_${TS}"
LOG="/root/v8012d_install_${TS}.log"
TMP_DIR="$(mktemp -d /tmp/v8012d_install.XXXXXX)"

EXPECTED_MAIN_OLD="ffa0aaa095faf438cda227d41fbf582e9f747d4582b8fd2adc2a94ab9ff50896"
EXPECTED_MAIN_NEW="5bdfd97b7adf79e0f697d88afb72444bee5d10d475d652eeaf45fee5f6c201de"
EXPECTED_NAV_OLD="b02b4206cca4ede59a412e7777e48086f8a9aa02b4cac9135aeeebf0a7f84e15"
EXPECTED_NAV_NEW="c912f9b147d08343af3fef79982bcec97fe133ff359fc302039615263ecd372c"
EXPECTED_V8012D="d2b5d8c0d0ee5d8dadf26bf025f1c994fd217b52ca801b02346ff0849d0c9d28"
EXPECTED_V8012A="30e36a321e9c41810d766aaa7c857637e2c15d2f11fbc504c9b5969c27390af9"
EXPECTED_V8012B="2c4ae0955b8888650834f9f332ef5267d9f75bdb9d8bb1fbd5662b525c3c006b"
EXPECTED_V8012C="e7b881d09a097adb75835e46d7c367a28f28092196d31dbaf25c84ef5135381e"
EXPECTED_COMPOSE_OLD="f7780a9c8eda3614114f4250e0fcb4092325078709330ed541dd074e994e66fd"
EXPECTED_COMPOSE_NEW="35c609cebc0195f78ca70445e38c4bcd7b2072ea993811f72d59c450dd4d955c"
EXPECTED_INGRESS="0b50a8dcce8e0f2ef71dead1d5489bdd1c915b932acefa166eec656828806c8b"
EXPECTED_V8004="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

ROLLBACK_ARMED=0
exec > >(tee -a "$LOG") 2>&1

sha() { sha256sum "$1" | awk '{print $1}'; }
die() { echo "FATAL: $*" >&2; exit 1; }
now_ms() { python3 - <<'PY'
import time
print(time.time_ns() // 1_000_000)
PY
}

wait_http_200() {
  local url="$1" attempts="${2:-75}" sleep_s="${3:-2}" i code
  for i in $(seq 1 "$attempts"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    echo "WAIT [$i/$attempts] $url status=${code:-none}"
    sleep "$sleep_s"
  done
  return 1
}

rollback() {
  local rc=$?
  trap - ERR
  rm -rf "$TMP_DIR" || true
  if [[ "$ROLLBACK_ARMED" != "1" ]]; then exit "$rc"; fi
  echo
  echo "=== V8012D ROLLBACK START ==="
  cp -a "$BACKUP/main.py" "$BASE/app/main.py" || true
  cp -a "$BACKUP/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py" || true
  cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml" || true
  cp -a "$BACKUP/.env" "$BASE/.env" || true
  chmod 600 "$BASE/.env" || true
  if [[ -f "$BACKUP/v8012d_dashboard_extraction.py" ]]; then
    mkdir -p "$BASE/app/routes"
    cp -a "$BACKUP/v8012d_dashboard_extraction.py" "$BASE/app/routes/v8012d_dashboard_extraction.py" || true
  else
    rm -f "$BASE/app/routes/v8012d_dashboard_extraction.py"
  fi
  if [[ -f "$BACKUP/v8012_consolidation_check.sh" ]]; then
    cp -a "$BACKUP/v8012_consolidation_check.sh" "$BASE/ops/v8012_consolidation_check.sh" || true
  fi
  if [[ -f "$BACKUP/README_V8012D.md" ]]; then
    cp -a "$BACKUP/README_V8012D.md" "$BASE/README_V8012D.md" || true
  else
    rm -f "$BASE/README_V8012D.md"
  fi
  if [[ -f "$BACKUP/v8012d_startup_metrics.json" ]]; then
    cp -a "$BACKUP/v8012d_startup_metrics.json" "$BASE/data/v8012d_startup_metrics.json" || true
  else
    rm -f "$BASE/data/v8012d_startup_metrics.json"
  fi
  cd "$BASE"
  docker compose config >/dev/null 2>&1 || true
  docker compose up -d --build --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8012D ROLLBACK ENDE ==="
  exit "$rc"
}
trap rollback ERR

cat <<EOF
================================================================================
$VERSION INSTALL
================================================================================
Generated UTC: $(date -u --iso-8601=seconds)
Project: $BASE
Package: $PACKAGE_DIR

Scope:
  First behavior-preserving extraction from app/main.py: YES
  Read-only dashboard route wrappers extracted: 16
  Extracted groups: V7246E, V7246F, V7246G, V8000
  APIRouter module: app/routes/v8012d_dashboard_extraction.py
  Existing URLs/methods/query defaults/responses: UNCHANGED
  Payload and scoring modules: UNCHANGED
  main.py reduction: 108 lines / 3964 bytes
  Health-ready and registration timing: MEASURE

Safety:
  V8004/V8006/V8007 changes: 0
  Canonical Pine changes: 0
  V8011 ingress/queue/dead-letter changes: 0
  Existing trading DB schema/writes: 0
  Live scoring/routing changes: 0
  Token mode: OFF
  Broker auto execution: FALSE
EOF

[[ -d "$BASE" ]] || die "Project not found: $BASE"

for f in \
  "$BASE/app/main.py" \
  "$BASE/app/v8003_master_navigation.py" \
  "$BASE/app/v8012a_route_consolidation.py" \
  "$BASE/app/routes/v8012b_consolidation_router.py" \
  "$BASE/app/routes/v8012c_side_effect_hardening.py" \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/docker-compose.yml" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine" \
  "$BASE/.env"
 do
  [[ -f "$f" ]] || die "Missing production file: $f"
 done

for f in \
  "$PACKAGE_DIR/app/main.py" \
  "$PACKAGE_DIR/app/v8003_master_navigation.py" \
  "$PACKAGE_DIR/app/routes/v8012d_dashboard_extraction.py" \
  "$PACKAGE_DIR/docker-compose.v8012d.yml" \
  "$PACKAGE_DIR/ops/v8012_consolidation_check.sh" \
  "$PACKAGE_DIR/README_V8012D.md" \
  "$PACKAGE_DIR/ROUTE_COMPATIBILITY.json" \
  "$PACKAGE_DIR/MANIFEST.sha256"
 do
  [[ -f "$f" ]] || die "Missing package file: $f"
 done

echo
echo "[1] Verify package hashes"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)
[[ "$(sha "$PACKAGE_DIR/app/main.py")" == "$EXPECTED_MAIN_NEW" ]] || die "Package main SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/v8003_master_navigation.py")" == "$EXPECTED_NAV_NEW" ]] || die "Package navigation SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/routes/v8012d_dashboard_extraction.py")" == "$EXPECTED_V8012D" ]] || die "Package V8012D SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/docker-compose.v8012d.yml")" == "$EXPECTED_COMPOSE_NEW" ]] || die "Package compose SHA mismatch"
python3 - "$PACKAGE_DIR/ROUTE_COMPATIBILITY.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
assert d.get('version')=='V8012D-MAIN-MODULAR-EXTRACTION-V1'
assert int(d.get('paths_compared') or 0)==16
assert int(d.get('paths_identical') or 0)==16
assert d.get('all_route_signatures_identical') is True
assert d.get('payload_modules_changed') is False
assert d.get('trading_logic_changed') is False
print('Route compatibility report: PASS')
PY

echo
echo "[2] Verify production baseline"
MAIN_SHA="$(sha "$BASE/app/main.py")"
NAV_SHA="$(sha "$BASE/app/v8003_master_navigation.py")"
V8012A_SHA="$(sha "$BASE/app/v8012a_route_consolidation.py")"
V8012B_SHA="$(sha "$BASE/app/routes/v8012b_consolidation_router.py")"
V8012C_SHA="$(sha "$BASE/app/routes/v8012c_side_effect_hardening.py")"
COMPOSE_SHA="$(sha "$BASE/docker-compose.yml")"
INGRESS_SHA="$(sha "$BASE/app/v8011_ingress.py")"
V8004_SHA="$(sha "$BASE/app/v8004_quality_router.py")"
V8006_SHA="$(sha "$BASE/app/v8006_calendar_execution_correction.py")"
V8007_SHA="$(sha "$BASE/app/v8007_v8001_gate_bridge.py")"
PINE_SHA="$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")"

printf 'main.py: %s\nV8003 nav: %s\nV8012A: %s\nV8012B.1: %s\nV8012C.1: %s\ncompose: %s\ningress: %s\nV8004: %s\nV8006: %s\nV8007: %s\nPine: %s\n' \
  "$MAIN_SHA" "$NAV_SHA" "$V8012A_SHA" "$V8012B_SHA" "$V8012C_SHA" "$COMPOSE_SHA" \
  "$INGRESS_SHA" "$V8004_SHA" "$V8006_SHA" "$V8007_SHA" "$PINE_SHA"

[[ "$MAIN_SHA" == "$EXPECTED_MAIN_OLD" || "$MAIN_SHA" == "$EXPECTED_MAIN_NEW" ]] || die "Unexpected main.py baseline"
[[ "$NAV_SHA" == "$EXPECTED_NAV_OLD" || "$NAV_SHA" == "$EXPECTED_NAV_NEW" ]] || die "Unexpected V8003 baseline"
[[ "$V8012A_SHA" == "$EXPECTED_V8012A" ]] || die "Unexpected V8012A baseline"
[[ "$V8012B_SHA" == "$EXPECTED_V8012B" ]] || die "Unexpected V8012B.1 baseline"
[[ "$V8012C_SHA" == "$EXPECTED_V8012C" ]] || die "Unexpected V8012C.1 baseline"
[[ "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_OLD" || "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_NEW" ]] || die "Unexpected compose baseline"
[[ "$INGRESS_SHA" == "$EXPECTED_INGRESS" ]] || die "Unexpected V8011 ingress baseline"
[[ "$V8004_SHA" == "$EXPECTED_V8004" ]] || die "V8004 mismatch"
[[ "$V8006_SHA" == "$EXPECTED_V8006" ]] || die "V8006 mismatch"
[[ "$V8007_SHA" == "$EXPECTED_V8007" ]] || die "V8007 mismatch"
[[ "$PINE_SHA" == "$EXPECTED_PINE" ]] || die "Pine mismatch"
if [[ -f "$BASE/app/routes/v8012d_dashboard_extraction.py" ]]; then
  [[ "$(sha "$BASE/app/routes/v8012d_dashboard_extraction.py")" == "$EXPECTED_V8012D" ]] || die "Unexpected existing V8012D file"
fi

echo
echo "[3] Create rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/app/main.py" "$BACKUP/main.py"
cp -a "$BASE/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/.env" "$BACKUP/.env"
chmod 600 "$BACKUP/.env"
[[ ! -f "$BASE/app/routes/v8012d_dashboard_extraction.py" ]] || cp -a "$BASE/app/routes/v8012d_dashboard_extraction.py" "$BACKUP/v8012d_dashboard_extraction.py"
[[ ! -f "$BASE/ops/v8012_consolidation_check.sh" ]] || cp -a "$BASE/ops/v8012_consolidation_check.sh" "$BACKUP/v8012_consolidation_check.sh"
[[ ! -f "$BASE/README_V8012D.md" ]] || cp -a "$BASE/README_V8012D.md" "$BACKUP/README_V8012D.md"
[[ ! -f "$BASE/data/v8012d_startup_metrics.json" ]] || cp -a "$BASE/data/v8012d_startup_metrics.json" "$BACKUP/v8012d_startup_metrics.json"
ROLLBACK_ARMED=1

echo
echo "[4] Keep webhook token fully OFF"
python3 - "$BASE/.env" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
lines=p.read_text(encoding='utf-8', errors='replace').splitlines()
changes={'V8011_TOKEN_MODE':'off','V8011_ENFORCE_TOKEN':'false','V8011_WEBHOOK_TOKEN':''}
out=[]; seen=set()
for line in lines:
    if '=' not in line or line.lstrip().startswith('#'):
        out.append(line); continue
    key=line.split('=',1)[0].strip()
    if key in changes:
        if key not in seen:
            out.append(f'{key}={changes[key]}'); seen.add(key)
    else:
        out.append(line)
for key,val in changes.items():
    if key not in seen: out.append(f'{key}={val}')
p.write_text('\n'.join(out).rstrip()+'\n', encoding='utf-8')
print('token_mode: off')
print('token_configured: false')
print('token_enforced: false')
PY
chmod 600 "$BASE/.env"

echo
echo "[5] Install V8012D files"
mkdir -p "$BASE/app/routes" "$BASE/ops" "$BASE/data"
install -m 0644 "$PACKAGE_DIR/app/main.py" "$BASE/app/main.py"
install -m 0644 "$PACKAGE_DIR/app/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
install -m 0644 "$PACKAGE_DIR/app/routes/v8012d_dashboard_extraction.py" "$BASE/app/routes/v8012d_dashboard_extraction.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8012d.yml" "$BASE/docker-compose.yml"
install -m 0755 "$PACKAGE_DIR/ops/v8012_consolidation_check.sh" "$BASE/ops/v8012_consolidation_check.sh"
install -m 0644 "$PACKAGE_DIR/README_V8012D.md" "$BASE/README_V8012D.md"

echo
echo "[6] Verify protected hashes remain unchanged"
[[ "$(sha "$BASE/app/v8011_ingress.py")" == "$EXPECTED_INGRESS" ]] || die "V8011 changed"
[[ "$(sha "$BASE/app/v8004_quality_router.py")" == "$EXPECTED_V8004" ]] || die "V8004 changed"
[[ "$(sha "$BASE/app/v8006_calendar_execution_correction.py")" == "$EXPECTED_V8006" ]] || die "V8006 changed"
[[ "$(sha "$BASE/app/v8007_v8001_gate_bridge.py")" == "$EXPECTED_V8007" ]] || die "V8007 changed"
[[ "$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")" == "$EXPECTED_PINE" ]] || die "Pine changed"
[[ "$(sha "$BASE/app/main.py")" == "$EXPECTED_MAIN_NEW" ]] || die "Installed main mismatch"
[[ "$(sha "$BASE/app/v8003_master_navigation.py")" == "$EXPECTED_NAV_NEW" ]] || die "Installed navigation mismatch"
[[ "$(sha "$BASE/app/routes/v8012d_dashboard_extraction.py")" == "$EXPECTED_V8012D" ]] || die "Installed V8012D mismatch"
[[ "$(sha "$BASE/docker-compose.yml")" == "$EXPECTED_COMPOSE_NEW" ]] || die "Installed compose mismatch"

python3 -m py_compile \
  "$BASE/app/main.py" \
  "$BASE/app/v8003_master_navigation.py" \
  "$BASE/app/routes/v8012d_dashboard_extraction.py"
bash -n "$BASE/ops/v8012_consolidation_check.sh"
cd "$BASE"
docker compose config >/dev/null

echo
echo "[7] Build shared V8012D image"
docker compose build tradingbot

echo
echo "[8] Start backend + ingress and measure health-ready time"
START_MS="$(now_ms)"
docker compose up -d --force-recreate --remove-orphans
wait_http_200 http://127.0.0.1/health 75 2
END_MS="$(now_ms)"
READY_MS=$((END_MS - START_MS))
python3 - "$BASE/data/v8012d_startup_metrics.json" "$READY_MS" <<'PY'
from pathlib import Path
from datetime import datetime, timezone
import json,sys
p=Path(sys.argv[1]); ready_ms=int(sys.argv[2])
data={
  'version':'V8012D-MAIN-MODULAR-EXTRACTION-V1',
  'measured_at':datetime.now(timezone.utc).isoformat(),
  'public_health_ready_ms':ready_ms,
  'public_health_ready_seconds':round(ready_ms/1000.0,3),
  'measurement':'docker_compose_force_recreate_to_public_health_200',
  'trading_db_writes':False,
}
p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2))
PY
chmod 0644 "$BASE/data/v8012d_startup_metrics.json"

echo
echo "[9] Validate V8012A/B.1/C.1/D and ingress"
for pair in \
  "a|http://127.0.0.1/v8012/selftest.json" \
  "b|http://127.0.0.1/v8012/selftest-b.json" \
  "c|http://127.0.0.1/v8012/selftest-c.json" \
  "d|http://127.0.0.1/v8012/selftest-d.json" \
  "i|http://127.0.0.1/v8011/selftest.json"
 do
  key="${pair%%|*}"; url="${pair#*|}"
  curl -fsS --max-time 45 "$url" -o "$TMP_DIR/$key.json"
 done
python3 - "$TMP_DIR/a.json" "$TMP_DIR/b.json" "$TMP_DIR/c.json" "$TMP_DIR/d.json" "$TMP_DIR/i.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:a=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f:b=json.load(f)
with open(sys.argv[3],encoding='utf-8') as f:c=json.load(f)
with open(sys.argv[4],encoding='utf-8') as f:d=json.load(f)
with open(sys.argv[5],encoding='utf-8') as f:i=json.load(f)
s=d.get('summary') or {}; inv=d.get('inventory') or {}; rt=d.get('runtime') or {}
print(json.dumps({
 'v8012a_ok':a.get('ok'),
 'duplicates_after':a.get('nonprotected_exact_duplicate_groups_after'),
 'v8012b_ok':b.get('ok'),
 'v8012c_ok':c.get('ok'),
 'v8012d_ok':d.get('ok'),
 'version':d.get('version'),
 'extracted_route_wrappers':s.get('extracted_route_wrappers'),
 'extracted_groups':s.get('extracted_groups'),
 'main_lines_removed':s.get('main_lines_removed'),
 'main_bytes_removed':s.get('main_bytes_removed'),
 'registered_paths':inv.get('registered_paths'),
 'missing_paths':inv.get('missing_paths'),
 'duplicate_signatures':inv.get('duplicate_signatures'),
 'wrong_endpoint_module':inv.get('wrong_endpoint_module'),
 'registration_ms':rt.get('registration_ms'),
 'ingress_ok':i.get('ok'),
 'token_mode':i.get('token_mode'),
},indent=2))
assert a.get('ok') is True
assert int(a.get('nonprotected_exact_duplicate_groups_after') or 0)==0
assert b.get('ok') is True
assert c.get('ok') is True
assert d.get('ok') is True
assert d.get('version')=='V8012D-MAIN-MODULAR-EXTRACTION-V1'
assert int(s.get('extracted_route_wrappers') or 0)==16
assert int(s.get('extracted_groups') or 0)==4
assert int(s.get('main_lines_removed') or 0)==108
assert int(s.get('main_bytes_removed') or 0)==3964
assert int(inv.get('registered_paths') or 0)==16
assert not (inv.get('missing_paths') or [])
assert not (inv.get('duplicate_signatures') or [])
assert not (inv.get('wrong_endpoint_module') or [])
assert int(rt.get('groups_installed') or 0)==4
assert not (rt.get('group_errors') or {})
assert i.get('ok') is True
assert i.get('backend_ok') is True
assert i.get('worker_alive') is True
assert i.get('token_mode')=='off'
assert i.get('token_configured') is False
assert i.get('token_enforced') is False
PY

echo
echo "[10] Lightweight behavior probes for the four extracted groups"
for route in \
  '/v7246e-entry-upgrade-sim.json?limit=1' \
  '/v7246f-clean-upgrade-candidates.json?limit=1' \
  '/v7246g-entry-guard.json?limit=1' \
  '/v8000/master.json?limit=1'
 do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 60 "http://127.0.0.1${route}" 2>/dev/null || true)"
  printf '%-58s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Behavior probe failed: $route status=$code"
 done

echo
echo "[11] Critical lightweight routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/selftest.json \
  /v8012/selftest-b.json \
  /v8012/selftest-c.json \
  /v8012/selftest-d.json \
  /v8012/hub \
  /v8012/modular-extraction \
  /v8012/modular-extraction.json \
  /v8012/startup-metrics.json
 do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 30 "http://127.0.0.1${route}" 2>/dev/null || true)"
  printf '%-52s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Critical route failed: $route status=$code"
 done

echo
echo "[12] Navigation"
curl -fsS --max-time 30 http://127.0.0.1/master | grep -q "V8012 Modular Extraction" || die "Master V8012D link missing"
echo "Master link: PASS"
curl -fsS --max-time 30 http://127.0.0.1/master-ai-review | grep -q "V8012 Modular Extraction" || die "AI Review V8012D link missing"
echo "AI Review link: PASS"

echo
echo "[13] Final protected hashes"
sha256sum \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"

echo
echo "[14] Containers"
docker compose ps

ROLLBACK_ARMED=0
rm -rf "$TMP_DIR"
trap - ERR

cat <<EOF
================================================================================
V8012D INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Modular extraction: http://91.107.237.214/v8012/modular-extraction
Extraction JSON:    http://91.107.237.214/v8012/modular-extraction.json
Startup metrics:    http://91.107.237.214/v8012/startup-metrics.json
Selftest:           http://91.107.237.214/v8012/selftest-d.json
COMPLETED:
  16 read-only dashboard route wrappers extracted from app/main.py
  4 route groups installed through one APIRouter module
  Existing URLs, methods, query defaults and response wrappers preserved
  main.py reduced by 108 lines and 3964 bytes
  Registration and public health-ready timing measured
  Master + AI Review link added
UNCHANGED:
  V8004 / V8006 / V8007
  Canonical Pine
  V8011 ingress/queue/dead-letter
  Existing trading DB schema
  Live scoring/routing
  Token OFF
  Broker auto execution FALSE
EOF
