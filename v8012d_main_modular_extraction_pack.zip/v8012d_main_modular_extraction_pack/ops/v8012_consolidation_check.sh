#!/usr/bin/env bash
set -u

BASE="/opt/tradingbot_v6000"
TMP_DIR="$(mktemp -d /tmp/v8012d_check.XXXXXX)"
trap 'rm -rf "$TMP_DIR"' EXIT
FAIL=0

fetch_json() {
  local url="$1" out="$2" timeout="${3:-30}"
  curl -fsS --max-time "$timeout" "$url" -o "$out"
}

status_code() {
  curl -sS -o /dev/null -w '%{http_code}' --max-time "${2:-20}" "$1" 2>/dev/null || true
}

echo "=== V8012D MAIN.PY MODULAR EXTRACTION CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"
cd "$BASE" || exit 1

echo "[1] Containers"
docker compose ps

echo "[2] V8012A / B.1 / C.1 / D selftests"
fetch_json http://127.0.0.1/v8012/selftest.json "$TMP_DIR/a.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-b.json "$TMP_DIR/b.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-c.json "$TMP_DIR/c.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-d.json "$TMP_DIR/d.json" || FAIL=1
if [[ -s "$TMP_DIR/a.json" && -s "$TMP_DIR/b.json" && -s "$TMP_DIR/c.json" && -s "$TMP_DIR/d.json" ]]; then
  python3 - "$TMP_DIR/a.json" "$TMP_DIR/b.json" "$TMP_DIR/c.json" "$TMP_DIR/d.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:a=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f:b=json.load(f)
with open(sys.argv[3],encoding='utf-8') as f:c=json.load(f)
with open(sys.argv[4],encoding='utf-8') as f:d=json.load(f)
s=d.get('summary') or {}; inv=d.get('inventory') or {}; rt=d.get('runtime') or {}
print(json.dumps({
  'v8012a_ok':a.get('ok'),
  'duplicates_after':a.get('nonprotected_exact_duplicate_groups_after'),
  'v8012b_ok':b.get('ok'),
  'v8012c_ok':c.get('ok'),
  'v8012d_ok':d.get('ok'),
  'version':d.get('version'),
  'confirmation_header_required':c.get('confirmation_header_required_for_added_alternatives'),
  'extracted_route_wrappers':s.get('extracted_route_wrappers'),
  'extracted_groups':s.get('extracted_groups'),
  'main_lines_before':s.get('main_lines_before'),
  'main_lines_after':s.get('main_lines_after'),
  'main_lines_removed':s.get('main_lines_removed'),
  'main_bytes_removed':s.get('main_bytes_removed'),
  'registered_paths':inv.get('registered_paths'),
  'missing_paths':inv.get('missing_paths'),
  'duplicate_signatures':inv.get('duplicate_signatures'),
  'wrong_endpoint_module':inv.get('wrong_endpoint_module'),
  'registration_ms':rt.get('registration_ms'),
  'group_errors':rt.get('group_errors'),
},indent=2))
assert a.get('ok') is True
assert int(a.get('nonprotected_exact_duplicate_groups_after') or 0)==0
assert b.get('ok') is True
assert c.get('ok') is True
assert c.get('confirmation_header_required_for_added_alternatives') is True
assert d.get('ok') is True
assert d.get('version')=='V8012D-MAIN-MODULAR-EXTRACTION-V1'
assert int(s.get('extracted_route_wrappers') or 0)==16
assert int(s.get('extracted_groups') or 0)==4
assert int(s.get('main_lines_before') or 0)==16113
assert int(s.get('main_lines_after') or 0)==16005
assert int(s.get('main_lines_removed') or 0)==108
assert int(s.get('main_bytes_removed') or 0)==3964
assert int(inv.get('registered_paths') or 0)==16
assert not (inv.get('missing_paths') or [])
assert not (inv.get('duplicate_signatures') or [])
assert not (inv.get('wrong_endpoint_module') or [])
assert int(rt.get('groups_installed') or 0)==4
assert not (rt.get('group_errors') or {})
PY
else
  FAIL=1
fi

echo "[3] Startup and registration metrics"
fetch_json http://127.0.0.1/v8012/startup-metrics.json "$TMP_DIR/startup.json" || FAIL=1
if [[ -s "$TMP_DIR/startup.json" ]]; then
  python3 - "$TMP_DIR/startup.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps(d,indent=2))
assert d.get('ok') is True
r=d.get('runtime') or {}
s=d.get('startup') or {}
assert float(r.get('registration_ms') or 0) >= 0
assert s.get('version')=='V8012D-MAIN-MODULAR-EXTRACTION-V1'
assert float(s.get('public_health_ready_seconds') or 0) > 0
assert s.get('trading_db_writes') is False
PY
fi

echo "[4] Extracted group behavior probes"
for route in \
  '/v7246e-entry-upgrade-sim.json?limit=1' \
  '/v7246f-clean-upgrade-candidates.json?limit=1' \
  '/v7246g-entry-guard.json?limit=1' \
  '/v8000/master.json?limit=1'
 do
  code="$(status_code "http://127.0.0.1${route}" 60)"
  printf '%-58s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || FAIL=1
 done

echo "[5] POST confirmation guard – no side effect executed"
BODY_FILE="$TMP_DIR/post_guard.json"
CODE="$(curl -sS -o "$BODY_FILE" -w '%{http_code}' --max-time 15 -X POST http://127.0.0.1/pause/on 2>/dev/null || true)"
printf 'POST /pause/on without confirmation: %s\n' "$CODE"
cat "$BODY_FILE" 2>/dev/null || true
echo
[[ "$CODE" == "428" ]] || FAIL=1

echo "[6] Ingress health and token OFF"
fetch_json http://127.0.0.1/v8011/selftest.json "$TMP_DIR/ingress.json" || FAIL=1
if [[ -s "$TMP_DIR/ingress.json" ]]; then
  python3 - "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps({
  'ok':d.get('ok'),
  'operational_status':d.get('operational_status'),
  'queue_depth':d.get('queue_depth'),
  'backend_ok':d.get('backend_ok'),
  'worker_alive':d.get('worker_alive'),
  'token_mode':d.get('token_mode'),
  'token_configured':d.get('token_configured'),
  'token_enforced':d.get('token_enforced'),
},indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY
fi

echo "[7] Critical lightweight routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/selftest.json \
  /v8012/selftest-b.json \
  /v8012/selftest-c.json \
  /v8012/selftest-d.json \
  /v8012/hub \
  /v8012/modular-extraction \
  /v8012/modular-extraction.json \
  /v8012/startup-metrics.json
 do
  code="$(status_code "http://127.0.0.1${route}" 30)"
  printf '%-52s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || FAIL=1
 done

echo "[8] Navigation"
if curl -fsS --max-time 30 http://127.0.0.1/master | grep -q "V8012 Modular Extraction"; then
  echo "Master link: PASS"
else
  echo "Master link: FAIL"; FAIL=1
fi
if curl -fsS --max-time 30 http://127.0.0.1/master-ai-review | grep -q "V8012 Modular Extraction"; then
  echo "AI Review link: PASS"
else
  echo "AI Review link: FAIL"; FAIL=1
fi

echo "[9] Source size"
wc -l -c app/main.py

echo "[10] Protected hashes"
sha256sum \
  app/v8011_ingress.py \
  app/v8004_quality_router.py \
  app/v8006_calendar_execution_correction.py \
  app/v8007_v8001_gate_bridge.py \
  pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine

echo "[11] Actual errors last 30m"
docker logs --since 30m tradingbot 2>&1 \
  | grep -Ei 'Traceback|ERROR|Exception|FATAL|V8012D.*error' \
  | tail -n 100 || true

echo "[12] Host resources"
uptime
free -h
df -h "$BASE"

if [[ "$FAIL" != "0" ]]; then
  echo "=== V8012D CHECK FEHLER ==="
  exit 1
fi

echo "=== V8012D CHECK FERTIG ==="
