# V8012E – Second Modular Extraction + Build/Backup Audit

Version: `V8012E-SECOND-MODULAR-EXTRACTION-BUILD-AUDIT-V1`

## Zweck

V8012E lagert 16 weitere ausschließlich lesende Dashboard-Routen aus `app/main.py` in den FastAPI-`APIRouter` `app/routes/v8012e_dashboard_extraction.py` aus. Zusammen mit V8012D sind damit 32 bestehende Routen modular registriert.

Extrahierte Gruppen:

- V7243.9 Stability Pack: 2 Routen
- V7244A Live Decision Quality: 2 Routen
- V7244C Explain Compare: 2 Routen
- V7244D Next Live Requirement: 2 Routen
- V7244E Threshold Simulator: 2 Routen
- V7244F Recommended Preset: 2 Routen
- V7245B TP Optimizer: 2 Routen
- V7245C Recommendation Board: 2 Routen

## Source-Reduktion

- `main.py` vorher: 16.005 Zeilen / 557.390 Bytes
- `main.py` danach: 15.851 Zeilen / 552.014 Bytes
- in V8012E entfernt: 154 Zeilen / 5.376 Bytes
- kumulativ V8012D + V8012E: 32 ausgelagerte Routen

## Kompatibilität

Unverändert bleiben:

- alle 16 bestehenden URLs
- HTTP-Methode GET
- Query-Parameter, Typen und Defaults
- HTML- und JSON-Response-Klassen
- bestehende Payload- und HTML-Funktionen
- Route-Verhalten und Legacy-Pfade

`ROUTE_COMPATIBILITY.json` bestätigt 16 von 16 identische Routensignaturen.

## Read-only Build-/Backup-Audit

Der Installer erzeugt `data/v8012e_build_backup_audit.json`. Der Report enthält ausschließlich Bestands- und Größeninformationen:

- Dateisystembelegung
- geschätzte Docker-Build-Kontextgröße
- Vorhandensein einer `.dockerignore`
- Anzahl und Größe der Rollback-Backups
- Review-Kandidaten älter als 14 Tage
- Anzahl der TradingBot-Docker-Images
- ungenutzte und dangling Images

Der Audit liest keine `.env`-Inhalte und sammelt keine Geheimnisse. Er löscht keine Dateien, Images oder Backups. Eine spätere Bereinigung darf nur über ein separates, explizites Allowlist-Paket erfolgen.

## Neue Diagnose-Routen

- `/v8012/modular-extraction-2`
- `/v8012/modular-extraction-2.json`
- `/v8012/build-backup-audit`
- `/v8012/build-backup-audit.json`
- `/v8012/selftest-e.json`

## Sicherheit

- V8004/V8006/V8007 unverändert
- Canonical Pine V8001.4D unverändert
- V8011 Ingress, Queue und Dead Letter unverändert
- bestehende Trading-Datenbank unverändert
- Live-Scoring und Signalrouting unverändert
- Webhook-Token bleibt OFF
- Broker Auto Execution bleibt FALSE
- automatische Bereinigung bleibt AUS
