from __future__ import annotations

import html
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8012E-SECOND-MODULAR-EXTRACTION-BUILD-AUDIT-V1"
MODE = "behavior_preserving_read_only_extraction_and_host_audit"
BASELINE_MAIN_LINES = 16005
CURRENT_MAIN_LINES = 15851
BASELINE_MAIN_BYTES = 557390
CURRENT_MAIN_BYTES = 552014
AUDIT_FILE = "v8012e_build_backup_audit.json"

EXTRACTED_GROUPS = {
    "v72439_stability": ["/stability-v7243.json", "/stability-v7243"],
    "v7244a_live_quality": ["/v7244-live-quality.json", "/v7244-live-quality"],
    "v7244c_explain_compare": ["/v7244-explain.json", "/v7244-explain"],
    "v7244d_next_live": ["/v7244d-next-live.json", "/v7244d-next-live"],
    "v7244e_threshold_sim": ["/v7244e-threshold-sim.json", "/v7244e-threshold-sim"],
    "v7244f_recommended_preset": ["/v7244f-recommended-preset.json", "/v7244f-recommended-preset"],
    "v7245b_tp_optimizer": ["/v7245b-tp-optimizer.json", "/v7245b-tp-optimizer"],
    "v7245c_recommendations": ["/v7245c-recommendations.json", "/v7245c-recommendations"],
}
EXTRACTED_PATHS = [path for paths in EXTRACTED_GROUPS.values() for path in paths]
AUDIT_PATHS = [
    "/v8012/modular-extraction-2",
    "/v8012/modular-extraction-2.json",
    "/v8012/build-backup-audit",
    "/v8012/build-backup-audit.json",
    "/v8012/selftest-e.json",
]
SAFETY = {
    "read_only_routes_extracted": True,
    "route_behavior_preserved": True,
    "payload_modules_changed": False,
    "trading_logic_changed": False,
    "v8004_changed": False,
    "v8006_changed": False,
    "v8007_changed": False,
    "v8011_changed": False,
    "pine_changed": False,
    "trading_db_writes": False,
    "trading_db_schema_changes": False,
    "automatic_cleanup": False,
    "files_deleted": 0,
    "images_deleted": 0,
    "backups_deleted": 0,
    "webhook_token_mode": "off",
    "broker_auto_execution": False,
}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _root() -> Path:
    for candidate in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        if (candidate / "app").exists() and (candidate / "data").exists():
            return candidate
    return Path.cwd()


def _read_audit() -> dict[str, Any]:
    path = _root() / "data" / AUDIT_FILE
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}", "path": str(path)}
    return {"ok": False, "error": "invalid_audit_payload", "path": str(path)}


def _route_inventory(app: Any) -> dict[str, Any]:
    signatures: dict[tuple[str, str], int] = {}
    methods_by_path: dict[str, set[str]] = {}
    modules_by_path: dict[str, set[str]] = {}
    for route in getattr(app, "routes", []):
        path = str(getattr(route, "path", "") or "")
        methods = set(getattr(route, "methods", set()) or set())
        endpoint = getattr(route, "endpoint", None)
        module = str(getattr(endpoint, "__module__", "") or "")
        for method in methods:
            signatures[(path, method)] = signatures.get((path, method), 0) + 1
            methods_by_path.setdefault(path, set()).add(method)
        if module:
            modules_by_path.setdefault(path, set()).add(module)
    missing = [path for path in EXTRACTED_PATHS if "GET" not in methods_by_path.get(path, set())]
    duplicates = [
        {"path": path, "method": method, "count": count}
        for (path, method), count in sorted(signatures.items())
        if path in EXTRACTED_PATHS and count > 1
    ]
    wrong_module = [
        {"path": path, "modules": sorted(modules_by_path.get(path, set()))}
        for path in EXTRACTED_PATHS
        if "app.routes.v8012e_dashboard_extraction" not in modules_by_path.get(path, set())
    ]
    return {
        "expected_paths": len(EXTRACTED_PATHS),
        "registered_paths": len(EXTRACTED_PATHS) - len(missing),
        "missing_paths": missing,
        "duplicate_signatures": duplicates,
        "wrong_endpoint_module": wrong_module,
        "groups": {
            name: {
                "expected": len(paths),
                "present": sum(1 for path in paths if "GET" in methods_by_path.get(path, set())),
            }
            for name, paths in EXTRACTED_GROUPS.items()
        },
    }


def _payload(app: Any) -> dict[str, Any]:
    inventory = _route_inventory(app)
    runtime = dict(getattr(app.state, "v8012e_install_metrics", {}) or {})
    audit = _read_audit()
    audit_ok = audit.get("ok") is True
    ok = (
        not runtime.get("group_errors")
        and not inventory["missing_paths"]
        and not inventory["duplicate_signatures"]
        and not inventory["wrong_endpoint_module"]
        and audit_ok
    )
    return {
        "ok": bool(ok),
        "version": VERSION,
        "mode": MODE,
        "generated_utc": _utcnow(),
        "summary": {
            "extracted_route_wrappers": len(EXTRACTED_PATHS),
            "extracted_groups": len(EXTRACTED_GROUPS),
            "main_lines_before": BASELINE_MAIN_LINES,
            "main_lines_after": CURRENT_MAIN_LINES,
            "main_lines_removed": BASELINE_MAIN_LINES - CURRENT_MAIN_LINES,
            "main_bytes_before": BASELINE_MAIN_BYTES,
            "main_bytes_after": CURRENT_MAIN_BYTES,
            "main_bytes_removed": BASELINE_MAIN_BYTES - CURRENT_MAIN_BYTES,
            "cumulative_v8012d_e_routes_extracted": 32,
            "payload_modules_changed": 0,
            "legacy_paths_changed": 0,
        },
        "inventory": inventory,
        "runtime": runtime,
        "audit": audit,
        "safety": dict(SAFETY),
    }


def _page(app: Any) -> str:
    data = _payload(app)
    summary = data["summary"]
    inventory = data["inventory"]
    audit = data.get("audit") or {}
    storage = audit.get("storage") or {}
    docker = audit.get("docker") or {}
    backups = audit.get("backups") or {}
    status = "GREEN" if data["ok"] else "YELLOW"
    status_class = "good" if data["ok"] else "warn"
    rows = "".join(
        f"<tr><td>{html.escape(name)}</td><td>{item['present']} / {item['expected']}</td></tr>"
        for name, item in inventory["groups"].items()
    )
    css = """
body{background:#07111e;color:#eef6ff;font-family:Arial,sans-serif;margin:0}
.wrap{max-width:1150px;margin:auto;padding:18px}
.card{background:#101d2e;border:1px solid #273a52;border-radius:16px;padding:16px;margin:12px 0}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.metric{background:#0b1728;border:1px solid #273a52;border-radius:12px;padding:12px}
.label{color:#9caec4;font-size:12px}.value{font-size:24px;font-weight:900;margin-top:4px}
.good{color:#86efac}.warn{color:#facc15}
table{width:100%;border-collapse:collapse}td,th{padding:9px;border-bottom:1px solid #273a52;text-align:left}
code{color:#a5d8ff}@media(max-width:760px){.grid{grid-template-columns:repeat(2,1fr)}}
"""
    return f"""<!doctype html><html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>V8012E Modular Extraction II</title><style>{css}</style></head><body><div class='wrap'><div class='card'><h1>V8012E Modular Extraction II + Build/Backup Audit</h1><p>Status: <b class='{status_class}'>{status}</b> · Keine automatische Löschung.</p></div>
<div class='grid'><div class='metric'><div class='label'>Routen Wave 2</div><div class='value'>{summary['extracted_route_wrappers']}</div></div><div class='metric'><div class='label'>Kumulativ D+E</div><div class='value'>{summary['cumulative_v8012d_e_routes_extracted']}</div></div><div class='metric'><div class='label'>main.py Zeilen entfernt</div><div class='value'>{summary['main_lines_removed']}</div></div><div class='metric'><div class='label'>Disk belegt</div><div class='value'>{storage.get('disk_used_percent','-')}%</div></div></div>
<div class='card'><h2>Extraktionsgruppen</h2><table><tr><th>Gruppe</th><th>Registriert</th></tr>{rows}</table></div>
<div class='grid'><div class='metric'><div class='label'>Backups</div><div class='value'>{backups.get('count','-')}</div></div><div class='metric'><div class='label'>Backup-Größe MiB</div><div class='value'>{backups.get('total_mib','-')}</div></div><div class='metric'><div class='label'>TradingBot Images</div><div class='value'>{docker.get('tradingbot_image_count','-')}</div></div><div class='metric'><div class='label'>Ungenutzte Images</div><div class='value'>{docker.get('unused_tradingbot_image_count','-')}</div></div></div>
<div class='card'><h2>Sicherheit</h2><p>Audit-only: keine Images, Backups oder Dateien wurden gelöscht. V8004/V8006/V8007, Pine, Ingress und Trading-Datenbank bleiben unverändert.</p><code>/v8012/build-backup-audit.json</code></div></div></body></html>"""


def install_v8012e_dashboard_extraction(app: Any) -> None:
    if getattr(app.state, "v8012e_dashboard_extraction_installed", False):
        return
    started = time.perf_counter()
    router = APIRouter()
    group_errors: dict[str, str] = {}
    installed_groups: list[str] = []

    try:
        from app.v7243_9_stability_pack import v72439_stability_payload, v72439_stability_html
        @router.get("/stability-v7243.json")
        def v72439_stability_json(token: str = ""):
            return JSONResponse(v72439_stability_payload())
        @router.get("/stability-v7243", response_class=HTMLResponse)
        def v72439_stability_page(token: str = ""):
            return HTMLResponse(v72439_stability_html())
        installed_groups.append("v72439_stability")
    except Exception as exc:
        group_errors["v72439_stability"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7244_live_decision_quality import v7244_live_quality_payload, v7244_live_quality_html
        @router.get("/v7244-live-quality.json")
        def v7244_live_quality_json(token: str = "", limit: int = 80):
            return JSONResponse(v7244_live_quality_payload(limit=limit))
        @router.get("/v7244-live-quality", response_class=HTMLResponse)
        def v7244_live_quality_page(token: str = ""):
            return HTMLResponse(v7244_live_quality_html())
        installed_groups.append("v7244a_live_quality")
    except Exception as exc:
        group_errors["v7244a_live_quality"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7244c_explain_compare import v7244c_explain_payload, v7244c_explain_html
        @router.get("/v7244-explain.json")
        def v7244c_explain_json(token: str = "", limit: int = 80):
            return JSONResponse(v7244c_explain_payload(limit=limit))
        @router.get("/v7244-explain", response_class=HTMLResponse)
        def v7244c_explain_page(token: str = ""):
            return HTMLResponse(v7244c_explain_html())
        installed_groups.append("v7244c_explain_compare")
    except Exception as exc:
        group_errors["v7244c_explain_compare"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7244d_next_live_requirement import v7244d_next_live_payload, v7244d_next_live_html
        @router.get("/v7244d-next-live.json")
        def v7244d_next_live_json(token: str = "", limit: int = 80):
            return JSONResponse(v7244d_next_live_payload(limit=limit))
        @router.get("/v7244d-next-live", response_class=HTMLResponse)
        def v7244d_next_live_page(token: str = ""):
            return HTMLResponse(v7244d_next_live_html())
        installed_groups.append("v7244d_next_live")
    except Exception as exc:
        group_errors["v7244d_next_live"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7244e_threshold_simulator import v7244e_threshold_payload, v7244e_threshold_html
        @router.get("/v7244e-threshold-sim.json")
        def v7244e_threshold_json(token: str = "", limit: int = 80):
            return JSONResponse(v7244e_threshold_payload(limit=limit))
        @router.get("/v7244e-threshold-sim", response_class=HTMLResponse)
        def v7244e_threshold_page(token: str = ""):
            return HTMLResponse(v7244e_threshold_html())
        installed_groups.append("v7244e_threshold_sim")
    except Exception as exc:
        group_errors["v7244e_threshold_sim"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7244f_recommended_preset import v7244f_recommended_preset_payload, v7244f_recommended_preset_html
        @router.get("/v7244f-recommended-preset.json")
        def v7244f_recommended_preset_json(token: str = "", limit: int = 80):
            return JSONResponse(v7244f_recommended_preset_payload(limit=limit))
        @router.get("/v7244f-recommended-preset", response_class=HTMLResponse)
        def v7244f_recommended_preset_page(token: str = ""):
            return HTMLResponse(v7244f_recommended_preset_html())
        installed_groups.append("v7244f_recommended_preset")
    except Exception as exc:
        group_errors["v7244f_recommended_preset"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7245b_tp_optimizer import v7245b_payload, v7245b_html
        @router.get("/v7245b-tp-optimizer.json")
        def v7245b_tp_optimizer_json(token: str = "", limit: int = 80):
            return JSONResponse(v7245b_payload(limit=limit))
        @router.get("/v7245b-tp-optimizer", response_class=HTMLResponse)
        def v7245b_tp_optimizer_page(token: str = ""):
            return HTMLResponse(v7245b_html())
        installed_groups.append("v7245b_tp_optimizer")
    except Exception as exc:
        group_errors["v7245b_tp_optimizer"] = f"{type(exc).__name__}: {exc}"

    try:
        from app.v7245c_recommendation_board import v7245c_payload, v7245c_html
        @router.get("/v7245c-recommendations.json")
        def v7245c_recommendations_json(token: str = "", limit: int = 80):
            return JSONResponse(v7245c_payload(limit=limit))
        @router.get("/v7245c-recommendations", response_class=HTMLResponse)
        def v7245c_recommendations_page(token: str = ""):
            return HTMLResponse(v7245c_html())
        installed_groups.append("v7245c_recommendations")
    except Exception as exc:
        group_errors["v7245c_recommendations"] = f"{type(exc).__name__}: {exc}"

    @router.get("/v8012/modular-extraction-2.json")
    def v8012e_modular_extraction_json():
        return JSONResponse(_payload(app))
    @router.get("/v8012/modular-extraction-2", response_class=HTMLResponse)
    def v8012e_modular_extraction_page():
        return HTMLResponse(_page(app))
    @router.get("/v8012/build-backup-audit.json")
    def v8012e_build_backup_audit_json():
        return JSONResponse(_read_audit())
    @router.get("/v8012/build-backup-audit", response_class=HTMLResponse)
    def v8012e_build_backup_audit_page():
        return HTMLResponse(_page(app))
    @router.get("/v8012/selftest-e.json")
    def v8012e_selftest():
        return JSONResponse(_payload(app))

    app.include_router(router)
    app.state.v8012e_dashboard_extraction_installed = True
    app.state.v8012e_install_metrics = {
        "installed_at": _utcnow(),
        "registration_ms": round((time.perf_counter() - started) * 1000.0, 3),
        "groups_expected": len(EXTRACTED_GROUPS),
        "groups_installed": len(installed_groups),
        "installed_groups": installed_groups,
        "group_errors": group_errors,
        "router_module": __name__,
    }
    print(
        "[V8012E] Second modular extraction installed: "
        f"groups={len(installed_groups)} routes={len(EXTRACTED_PATHS)} "
        f"registration_ms={app.state.v8012e_install_metrics['registration_ms']} errors={len(group_errors)}"
    )
