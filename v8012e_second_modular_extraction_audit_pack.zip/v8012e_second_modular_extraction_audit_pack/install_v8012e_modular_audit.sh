#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="V8012E-SECOND-MODULAR-EXTRACTION-BUILD-AUDIT-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8012e_before_${TS}"
LOG="/root/v8012e_install_${TS}.log"
TMP_DIR="$(mktemp -d /tmp/v8012e_install.XXXXXX)"

EXPECTED_MAIN_OLD="5bdfd97b7adf79e0f697d88afb72444bee5d10d475d652eeaf45fee5f6c201de"
EXPECTED_MAIN_NEW="2307535e6288b7850ff8f54dbbb537fa2c66ae49011db24e9a29a2b478110d11"
EXPECTED_NAV_OLD="c912f9b147d08343af3fef79982bcec97fe133ff359fc302039615263ecd372c"
EXPECTED_NAV_NEW="2125fafc9bae15329ad36528380c815820a38c9a4373fc30e5d556f5fa0ecd42"
EXPECTED_COMPOSE_OLD="35c609cebc0195f78ca70445e38c4bcd7b2072ea993811f72d59c450dd4d955c"
EXPECTED_COMPOSE_NEW="7c2ed71de999a728f433ddf06eb8a5b41fcc74c0201185ee082518cf56da15a4"
EXPECTED_V8012E="c8a37f938e0d0f44a7df7b64f75edfe27c59be55b2046d8c9264641baafd0db4"
EXPECTED_AUDIT_GENERATOR="2b7e128d68f8e25beea33249926cb979f1877bd7d256d2242f905785681c3580"
EXPECTED_V8012D="d2b5d8c0d0ee5d8dadf26bf025f1c994fd217b52ca801b02346ff0849d0c9d28"
EXPECTED_V8012A="30e36a321e9c41810d766aaa7c857637e2c15d2f11fbc504c9b5969c27390af9"
EXPECTED_V8012B="2c4ae0955b8888650834f9f332ef5267d9f75bdb9d8bb1fbd5662b525c3c006b"
EXPECTED_V8012C="e7b881d09a097adb75835e46d7c367a28f28092196d31dbaf25c84ef5135381e"
EXPECTED_INGRESS="0b50a8dcce8e0f2ef71dead1d5489bdd1c915b932acefa166eec656828806c8b"
EXPECTED_V8004="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

ROLLBACK_ARMED=0
exec > >(tee -a "$LOG") 2>&1

sha() { sha256sum "$1" | awk '{print $1}'; }
die() { echo "FATAL: $*" >&2; exit 1; }

wait_http_200() {
  local url="$1" attempts="${2:-75}" sleep_s="${3:-2}" i code
  for i in $(seq 1 "$attempts"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    echo "WAIT [$i/$attempts] $url status=${code:-none}"
    sleep "$sleep_s"
  done
  return 1
}

restore_optional() {
  local backup_file="$1" target_file="$2"
  if [[ -f "$backup_file" ]]; then
    mkdir -p "$(dirname "$target_file")"
    cp -a "$backup_file" "$target_file" || true
  else
    rm -f "$target_file" || true
  fi
}

rollback() {
  local rc=$?
  trap - ERR
  rm -rf "$TMP_DIR" || true
  if [[ "$ROLLBACK_ARMED" != "1" ]]; then exit "$rc"; fi
  echo
  echo "=== V8012E ROLLBACK START ==="
  cp -a "$BACKUP/main.py" "$BASE/app/main.py" || true
  cp -a "$BACKUP/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py" || true
  cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml" || true
  cp -a "$BACKUP/.env" "$BASE/.env" || true
  chmod 600 "$BASE/.env" || true
  restore_optional "$BACKUP/v8012e_dashboard_extraction.py" "$BASE/app/routes/v8012e_dashboard_extraction.py"
  restore_optional "$BACKUP/v8012e_generate_build_backup_audit.py" "$BASE/ops/v8012e_generate_build_backup_audit.py"
  restore_optional "$BACKUP/v8012_consolidation_check.sh" "$BASE/ops/v8012_consolidation_check.sh"
  restore_optional "$BACKUP/README_V8012E.md" "$BASE/README_V8012E.md"
  restore_optional "$BACKUP/ROUTE_COMPATIBILITY_V8012E.json" "$BASE/ROUTE_COMPATIBILITY_V8012E.json"
  restore_optional "$BACKUP/v8012e_build_backup_audit.json" "$BASE/data/v8012e_build_backup_audit.json"
  cd "$BASE"
  docker compose config >/dev/null 2>&1 || true
  docker compose up -d --build --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8012E ROLLBACK ENDE ==="
  exit "$rc"
}
trap rollback ERR

cat <<EOF
================================================================================
$VERSION INSTALL
================================================================================
Generated UTC: $(date -u --iso-8601=seconds)
Project: $BASE
Package: $PACKAGE_DIR

Scope:
  Second behavior-preserving extraction from app/main.py: YES
  Read-only dashboard route wrappers extracted: 16
  Extracted groups: V7243.9, V7244A, V7244C, V7244D, V7244E, V7244F, V7245B, V7245C
  APIRouter module: app/routes/v8012e_dashboard_extraction.py
  Existing URLs/methods/query defaults/responses: UNCHANGED
  Cumulative V8012D + V8012E extracted routes: 32
  main.py reduction in this wave: 154 lines / 5376 bytes
  Build/backup/image inventory: READ-ONLY AUDIT
  Automatic cleanup: FALSE

Safety:
  V8004/V8006/V8007 changes: 0
  Canonical Pine changes: 0
  V8011 ingress/queue/dead-letter changes: 0
  Existing trading DB schema/writes: 0
  Live scoring/routing changes: 0
  Files/images/backups deleted: 0
  Token mode: OFF
  Broker auto execution: FALSE
EOF

[[ -d "$BASE" ]] || die "Project not found: $BASE"

for f in \
  "$BASE/app/main.py" \
  "$BASE/app/v8003_master_navigation.py" \
  "$BASE/app/v8012a_route_consolidation.py" \
  "$BASE/app/routes/v8012b_consolidation_router.py" \
  "$BASE/app/routes/v8012c_side_effect_hardening.py" \
  "$BASE/app/routes/v8012d_dashboard_extraction.py" \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/docker-compose.yml" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine" \
  "$BASE/.env"
 do
  [[ -f "$f" ]] || die "Missing production file: $f"
 done

for f in \
  "$PACKAGE_DIR/app/main.py" \
  "$PACKAGE_DIR/app/v8003_master_navigation.py" \
  "$PACKAGE_DIR/app/routes/v8012e_dashboard_extraction.py" \
  "$PACKAGE_DIR/ops/v8012e_generate_build_backup_audit.py" \
  "$PACKAGE_DIR/docker-compose.v8012e.yml" \
  "$PACKAGE_DIR/ops/v8012_consolidation_check.sh" \
  "$PACKAGE_DIR/README_V8012E.md" \
  "$PACKAGE_DIR/ROUTE_COMPATIBILITY.json" \
  "$PACKAGE_DIR/MANIFEST.sha256"
 do
  [[ -f "$f" ]] || die "Missing package file: $f"
 done

echo
echo "[1] Verify package hashes and compatibility report"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)
[[ "$(sha "$PACKAGE_DIR/app/main.py")" == "$EXPECTED_MAIN_NEW" ]] || die "Package main SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/v8003_master_navigation.py")" == "$EXPECTED_NAV_NEW" ]] || die "Package navigation SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/routes/v8012e_dashboard_extraction.py")" == "$EXPECTED_V8012E" ]] || die "Package V8012E SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/ops/v8012e_generate_build_backup_audit.py")" == "$EXPECTED_AUDIT_GENERATOR" ]] || die "Package audit generator SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/docker-compose.v8012e.yml")" == "$EXPECTED_COMPOSE_NEW" ]] || die "Package compose SHA mismatch"
python3 - "$PACKAGE_DIR/ROUTE_COMPATIBILITY.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
assert d.get('version')=='V8012E-SECOND-MODULAR-EXTRACTION-BUILD-AUDIT-V1'
assert int(d.get('paths_compared') or 0)==16
assert int(d.get('paths_identical') or 0)==16
assert d.get('all_route_signatures_identical') is True
assert d.get('payload_modules_changed') is False
assert d.get('trading_logic_changed') is False
print('Route compatibility report: PASS (16/16)')
PY

echo
echo "[2] Verify production baseline"
MAIN_SHA="$(sha "$BASE/app/main.py")"
NAV_SHA="$(sha "$BASE/app/v8003_master_navigation.py")"
V8012A_SHA="$(sha "$BASE/app/v8012a_route_consolidation.py")"
V8012B_SHA="$(sha "$BASE/app/routes/v8012b_consolidation_router.py")"
V8012C_SHA="$(sha "$BASE/app/routes/v8012c_side_effect_hardening.py")"
V8012D_SHA="$(sha "$BASE/app/routes/v8012d_dashboard_extraction.py")"
COMPOSE_SHA="$(sha "$BASE/docker-compose.yml")"
INGRESS_SHA="$(sha "$BASE/app/v8011_ingress.py")"
V8004_SHA="$(sha "$BASE/app/v8004_quality_router.py")"
V8006_SHA="$(sha "$BASE/app/v8006_calendar_execution_correction.py")"
V8007_SHA="$(sha "$BASE/app/v8007_v8001_gate_bridge.py")"
PINE_SHA="$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")"

printf 'main.py: %s\nV8003 nav: %s\nV8012A: %s\nV8012B.1: %s\nV8012C.1: %s\nV8012D: %s\ncompose: %s\ningress: %s\nV8004: %s\nV8006: %s\nV8007: %s\nPine: %s\n' \
  "$MAIN_SHA" "$NAV_SHA" "$V8012A_SHA" "$V8012B_SHA" "$V8012C_SHA" "$V8012D_SHA" "$COMPOSE_SHA" \
  "$INGRESS_SHA" "$V8004_SHA" "$V8006_SHA" "$V8007_SHA" "$PINE_SHA"

[[ "$MAIN_SHA" == "$EXPECTED_MAIN_OLD" || "$MAIN_SHA" == "$EXPECTED_MAIN_NEW" ]] || die "Unexpected main.py baseline"
[[ "$NAV_SHA" == "$EXPECTED_NAV_OLD" || "$NAV_SHA" == "$EXPECTED_NAV_NEW" ]] || die "Unexpected V8003 baseline"
[[ "$V8012A_SHA" == "$EXPECTED_V8012A" ]] || die "Unexpected V8012A baseline"
[[ "$V8012B_SHA" == "$EXPECTED_V8012B" ]] || die "Unexpected V8012B.1 baseline"
[[ "$V8012C_SHA" == "$EXPECTED_V8012C" ]] || die "Unexpected V8012C.1 baseline"
[[ "$V8012D_SHA" == "$EXPECTED_V8012D" ]] || die "Unexpected V8012D baseline"
[[ "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_OLD" || "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_NEW" ]] || die "Unexpected compose baseline"
[[ "$INGRESS_SHA" == "$EXPECTED_INGRESS" ]] || die "Unexpected V8011 ingress baseline"
[[ "$V8004_SHA" == "$EXPECTED_V8004" ]] || die "V8004 mismatch"
[[ "$V8006_SHA" == "$EXPECTED_V8006" ]] || die "V8006 mismatch"
[[ "$V8007_SHA" == "$EXPECTED_V8007" ]] || die "V8007 mismatch"
[[ "$PINE_SHA" == "$EXPECTED_PINE" ]] || die "Pine mismatch"
if [[ -f "$BASE/app/routes/v8012e_dashboard_extraction.py" ]]; then
  [[ "$(sha "$BASE/app/routes/v8012e_dashboard_extraction.py")" == "$EXPECTED_V8012E" ]] || die "Unexpected existing V8012E file"
fi
if [[ -f "$BASE/ops/v8012e_generate_build_backup_audit.py" ]]; then
  [[ "$(sha "$BASE/ops/v8012e_generate_build_backup_audit.py")" == "$EXPECTED_AUDIT_GENERATOR" ]] || die "Unexpected existing V8012E audit generator"
fi

echo
echo "[3] Create rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/app/main.py" "$BACKUP/main.py"
cp -a "$BASE/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/.env" "$BACKUP/.env"
chmod 600 "$BACKUP/.env"
[[ ! -f "$BASE/app/routes/v8012e_dashboard_extraction.py" ]] || cp -a "$BASE/app/routes/v8012e_dashboard_extraction.py" "$BACKUP/v8012e_dashboard_extraction.py"
[[ ! -f "$BASE/ops/v8012e_generate_build_backup_audit.py" ]] || cp -a "$BASE/ops/v8012e_generate_build_backup_audit.py" "$BACKUP/v8012e_generate_build_backup_audit.py"
[[ ! -f "$BASE/ops/v8012_consolidation_check.sh" ]] || cp -a "$BASE/ops/v8012_consolidation_check.sh" "$BACKUP/v8012_consolidation_check.sh"
[[ ! -f "$BASE/README_V8012E.md" ]] || cp -a "$BASE/README_V8012E.md" "$BACKUP/README_V8012E.md"
[[ ! -f "$BASE/ROUTE_COMPATIBILITY_V8012E.json" ]] || cp -a "$BASE/ROUTE_COMPATIBILITY_V8012E.json" "$BACKUP/ROUTE_COMPATIBILITY_V8012E.json"
[[ ! -f "$BASE/data/v8012e_build_backup_audit.json" ]] || cp -a "$BASE/data/v8012e_build_backup_audit.json" "$BACKUP/v8012e_build_backup_audit.json"
ROLLBACK_ARMED=1

echo
echo "[4] Keep webhook token fully OFF"
python3 - "$BASE/.env" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])
lines=p.read_text(encoding='utf-8', errors='replace').splitlines()
changes={'V8011_TOKEN_MODE':'off','V8011_ENFORCE_TOKEN':'false','V8011_WEBHOOK_TOKEN':''}
out=[]; seen=set()
for line in lines:
    if '=' not in line or line.lstrip().startswith('#'):
        out.append(line); continue
    key=line.split('=',1)[0].strip()
    if key in changes:
        if key not in seen:
            out.append(f'{key}={changes[key]}'); seen.add(key)
    else:
        out.append(line)
for key,value in changes.items():
    if key not in seen: out.append(f'{key}={value}')
p.write_text('\n'.join(out).rstrip()+'\n',encoding='utf-8')
print('token_mode: off')
print('token_configured: false')
print('token_enforced: false')
PY
chmod 600 "$BASE/.env"

echo
echo "[5] Install V8012E files"
mkdir -p "$BASE/app/routes" "$BASE/ops" "$BASE/data"
install -m 0644 "$PACKAGE_DIR/app/main.py" "$BASE/app/main.py"
install -m 0644 "$PACKAGE_DIR/app/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
install -m 0644 "$PACKAGE_DIR/app/routes/v8012e_dashboard_extraction.py" "$BASE/app/routes/v8012e_dashboard_extraction.py"
install -m 0755 "$PACKAGE_DIR/ops/v8012e_generate_build_backup_audit.py" "$BASE/ops/v8012e_generate_build_backup_audit.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8012e.yml" "$BASE/docker-compose.yml"
install -m 0755 "$PACKAGE_DIR/ops/v8012_consolidation_check.sh" "$BASE/ops/v8012_consolidation_check.sh"
install -m 0644 "$PACKAGE_DIR/README_V8012E.md" "$BASE/README_V8012E.md"
install -m 0644 "$PACKAGE_DIR/ROUTE_COMPATIBILITY.json" "$BASE/ROUTE_COMPATIBILITY_V8012E.json"

python3 -m py_compile \
  "$BASE/app/main.py" \
  "$BASE/app/v8003_master_navigation.py" \
  "$BASE/app/routes/v8012e_dashboard_extraction.py" \
  "$BASE/ops/v8012e_generate_build_backup_audit.py"
bash -n "$BASE/ops/v8012_consolidation_check.sh"
cd "$BASE"
docker compose config >/dev/null

echo
echo "[6] Verify protected hashes remain unchanged"
[[ "$(sha "$BASE/app/routes/v8012d_dashboard_extraction.py")" == "$EXPECTED_V8012D" ]] || die "V8012D changed"
[[ "$(sha "$BASE/app/v8011_ingress.py")" == "$EXPECTED_INGRESS" ]] || die "V8011 changed"
[[ "$(sha "$BASE/app/v8004_quality_router.py")" == "$EXPECTED_V8004" ]] || die "V8004 changed"
[[ "$(sha "$BASE/app/v8006_calendar_execution_correction.py")" == "$EXPECTED_V8006" ]] || die "V8006 changed"
[[ "$(sha "$BASE/app/v8007_v8001_gate_bridge.py")" == "$EXPECTED_V8007" ]] || die "V8007 changed"
[[ "$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")" == "$EXPECTED_PINE" ]] || die "Pine changed"

echo
echo "[7] Generate pre-build read-only storage audit"
python3 "$BASE/ops/v8012e_generate_build_backup_audit.py" \
  "$BASE" "$BASE/data/v8012e_build_backup_audit.json"

echo
echo "[8] Build shared V8012E image"
docker compose build tradingbot

echo
echo "[9] Start backend + ingress"
docker compose up -d --force-recreate --remove-orphans
wait_http_200 "http://127.0.0.1/health" 75 2 || die "Public health did not become ready"

echo
echo "[10] Refresh read-only storage audit after build"
python3 "$BASE/ops/v8012e_generate_build_backup_audit.py" \
  "$BASE" "$BASE/data/v8012e_build_backup_audit.json"

echo
echo "[11] Validate V8012A/B.1/C.1/D/E and ingress"
for name in a b c d e ingress audit; do : > "$TMP_DIR/$name.json"; done
curl -fsS --max-time 30 http://127.0.0.1/v8012/selftest.json -o "$TMP_DIR/a.json"
curl -fsS --max-time 30 http://127.0.0.1/v8012/selftest-b.json -o "$TMP_DIR/b.json"
curl -fsS --max-time 30 http://127.0.0.1/v8012/selftest-c.json -o "$TMP_DIR/c.json"
curl -fsS --max-time 30 http://127.0.0.1/v8012/selftest-d.json -o "$TMP_DIR/d.json"
curl -fsS --max-time 30 http://127.0.0.1/v8012/selftest-e.json -o "$TMP_DIR/e.json"
curl -fsS --max-time 30 http://127.0.0.1/v8011/selftest.json -o "$TMP_DIR/ingress.json"
curl -fsS --max-time 30 http://127.0.0.1/v8012/build-backup-audit.json -o "$TMP_DIR/audit.json"
python3 - "$TMP_DIR/a.json" "$TMP_DIR/b.json" "$TMP_DIR/c.json" "$TMP_DIR/d.json" "$TMP_DIR/e.json" "$TMP_DIR/ingress.json" "$TMP_DIR/audit.json" <<'PY'
import json,sys
files=[]
for p in sys.argv[1:]:
    with open(p,encoding='utf-8') as f: files.append(json.load(f))
a,b,c,d,e,i,audit=files
s=e.get('summary') or {}; inv=e.get('inventory') or {}; rt=e.get('runtime') or {}; safe=e.get('safety') or {}
astore=audit.get('storage') or {}; aback=audit.get('backups') or {}; adocker=audit.get('docker') or {}; asafe=audit.get('safety') or {}
print(json.dumps({
 'v8012a_ok':a.get('ok'),
 'duplicates_after':a.get('nonprotected_exact_duplicate_groups_after'),
 'v8012b_ok':b.get('ok'),
 'v8012c_ok':c.get('ok'),
 'v8012d_ok':d.get('ok'),
 'v8012e_ok':e.get('ok'),
 'version':e.get('version'),
 'extracted_route_wrappers':s.get('extracted_route_wrappers'),
 'extracted_groups':s.get('extracted_groups'),
 'cumulative_routes_extracted':s.get('cumulative_v8012d_e_routes_extracted'),
 'main_lines_removed':s.get('main_lines_removed'),
 'main_bytes_removed':s.get('main_bytes_removed'),
 'registered_paths':inv.get('registered_paths'),
 'missing_paths':inv.get('missing_paths'),
 'duplicate_signatures':inv.get('duplicate_signatures'),
 'wrong_endpoint_module':inv.get('wrong_endpoint_module'),
 'registration_ms':rt.get('registration_ms'),
 'audit_ok':audit.get('ok'),
 'disk_used_percent':astore.get('disk_used_percent'),
 'build_context_mib':astore.get('estimated_docker_build_context_mib'),
 'dockerignore_present':astore.get('dockerignore_present'),
 'backup_count':aback.get('count'),
 'backup_total_mib':aback.get('total_mib'),
 'tradingbot_image_count':adocker.get('tradingbot_image_count'),
 'unused_tradingbot_image_count':adocker.get('unused_tradingbot_image_count'),
 'ingress_ok':i.get('ok'),
 'token_mode':i.get('token_mode'),
},indent=2))
assert a.get('ok') is True
assert int(a.get('nonprotected_exact_duplicate_groups_after') or 0)==0
assert b.get('ok') is True
assert c.get('ok') is True
assert c.get('confirmation_header_required_for_added_alternatives') is True
assert d.get('ok') is True
assert e.get('ok') is True
assert e.get('version')=='V8012E-SECOND-MODULAR-EXTRACTION-BUILD-AUDIT-V1'
assert int(s.get('extracted_route_wrappers') or 0)==16
assert int(s.get('extracted_groups') or 0)==8
assert int(s.get('cumulative_v8012d_e_routes_extracted') or 0)==32
assert int(s.get('main_lines_before') or 0)==16005
assert int(s.get('main_lines_after') or 0)==15851
assert int(s.get('main_lines_removed') or 0)==154
assert int(s.get('main_bytes_removed') or 0)==5376
assert int(inv.get('registered_paths') or 0)==16
assert not (inv.get('missing_paths') or [])
assert not (inv.get('duplicate_signatures') or [])
assert not (inv.get('wrong_endpoint_module') or [])
assert int(rt.get('groups_installed') or 0)==8
assert not (rt.get('group_errors') or {})
assert audit.get('ok') is True
assert (audit.get('mode') or '')=='read_only_host_inventory'
assert (audit.get('recommendations') or {}).get('automatic_cleanup') is False
assert (audit.get('recommendations') or {}).get('deletion_performed') is False
assert asafe.get('files_deleted')==0
assert asafe.get('images_deleted')==0
assert asafe.get('backups_deleted')==0
assert asafe.get('trading_db_writes') is False
assert safe.get('automatic_cleanup') is False
assert i.get('ok') is True
assert i.get('backend_ok') is True
assert i.get('worker_alive') is True
assert i.get('token_mode')=='off'
assert i.get('token_configured') is False
assert i.get('token_enforced') is False
PY

echo
echo "[12] Lightweight behavior probes for eight extracted groups"
for route in \
  '/stability-v7243.json' \
  '/v7244-live-quality.json?limit=1' \
  '/v7244-explain.json?limit=1' \
  '/v7244d-next-live.json?limit=1' \
  '/v7244e-threshold-sim.json?limit=1' \
  '/v7244f-recommended-preset.json?limit=1' \
  '/v7245b-tp-optimizer.json?limit=1' \
  '/v7245c-recommendations.json?limit=1'
 do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 60 "http://127.0.0.1${route}" 2>/dev/null || true)"
  printf '%-60s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Route probe failed: $route -> $code"
 done

echo
echo "[13] Critical lightweight routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/selftest.json \
  /v8012/selftest-b.json \
  /v8012/selftest-c.json \
  /v8012/selftest-d.json \
  /v8012/selftest-e.json \
  /v8012/hub \
  /v8012/modular-extraction \
  /v8012/modular-extraction-2 \
  /v8012/modular-extraction-2.json \
  /v8012/build-backup-audit \
  /v8012/build-backup-audit.json
 do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 30 "http://127.0.0.1${route}" 2>/dev/null || true)"
  printf '%-54s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Critical route failed: $route -> $code"
 done

echo
echo "[14] Navigation"
curl -fsS --max-time 30 http://127.0.0.1/master | grep -q "V8012 Modular Extraction II" || die "Master link missing"
echo "Master link: PASS"
curl -fsS --max-time 30 http://127.0.0.1/master-ai-review | grep -q "V8012 Extraction II" || die "AI Review link missing"
echo "AI Review link: PASS"

echo
echo "[15] Final protected hashes"
sha256sum \
  "$BASE/app/routes/v8012d_dashboard_extraction.py" \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"

echo
echo "[16] Containers"
docker compose ps

ROLLBACK_ARMED=0
rm -rf "$TMP_DIR"
trap - ERR

cat <<EOF
================================================================================
V8012E INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Extraction II: http://91.107.237.214/v8012/modular-extraction-2
Extraction JSON: http://91.107.237.214/v8012/modular-extraction-2.json
Build/Backup Audit: http://91.107.237.214/v8012/build-backup-audit
Audit JSON: http://91.107.237.214/v8012/build-backup-audit.json
Selftest: http://91.107.237.214/v8012/selftest-e.json

COMPLETED:
  16 additional read-only dashboard route wrappers extracted from app/main.py
  8 route groups installed through one APIRouter module
  Existing URLs, methods, query defaults and response wrappers preserved
  Cumulative V8012D + V8012E modularized routes: 32
  main.py reduced by another 154 lines and 5376 bytes
  Read-only build context, backup and Docker image audit generated
  Master + AI Review links added

AUDIT SAFETY:
  No files deleted
  No images deleted
  No backups deleted
  No .env or secret contents collected
  No automatic cleanup

UNCHANGED:
  V8004 / V8006 / V8007
  Canonical Pine
  V8011 ingress/queue/dead-letter
  Existing trading DB schema
  Live scoring/routing
  Token OFF
  Broker auto execution FALSE
EOF
