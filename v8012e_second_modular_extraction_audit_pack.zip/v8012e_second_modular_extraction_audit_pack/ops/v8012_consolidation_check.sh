#!/usr/bin/env bash
set -u

BASE="/opt/tradingbot_v6000"
TMP_DIR="$(mktemp -d /tmp/v8012e_check.XXXXXX)"
trap 'rm -rf "$TMP_DIR"' EXIT
FAIL=0

fetch_json() {
  local url="$1" out="$2" timeout="${3:-30}"
  curl -fsS --max-time "$timeout" "$url" -o "$out"
}

status_code() {
  curl -sS -o /dev/null -w '%{http_code}' --max-time "${2:-20}" "$1" 2>/dev/null || true
}

echo "=== V8012E SECOND MODULAR EXTRACTION + BUILD AUDIT CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"
cd "$BASE" || exit 1

echo "[1] Containers"
docker compose ps

echo "[2] V8012A / B.1 / C.1 / D / E selftests"
fetch_json http://127.0.0.1/v8012/selftest.json "$TMP_DIR/a.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-b.json "$TMP_DIR/b.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-c.json "$TMP_DIR/c.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-d.json "$TMP_DIR/d.json" || FAIL=1
fetch_json http://127.0.0.1/v8012/selftest-e.json "$TMP_DIR/e.json" || FAIL=1
if [[ -s "$TMP_DIR/a.json" && -s "$TMP_DIR/b.json" && -s "$TMP_DIR/c.json" && -s "$TMP_DIR/d.json" && -s "$TMP_DIR/e.json" ]]; then
  python3 - "$TMP_DIR/a.json" "$TMP_DIR/b.json" "$TMP_DIR/c.json" "$TMP_DIR/d.json" "$TMP_DIR/e.json" <<'PY'
import json,sys
rows=[]
for path in sys.argv[1:]:
    with open(path,encoding='utf-8') as f: rows.append(json.load(f))
a,b,c,d,e=rows
s=e.get('summary') or {}; inv=e.get('inventory') or {}; rt=e.get('runtime') or {}
print(json.dumps({
  'v8012a_ok':a.get('ok'),
  'duplicates_after':a.get('nonprotected_exact_duplicate_groups_after'),
  'v8012b_ok':b.get('ok'),
  'v8012c_ok':c.get('ok'),
  'v8012d_ok':d.get('ok'),
  'v8012e_ok':e.get('ok'),
  'version':e.get('version'),
  'confirmation_header_required':c.get('confirmation_header_required_for_added_alternatives'),
  'wave_2_route_wrappers':s.get('extracted_route_wrappers'),
  'wave_2_groups':s.get('extracted_groups'),
  'cumulative_v8012d_e_routes':s.get('cumulative_v8012d_e_routes_extracted'),
  'main_lines_before':s.get('main_lines_before'),
  'main_lines_after':s.get('main_lines_after'),
  'main_lines_removed':s.get('main_lines_removed'),
  'main_bytes_removed':s.get('main_bytes_removed'),
  'registered_paths':inv.get('registered_paths'),
  'missing_paths':inv.get('missing_paths'),
  'duplicate_signatures':inv.get('duplicate_signatures'),
  'wrong_endpoint_module':inv.get('wrong_endpoint_module'),
  'registration_ms':rt.get('registration_ms'),
  'group_errors':rt.get('group_errors'),
},indent=2))
assert a.get('ok') is True
assert int(a.get('nonprotected_exact_duplicate_groups_after') or 0)==0
assert b.get('ok') is True
assert c.get('ok') is True
assert c.get('confirmation_header_required_for_added_alternatives') is True
assert d.get('ok') is True
assert e.get('ok') is True
assert e.get('version')=='V8012E-SECOND-MODULAR-EXTRACTION-BUILD-AUDIT-V1'
assert int(s.get('extracted_route_wrappers') or 0)==16
assert int(s.get('extracted_groups') or 0)==8
assert int(s.get('cumulative_v8012d_e_routes_extracted') or 0)==32
assert int(s.get('main_lines_before') or 0)==16005
assert int(s.get('main_lines_after') or 0)==15851
assert int(s.get('main_lines_removed') or 0)==154
assert int(s.get('main_bytes_removed') or 0)==5376
assert int(inv.get('registered_paths') or 0)==16
assert not (inv.get('missing_paths') or [])
assert not (inv.get('duplicate_signatures') or [])
assert not (inv.get('wrong_endpoint_module') or [])
assert int(rt.get('groups_installed') or 0)==8
assert not (rt.get('group_errors') or {})
PY
else
  FAIL=1
fi

echo "[3] Read-only build / backup / image audit"
fetch_json http://127.0.0.1/v8012/build-backup-audit.json "$TMP_DIR/audit.json" || FAIL=1
if [[ -s "$TMP_DIR/audit.json" ]]; then
  python3 - "$TMP_DIR/audit.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
storage=d.get('storage') or {}; backups=d.get('backups') or {}; docker=d.get('docker') or {}; rec=d.get('recommendations') or {}; safe=d.get('safety') or {}
print(json.dumps({
  'ok':d.get('ok'),
  'version':d.get('version'),
  'mode':d.get('mode'),
  'generated_utc':d.get('generated_utc'),
  'disk_used_percent':storage.get('disk_used_percent'),
  'estimated_build_context_mib':storage.get('estimated_docker_build_context_mib'),
  'build_context_basis':storage.get('build_context_basis'),
  'dockerignore_present':storage.get('dockerignore_present'),
  'backup_count':backups.get('count'),
  'backup_total_mib':backups.get('total_mib'),
  'backup_review_candidates_over_14d':backups.get('review_candidates_over_14d'),
  'tradingbot_image_count':docker.get('tradingbot_image_count'),
  'unused_tradingbot_image_count':docker.get('unused_tradingbot_image_count'),
  'dangling_image_count':docker.get('dangling_image_count'),
  'automatic_cleanup':rec.get('automatic_cleanup'),
  'deletion_performed':rec.get('deletion_performed'),
  'files_deleted':safe.get('files_deleted'),
  'images_deleted':safe.get('images_deleted'),
  'backups_deleted':safe.get('backups_deleted'),
  'trading_db_writes':safe.get('trading_db_writes'),
},indent=2))
assert d.get('ok') is True
assert d.get('version')=='V8012E-SECOND-MODULAR-EXTRACTION-BUILD-AUDIT-V1'
assert d.get('mode')=='read_only_host_inventory'
assert rec.get('automatic_cleanup') is False
assert rec.get('deletion_performed') is False
assert safe.get('files_deleted')==0
assert safe.get('images_deleted')==0
assert safe.get('backups_deleted')==0
assert safe.get('trading_db_writes') is False
PY
fi

echo "[4] Extracted group behavior probes"
for route in \
  '/stability-v7243.json' \
  '/v7244-live-quality.json?limit=1' \
  '/v7244-explain.json?limit=1' \
  '/v7244d-next-live.json?limit=1' \
  '/v7244e-threshold-sim.json?limit=1' \
  '/v7244f-recommended-preset.json?limit=1' \
  '/v7245b-tp-optimizer.json?limit=1' \
  '/v7245c-recommendations.json?limit=1'
 do
  code="$(status_code "http://127.0.0.1${route}" 60)"
  printf '%-60s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || FAIL=1
 done

echo "[5] POST confirmation guard – no side effect executed"
BODY_FILE="$TMP_DIR/post_guard.json"
CODE="$(curl -sS -o "$BODY_FILE" -w '%{http_code}' --max-time 15 -X POST http://127.0.0.1/pause/on 2>/dev/null || true)"
printf 'POST /pause/on without confirmation: %s\n' "$CODE"
cat "$BODY_FILE" 2>/dev/null || true
echo
[[ "$CODE" == "428" ]] || FAIL=1

echo "[6] Ingress health and token OFF"
fetch_json http://127.0.0.1/v8011/selftest.json "$TMP_DIR/ingress.json" || FAIL=1
if [[ -s "$TMP_DIR/ingress.json" ]]; then
  python3 - "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps({
  'ok':d.get('ok'),
  'operational_status':d.get('operational_status'),
  'queue_depth':d.get('queue_depth'),
  'backend_ok':d.get('backend_ok'),
  'worker_alive':d.get('worker_alive'),
  'token_mode':d.get('token_mode'),
  'token_configured':d.get('token_configured'),
  'token_enforced':d.get('token_enforced'),
},indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY
fi

echo "[7] Critical lightweight routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8004/selftest.json \
  /v8006/selftest.json \
  /v8007/selftest.json \
  /v8008a/selftest.json \
  /v8009/selftest.json \
  /v8011/selftest.json \
  /v8012/selftest.json \
  /v8012/selftest-b.json \
  /v8012/selftest-c.json \
  /v8012/selftest-d.json \
  /v8012/selftest-e.json \
  /v8012/hub \
  /v8012/modular-extraction \
  /v8012/modular-extraction-2 \
  /v8012/modular-extraction-2.json \
  /v8012/build-backup-audit \
  /v8012/build-backup-audit.json
 do
  code="$(status_code "http://127.0.0.1${route}" 30)"
  printf '%-54s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || FAIL=1
 done

echo "[8] Navigation"
if curl -fsS --max-time 30 http://127.0.0.1/master | grep -q "V8012 Modular Extraction II"; then
  echo "Master link: PASS"
else
  echo "Master link: FAIL"; FAIL=1
fi
if curl -fsS --max-time 30 http://127.0.0.1/master-ai-review | grep -q "V8012 Extraction II"; then
  echo "AI Review link: PASS"
else
  echo "AI Review link: FAIL"; FAIL=1
fi

echo "[9] Source size"
wc -l -c app/main.py

echo "[10] Protected hashes"
sha256sum \
  app/routes/v8012d_dashboard_extraction.py \
  app/v8011_ingress.py \
  app/v8004_quality_router.py \
  app/v8006_calendar_execution_correction.py \
  app/v8007_v8001_gate_bridge.py \
  pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine

echo "[11] Actual errors last 30m"
docker logs --since 30m tradingbot 2>&1 \
  | grep -Ei 'Traceback|ERROR|Exception|FATAL|V8012E.*(error|failed)' \
  | tail -n 100 || true

echo "[12] Host resources"
uptime
free -h
df -h "$BASE"

if [[ "$FAIL" != "0" ]]; then
  echo "=== V8012E CHECK FEHLER ==="
  exit 1
fi

echo "=== V8012E CHECK FERTIG ==="
