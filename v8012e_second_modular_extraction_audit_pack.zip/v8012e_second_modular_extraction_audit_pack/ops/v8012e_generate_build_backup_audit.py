#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VERSION = "V8012E-SECOND-MODULAR-EXTRACTION-BUILD-AUDIT-V1"


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def run(args: list[str], timeout: int = 30) -> dict[str, Any]:
    try:
        cp = subprocess.run(
            args,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        return {
            "ok": cp.returncode == 0,
            "returncode": cp.returncode,
            "stdout": cp.stdout.strip(),
            "stderr": cp.stderr.strip(),
        }
    except Exception as exc:
        return {
            "ok": False,
            "returncode": None,
            "stdout": "",
            "stderr": f"{type(exc).__name__}: {exc}",
        }


def tree_size(path: Path, excluded_names: set[str] | None = None) -> tuple[int, int]:
    total = 0
    files = 0
    excluded = excluded_names or set()
    if not path.exists():
        return 0, 0
    for root, dirs, names in os.walk(path, followlinks=False):
        dirs[:] = [
            d
            for d in dirs
            if d not in excluded and not Path(root, d).is_symlink()
        ]
        for name in names:
            if name in excluded:
                continue
            p = Path(root, name)
            try:
                if p.is_symlink():
                    continue
                total += p.stat().st_size
                files += 1
            except OSError:
                pass
    return total, files


def mib(value: int) -> float:
    return round(value / 1024 / 1024, 2)


def main() -> int:
    base = Path(
        sys.argv[1] if len(sys.argv) > 1 else "/opt/tradingbot_v6000"
    ).resolve()
    out = Path(
        sys.argv[2]
        if len(sys.argv) > 2
        else base / "data" / "v8012e_build_backup_audit.json"
    )
    out.parent.mkdir(parents=True, exist_ok=True)

    disk = shutil.disk_usage(base)
    directory_names = [
        "app",
        "data",
        "backups",
        "tradingbot_v7000",
        "pine",
        "ops",
    ]
    directories: dict[str, dict[str, Any]] = {}
    for name in directory_names:
        size, count = tree_size(base / name, {"__pycache__"})
        directories[name] = {"bytes": size, "mib": mib(size), "files": count}

    # Docker receives the complete project tree unless .dockerignore excludes files.
    # This is intentionally an estimate: parsing every Docker ignore rule is outside
    # the audit scope. No file contents or secrets are read.
    project_bytes, project_files = tree_size(base, {".git", "__pycache__"})
    dockerignore = base / ".dockerignore"
    dockerignore_present = dockerignore.is_file()
    context_basis = (
        "project_tree_before_dockerignore_rules"
        if dockerignore_present
        else "project_tree_no_dockerignore_detected"
    )

    backups_dir = base / "backups"
    backup_rows: list[dict[str, Any]] = []
    now_ts = datetime.now(timezone.utc).timestamp()
    if backups_dir.exists():
        for child in backups_dir.iterdir():
            try:
                stat = child.stat()
                size, count = (
                    tree_size(child, {"__pycache__"})
                    if child.is_dir()
                    else (stat.st_size, 1)
                )
                age_days = max(0.0, (now_ts - stat.st_mtime) / 86400.0)
                backup_rows.append(
                    {
                        "name": child.name,
                        "bytes": size,
                        "mib": mib(size),
                        "files": count,
                        "modified_utc": datetime.fromtimestamp(
                            stat.st_mtime, timezone.utc
                        ).isoformat(),
                        "age_days": round(age_days, 2),
                        "review_candidate_over_14d": age_days > 14.0,
                    }
                )
            except OSError:
                continue
    backup_rows.sort(key=lambda row: row["modified_utc"], reverse=True)
    backup_total = sum(int(row["bytes"]) for row in backup_rows)

    image_cmd = run(
        ["docker", "images", "--no-trunc", "--format", "{{json .}}"]
    )
    images: list[dict[str, Any]] = []
    if image_cmd["ok"]:
        for line in image_cmd["stdout"].splitlines():
            try:
                row = json.loads(line)
                if isinstance(row, dict):
                    images.append(row)
            except json.JSONDecodeError:
                pass

    ps_cmd = run(["docker", "ps", "--no-trunc", "--format", "{{json .}}"])
    containers: list[dict[str, Any]] = []
    used_image_names: set[str] = set()
    if ps_cmd["ok"]:
        for line in ps_cmd["stdout"].splitlines():
            try:
                row = json.loads(line)
                if isinstance(row, dict):
                    containers.append(row)
                    image = str(row.get("Image") or "")
                    if image:
                        used_image_names.add(image)
            except json.JSONDecodeError:
                pass

    tradingbot_images = [
        row
        for row in images
        if str(row.get("Repository") or "") == "tradingbot_v6000-app"
    ]
    unused_tradingbot = [
        row
        for row in tradingbot_images
        if f"{row.get('Repository')}:{row.get('Tag')}" not in used_image_names
    ]
    dangling = [
        row
        for row in images
        if str(row.get("Repository") or "") == "<none>"
        or str(row.get("Tag") or "") == "<none>"
    ]
    system_df = run(["docker", "system", "df"])

    report = {
        "ok": True,
        "version": VERSION,
        "generated_utc": utcnow(),
        "mode": "read_only_host_inventory",
        "storage": {
            "filesystem_total_bytes": disk.total,
            "filesystem_used_bytes": disk.used,
            "filesystem_free_bytes": disk.free,
            "disk_used_percent": (
                round((disk.used / disk.total) * 100.0, 2) if disk.total else 0.0
            ),
            "directories": directories,
            "estimated_docker_build_context_bytes": project_bytes,
            "estimated_docker_build_context_mib": mib(project_bytes),
            "estimated_docker_build_context_files": project_files,
            "build_context_basis": context_basis,
            "dockerignore_present": dockerignore_present,
        },
        "backups": {
            "count": len(backup_rows),
            "total_bytes": backup_total,
            "total_mib": mib(backup_total),
            "review_candidates_over_14d": sum(
                1 for row in backup_rows if row["review_candidate_over_14d"]
            ),
            "latest": backup_rows[:12],
        },
        "docker": {
            "available": bool(image_cmd["ok"] and ps_cmd["ok"]),
            "tradingbot_image_count": len(tradingbot_images),
            "unused_tradingbot_image_count": len(unused_tradingbot),
            "dangling_image_count": len(dangling),
            "running_container_count": len(containers),
            "running_images": sorted(used_image_names),
            "unused_tradingbot_images": [
                {
                    "repository": row.get("Repository"),
                    "tag": row.get("Tag"),
                    "id": row.get("ID"),
                    "size": row.get("Size"),
                    "created": row.get("CreatedSince"),
                }
                for row in unused_tradingbot[:30]
            ],
            "system_df": system_df["stdout"] if system_df["ok"] else "",
            "errors": [
                item
                for item in [
                    image_cmd["stderr"],
                    ps_cmd["stderr"],
                    system_df["stderr"],
                ]
                if item
            ],
        },
        "recommendations": {
            "automatic_cleanup": False,
            "deletion_performed": False,
            "review_old_backups_manually": any(
                row["review_candidate_over_14d"] for row in backup_rows
            ),
            "review_unused_images_manually": len(unused_tradingbot) > 0,
            "review_dockerignore_manually": (
                not dockerignore_present and mib(project_bytes) >= 100.0
            ),
            "next_safe_step": (
                "Create an explicit allowlist-based cleanup package only after "
                "reviewing this audit."
            ),
        },
        "safety": {
            "env_read": False,
            "secrets_collected": False,
            "files_deleted": 0,
            "images_deleted": 0,
            "backups_deleted": 0,
            "trading_db_writes": False,
            "broker_auto_execution": False,
        },
    }

    tmp = out.with_suffix(out.suffix + ".tmp")
    tmp.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(tmp, out)
    print(
        json.dumps(
            {
                "ok": True,
                "output": str(out),
                "disk_used_percent": report["storage"]["disk_used_percent"],
                "build_context_mib": report["storage"][
                    "estimated_docker_build_context_mib"
                ],
                "dockerignore_present": dockerignore_present,
                "backup_count": report["backups"]["count"],
                "backup_total_mib": report["backups"]["total_mib"],
                "tradingbot_image_count": report["docker"][
                    "tradingbot_image_count"
                ],
                "unused_tradingbot_image_count": report["docker"][
                    "unused_tradingbot_image_count"
                ],
                "automatic_cleanup": False,
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
