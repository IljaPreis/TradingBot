# V8013A B/Review Breakdown

V8013A erklärt den hohen B-/Review-Zähler des V8004 Quality Routers, ohne eine Handelsregel zu verändern.

## Neue Seiten

- `/v8013/b-review-breakdown`
- `/v8013/b-review-breakdown.json`
- `/v8013/reasons.json`
- `/v8013/selftest-a.json`

## Auswertung

Das Dashboard trennt:

- Grade B und REVIEW
- LIVE, SHADOW, WATCH_ONLY und NO_TRADE
- Märkte, Setups und Playbooks
- Stale-, Chase-/Late-Entry- und Duplicate-Gründe
- Pine-Score, Server-Confidence und Score-Gap
- Allzeit, 7 Tage, 24 Stunden, 6 Stunden und 1 Stunde

Der B-/Review-Zähler ist ein historisch wachsender Analysezähler. Er ist kein Live-Trade- oder Broker-Order-Zähler.

## Sicherheit

- SQLite ausschließlich `mode=ro`
- `PRAGMA query_only=ON`
- keine Tabellen oder Indizes angelegt
- keine DB-Schreibvorgänge
- keine Threshold-, Routing- oder Signaländerung
- V8004, V8006, V8007 und Pine unverändert
- Webhook-Token bleibt OFF
- Broker Auto Execution bleibt FALSE

## Lokaler Test

- Python-Kompilierung: PASS
- vollständiger `app.main`-Import: PASS
- vier neue Routen jeweils exakt einmal registriert
- V8013-Duplikate: 0
- synthetischer Datentest und Selftest: PASS
