from __future__ import annotations

import html
import json
import sqlite3
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8013A-B-REVIEW-BREAKDOWN-OBSERVE-V1"
MODE = "read_only_v8004_quality_diagnostics"
MAX_REASON_ROWS = 20000
WINDOWS: dict[str, timedelta | None] = {
    "1h": timedelta(hours=1),
    "6h": timedelta(hours=6),
    "24h": timedelta(hours=24),
    "7d": timedelta(days=7),
    "all": None,
}

SAFETY = {
    "observe_only": True,
    "db_writes": False,
    "db_schema_changes": False,
    "routing_changes": False,
    "threshold_changes": False,
    "live_rule_changes": False,
    "broker_auto_execution": False,
    "token_mode_changed": False,
}


def _root() -> Path:
    for p in (Path.cwd(), Path("/app"), Path("/opt/tradingbot_v6000")):
        try:
            if (p / "data").exists():
                return p
        except Exception:
            pass
    return Path.cwd()


def _db_path() -> Path:
    return _root() / "data" / "v7000_learning.sqlite3"


def _connect_ro() -> sqlite3.Connection:
    path = _db_path()
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=3)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA busy_timeout=3000")
    return con


def _table_exists(con: sqlite3.Connection, table: str) -> bool:
    return con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone() is not None


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def _parse_dt(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _window(value: str) -> str:
    key = str(value or "all").lower().strip()
    return key if key in WINDOWS else "all"


def _where(window: str) -> tuple[str, list[Any]]:
    delta = WINDOWS[_window(window)]
    if delta is None:
        return "", []
    cutoff = _iso(_now() - delta)
    return " WHERE datetime(created_at) >= datetime(?) ", [cutoff]


def _json_list(value: Any) -> list[str]:
    try:
        obj = json.loads(str(value or "[]"))
    except Exception:
        return []
    if isinstance(obj, list):
        return [str(x).strip() for x in obj if str(x).strip()]
    if isinstance(obj, str) and obj.strip():
        return [obj.strip()]
    return []


def _raw_obj(value: Any) -> dict[str, Any]:
    try:
        obj = json.loads(str(value or "{}"))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _num(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except Exception:
        return None


def _round(value: Any, digits: int = 2) -> float | None:
    number = _num(value)
    return round(number, digits) if number is not None else None


def _counter_rows(counter: Counter[str], limit: int = 20) -> list[dict[str, Any]]:
    return [{"name": key, "count": int(value)} for key, value in counter.most_common(limit)]


def _group(con: sqlite3.Connection, field: str, window: str, grade_filter: bool = False, limit: int = 20) -> list[dict[str, Any]]:
    allowed = {"market", "direction", "setup_name", "playbook", "grade", "route"}
    if field not in allowed:
        raise ValueError("unsupported group field")
    where_sql, params = _where(window)
    extra = "grade IN ('B','REVIEW')"
    if grade_filter:
        where_sql += (" AND " if where_sql else " WHERE ") + extra
    sql = f"""
        SELECT COALESCE(NULLIF(TRIM({field}), ''), 'UNKNOWN') AS name, COUNT(*) AS count
        FROM v8004_quality_router_log
        {where_sql}
        GROUP BY COALESCE(NULLIF(TRIM({field}), ''), 'UNKNOWN')
        ORDER BY count DESC, name ASC
        LIMIT ?
    """
    rows = con.execute(sql, [*params, max(1, min(int(limit), 100))]).fetchall()
    return [{"name": str(row["name"]), "count": int(row["count"] or 0)} for row in rows]


def _summary_sql(con: sqlite3.Connection, window: str) -> dict[str, Any]:
    where_sql, params = _where(window)
    row = con.execute(
        f"""
        SELECT
          COUNT(*) AS evaluated,
          COUNT(DISTINCT CASE WHEN signal_event_id IS NOT NULL AND TRIM(signal_event_id)<>'' THEN signal_event_id END) AS unique_signal_ids,
          COUNT(DISTINCT CASE WHEN market IS NOT NULL AND TRIM(market)<>'' THEN market END) AS unique_markets,
          SUM(CASE WHEN grade='A_PLUS' THEN 1 ELSE 0 END) AS a_plus,
          SUM(CASE WHEN grade='A' THEN 1 ELSE 0 END) AS a,
          SUM(CASE WHEN grade='B' THEN 1 ELSE 0 END) AS b,
          SUM(CASE WHEN grade='REVIEW' THEN 1 ELSE 0 END) AS review,
          SUM(CASE WHEN grade='WATCH' THEN 1 ELSE 0 END) AS watch,
          SUM(CASE WHEN grade='NO_TRADE' THEN 1 ELSE 0 END) AS no_trade_grade,
          SUM(CASE WHEN route='LIVE' THEN 1 ELSE 0 END) AS live,
          SUM(CASE WHEN route='SHADOW' THEN 1 ELSE 0 END) AS shadow,
          SUM(CASE WHEN route='WATCH_ONLY' THEN 1 ELSE 0 END) AS watch_only,
          SUM(CASE WHEN route='NO_TRADE' THEN 1 ELSE 0 END) AS no_trade,
          SUM(CASE WHEN duplicate=1 THEN 1 ELSE 0 END) AS duplicates,
          SUM(CASE WHEN grade IN ('B','REVIEW') THEN 1 ELSE 0 END) AS b_review_total,
          SUM(CASE WHEN grade IN ('B','REVIEW') AND route='SHADOW' THEN 1 ELSE 0 END) AS b_review_shadow,
          AVG(CASE WHEN grade IN ('B','REVIEW') THEN pine_score END) AS b_review_avg_pine,
          AVG(CASE WHEN grade IN ('B','REVIEW') THEN server_confidence END) AS b_review_avg_server,
          AVG(CASE WHEN grade IN ('B','REVIEW') THEN pine_score-server_confidence END) AS b_review_avg_gap,
          MIN(created_at) AS first_created_at,
          MAX(created_at) AS latest_created_at
        FROM v8004_quality_router_log
        {where_sql}
        """,
        params,
    ).fetchone()
    result = {key: row[key] for key in row.keys()} if row else {}
    for key in (
        "evaluated", "unique_signal_ids", "unique_markets", "a_plus", "a", "b", "review",
        "watch", "no_trade_grade", "live", "shadow", "watch_only", "no_trade", "duplicates",
        "b_review_total", "b_review_shadow",
    ):
        result[key] = int(result.get(key) or 0)
    for key in ("b_review_avg_pine", "b_review_avg_server", "b_review_avg_gap"):
        result[key] = _round(result.get(key))
    evaluated = int(result.get("evaluated") or 0)
    b_review = int(result.get("b_review_total") or 0)
    result["b_review_percent"] = round((b_review / evaluated * 100.0), 2) if evaluated else 0.0
    latest = _parse_dt(result.get("latest_created_at"))
    result["latest_age_seconds"] = round(max(0.0, (_now() - latest).total_seconds()), 1) if latest else None
    return result


def _reason_analysis(con: sqlite3.Connection, window: str) -> dict[str, Any]:
    where_sql, params = _where(window)
    total = int(con.execute(f"SELECT COUNT(*) FROM v8004_quality_router_log {where_sql}", params).fetchone()[0])
    rows = con.execute(
        f"""
        SELECT grade, route, reasons_json, blockers_json, raw_json
        FROM v8004_quality_router_log
        {where_sql}
        ORDER BY id DESC
        LIMIT ?
        """,
        [*params, MAX_REASON_ROWS],
    ).fetchall()

    all_reasons: Counter[str] = Counter()
    all_blockers: Counter[str] = Counter()
    b_review_reasons: Counter[str] = Counter()
    b_review_blockers: Counter[str] = Counter()
    sessions: Counter[str] = Counter()
    b_review_sessions: Counter[str] = Counter()
    families: Counter[str] = Counter()
    missing_raw = 0
    missing_session = 0

    for row in rows:
        grade = str(row["grade"] or "").upper()
        reasons = _json_list(row["reasons_json"])
        blockers = _json_list(row["blockers_json"])
        raw = _raw_obj(row["raw_json"])
        if not raw:
            missing_raw += 1
        session = str(raw.get("session") or "").upper().strip()
        if session:
            sessions[session] += 1
            if grade in {"B", "REVIEW"}:
                b_review_sessions[session] += 1
        else:
            missing_session += 1
        all_reasons.update(reasons)
        all_blockers.update(blockers)
        if grade in {"B", "REVIEW"}:
            b_review_reasons.update(reasons)
            b_review_blockers.update(blockers)

        tokens = set(reasons + blockers)
        if "V8004_STALE_SIGNAL" in tokens:
            families["STALE_SIGNAL"] += 1
        if "V8004_CHASE_OR_LATE_ENTRY" in tokens:
            families["CHASE_OR_LATE_ENTRY"] += 1
        if "V8004_DUPLICATE_SIGNAL_EVENT_ID" in tokens:
            families["DUPLICATE_SIGNAL_EVENT_ID"] += 1
        if "V8004_B_SHADOW_QUALITY" in tokens:
            families["B_SHADOW_QUALITY"] += 1
        if "V8004_REVIEW_SHADOW" in tokens:
            families["REVIEW_SHADOW"] += 1
        if any("NEWS" in token or "HIGH_IMPACT" in token for token in tokens):
            families["NEWS_OR_HIGH_IMPACT"] += 1
        if any("MISSING_" in token or "INVALID_" in token for token in tokens):
            families["MISSING_OR_INVALID_PAYLOAD"] += 1
        if any("EXTERNAL_HARD_BLOCK" in token or "OPEN_POSITION" in token for token in tokens):
            families["EXTERNAL_HARD_BLOCK"] += 1

    return {
        "rows_available": total,
        "rows_analyzed": len(rows),
        "truncated": total > len(rows),
        "max_reason_rows": MAX_REASON_ROWS,
        "all_reasons": _counter_rows(all_reasons),
        "all_blockers": _counter_rows(all_blockers),
        "b_review_reasons": _counter_rows(b_review_reasons),
        "b_review_blockers": _counter_rows(b_review_blockers),
        "reason_families": _counter_rows(families),
        "sessions": _counter_rows(sessions),
        "b_review_sessions": _counter_rows(b_review_sessions),
        "missing_raw_json": missing_raw,
        "missing_session": missing_session,
    }


def _latest_rows(con: sqlite3.Connection, window: str, limit: int, grades: tuple[str, ...] | None = None) -> list[dict[str, Any]]:
    where_sql, params = _where(window)
    if grades:
        placeholders = ",".join("?" for _ in grades)
        where_sql += (" AND " if where_sql else " WHERE ") + f"grade IN ({placeholders})"
        params.extend(grades)
    rows = con.execute(
        f"""
        SELECT id, created_at, signal_event_id, market, direction, setup_name, playbook,
               pine_score, server_confidence, grade, route, duplicate,
               reasons_json, blockers_json, raw_json
        FROM v8004_quality_router_log
        {where_sql}
        ORDER BY id DESC
        LIMIT ?
        """,
        [*params, max(1, min(int(limit), 300))],
    ).fetchall()
    result: list[dict[str, Any]] = []
    for row in rows:
        item = dict(row)
        reasons = _json_list(item.pop("reasons_json", "[]"))
        blockers = _json_list(item.pop("blockers_json", "[]"))
        raw = _raw_obj(item.pop("raw_json", "{}"))
        item["pine_score"] = _round(item.get("pine_score"))
        item["server_confidence"] = _round(item.get("server_confidence"))
        item["score_gap"] = _round((_num(item.get("pine_score")) or 0) - (_num(item.get("server_confidence")) or 0))
        item["session"] = str(raw.get("session") or "UNKNOWN")
        item["reasons"] = reasons
        item["blockers"] = blockers
        item["main_reason"] = (blockers + reasons + [""])[0]
        result.append(item)
    return result


def build_breakdown(window: str = "all", limit: int = 80) -> dict[str, Any]:
    selected = _window(window)
    result: dict[str, Any] = {
        "ok": True,
        "version": VERSION,
        "mode": MODE,
        "generated_utc": _iso(_now()),
        "window": selected,
        "available_windows": list(WINDOWS),
        "db_path": str(_db_path()),
        "table_exists": False,
        "summary": {},
        "comparison": {},
        "breakdowns": {},
        "reason_analysis": {},
        "latest_b_review": [],
        "latest_all": [],
        "interpretation": {
            "b_review_definition": "grade B plus grade REVIEW",
            "b_review_is_not_live_trade_count": True,
            "b_review_default_route": "SHADOW",
            "historical_accumulation": selected == "all",
            "no_broker_orders": True,
            "threshold_change_recommended_now": False,
            "next_step": "Compare B/Review outcomes before changing freshness or chase thresholds.",
        },
        "safety": dict(SAFETY),
    }
    con: sqlite3.Connection | None = None
    try:
        if not _db_path().exists():
            result["ok"] = False
            result["error"] = "database_missing"
            return result
        con = _connect_ro()
        if not _table_exists(con, "v8004_quality_router_log"):
            result["ok"] = False
            result["error"] = "v8004_quality_router_log_missing"
            return result
        result["table_exists"] = True
        result["summary"] = _summary_sql(con, selected)
        result["comparison"] = {
            "all": _summary_sql(con, "all"),
            "24h": _summary_sql(con, "24h"),
            "6h": _summary_sql(con, "6h"),
            "1h": _summary_sql(con, "1h"),
        }
        result["breakdowns"] = {
            "b_review_by_grade": _group(con, "grade", selected, grade_filter=True),
            "b_review_by_market": _group(con, "market", selected, grade_filter=True),
            "b_review_by_setup": _group(con, "setup_name", selected, grade_filter=True),
            "b_review_by_playbook": _group(con, "playbook", selected, grade_filter=True),
            "all_by_route": _group(con, "route", selected, grade_filter=False),
            "all_by_grade": _group(con, "grade", selected, grade_filter=False),
        }
        result["reason_analysis"] = _reason_analysis(con, selected)
        result["latest_b_review"] = _latest_rows(con, selected, limit, ("B", "REVIEW"))
        result["latest_all"] = _latest_rows(con, selected, min(limit, 40), None)
    except Exception as exc:
        result["ok"] = False
        result["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        try:
            if con is not None:
                con.close()
        except Exception:
            pass
    return result


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _token_ok(request: Request) -> bool:
    try:
        from app.v7200_event_risk import _token_ok as real_token_ok
        return bool(real_token_ok(request))
    except Exception:
        return True


def _suffix(token: str) -> str:
    return f"?token={quote(token)}" if token else ""


def _metric(label: str, value: Any, cls: str = "") -> str:
    return f"<div class='metric'><div class='label'>{_esc(label)}</div><div class='value {cls}'>{_esc(value)}</div></div>"


def _bars(rows: list[dict[str, Any]], total: int, empty: str = "Keine Daten") -> str:
    if not rows:
        return f"<div class='empty'>{_esc(empty)}</div>"
    top = max([int(x.get('count') or 0) for x in rows] + [1])
    parts = []
    for row in rows[:12]:
        count = int(row.get("count") or 0)
        pct = round(count / total * 100.0, 1) if total else 0.0
        width = max(2.0, count / top * 100.0)
        parts.append(
            f"<div class='barrow'><div class='barname'>{_esc(row.get('name'))}</div>"
            f"<div class='bartrack'><span style='width:{width:.1f}%'></span></div>"
            f"<div class='barcount'>{count} <small>{pct}%</small></div></div>"
        )
    return "".join(parts)


def _rows_table(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<div class='empty'>Keine B-/Review-Einträge im gewählten Zeitraum.</div>"
    items = []
    for row in rows:
        items.append(f"""
        <tr>
          <td>{_esc(row.get('created_at'))}</td><td>{_esc(row.get('market'))}</td>
          <td>{_esc(row.get('direction'))}</td><td>{_esc(row.get('setup_name'))}</td>
          <td>{_esc(row.get('playbook'))}</td><td>{_esc(row.get('session'))}</td>
          <td>{_esc(row.get('pine_score'))}</td><td>{_esc(row.get('server_confidence'))}</td>
          <td>{_esc(row.get('score_gap'))}</td><td>{_esc(row.get('grade'))}</td>
          <td>{_esc(row.get('route'))}</td><td>{_esc(row.get('main_reason'))}</td>
        </tr>""")
    return "<div class='tablewrap'><table><thead><tr><th>Zeit</th><th>Markt</th><th>Dir</th><th>Setup</th><th>Playbook</th><th>Session</th><th>Pine</th><th>Server</th><th>Gap</th><th>Grade</th><th>Route</th><th>Hauptgrund</th></tr></thead><tbody>" + "".join(items) + "</tbody></table></div>"


def page_html(data: dict[str, Any], token: str = "") -> str:
    summary = data.get("summary") or {}
    comparison = data.get("comparison") or {}
    breakdowns = data.get("breakdowns") or {}
    reasons = data.get("reason_analysis") or {}
    selected = data.get("window") or "all"
    suffix = _suffix(token)
    tabs = []
    for window in WINDOWS:
        active = " active" if window == selected else ""
        join = "&" if suffix else "?"
        href = f"/v8013/b-review-breakdown{suffix}{join}window={window}"
        tabs.append(f"<a class='tab{active}' href='{_esc(href)}'>{_esc(window.upper())}</a>")
    all_s = comparison.get("all") or {}
    day_s = comparison.get("24h") or {}
    total = int(summary.get("evaluated") or 0)
    b_review_total = int(summary.get("b_review_total") or 0)
    family_rows = reasons.get("reason_families") or []
    return f"""<!doctype html><html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>V8013A B/Review Breakdown</title><style>
:root{{--bg:#07111e;--panel:#101d2e;--panel2:#0b1728;--line:#273a52;--text:#eef6ff;--muted:#9caec4;--green:#22c55e;--yellow:#facc15;--red:#f87171;--blue:#93c5fd}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Arial,sans-serif}}a{{color:var(--blue)}}.wrap{{max-width:1500px;margin:auto;padding:12px}}.hero,.panel{{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:14px;margin:10px 0}}h1{{margin:0 0 6px;font-size:30px}}h2{{font-size:20px;margin:0 0 10px}}.muted{{color:var(--muted);line-height:1.45}}.nav,.tabs{{display:flex;gap:8px;flex-wrap:wrap}}.nav a,.tab{{text-decoration:none;padding:8px 11px;background:var(--panel2);border:1px solid var(--line);border-radius:10px;font-weight:800}}.tab.active{{border-color:#4c8fd8;background:#15314e}}.metrics{{display:grid;grid-template-columns:repeat(6,minmax(110px,1fr));gap:8px;margin:10px 0}}.metric{{background:var(--panel2);border:1px solid var(--line);border-radius:13px;padding:11px}}.label{{font-size:10px;color:var(--muted);text-transform:uppercase}}.value{{font-size:25px;font-weight:900;margin-top:4px}}.good{{color:var(--green)}}.warn{{color:var(--yellow)}}.bad{{color:var(--red)}}.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}.notice{{border-left:4px solid var(--yellow);padding:12px;background:#111d2d;border-radius:10px;line-height:1.45}}.barrow{{display:grid;grid-template-columns:minmax(150px,1.4fr) 2fr 90px;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid #203147}}.barname{{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}.bartrack{{height:9px;border-radius:9px;background:#07111e;overflow:hidden}}.bartrack span{{display:block;height:100%;background:#4c8fd8}}.barcount{{text-align:right;font-weight:800}}small{{color:var(--muted)}}.tablewrap{{overflow:auto;border:1px solid var(--line);border-radius:12px}}table{{width:100%;border-collapse:collapse;font-size:11px}}th,td{{padding:8px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}}th{{color:#a5d8ff;background:#0b1728;position:sticky;top:0}}.empty{{color:var(--muted);padding:12px}}.pill{{display:inline-block;padding:5px 8px;border:1px solid var(--line);border-radius:999px;font-size:11px;font-weight:800;margin:4px 4px 0 0}}@media(max-width:1050px){{.metrics{{grid-template-columns:repeat(3,1fr)}}.grid2{{grid-template-columns:1fr}}}}@media(max-width:650px){{.wrap{{padding:8px}}h1{{font-size:26px}}.metrics{{grid-template-columns:repeat(2,1fr)}}.barrow{{grid-template-columns:minmax(120px,1fr) 1.2fr 72px}}}}
</style></head><body><div class='wrap'>
<div class='hero'><h1>V8013A B/Review Breakdown</h1><div class='muted'>Warum der B-/Review-Zähler hoch ist: Der Wert zählt historische Qualitätskandidaten mit Grade B oder REVIEW. Er ist kein Live-Trade- und kein Broker-Order-Zähler.</div><div class='nav' style='margin-top:10px'><a href='/master{suffix}'>Master</a><a href='/master-ai-review{suffix}'>AI Review</a><a href='/v8004/quality-router{suffix}'>V8004 Router</a><a href='/v8013/b-review-breakdown.json{suffix}'>JSON</a><a href='/v8013/selftest-a.json{suffix}'>Selftest</a></div><div class='tabs' style='margin-top:10px'>{''.join(tabs)}</div></div>
<div class='metrics'>
{_metric('Ausgewertet', total)}{_metric('B', summary.get('b',0), 'warn')}{_metric('Review', summary.get('review',0), 'warn')}{_metric('B + Review', b_review_total, 'warn')}{_metric('B/Review Shadow', summary.get('b_review_shadow',0), 'warn')}{_metric('Live', summary.get('live',0), 'good')}
{_metric('No Trade', summary.get('no_trade',0), 'bad')}{_metric('Duplikate', summary.get('duplicates',0), 'bad')}{_metric('Märkte', summary.get('unique_markets',0))}{_metric('Pine Ø', summary.get('b_review_avg_pine'))}{_metric('Server Ø', summary.get('b_review_avg_server'))}{_metric('Gap Ø', summary.get('b_review_avg_gap'))}
</div>
<div class='panel notice'><b>Einordnung:</b> Im gewählten Fenster sind <b>{b_review_total}</b> B-/Review-Kandidaten. Davon wurden <b>{_esc(summary.get('b_review_shadow',0))}</b> nach SHADOW geroutet. Allzeit stehen <b>{_esc(all_s.get('b_review_total',0))}</b>, in den letzten 24 Stunden <b>{_esc(day_s.get('b_review_total',0))}</b>. B/Review bedeutet Analyse- und Lernmaterial; Broker Auto Execution bleibt FALSE.</div>
<div class='grid2'>
<div class='panel'><h2>B/Review nach Markt</h2>{_bars(breakdowns.get('b_review_by_market') or [], b_review_total)}</div>
<div class='panel'><h2>B/Review nach Setup</h2>{_bars(breakdowns.get('b_review_by_setup') or [], b_review_total)}</div>
<div class='panel'><h2>B/Review nach Playbook</h2>{_bars(breakdowns.get('b_review_by_playbook') or [], b_review_total)}</div>
<div class='panel'><h2>B/Review Hauptgründe</h2>{_bars(reasons.get('b_review_reasons') or [], b_review_total)}</div>
<div class='panel'><h2>Blocker-Familien aller Signale</h2>{_bars(family_rows, total)}</div>
<div class='panel'><h2>Alle Routen</h2>{_bars(breakdowns.get('all_by_route') or [], total)}</div>
</div>
<div class='panel'><h2>Neueste B-/Review-Kandidaten</h2>{_rows_table(data.get('latest_b_review') or [])}</div>
<div class='panel muted'><span class='pill'>READ ONLY</span><span class='pill'>DB WRITES 0</span><span class='pill'>ROUTING CHANGES 0</span><span class='pill'>THRESHOLD CHANGES 0</span><span class='pill'>TOKEN UNCHANGED</span><span class='pill'>BROKER FALSE</span><br><br>Reason-Analyse: {_esc(reasons.get('rows_analyzed',0))} von {_esc(reasons.get('rows_available',0))} Zeilen. Truncated: {_esc(reasons.get('truncated',False))}. Generated {_esc(data.get('generated_utc'))}.</div>
</div></body></html>"""


def selftest_payload(app) -> dict[str, Any]:
    required = {
        ("GET", "/v8013/b-review-breakdown"),
        ("GET", "/v8013/b-review-breakdown.json"),
        ("GET", "/v8013/reasons.json"),
        ("GET", "/v8013/selftest-a.json"),
    }
    signatures: Counter[tuple[str, str]] = Counter()
    for route in getattr(app, "routes", []):
        path = str(getattr(route, "path", "") or "")
        for method in set(getattr(route, "methods", set()) or set()):
            signatures[(str(method).upper(), path)] += 1
    missing = sorted([f"{method} {path}" for method, path in required if signatures[(method, path)] == 0])
    duplicates = sorted([f"{method} {path}" for method, path in required if signatures[(method, path)] > 1])
    sample = build_breakdown("24h", 5)
    return {
        "ok": not missing and not duplicates and bool(sample.get("ok")),
        "version": VERSION,
        "mode": MODE,
        "required_routes": len(required),
        "missing_routes": missing,
        "duplicate_routes": duplicates,
        "data_ok": bool(sample.get("ok")),
        "table_exists": bool(sample.get("table_exists")),
        "selected_window": sample.get("window"),
        "b_review_24h": (sample.get("summary") or {}).get("b_review_total"),
        "safety": dict(SAFETY),
    }


def install_v8013a_b_review_breakdown(app) -> None:
    if getattr(app.state, "v8013a_b_review_breakdown_installed", False):
        return

    @app.get("/v8013/b-review-breakdown", response_class=HTMLResponse)
    def v8013a_page(request: Request, window: str = "all", limit: int = 80):
        if not _token_ok(request):
            return HTMLResponse("unauthorized", status_code=401)
        token = request.query_params.get("token", "")
        return HTMLResponse(page_html(build_breakdown(window, limit), token))

    @app.get("/v8013/b-review-breakdown.json")
    def v8013a_json(request: Request, window: str = "all", limit: int = 80):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(build_breakdown(window, limit))

    @app.get("/v8013/reasons.json")
    def v8013a_reasons(request: Request, window: str = "all"):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        data = build_breakdown(window, 20)
        return JSONResponse({
            "ok": data.get("ok"),
            "version": VERSION,
            "window": data.get("window"),
            "summary": data.get("summary"),
            "reason_analysis": data.get("reason_analysis"),
            "safety": data.get("safety"),
        })

    @app.get("/v8013/selftest-a.json")
    def v8013a_selftest(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(selftest_payload(app))

    app.state.v8013a_b_review_breakdown_installed = True
    print("[V8013A] B/Review breakdown installed (read-only, routing unchanged)")
