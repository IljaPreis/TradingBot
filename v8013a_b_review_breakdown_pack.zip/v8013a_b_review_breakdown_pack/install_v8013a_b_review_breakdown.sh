#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="V8013A-B-REVIEW-BREAKDOWN-OBSERVE-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8013a_before_${TS}"
LOG="/root/v8013a_install_${TS}.log"
TMP_DIR="$(mktemp -d /tmp/v8013a_install.XXXXXX)"

EXPECTED_MAIN_OLD="2307535e6288b7850ff8f54dbbb537fa2c66ae49011db24e9a29a2b478110d11"
EXPECTED_MAIN_NEW="bc54d0ca28843aa44f4aef0173da936bb2271b094b6950cc129405382c1c92f3"
EXPECTED_NAV_OLD="2125fafc9bae15329ad36528380c815820a38c9a4373fc30e5d556f5fa0ecd42"
EXPECTED_NAV_NEW="b9d5ef3c35683be54bf7f9429e14710c74e571d32a2c3a243a75ac68f3d60c70"
EXPECTED_COMPOSE_OLD="7c2ed71de999a728f433ddf06eb8a5b41fcc74c0201185ee082518cf56da15a4"
EXPECTED_COMPOSE_NEW="be820aff788cf96a1242c51e3d826023f940498d4b65302abe296ad0f82d1bc7"
EXPECTED_V8013A="f7894e681d858cf70414616b37f8c09c4dce5906715f69f3f447b8934aa23689"
EXPECTED_V8012E="c8a37f938e0d0f44a7df7b64f75edfe27c59be55b2046d8c9264641baafd0db4"
EXPECTED_V8012D="d2b5d8c0d0ee5d8dadf26bf025f1c994fd217b52ca801b02346ff0849d0c9d28"
EXPECTED_V8012A="30e36a321e9c41810d766aaa7c857637e2c15d2f11fbc504c9b5969c27390af9"
EXPECTED_V8012B="2c4ae0955b8888650834f9f332ef5267d9f75bdb9d8bb1fbd5662b525c3c006b"
EXPECTED_V8012C="e7b881d09a097adb75835e46d7c367a28f28092196d31dbaf25c84ef5135381e"
EXPECTED_INGRESS="0b50a8dcce8e0f2ef71dead1d5489bdd1c915b932acefa166eec656828806c8b"
EXPECTED_V8004="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

ROLLBACK_ARMED=0
exec > >(tee -a "$LOG") 2>&1
sha() { sha256sum "$1" | awk '{print $1}'; }
die() { echo "FATAL: $*" >&2; exit 1; }

wait_http_200() {
  local url="$1" attempts="${2:-75}" sleep_s="${3:-2}" i code
  for i in $(seq 1 "$attempts"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    echo "WAIT [$i/$attempts] $url status=${code:-none}"
    sleep "$sleep_s"
  done
  return 1
}

restore_optional() {
  local backup_file="$1" target_file="$2"
  if [[ -f "$backup_file" ]]; then
    mkdir -p "$(dirname "$target_file")"
    cp -a "$backup_file" "$target_file" || true
  else
    rm -f "$target_file" || true
  fi
}

rollback() {
  local rc=$?
  trap - ERR
  rm -rf "$TMP_DIR" || true
  if [[ "$ROLLBACK_ARMED" != "1" ]]; then exit "$rc"; fi
  echo
  echo "=== V8013A ROLLBACK START ==="
  cp -a "$BACKUP/main.py" "$BASE/app/main.py" || true
  cp -a "$BACKUP/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py" || true
  cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml" || true
  cp -a "$BACKUP/.env" "$BASE/.env" || true
  chmod 600 "$BASE/.env" || true
  restore_optional "$BACKUP/v8013a_b_review_breakdown.py" "$BASE/app/routes/v8013a_b_review_breakdown.py"
  restore_optional "$BACKUP/v8013_b_review_check.sh" "$BASE/ops/v8013_b_review_check.sh"
  restore_optional "$BACKUP/README_V8013A.md" "$BASE/README_V8013A.md"
  restore_optional "$BACKUP/STATIC_AUDIT_V8013A.json" "$BASE/STATIC_AUDIT_V8013A.json"
  cd "$BASE"
  docker compose config >/dev/null 2>&1 || true
  docker compose up -d --build --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8013A ROLLBACK ENDE ==="
  exit "$rc"
}
trap rollback ERR

cat <<EOF
================================================================================
$VERSION INSTALL
================================================================================
Generated UTC: $(date -u --iso-8601=seconds)
Project: $BASE
Package: $PACKAGE_DIR
Scope:
  B/Review historical breakdown: ADD
  Grade, route, market, setup, playbook and reason analysis: ADD
  Time windows: all / 7d / 24h / 6h / 1h
  Existing V8004 data: READ ONLY
Safety:
  SQLite mode=ro and query_only: YES
  DB writes/schema changes: 0
  V8004/V8006/V8007 changes: 0
  Canonical Pine changes: 0
  V8011 ingress/queue/dead-letter changes: 0
  Threshold/routing changes: 0
  Token mode: OFF
  Broker auto execution: FALSE
EOF

[[ -d "$BASE" ]] || die "Project not found: $BASE"
for f in \
  "$BASE/app/main.py" \
  "$BASE/app/v8003_master_navigation.py" \
  "$BASE/app/routes/v8012d_dashboard_extraction.py" \
  "$BASE/app/routes/v8012e_dashboard_extraction.py" \
  "$BASE/app/v8012a_route_consolidation.py" \
  "$BASE/app/routes/v8012b_consolidation_router.py" \
  "$BASE/app/routes/v8012c_side_effect_hardening.py" \
  "$BASE/app/v8011_ingress.py" \
  "$BASE/app/v8004_quality_router.py" \
  "$BASE/app/v8006_calendar_execution_correction.py" \
  "$BASE/app/v8007_v8001_gate_bridge.py" \
  "$BASE/docker-compose.yml" \
  "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine" \
  "$BASE/.env"
 do [[ -f "$f" ]] || die "Missing production file: $f"; done

for f in \
  "$PACKAGE_DIR/app/main.py" \
  "$PACKAGE_DIR/app/v8003_master_navigation.py" \
  "$PACKAGE_DIR/app/routes/v8013a_b_review_breakdown.py" \
  "$PACKAGE_DIR/docker-compose.v8013a.yml" \
  "$PACKAGE_DIR/ops/v8013_b_review_check.sh" \
  "$PACKAGE_DIR/README_V8013A.md" \
  "$PACKAGE_DIR/STATIC_AUDIT.json" \
  "$PACKAGE_DIR/MANIFEST.sha256"
 do [[ -f "$f" ]] || die "Missing package file: $f"; done

echo "[1] Verify package hashes and static audit"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)
[[ "$(sha "$PACKAGE_DIR/app/main.py")" == "$EXPECTED_MAIN_NEW" ]] || die "Package main SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/v8003_master_navigation.py")" == "$EXPECTED_NAV_NEW" ]] || die "Package navigation SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/app/routes/v8013a_b_review_breakdown.py")" == "$EXPECTED_V8013A" ]] || die "Package V8013A SHA mismatch"
[[ "$(sha "$PACKAGE_DIR/docker-compose.v8013a.yml")" == "$EXPECTED_COMPOSE_NEW" ]] || die "Package compose SHA mismatch"
python3 - "$PACKAGE_DIR/STATIC_AUDIT.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
assert d.get('version')=='V8013A-B-REVIEW-BREAKDOWN-OBSERVE-V1'
assert len(d.get('routes_added') or [])==4
s=d.get('safety') or {}
assert s.get('db_writes') is False
assert s.get('db_schema_changes') is False
assert s.get('routing_changes') is False
assert s.get('threshold_changes') is False
assert s.get('broker_auto_execution') is False
print('Static audit: PASS')
PY

echo "[2] Verify production baseline"
MAIN_SHA="$(sha "$BASE/app/main.py")"
NAV_SHA="$(sha "$BASE/app/v8003_master_navigation.py")"
COMPOSE_SHA="$(sha "$BASE/docker-compose.yml")"
V8012E_SHA="$(sha "$BASE/app/routes/v8012e_dashboard_extraction.py")"
V8012D_SHA="$(sha "$BASE/app/routes/v8012d_dashboard_extraction.py")"
V8012A_SHA="$(sha "$BASE/app/v8012a_route_consolidation.py")"
V8012B_SHA="$(sha "$BASE/app/routes/v8012b_consolidation_router.py")"
V8012C_SHA="$(sha "$BASE/app/routes/v8012c_side_effect_hardening.py")"
INGRESS_SHA="$(sha "$BASE/app/v8011_ingress.py")"
V8004_SHA="$(sha "$BASE/app/v8004_quality_router.py")"
V8006_SHA="$(sha "$BASE/app/v8006_calendar_execution_correction.py")"
V8007_SHA="$(sha "$BASE/app/v8007_v8001_gate_bridge.py")"
PINE_SHA="$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")"
printf 'main.py: %s\nV8003 nav: %s\ncompose: %s\nV8012E: %s\nV8012D: %s\nV8012A: %s\nV8012B.1: %s\nV8012C.1: %s\ningress: %s\nV8004: %s\nV8006: %s\nV8007: %s\nPine: %s\n' "$MAIN_SHA" "$NAV_SHA" "$COMPOSE_SHA" "$V8012E_SHA" "$V8012D_SHA" "$V8012A_SHA" "$V8012B_SHA" "$V8012C_SHA" "$INGRESS_SHA" "$V8004_SHA" "$V8006_SHA" "$V8007_SHA" "$PINE_SHA"
[[ "$MAIN_SHA" == "$EXPECTED_MAIN_OLD" || "$MAIN_SHA" == "$EXPECTED_MAIN_NEW" ]] || die "Unexpected main.py baseline"
[[ "$NAV_SHA" == "$EXPECTED_NAV_OLD" || "$NAV_SHA" == "$EXPECTED_NAV_NEW" ]] || die "Unexpected navigation baseline"
[[ "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_OLD" || "$COMPOSE_SHA" == "$EXPECTED_COMPOSE_NEW" ]] || die "Unexpected compose baseline"
[[ "$V8012E_SHA" == "$EXPECTED_V8012E" ]] || die "Unexpected V8012E baseline"
[[ "$V8012D_SHA" == "$EXPECTED_V8012D" ]] || die "Unexpected V8012D baseline"
[[ "$V8012A_SHA" == "$EXPECTED_V8012A" ]] || die "Unexpected V8012A baseline"
[[ "$V8012B_SHA" == "$EXPECTED_V8012B" ]] || die "Unexpected V8012B baseline"
[[ "$V8012C_SHA" == "$EXPECTED_V8012C" ]] || die "Unexpected V8012C baseline"
[[ "$INGRESS_SHA" == "$EXPECTED_INGRESS" ]] || die "Unexpected ingress baseline"
[[ "$V8004_SHA" == "$EXPECTED_V8004" ]] || die "V8004 mismatch"
[[ "$V8006_SHA" == "$EXPECTED_V8006" ]] || die "V8006 mismatch"
[[ "$V8007_SHA" == "$EXPECTED_V8007" ]] || die "V8007 mismatch"
[[ "$PINE_SHA" == "$EXPECTED_PINE" ]] || die "Pine mismatch"
if [[ -f "$BASE/app/routes/v8013a_b_review_breakdown.py" ]]; then [[ "$(sha "$BASE/app/routes/v8013a_b_review_breakdown.py")" == "$EXPECTED_V8013A" ]] || die "Unexpected existing V8013A file"; fi

echo "[3] Create rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/app/main.py" "$BACKUP/main.py"
cp -a "$BASE/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/.env" "$BACKUP/.env"
for pair in \
  "app/routes/v8013a_b_review_breakdown.py:v8013a_b_review_breakdown.py" \
  "ops/v8013_b_review_check.sh:v8013_b_review_check.sh" \
  "README_V8013A.md:README_V8013A.md" \
  "STATIC_AUDIT_V8013A.json:STATIC_AUDIT_V8013A.json"
 do
  src="${pair%%:*}"; dst="${pair##*:}"
  [[ -f "$BASE/$src" ]] && cp -a "$BASE/$src" "$BACKUP/$dst"
 done
ROLLBACK_ARMED=1

echo "[4] Keep webhook token fully OFF"
python3 - "$BASE/.env" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
changes={'V8011_TOKEN_MODE':'off','V8011_ENFORCE_TOKEN':'false','V8011_WEBHOOK_TOKEN':''}
out=[]; seen=set()
for line in lines:
    if '=' not in line or line.lstrip().startswith('#'):
        out.append(line); continue
    key=line.split('=',1)[0].strip()
    if key in changes:
        if key not in seen: out.append(f"{key}={changes[key]}"); seen.add(key)
    else: out.append(line)
for key,value in changes.items():
    if key not in seen: out.append(f"{key}={value}")
p.write_text('\n'.join(out).rstrip()+'\n',encoding='utf-8')
print('token_mode: off')
print('token_configured: false')
print('token_enforced: false')
PY
chmod 600 "$BASE/.env"

echo "[5] Install V8013A files"
install -m 0644 "$PACKAGE_DIR/app/main.py" "$BASE/app/main.py"
install -m 0644 "$PACKAGE_DIR/app/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
install -m 0644 "$PACKAGE_DIR/app/routes/v8013a_b_review_breakdown.py" "$BASE/app/routes/v8013a_b_review_breakdown.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8013a.yml" "$BASE/docker-compose.yml"
install -m 0755 "$PACKAGE_DIR/ops/v8013_b_review_check.sh" "$BASE/ops/v8013_b_review_check.sh"
install -m 0644 "$PACKAGE_DIR/README_V8013A.md" "$BASE/README_V8013A.md"
install -m 0644 "$PACKAGE_DIR/STATIC_AUDIT.json" "$BASE/STATIC_AUDIT_V8013A.json"
python3 -m py_compile "$BASE/app/main.py" "$BASE/app/v8003_master_navigation.py" "$BASE/app/routes/v8013a_b_review_breakdown.py"

echo "[6] Verify protected hashes remain unchanged"
[[ "$(sha "$BASE/app/routes/v8012e_dashboard_extraction.py")" == "$EXPECTED_V8012E" ]] || die "V8012E changed"
[[ "$(sha "$BASE/app/routes/v8012d_dashboard_extraction.py")" == "$EXPECTED_V8012D" ]] || die "V8012D changed"
[[ "$(sha "$BASE/app/v8011_ingress.py")" == "$EXPECTED_INGRESS" ]] || die "Ingress changed"
[[ "$(sha "$BASE/app/v8004_quality_router.py")" == "$EXPECTED_V8004" ]] || die "V8004 changed"
[[ "$(sha "$BASE/app/v8006_calendar_execution_correction.py")" == "$EXPECTED_V8006" ]] || die "V8006 changed"
[[ "$(sha "$BASE/app/v8007_v8001_gate_bridge.py")" == "$EXPECTED_V8007" ]] || die "V8007 changed"
[[ "$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")" == "$EXPECTED_PINE" ]] || die "Pine changed"

echo "[7] Build shared V8013A image"
cd "$BASE"
docker compose config >/dev/null
docker compose build tradingbot

echo "[8] Start backend + ingress"
docker compose up -d --force-recreate --remove-orphans
wait_http_200 http://127.0.0.1/health 75 2 || die "Public health did not become ready"

echo "[9] Validate V8013A selftest and live data"
curl -fsS --max-time 60 http://127.0.0.1/v8013/selftest-a.json -o "$TMP_DIR/selftest.json"
curl -fsS --max-time 60 'http://127.0.0.1/v8013/b-review-breakdown.json?window=all&limit=10' -o "$TMP_DIR/data.json"
python3 - "$TMP_DIR/selftest.json" "$TMP_DIR/data.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:s=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f:d=json.load(f)
summary=d.get('summary') or {}; comp=d.get('comparison') or {}; safe=d.get('safety') or {}
print(json.dumps({
  'selftest_ok':s.get('ok'),'version':s.get('version'),'table_exists':s.get('table_exists'),
  'missing_routes':s.get('missing_routes'),'duplicate_routes':s.get('duplicate_routes'),
  'evaluated_all':summary.get('evaluated'),'b':summary.get('b'),'review':summary.get('review'),
  'b_review_all':summary.get('b_review_total'),'b_review_24h':(comp.get('24h') or {}).get('b_review_total'),
  'b_review_shadow':summary.get('b_review_shadow'),'live':summary.get('live'),
  'no_trade':summary.get('no_trade'),'duplicates':summary.get('duplicates'),
  'db_writes':safe.get('db_writes'),'routing_changes':safe.get('routing_changes'),
  'threshold_changes':safe.get('threshold_changes'),'broker_auto_execution':safe.get('broker_auto_execution'),
},indent=2))
assert s.get('ok') is True
assert s.get('version')=='V8013A-B-REVIEW-BREAKDOWN-OBSERVE-V1'
assert s.get('table_exists') is True
assert not (s.get('missing_routes') or [])
assert not (s.get('duplicate_routes') or [])
assert d.get('ok') is True and d.get('table_exists') is True
assert safe.get('db_writes') is False
assert safe.get('routing_changes') is False
assert safe.get('threshold_changes') is False
assert safe.get('broker_auto_execution') is False
PY

echo "[10] Critical route status"
for route in /health /master /master-ai-review /v8004/selftest.json /v8006/selftest.json /v8007/selftest.json /v8008a/selftest.json /v8009/selftest.json /v8011/selftest.json /v8012/selftest-e.json /v8013/b-review-breakdown /v8013/b-review-breakdown.json /v8013/reasons.json /v8013/selftest-a.json
 do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 60 "http://127.0.0.1$route" 2>/dev/null || true)"
  printf '%-50s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Route failed: $route status=$code"
 done

echo "[11] Navigation"
curl -fsS --max-time 60 http://127.0.0.1/master | grep -q "V8013 B/Review Breakdown" || die "Master link missing"
curl -fsS --max-time 60 http://127.0.0.1/master-ai-review | grep -q "V8013 B/Review Breakdown" || die "AI Review link missing"
echo "Master link: PASS"
echo "AI Review link: PASS"

echo "[12] Token OFF and ingress health"
curl -fsS --max-time 30 http://127.0.0.1/v8011/selftest.json -o "$TMP_DIR/ingress.json"
python3 - "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps({'ok':d.get('ok'),'operational_status':d.get('operational_status'),'queue_depth':d.get('queue_depth'),'backend_ok':d.get('backend_ok'),'worker_alive':d.get('worker_alive'),'token_mode':d.get('token_mode'),'token_configured':d.get('token_configured'),'token_enforced':d.get('token_enforced')},indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY

echo "[13] Final protected hashes"
sha256sum "$BASE/app/routes/v8012e_dashboard_extraction.py" "$BASE/app/routes/v8012d_dashboard_extraction.py" "$BASE/app/v8011_ingress.py" "$BASE/app/v8004_quality_router.py" "$BASE/app/v8006_calendar_execution_correction.py" "$BASE/app/v8007_v8001_gate_bridge.py" "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"

echo "[14] Containers"
docker compose ps
ROLLBACK_ARMED=0
rm -rf "$TMP_DIR"
trap - ERR
cat <<EOF
================================================================================
V8013A INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Dashboard: http://91.107.237.214/v8013/b-review-breakdown
JSON:      http://91.107.237.214/v8013/b-review-breakdown.json
Reasons:   http://91.107.237.214/v8013/reasons.json
Selftest:  http://91.107.237.214/v8013/selftest-a.json
COMPLETED:
  B and REVIEW separated
  All-time versus 24h/6h/1h comparison added
  Market, setup, playbook, session and reason breakdown added
  Pine/server score gap added
  Stale, chase/late-entry and duplicate families added
  Master + AI Review link added
UNCHANGED:
  V8004 / V8006 / V8007
  Canonical Pine
  V8011 ingress/queue/dead-letter
  Existing trading DB schema and rows
  Live scoring/routing and thresholds
  Token OFF
  Broker auto execution FALSE
EOF
