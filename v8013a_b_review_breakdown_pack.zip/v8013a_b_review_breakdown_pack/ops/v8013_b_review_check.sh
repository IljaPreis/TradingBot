#!/usr/bin/env bash
set -u
BASE="/opt/tradingbot_v6000"
TMP_DIR="$(mktemp -d /tmp/v8013a_check.XXXXXX)"
trap 'rm -rf "$TMP_DIR"' EXIT
FAIL=0
fetch_json() { curl -fsS --max-time "${3:-60}" "$1" -o "$2"; }
status_code() { curl -sS -o /dev/null -w '%{http_code}' --max-time "${2:-30}" "$1" 2>/dev/null || true; }

echo "=== V8013A B/REVIEW BREAKDOWN CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"
cd "$BASE" || exit 1

echo "[1] Containers"
docker compose ps

echo "[2] V8013A selftest"
fetch_json http://127.0.0.1/v8013/selftest-a.json "$TMP_DIR/self.json" || FAIL=1
if [[ -s "$TMP_DIR/self.json" ]]; then
python3 - "$TMP_DIR/self.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps(d,indent=2))
assert d.get('ok') is True
assert d.get('version')=='V8013A-B-REVIEW-BREAKDOWN-OBSERVE-V1'
assert d.get('table_exists') is True
assert not (d.get('missing_routes') or [])
assert not (d.get('duplicate_routes') or [])
s=d.get('safety') or {}
assert s.get('db_writes') is False
assert s.get('db_schema_changes') is False
assert s.get('routing_changes') is False
assert s.get('threshold_changes') is False
assert s.get('broker_auto_execution') is False
PY
else FAIL=1; fi

echo "[3] Why B/Review is high"
fetch_json 'http://127.0.0.1/v8013/b-review-breakdown.json?window=all&limit=20' "$TMP_DIR/all.json" || FAIL=1
if [[ -s "$TMP_DIR/all.json" ]]; then
python3 - "$TMP_DIR/all.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
s=d.get('summary') or {}; c=d.get('comparison') or {}; r=d.get('reason_analysis') or {}; b=d.get('breakdowns') or {}; i=d.get('interpretation') or {}
print(json.dumps({
 'ok':d.get('ok'),'window':d.get('window'),'evaluated_all':s.get('evaluated'),
 'unique_signal_ids':s.get('unique_signal_ids'),'unique_markets':s.get('unique_markets'),
 'a_plus':s.get('a_plus'),'a':s.get('a'),'b':s.get('b'),'review':s.get('review'),
 'b_review_all':s.get('b_review_total'),'b_review_percent':s.get('b_review_percent'),
 'b_review_shadow':s.get('b_review_shadow'),'live':s.get('live'),'no_trade':s.get('no_trade'),'duplicates':s.get('duplicates'),
 'b_review_24h':(c.get('24h') or {}).get('b_review_total'),'b_review_6h':(c.get('6h') or {}).get('b_review_total'),'b_review_1h':(c.get('1h') or {}).get('b_review_total'),
 'avg_pine':s.get('b_review_avg_pine'),'avg_server':s.get('b_review_avg_server'),'avg_gap':s.get('b_review_avg_gap'),
 'top_markets':(b.get('b_review_by_market') or [])[:8],'top_setups':(b.get('b_review_by_setup') or [])[:8],
 'top_reasons':(r.get('b_review_reasons') or [])[:8],'blocker_families':(r.get('reason_families') or [])[:8],
 'not_live_trade_count':i.get('b_review_is_not_live_trade_count'),'no_broker_orders':i.get('no_broker_orders'),
},indent=2))
assert d.get('ok') is True
assert i.get('b_review_is_not_live_trade_count') is True
assert i.get('no_broker_orders') is True
PY
else FAIL=1; fi

echo "[4] Ingress health and token OFF"
fetch_json http://127.0.0.1/v8011/selftest.json "$TMP_DIR/ingress.json" || FAIL=1
if [[ -s "$TMP_DIR/ingress.json" ]]; then
python3 - "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps({'ok':d.get('ok'),'operational_status':d.get('operational_status'),'queue_depth':d.get('queue_depth'),'backend_ok':d.get('backend_ok'),'worker_alive':d.get('worker_alive'),'token_mode':d.get('token_mode'),'token_configured':d.get('token_configured'),'token_enforced':d.get('token_enforced')},indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY
else FAIL=1; fi

echo "[5] Critical routes"
for route in /health /master /master-ai-review /v8004/quality-router /v8004/selftest.json /v8011/selftest.json /v8012/selftest-e.json /v8013/b-review-breakdown /v8013/b-review-breakdown.json /v8013/reasons.json /v8013/selftest-a.json
 do
  code="$(status_code "http://127.0.0.1$route" 60)"
  printf '%-50s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || FAIL=1
 done

echo "[6] Navigation"
if curl -fsS --max-time 60 http://127.0.0.1/master | grep -q "V8013 B/Review Breakdown"; then echo "Master link: PASS"; else echo "Master link: FAIL"; FAIL=1; fi
if curl -fsS --max-time 60 http://127.0.0.1/master-ai-review | grep -q "V8013 B/Review Breakdown"; then echo "AI Review link: PASS"; else echo "AI Review link: FAIL"; FAIL=1; fi

echo "[7] Protected hashes"
sha256sum app/routes/v8012e_dashboard_extraction.py app/routes/v8012d_dashboard_extraction.py app/v8011_ingress.py app/v8004_quality_router.py app/v8006_calendar_execution_correction.py app/v8007_v8001_gate_bridge.py pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine

echo "[8] Actual errors last 30m"
docker logs --since 30m tradingbot 2>&1 | grep -Ei 'Traceback|ERROR|Exception|FATAL|V8013A.*(error|failed)' | tail -n 100 || true

echo "[9] Host resources"
uptime
free -h
df -h "$BASE"
if [[ "$FAIL" != "0" ]]; then echo "=== V8013A CHECK FEHLER ==="; exit 1; fi
echo "=== V8013A CHECK FERTIG ==="
