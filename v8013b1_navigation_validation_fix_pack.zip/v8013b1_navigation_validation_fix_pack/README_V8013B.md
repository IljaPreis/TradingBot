# V8013B.1 Score-Gap, Freshness and Ingress Timing Audit

Version: `V8013B.1-SCORE-GAP-STALE-TIMING-AUDIT-NAV-FIX-V1`

V8013B explains why V8004 signals become B, REVIEW or NO_TRADE without changing any rule.

## Important interpretation

- `server_confidence` is recorded for diagnostics, but it is not the direct grade input for V8004 B/REVIEW classification.
- V8004 grade A/B/REVIEW is based on Pine score, confirmation count and aligned/opposing biases.
- The existing `base_allow` safety gate can separately affect whether an A/A+ candidate may route LIVE.
- `V8004_STALE_SIGNAL` is not a measured network delay. It is added when payload field `is_fresh` is false.
- Pine V8001.4D sets `is_fresh=true` only for entry quality `FRESH`. Entry quality `VALID` therefore also fails `require_fresh=true`.
- V8011 queue timing is correlated read-only using the signal event ID. Exact TradingView-to-server transit age is only measurable when the source payload contains a timestamp.

## Routes

- `/v8013/score-gap-timing`
- `/v8013/score-gap-timing.json`
- `/v8013/stale-audit.json`
- `/v8013/queue-correlation.json`
- `/v8013/selftest-b.json`

## Build-context optimization

The pack installs a conservative `.dockerignore` before building. It excludes backups, logs, archives, Python caches, `.env`, runtime SQLite files and historical `.bak_*` files from Docker build context. It does not delete any file.

A storage dry-run is written to `data/v8013b_storage_dry_run.json`. No Docker image or backup is deleted.

## Safety

- SQLite connections: read-only and query-only
- Database writes: none
- Database schema changes: none
- Routing changes: none
- Threshold changes: none
- Image deletion: none
- Backup deletion: none
- Webhook token remains off
- Broker auto execution remains false

## V8013B.1 navigation validation fix

The first V8013B installer completed the build, routes, selftest and live-data checks, but rolled back on a false-negative navigation test. With `set -o pipefail`, `curl | grep -q` can report failure after `grep` exits early on a successful match. V8013B.1 downloads each full page to a temporary file and then checks the canonical href. No runtime scoring or routing code was changed by this fix.
