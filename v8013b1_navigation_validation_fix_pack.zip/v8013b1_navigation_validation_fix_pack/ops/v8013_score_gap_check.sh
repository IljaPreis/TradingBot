#!/usr/bin/env bash
set -u
BASE="/opt/tradingbot_v6000"
cd "$BASE" || exit 1
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "=== V8013B.1 SCORE-GAP + STALE TIMING CHECK ==="
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"

echo "[1] Containers"
docker compose ps

echo "[2] V8013A + V8013B selftests"
curl -fsS --max-time 60 http://127.0.0.1/v8013/selftest-a.json -o "$TMP/a.json" || exit 1
curl -fsS --max-time 60 http://127.0.0.1/v8013/selftest-b.json -o "$TMP/b.json" || exit 1
python3 - "$TMP/a.json" "$TMP/b.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:a=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f:b=json.load(f)
print(json.dumps({
 'v8013a_ok':a.get('ok'),'v8013b_ok':b.get('ok'),'version':b.get('version'),
 'missing_routes':b.get('missing_routes'),'duplicate_routes':b.get('duplicate_routes'),
 'evaluated_24h':b.get('evaluated_24h'),'b_review_24h':b.get('b_review_24h'),
 'stale_24h':b.get('stale_24h'),'stale_valid_24h':b.get('stale_valid_24h'),
 'queue_matches_24h':b.get('queue_matches_24h'),'safety':b.get('safety')
},indent=2))
assert a.get('ok') is True
assert b.get('ok') is True
assert b.get('version')=='V8013B.1-SCORE-GAP-STALE-TIMING-AUDIT-NAV-FIX-V1'
assert not (b.get('missing_routes') or [])
assert not (b.get('duplicate_routes') or [])
s=b.get('safety') or {}
for key in ('db_writes','db_schema_changes','routing_changes','threshold_changes','live_rule_changes','image_deletion','backup_deletion','broker_auto_execution','token_mode_changed'):
    assert s.get(key) is False,(key,s.get(key))
PY

echo "[3] Core finding – score gap and A-gate failures"
curl -fsS --max-time 60 'http://127.0.0.1/v8013/score-gap-timing.json?window=all&limit=10' -o "$TMP/data.json" || exit 1
python3 - "$TMP/data.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
s=d.get('summary') or {}; g=d.get('score_gap') or {}; a=d.get('a_gate_failures_for_b_review') or {}; fr=d.get('freshness_audit') or {}; q=d.get('ingress_timing') or {}
print(json.dumps({
 'ok':d.get('ok'),'window':d.get('window'),'evaluated':s.get('evaluated'),'b_review':s.get('b_review'),
 'avg_pine':s.get('avg_pine_score'),'avg_server':s.get('avg_server_confidence'),'avg_gap':s.get('avg_score_gap'),
 'server_confidence_directly_used_for_v8004_grade':g.get('server_confidence_directly_used_for_v8004_grade'),
 'a_gate_failures':a.get('counts'),'stale_blocked':s.get('stale_blocked'),
 'stale_with_valid_entry_quality':s.get('stale_with_valid_entry_quality'),
 'stale_valid_share_percent':s.get('stale_valid_share_percent'),
 'queue_matches':q.get('matched'),'avg_queue_wait_ms':q.get('avg_queue_wait_ms'),
 'avg_backend_latency_ms':q.get('avg_backend_latency_ms'),
 'network_transit_age_measurable':q.get('network_transit_age_measurable'),
 'threshold_change_applied':fr.get('threshold_change_applied')
},indent=2))
assert d.get('ok') is True
assert g.get('server_confidence_directly_used_for_v8004_grade') is False
assert fr.get('threshold_change_applied') is False
safe=d.get('safety') or {}
assert safe.get('db_writes') is False
assert safe.get('routing_changes') is False
assert safe.get('threshold_changes') is False
PY

echo "[4] Stale semantics"
curl -fsS --max-time 60 'http://127.0.0.1/v8013/stale-audit.json?window=all' | python3 -m json.tool

echo "[5] Queue correlation"
curl -fsS --max-time 60 'http://127.0.0.1/v8013/queue-correlation.json?window=7d' | python3 -m json.tool

echo "[6] Build context and cleanup dry-run"
[[ -f .dockerignore ]] || { echo '.dockerignore missing'; exit 1; }
sha256sum .dockerignore
python3 ops/v8013b_storage_dry_run.py > "$TMP/storage.txt" || exit 1
python3 - <<'PY'
import json
from pathlib import Path
p=Path('/opt/tradingbot_v6000/data/v8013b_storage_dry_run.json')
d=json.loads(p.read_text(encoding='utf-8'))
print(json.dumps({
 'ok':d.get('ok'),'disk_used_percent':d.get('disk_used_percent'),
 'dockerignore_present':d.get('dockerignore_present'),
 'tradingbot_image_count':len(d.get('tradingbot_images') or []),
 'cleanup_candidate_count':d.get('cleanup_candidate_count'),
 'keep_tags':d.get('keep_tags'),'automatic_cleanup':d.get('automatic_cleanup'),
 'deletion_performed':d.get('deletion_performed'),'images_deleted':d.get('images_deleted'),
 'backups_deleted':d.get('backups_deleted'),'files_deleted':d.get('files_deleted')
},indent=2))
assert d.get('ok') is True
assert d.get('dockerignore_present') is True
assert d.get('automatic_cleanup') is False
assert d.get('deletion_performed') is False
assert d.get('images_deleted')==0
assert d.get('backups_deleted')==0
assert d.get('files_deleted')==0
PY

echo "[7] Ingress health and token OFF"
curl -fsS --max-time 30 http://127.0.0.1/v8011/selftest.json -o "$TMP/ingress.json" || exit 1
python3 - "$TMP/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps({'ok':d.get('ok'),'operational_status':d.get('operational_status'),'queue_depth':d.get('queue_depth'),'backend_ok':d.get('backend_ok'),'worker_alive':d.get('worker_alive'),'token_mode':d.get('token_mode'),'token_configured':d.get('token_configured'),'token_enforced':d.get('token_enforced')},indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY

echo "[8] Critical routes"
for route in /health /master /master-ai-review /v8004/selftest.json /v8011/selftest.json /v8012/selftest-e.json /v8013/selftest-a.json /v8013/selftest-b.json /v8013/b-review-breakdown /v8013/score-gap-timing /v8013/score-gap-timing.json /v8013/stale-audit.json /v8013/queue-correlation.json; do
 code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 60 "http://127.0.0.1$route" 2>/dev/null || true)"
 printf '%-52s %s\n' "$route" "$code"
 [[ "$code" == "200" ]] || exit 1
done

echo "[9] Navigation"
curl -fsS --max-time 60 http://127.0.0.1/master -o "$TMP/master.html" || exit 1
curl -fsS --max-time 60 http://127.0.0.1/master-ai-review -o "$TMP/master-ai-review.html" || exit 1
grep -Fq '/v8013/score-gap-timing' "$TMP/master.html" || exit 1
grep -Fq '/v8013/score-gap-timing' "$TMP/master-ai-review.html" || exit 1
echo 'Master link: PASS'
echo 'AI Review link: PASS'

echo "[10] Host resources"
uptime
free -h
df -h /
echo "=== V8013B.1 CHECK FERTIG ==="
