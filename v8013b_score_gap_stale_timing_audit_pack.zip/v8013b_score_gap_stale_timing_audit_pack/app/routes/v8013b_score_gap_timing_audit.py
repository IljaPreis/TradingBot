from __future__ import annotations

import html
import json
import math
import sqlite3
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import mean
from typing import Any
from urllib.parse import quote

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8013B-SCORE-GAP-STALE-TIMING-AUDIT-OBSERVE-V1"
MODE = "read_only_score_gap_freshness_and_ingress_correlation"
MAX_ROWS = 20000
WINDOWS: dict[str, timedelta | None] = {
    "1h": timedelta(hours=1),
    "6h": timedelta(hours=6),
    "24h": timedelta(hours=24),
    "7d": timedelta(days=7),
    "all": None,
}
SAFETY = {
    "observe_only": True,
    "db_writes": False,
    "db_schema_changes": False,
    "routing_changes": False,
    "threshold_changes": False,
    "live_rule_changes": False,
    "image_deletion": False,
    "backup_deletion": False,
    "broker_auto_execution": False,
    "token_mode_changed": False,
}


def _root() -> Path:
    for p in (Path.cwd(), Path("/app"), Path("/opt/tradingbot_v6000")):
        try:
            if (p / "data").exists():
                return p
        except Exception:
            pass
    return Path.cwd()


def _learning_db() -> Path:
    return _root() / "data" / "v7000_learning.sqlite3"


def _queue_db() -> Path:
    return _root() / "data" / "v8011_ingress.sqlite3"


def _connect_ro(path: Path) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=4)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA busy_timeout=4000")
    return con


def _table_exists(con: sqlite3.Connection, table: str) -> bool:
    return con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone() is not None


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def _parse_dt(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _window(value: str) -> str:
    key = str(value or "24h").strip().lower()
    return key if key in WINDOWS else "24h"


def _cutoff(window: str) -> datetime | None:
    delta = WINDOWS[_window(window)]
    return _now() - delta if delta else None


def _num(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        number = float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None


def _bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value or "").strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off", ""}:
        return False
    return default


def _obj(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    try:
        parsed = json.loads(str(value or "{}"))
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def _list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    try:
        parsed = json.loads(str(value or "[]"))
        if isinstance(parsed, list):
            return [str(x).strip() for x in parsed if str(x).strip()]
    except Exception:
        pass
    text = str(value or "").strip()
    return [text] if text else []


def _confirmations(signal: dict[str, Any], decision: dict[str, Any]) -> list[str]:
    raw = decision.get("confirmations")
    if isinstance(raw, list):
        return [str(x).strip().upper() for x in raw if str(x).strip()]
    text = str(signal.get("confirmations_csv") or "")
    for sep in (";", "|"):
        text = text.replace(sep, ",")
    return [x.strip().upper() for x in text.split(",") if x.strip()]


def _load_config() -> dict[str, Any]:
    path = _root() / "data" / "v8004_quality_router_config.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _thresholds(cfg: dict[str, Any], playbook: str) -> dict[str, Any]:
    section = cfg.get("playbook_a", {}) if playbook.startswith("PLAYBOOK_A") else cfg.get("playbook_b", {})
    if not isinstance(section, dict):
        section = {}
    return {
        "a_plus_score": _num(section.get("a_plus_score")) or 76.0,
        "a_score": _num(section.get("a_score")) or 68.0,
        "b_score": _num(section.get("b_score")) or 58.0,
        "review_score": _num(section.get("review_score")) or 52.0,
        "a_plus_min_confirmations": int(_num(cfg.get("a_plus_min_confirmations")) or 3),
        "a_min_confirmations": int(_num(cfg.get("a_min_confirmations")) or 2),
        "a_plus_min_aligned_biases": int(_num(cfg.get("a_plus_min_aligned_biases")) or 3),
        "a_min_aligned_biases": int(_num(cfg.get("a_min_aligned_biases")) or 2),
        "require_fresh": bool(cfg.get("require_fresh", True)),
        "reject_chase": bool(cfg.get("reject_chase", True)),
    }


def _ms_between(a: Any, b: Any) -> float | None:
    first, second = _parse_dt(a), _parse_dt(b)
    if not first or not second:
        return None
    return round((second - first).total_seconds() * 1000.0, 2)


def _avg(values: list[float]) -> float | None:
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    return round(mean(vals), 2) if vals else None


def _max(values: list[float]) -> float | None:
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    return round(max(vals), 2) if vals else None


def _counter_rows(counter: Counter[str], limit: int = 15) -> list[dict[str, Any]]:
    return [{"name": k, "count": int(v)} for k, v in counter.most_common(limit)]


def _gap_bucket(gap: float | None) -> str:
    if gap is None:
        return "UNKNOWN"
    if gap < 10:
        return "<10"
    if gap < 25:
        return "10-24.99"
    if gap < 40:
        return "25-39.99"
    if gap < 55:
        return "40-54.99"
    return ">=55"


def _load_queue_map(cutoff: datetime | None) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    path = _queue_db()
    result: dict[str, dict[str, Any]] = {}
    meta = {"db_exists": path.exists(), "table_exists": False, "rows_scanned": 0, "parse_errors": 0}
    if not path.exists():
        return result, meta
    con: sqlite3.Connection | None = None
    try:
        con = _connect_ro(path)
        if not _table_exists(con, "v8011_ingress_queue"):
            return result, meta
        meta["table_exists"] = True
        sql = """
            SELECT event_id, payload_json, status, attempts, created_at, started_at,
                   processed_at, backend_status, backend_latency_ms
            FROM v8011_ingress_queue
            WHERE endpoint='/webhook/tradingview'
        """
        params: list[Any] = []
        if cutoff:
            sql += " AND datetime(created_at) >= datetime(?)"
            params.append(_iso(cutoff))
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(MAX_ROWS)
        rows = con.execute(sql, params).fetchall()
        meta["rows_scanned"] = len(rows)
        for row in rows:
            try:
                payload = _obj(row["payload_json"])
                signal_id = str(payload.get("signal_event_id") or payload.get("client_trade_id") or "").strip()
                if not signal_id or signal_id in result:
                    continue
                result[signal_id] = {
                    "event_id": row["event_id"],
                    "status": row["status"],
                    "attempts": int(row["attempts"] or 0),
                    "created_at": row["created_at"],
                    "started_at": row["started_at"],
                    "processed_at": row["processed_at"],
                    "backend_status": row["backend_status"],
                    "backend_latency_ms": _num(row["backend_latency_ms"]),
                    "queue_wait_ms": _ms_between(row["created_at"], row["started_at"]),
                    "ingress_total_ms": _ms_between(row["created_at"], row["processed_at"]),
                }
            except Exception:
                meta["parse_errors"] += 1
    except Exception as exc:
        meta["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        try:
            if con is not None:
                con.close()
        except Exception:
            pass
    return result, meta


def _query_rows(window: str) -> tuple[list[sqlite3.Row], dict[str, Any]]:
    path = _learning_db()
    meta = {"db_exists": path.exists(), "table_exists": False, "truncated": False}
    if not path.exists():
        return [], meta
    cutoff = _cutoff(window)
    con: sqlite3.Connection | None = None
    try:
        con = _connect_ro(path)
        if not _table_exists(con, "v8004_quality_router_log"):
            return [], meta
        meta["table_exists"] = True
        where = ""
        params: list[Any] = []
        if cutoff:
            where = "WHERE datetime(created_at) >= datetime(?)"
            params.append(_iso(cutoff))
        total = int(con.execute(f"SELECT COUNT(*) FROM v8004_quality_router_log {where}", params).fetchone()[0])
        meta["rows_available"] = total
        meta["truncated"] = total > MAX_ROWS
        rows = con.execute(
            f"""
            SELECT id, created_at, signal_event_id, client_trade_id, market, direction,
                   setup_name, playbook, pine_score, server_confidence, grade, route,
                   base_allow, final_allow, duplicate, reasons_json, blockers_json, raw_json
            FROM v8004_quality_router_log
            {where}
            ORDER BY id DESC
            LIMIT ?
            """,
            [*params, MAX_ROWS],
        ).fetchall()
        return rows, meta
    finally:
        if con is not None:
            con.close()


def build_audit(window: str = "24h", limit: int = 100) -> dict[str, Any]:
    selected = _window(window)
    cfg = _load_config()
    rows, db_meta = _query_rows(selected)
    queue_map, queue_meta = _load_queue_map(_cutoff(selected))

    grade_counts: Counter[str] = Counter()
    route_counts: Counter[str] = Counter()
    gap_buckets: Counter[str] = Counter()
    entry_quality_counts: Counter[str] = Counter()
    stale_quality_counts: Counter[str] = Counter()
    stale_market_counts: Counter[str] = Counter()
    stale_setup_counts: Counter[str] = Counter()
    a_gate_failures: Counter[str] = Counter()
    a_gate_by_market: dict[str, Counter[str]] = defaultdict(Counter)
    a_gate_by_setup: dict[str, Counter[str]] = defaultdict(Counter)
    timestamp_fields: Counter[str] = Counter()
    scores_pine: list[float] = []
    scores_server: list[float] = []
    gaps: list[float] = []
    queue_waits: list[float] = []
    backend_latencies: list[float] = []
    ingress_totals: list[float] = []
    ingress_to_router: list[float] = []
    latest: list[dict[str, Any]] = []

    b_review = 0
    stale = 0
    stale_valid = 0
    stale_late = 0
    stale_fresh = 0
    chase_or_late = 0
    queue_matches = 0
    source_timestamp_rows = 0
    base_gate_denied_b_review = 0

    for row in rows:
        raw = _obj(row["raw_json"])
        signal = raw.get("signal") if isinstance(raw.get("signal"), dict) else raw
        decision = raw.get("decision") if isinstance(raw.get("decision"), dict) else {}
        reasons = _list(row["reasons_json"])
        blockers = _list(row["blockers_json"])
        tokens = set(reasons + blockers)
        grade = str(row["grade"] or "UNKNOWN").upper()
        route = str(row["route"] or "UNKNOWN").upper()
        market = str(row["market"] or "UNKNOWN").upper()
        setup = str(row["setup_name"] or "UNKNOWN").upper()
        playbook = str(row["playbook"] or "UNKNOWN").upper()
        pine = _num(row["pine_score"])
        server = _num(row["server_confidence"])
        gap = (pine - server) if pine is not None and server is not None else None
        quality = str(signal.get("entry_quality") or signal.get("entry_state") or "UNKNOWN").upper()
        is_fresh = _bool(signal.get("is_fresh"), False)
        is_late = _bool(signal.get("is_late_entry"), False)
        is_chase = _bool(signal.get("is_chase"), False)
        confs = _confirmations(signal, decision)
        conf_count = int(_num(decision.get("confirmation_count")) or len(confs))
        aligned = int(_num(decision.get("aligned_bias_count")) or 0)
        opposing = int(_num(decision.get("opposing_bias_count")) or 0)
        thresholds = _thresholds(cfg, playbook)
        is_b_review = grade in {"B", "REVIEW"}

        grade_counts[grade] += 1
        route_counts[route] += 1
        gap_buckets[_gap_bucket(gap)] += 1
        entry_quality_counts[quality] += 1
        if pine is not None:
            scores_pine.append(pine)
        if server is not None:
            scores_server.append(server)
        if gap is not None:
            gaps.append(gap)

        if is_b_review:
            b_review += 1
            failures: list[str] = []
            if pine is None or pine < thresholds["a_score"]:
                failures.append("PINE_BELOW_A_SCORE")
            if conf_count < thresholds["a_min_confirmations"]:
                failures.append("CONFIRMATIONS_BELOW_A_MIN")
            if aligned < thresholds["a_min_aligned_biases"]:
                failures.append("ALIGNED_BIASES_BELOW_A_MIN")
            if opposing > 0:
                failures.append("OPPOSING_BIAS_PRESENT")
            if not bool(row["base_allow"]):
                failures.append("EXISTING_BASE_GATE_DENIED")
                base_gate_denied_b_review += 1
            if not failures:
                failures.append("A_GATE_OTHER_OR_BOUNDARY")
            for failure in failures:
                a_gate_failures[failure] += 1
                a_gate_by_market[market][failure] += 1
                a_gate_by_setup[setup][failure] += 1

        stale_flag = "V8004_STALE_SIGNAL" in tokens
        if stale_flag:
            stale += 1
            stale_quality_counts[quality] += 1
            stale_market_counts[market] += 1
            stale_setup_counts[setup] += 1
            if quality == "VALID" and not is_late and not is_chase:
                stale_valid += 1
            elif quality == "LATE" or is_late:
                stale_late += 1
            elif quality == "FRESH" or is_fresh:
                stale_fresh += 1
        if "V8004_CHASE_OR_LATE_ENTRY" in tokens:
            chase_or_late += 1

        timestamp_keys = [
            key for key in ("bar_time", "bar_time_utc", "signal_time", "event_time", "timestamp", "timenow", "time")
            if signal.get(key) not in (None, "")
        ]
        if timestamp_keys:
            source_timestamp_rows += 1
            timestamp_fields.update(timestamp_keys)

        sid = str(row["signal_event_id"] or row["client_trade_id"] or "").strip()
        q = queue_map.get(sid)
        if q:
            queue_matches += 1
            if q.get("queue_wait_ms") is not None:
                queue_waits.append(float(q["queue_wait_ms"]))
            if q.get("backend_latency_ms") is not None:
                backend_latencies.append(float(q["backend_latency_ms"]))
            if q.get("ingress_total_ms") is not None:
                ingress_totals.append(float(q["ingress_total_ms"]))
            router_ms = _ms_between(q.get("created_at"), row["created_at"])
            if router_ms is not None:
                ingress_to_router.append(router_ms)
        else:
            router_ms = None

        if len(latest) < max(1, min(int(limit), 300)):
            latest.append({
                "created_at": row["created_at"], "market": market, "direction": row["direction"],
                "setup": setup, "playbook": playbook, "grade": grade, "route": route,
                "pine": round(pine, 2) if pine is not None else None,
                "server": round(server, 2) if server is not None else None,
                "gap": round(gap, 2) if gap is not None else None,
                "confirmations": conf_count, "aligned_biases": aligned, "opposing_biases": opposing,
                "entry_quality": quality, "is_fresh": is_fresh, "is_late": is_late, "is_chase": is_chase,
                "stale_block": stale_flag, "queue_matched": bool(q),
                "queue_wait_ms": q.get("queue_wait_ms") if q else None,
                "backend_latency_ms": q.get("backend_latency_ms") if q else None,
                "ingress_to_router_ms": router_ms,
                "main_reason": (blockers + reasons + [""])[0],
            })

    def top_group(source: dict[str, Counter[str]]) -> list[dict[str, Any]]:
        scored = []
        for name, counter in source.items():
            scored.append({"name": name, "count": sum(counter.values()), "failures": _counter_rows(counter, 5)})
        return sorted(scored, key=lambda x: (-int(x["count"]), str(x["name"])))[:15]

    stale_valid_pct = round(stale_valid / stale * 100.0, 2) if stale else 0.0
    queue_match_pct = round(queue_matches / len(rows) * 100.0, 2) if rows else 0.0
    result = {
        "ok": bool(db_meta.get("table_exists")),
        "version": VERSION,
        "mode": MODE,
        "generated_utc": _iso(_now()),
        "window": selected,
        "available_windows": list(WINDOWS),
        "summary": {
            "evaluated": len(rows), "b_review": b_review,
            "grade_counts": dict(grade_counts), "route_counts": dict(route_counts),
            "avg_pine_score": _avg(scores_pine), "avg_server_confidence": _avg(scores_server),
            "avg_score_gap": _avg(gaps), "max_score_gap": _max(gaps),
            "stale_blocked": stale, "stale_with_valid_entry_quality": stale_valid,
            "stale_with_late_entry_quality": stale_late, "stale_with_fresh_entry_quality": stale_fresh,
            "stale_valid_share_percent": stale_valid_pct,
            "chase_or_late_blocked": chase_or_late,
            "base_gate_denied_b_review": base_gate_denied_b_review,
            "queue_matches": queue_matches, "queue_match_percent": queue_match_pct,
            "source_timestamp_rows": source_timestamp_rows,
        },
        "score_gap": {
            "buckets": _counter_rows(gap_buckets, 10),
            "important": "server_confidence is diagnostic in V8004 grading; B/REVIEW grade is determined by Pine score, confirmations and bias alignment. Existing base_allow affects LIVE eligibility separately.",
            "server_confidence_directly_used_for_v8004_grade": False,
            "existing_base_gate_can_affect_live_route": True,
        },
        "a_gate_failures_for_b_review": {
            "counts": _counter_rows(a_gate_failures, 15),
            "overlapping": True,
            "by_market": top_group(a_gate_by_market),
            "by_setup": top_group(a_gate_by_setup),
        },
        "freshness_audit": {
            "entry_quality_counts": _counter_rows(entry_quality_counts, 10),
            "stale_by_entry_quality": _counter_rows(stale_quality_counts, 10),
            "stale_top_markets": _counter_rows(stale_market_counts, 15),
            "stale_top_setups": _counter_rows(stale_setup_counts, 15),
            "v8004_stale_semantics": "V8004_STALE_SIGNAL is triggered when payload is_fresh is false. In Pine V8001.4D, is_fresh is true only for entry_quality FRESH; entry_quality VALID is therefore also rejected when require_fresh=true.",
            "is_wall_clock_age_measurement": False,
            "threshold_change_applied": False,
        },
        "ingress_timing": {
            "queue_db": queue_meta,
            "matched": queue_matches,
            "match_percent": queue_match_pct,
            "avg_queue_wait_ms": _avg(queue_waits), "max_queue_wait_ms": _max(queue_waits),
            "avg_backend_latency_ms": _avg(backend_latencies), "max_backend_latency_ms": _max(backend_latencies),
            "avg_ingress_total_ms": _avg(ingress_totals), "max_ingress_total_ms": _max(ingress_totals),
            "avg_ingress_to_v8004_log_ms": _avg(ingress_to_router),
            "source_timestamp_available_rows": source_timestamp_rows,
            "source_timestamp_fields": _counter_rows(timestamp_fields, 10),
            "network_transit_age_measurable": source_timestamp_rows > 0,
            "note": "Queue timing measures server ingress and backend processing. Exact TradingView-to-server transit age requires a source timestamp in the signal payload.",
        },
        "latest": latest,
        "config_snapshot": {
            "require_fresh": bool(cfg.get("require_fresh", True)),
            "reject_chase": bool(cfg.get("reject_chase", True)),
            "a_min_confirmations": int(_num(cfg.get("a_min_confirmations")) or 2),
            "a_min_aligned_biases": int(_num(cfg.get("a_min_aligned_biases")) or 2),
            "playbook_a": _thresholds(cfg, "PLAYBOOK_A_HTF_OB_REACTION"),
            "playbook_b": _thresholds(cfg, "PLAYBOOK_B_SESSION_MOMENTUM"),
        },
        "interpretation": {
            "score_gap_alone_explains_b_review": False,
            "stale_may_include_valid_distance_state": stale_valid > 0,
            "change_rules_now": False,
            "next_evidence_needed": "Compare closed Shadow outcomes for FRESH versus VALID versus LATE before changing require_fresh or chase rules.",
        },
        "db": db_meta,
        "safety": dict(SAFETY),
    }
    return result


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _token_ok(request: Request) -> bool:
    try:
        from app.v7200_event_risk import _token_ok as real_token_ok
        return bool(real_token_ok(request))
    except Exception:
        return True


def _suffix(token: str) -> str:
    return f"?token={quote(token)}" if token else ""


def _metric(label: str, value: Any, cls: str = "") -> str:
    return f"<div class='metric'><div class='label'>{_esc(label)}</div><div class='value {cls}'>{_esc(value)}</div></div>"


def _bars(rows: list[dict[str, Any]], total: int) -> str:
    if not rows:
        return "<div class='empty'>Keine Daten</div>"
    top = max([int(x.get("count") or 0) for x in rows] + [1])
    out = []
    for row in rows[:12]:
        count = int(row.get("count") or 0)
        pct = round(count / total * 100, 1) if total else 0.0
        out.append(f"<div class='barrow'><div class='barname'>{_esc(row.get('name'))}</div><div class='bartrack'><span style='width:{count/top*100:.1f}%'></span></div><div class='barcount'>{count} · {pct}%</div></div>")
    return "".join(out)


def _latest_table(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<div class='empty'>Keine Daten</div>"
    body = []
    for r in rows:
        body.append("<tr>" + "".join([
            f"<td>{_esc(str(r.get('created_at') or '')[11:19])}</td>",
            f"<td>{_esc(r.get('market'))}</td><td>{_esc(r.get('grade'))}</td><td>{_esc(r.get('route'))}</td>",
            f"<td>{_esc(r.get('pine'))}</td><td>{_esc(r.get('server'))}</td><td>{_esc(r.get('gap'))}</td>",
            f"<td>{_esc(r.get('confirmations'))}</td><td>{_esc(r.get('aligned_biases'))}/{_esc(r.get('opposing_biases'))}</td>",
            f"<td>{_esc(r.get('entry_quality'))}</td><td>{_esc(r.get('stale_block'))}</td>",
            f"<td>{_esc(r.get('queue_wait_ms'))}</td><td>{_esc(r.get('backend_latency_ms'))}</td>",
            f"<td>{_esc(r.get('main_reason'))}</td>",
        ]) + "</tr>")
    return "<div class='tablewrap'><table><thead><tr><th>Zeit</th><th>Markt</th><th>Grade</th><th>Route</th><th>Pine</th><th>Server</th><th>Gap</th><th>Conf</th><th>Bias A/O</th><th>Entry</th><th>Stale</th><th>Queue ms</th><th>Backend ms</th><th>Grund</th></tr></thead><tbody>" + "".join(body) + "</tbody></table></div>"


def page_html(data: dict[str, Any], token: str = "") -> str:
    s = data.get("summary") or {}
    fresh = data.get("freshness_audit") or {}
    gates = data.get("a_gate_failures_for_b_review") or {}
    timing = data.get("ingress_timing") or {}
    suffix = _suffix(token)
    tabs = []
    for w in WINDOWS:
        active = " active" if data.get("window") == w else ""
        sep = "&" if suffix else "?"
        tabs.append(f"<a class='tab{active}' href='/v8013/score-gap-timing{suffix}{sep}window={w}'>{w.upper()}</a>")
    return f"""<!doctype html><html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>V8013B Score Gap & Timing</title><style>
:root{{--bg:#07111e;--panel:#101d2e;--panel2:#0b1728;--line:#273a52;--text:#eef6ff;--muted:#9caec4;--green:#22c55e;--yellow:#facc15;--red:#f87171;--blue:#93c5fd}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Arial,sans-serif}}a{{color:var(--blue)}}.wrap{{max-width:1500px;margin:auto;padding:10px}}.hero,.panel{{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:14px;margin:10px 0}}h1{{margin:0 0 6px;font-size:29px}}h2{{font-size:20px;margin:0 0 10px}}.muted{{color:var(--muted);line-height:1.45}}.nav,.tabs{{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}}.nav a,.tab{{text-decoration:none;padding:8px 10px;background:var(--panel2);border:1px solid var(--line);border-radius:10px;font-weight:800}}.tab.active{{border-color:#4c8fd8;background:#15314e}}.metrics{{display:grid;grid-template-columns:repeat(6,minmax(105px,1fr));gap:8px}}.metric{{background:var(--panel2);border:1px solid var(--line);border-radius:13px;padding:11px}}.label{{font-size:10px;color:var(--muted);text-transform:uppercase}}.value{{font-size:24px;font-weight:900;margin-top:4px}}.warn{{color:var(--yellow)}}.bad{{color:var(--red)}}.good{{color:var(--green)}}.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}.notice{{border-left:4px solid var(--yellow);line-height:1.5}}.barrow{{display:grid;grid-template-columns:minmax(150px,1.4fr) 2fr 100px;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid #203147}}.barname{{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}.bartrack{{height:9px;background:#07111e;border-radius:9px;overflow:hidden}}.bartrack span{{display:block;height:100%;background:#4c8fd8}}.barcount{{text-align:right;font-weight:800;font-size:12px}}.tablewrap{{overflow:auto;border:1px solid var(--line);border-radius:12px}}table{{width:100%;border-collapse:collapse;font-size:11px}}th,td{{padding:8px;border-bottom:1px solid var(--line);white-space:nowrap;text-align:left}}th{{color:#a5d8ff;background:#0b1728;position:sticky;top:0}}.pill{{display:inline-block;padding:5px 8px;border:1px solid var(--line);border-radius:999px;font-size:11px;font-weight:800;margin:3px}}.empty{{color:var(--muted);padding:10px}}@media(max-width:1000px){{.metrics{{grid-template-columns:repeat(3,1fr)}}.grid2{{grid-template-columns:1fr}}}}@media(max-width:620px){{.metrics{{grid-template-columns:repeat(2,1fr)}}h1{{font-size:25px}}.barrow{{grid-template-columns:minmax(120px,1fr) 1fr 84px}}}}
</style></head><body><div class='wrap'><div class='hero'><h1>V8013B Score-Gap & Freshness Audit</h1><div class='muted'>Read-only Diagnose: Was erzeugt B/Review wirklich, was bedeutet STALE_SIGNAL, und ist die V8011-Queue langsam?</div><div class='nav'><a href='/master{suffix}'>Master</a><a href='/master-ai-review{suffix}'>AI Review</a><a href='/v8013/b-review-breakdown{suffix}'>B/Review</a><a href='/v8013/score-gap-timing.json{suffix}'>JSON</a><a href='/v8013/selftest-b.json{suffix}'>Selftest</a></div><div class='tabs'>{''.join(tabs)}</div></div>
<div class='metrics'>{_metric('Ausgewertet',s.get('evaluated'))}{_metric('B/Review',s.get('b_review'),'warn')}{_metric('Gap Ø',s.get('avg_score_gap'))}{_metric('Stale',s.get('stale_blocked'),'bad')}{_metric('Stale aber VALID',s.get('stale_with_valid_entry_quality'),'warn')}{_metric('Chase/Late',s.get('chase_or_late_blocked'),'bad')}{_metric('Queue-Matches',s.get('queue_matches'))}{_metric('Queue Ø ms',timing.get('avg_queue_wait_ms'),'good')}{_metric('Backend Ø ms',timing.get('avg_backend_latency_ms'),'good')}{_metric('Ingress→Router Ø',timing.get('avg_ingress_to_v8004_log_ms'))}{_metric('Pine Ø',s.get('avg_pine_score'))}{_metric('Server Ø',s.get('avg_server_confidence'))}</div>
<div class='panel notice'><b>Wichtig:</b> Der Pine/Server-Gap allein macht kein B/Review. V8004 vergibt B/REVIEW anhand von Pine-Score, Bestätigungen und Bias-Ausrichtung. <b>STALE_SIGNAL</b> ist außerdem keine gemessene Netzwerkverspätung: Es wird ausgelöst, wenn <code>is_fresh=false</code>. V8001.4D setzt <code>is_fresh</code> nur bei Entry-Qualität FRESH; auch VALID kann dadurch als STALE blockiert werden. Regeln bleiben unverändert.</div>
<div class='grid2'><div class='panel'><h2>Warum B/Review nicht A wurde</h2>{_bars(gates.get('counts') or [], int(s.get('b_review') or 0))}</div><div class='panel'><h2>Stale nach Entry-Qualität</h2>{_bars(fresh.get('stale_by_entry_quality') or [], int(s.get('stale_blocked') or 0))}</div><div class='panel'><h2>Alle Entry-Qualitäten</h2>{_bars(fresh.get('entry_quality_counts') or [], int(s.get('evaluated') or 0))}</div><div class='panel'><h2>Stale – häufigste Märkte</h2>{_bars(fresh.get('stale_top_markets') or [], int(s.get('stale_blocked') or 0))}</div></div>
<div class='panel'><h2>Neueste Signale mit Queue-Korrelation</h2>{_latest_table(data.get('latest') or [])}</div>
<div class='panel muted'><span class='pill'>READ ONLY</span><span class='pill'>DB WRITES 0</span><span class='pill'>ROUTING CHANGES 0</span><span class='pill'>THRESHOLDS 0</span><span class='pill'>TOKEN OFF</span><span class='pill'>BROKER FALSE</span><br><br>Queue-Match: {_esc(timing.get('matched'))} · Source-Timestamp-Zeilen: {_esc(timing.get('source_timestamp_available_rows'))} · Generated: {_esc(data.get('generated_utc'))}</div></div></body></html>"""


def selftest_payload(app) -> dict[str, Any]:
    required = {
        ("GET", "/v8013/score-gap-timing"),
        ("GET", "/v8013/score-gap-timing.json"),
        ("GET", "/v8013/stale-audit.json"),
        ("GET", "/v8013/queue-correlation.json"),
        ("GET", "/v8013/selftest-b.json"),
    }
    counts: Counter[tuple[str, str]] = Counter()
    for route in getattr(app, "routes", []):
        path = str(getattr(route, "path", "") or "")
        for method in set(getattr(route, "methods", set()) or set()):
            counts[(str(method).upper(), path)] += 1
    missing = sorted(f"{m} {p}" for m, p in required if counts[(m, p)] == 0)
    duplicates = sorted(f"{m} {p}" for m, p in required if counts[(m, p)] > 1)
    sample = build_audit("24h", 5)
    return {
        "ok": not missing and not duplicates and bool(sample.get("ok")),
        "version": VERSION, "mode": MODE,
        "missing_routes": missing, "duplicate_routes": duplicates,
        "table_exists": bool((sample.get("db") or {}).get("table_exists")),
        "evaluated_24h": (sample.get("summary") or {}).get("evaluated"),
        "b_review_24h": (sample.get("summary") or {}).get("b_review"),
        "stale_24h": (sample.get("summary") or {}).get("stale_blocked"),
        "stale_valid_24h": (sample.get("summary") or {}).get("stale_with_valid_entry_quality"),
        "queue_matches_24h": (sample.get("summary") or {}).get("queue_matches"),
        "safety": dict(SAFETY),
    }


def install_v8013b_score_gap_timing_audit(app) -> None:
    if getattr(app.state, "v8013b_score_gap_timing_installed", False):
        return

    @app.get("/v8013/score-gap-timing", response_class=HTMLResponse)
    def v8013b_page(request: Request, window: str = "24h", limit: int = 100):
        if not _token_ok(request):
            return HTMLResponse("unauthorized", status_code=401)
        return HTMLResponse(page_html(build_audit(window, limit), request.query_params.get("token", "")))

    @app.get("/v8013/score-gap-timing.json")
    def v8013b_json(request: Request, window: str = "24h", limit: int = 100):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(build_audit(window, limit))

    @app.get("/v8013/stale-audit.json")
    def v8013b_stale(request: Request, window: str = "24h"):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        data = build_audit(window, 30)
        return JSONResponse({"ok": data.get("ok"), "version": VERSION, "window": data.get("window"), "summary": data.get("summary"), "freshness_audit": data.get("freshness_audit"), "config_snapshot": data.get("config_snapshot"), "safety": data.get("safety")})

    @app.get("/v8013/queue-correlation.json")
    def v8013b_queue(request: Request, window: str = "24h"):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        data = build_audit(window, 30)
        return JSONResponse({"ok": data.get("ok"), "version": VERSION, "window": data.get("window"), "summary": data.get("summary"), "ingress_timing": data.get("ingress_timing"), "safety": data.get("safety")})

    @app.get("/v8013/selftest-b.json")
    def v8013b_selftest(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(selftest_payload(app))

    app.state.v8013b_score_gap_timing_installed = True
    print("[V8013B] Score-gap, freshness and ingress timing audit installed (read-only)")
