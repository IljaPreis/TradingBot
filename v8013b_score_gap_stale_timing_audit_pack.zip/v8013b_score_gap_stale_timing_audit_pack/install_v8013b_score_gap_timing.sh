#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="V8013B-SCORE-GAP-STALE-TIMING-AUDIT-OBSERVE-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8013b_before_$STAMP"
LOG="/root/v8013b_install_$STAMP.log"
BUILD_LOG="/root/v8013b_build_$STAMP.log"
TMP_DIR="$(mktemp -d)"
ROLLBACK_ARMED=0

exec > >(tee -a "$LOG") 2>&1

die(){ echo "ERROR: $*" >&2; return 1; }
sha(){ sha256sum "$1" | awk '{print $1}'; }
wait_http_200(){
  local url="$1" tries="${2:-75}" sleep_s="${3:-2}" code i
  for i in $(seq 1 "$tries"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 10 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    if [[ "$i" == "1" || $((i % 5)) -eq 0 ]]; then echo "WAIT [$i/$tries] $url status=$code"; fi
    sleep "$sleep_s"
  done
  return 1
}

rollback(){
  local rc="${1:-1}"
  set +e
  echo "=== V8013B ROLLBACK START ==="
  if [[ -d "$BACKUP" ]]; then
    [[ -f "$BACKUP/main.py" ]] && cp -a "$BACKUP/main.py" "$BASE/app/main.py"
    [[ -f "$BACKUP/v8003_master_navigation.py" ]] && cp -a "$BACKUP/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
    [[ -f "$BACKUP/docker-compose.yml" ]] && cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml"
    [[ -f "$BACKUP/.env" ]] && cp -a "$BACKUP/.env" "$BASE/.env" && chmod 600 "$BASE/.env"
    if [[ -f "$BACKUP/dockerignore_was_present" ]]; then
      [[ -f "$BACKUP/.dockerignore" ]] && cp -a "$BACKUP/.dockerignore" "$BASE/.dockerignore"
    else
      rm -f "$BASE/.dockerignore"
    fi
  fi
  rm -f "$BASE/app/routes/v8013b_score_gap_timing_audit.py"
  rm -f "$BASE/ops/v8013_score_gap_check.sh" "$BASE/ops/v8013b_storage_dry_run.py"
  rm -f "$BASE/README_V8013B.md" "$BASE/STATIC_AUDIT_V8013B.json"
  rm -f "$BASE/data/v8013b_storage_dry_run.json"
  cd "$BASE" || true
  docker compose build tradingbot || true
  docker compose up -d --force-recreate --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8013B ROLLBACK ENDE ==="
  rm -rf "$TMP_DIR"
  exit "$rc"
}

on_error(){
  local rc=$?
  if [[ "$ROLLBACK_ARMED" == "1" ]]; then rollback "$rc"; fi
  rm -rf "$TMP_DIR"
  exit "$rc"
}
trap on_error ERR

EXPECTED_MAIN="bc54d0ca28843aa44f4aef0173da936bb2271b094b6950cc129405382c1c92f3"
EXPECTED_NAV="b9d5ef3c35683be54bf7f9429e14710c74e571d32a2c3a243a75ac68f3d60c70"
EXPECTED_COMPOSE="be820aff788cf96a1242c51e3d826023f940498d4b65302abe296ad0f82d1bc7"
EXPECTED_V8013A="f7894e681d858cf70414616b37f8c09c4dce5906715f69f3f447b8934aa23689"
EXPECTED_V8012E="c8a37f938e0d0f44a7df7b64f75edfe27c59be55b2046d8c9264641baafd0db4"
EXPECTED_V8012D="d2b5d8c0d0ee5d8dadf26bf025f1c994fd217b52ca801b02346ff0849d0c9d28"
EXPECTED_INGRESS="0b50a8dcce8e0f2ef71dead1d5489bdd1c915b932acefa166eec656828806c8b"
EXPECTED_V8004="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

echo "================================================================================"
echo "$VERSION INSTALL"
echo "================================================================================"
echo "Generated UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"
echo "Project: $BASE"
echo "Package: $PACKAGE_DIR"
echo "Scope:"
echo "  Pine/server score-gap explanation: ADD"
echo "  B/Review A-gate failure decomposition: ADD"
echo "  FRESH / VALID / LATE semantics audit: ADD"
echo "  V8011 ingress queue correlation: ADD"
echo "  Conservative .dockerignore before build: ADD"
echo "  Storage cleanup: DRY RUN ONLY"
echo "Safety:"
echo "  DB writes/schema changes: 0"
echo "  V8004/V8006/V8007 changes: 0"
echo "  Canonical Pine changes: 0"
echo "  Threshold/routing changes: 0"
echo "  Files/images/backups deleted: 0"
echo "  Token mode: OFF"
echo "  Broker auto execution: FALSE"

[[ -d "$BASE/app" && -d "$BASE/data" ]] || die "Project structure missing"
[[ -f "$PACKAGE_DIR/MANIFEST.sha256" ]] || die "Package manifest missing"

echo "[1] Verify package hashes and static audit"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)
python3 - "$PACKAGE_DIR/STATIC_AUDIT.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
assert d.get('version')=='V8013B-SCORE-GAP-STALE-TIMING-AUDIT-OBSERVE-V1'
local=d.get('local_validation') or {}; safe=d.get('safety') or {}
assert local.get('python_compile') is True
assert local.get('full_app_import') is True
assert local.get('duplicate_v8013b_routes')==0
for key in ('db_writes','db_schema_changes','routing_changes','threshold_changes','live_rule_changes','image_deletion','backup_deletion','file_deletion','token_mode_changed','broker_auto_execution'):
    assert safe.get(key) is False,(key,safe.get(key))
print('Static audit: PASS')
PY

echo "[2] Verify production baseline"
for pair in \
 "$BASE/app/main.py|$EXPECTED_MAIN|main.py" \
 "$BASE/app/v8003_master_navigation.py|$EXPECTED_NAV|V8003 nav" \
 "$BASE/docker-compose.yml|$EXPECTED_COMPOSE|compose" \
 "$BASE/app/routes/v8013a_b_review_breakdown.py|$EXPECTED_V8013A|V8013A" \
 "$BASE/app/routes/v8012e_dashboard_extraction.py|$EXPECTED_V8012E|V8012E" \
 "$BASE/app/routes/v8012d_dashboard_extraction.py|$EXPECTED_V8012D|V8012D" \
 "$BASE/app/v8011_ingress.py|$EXPECTED_INGRESS|ingress" \
 "$BASE/app/v8004_quality_router.py|$EXPECTED_V8004|V8004" \
 "$BASE/app/v8006_calendar_execution_correction.py|$EXPECTED_V8006|V8006" \
 "$BASE/app/v8007_v8001_gate_bridge.py|$EXPECTED_V8007|V8007" \
 "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine|$EXPECTED_PINE|Pine"; do
 IFS='|' read -r file expected label <<<"$pair"
 actual="$(sha "$file")"
 echo "$label: $actual"
 [[ "$actual" == "$expected" ]] || die "$label baseline mismatch"
done
[[ ! -e "$BASE/app/routes/v8013b_score_gap_timing_audit.py" ]] || die "V8013B module already exists"

echo "[3] Create rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/app/main.py" "$BACKUP/main.py"
cp -a "$BASE/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/.env" "$BACKUP/.env"
chmod 600 "$BACKUP/.env"
if [[ -f "$BASE/.dockerignore" ]]; then
  touch "$BACKUP/dockerignore_was_present"
  cp -a "$BASE/.dockerignore" "$BACKUP/.dockerignore"
fi
ROLLBACK_ARMED=1

echo "[4] Keep webhook token fully OFF"
python3 - <<'PY'
from pathlib import Path
p=Path('/opt/tradingbot_v6000/.env')
lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
changes={'V8011_TOKEN_MODE':'off','V8011_ENFORCE_TOKEN':'false','V8011_WEBHOOK_TOKEN':''}
out=[]; seen=set()
for line in lines:
    if '=' not in line or line.lstrip().startswith('#'):
        out.append(line); continue
    key=line.split('=',1)[0].strip()
    if key in changes:
        if key not in seen: out.append(f"{key}={changes[key]}"); seen.add(key)
    else: out.append(line)
for key,value in changes.items():
    if key not in seen: out.append(f"{key}={value}")
p.write_text('\n'.join(out).rstrip()+'\n',encoding='utf-8')
print('token_mode: off')
print('token_configured: false')
print('token_enforced: false')
PY
chmod 600 "$BASE/.env"

echo "[5] Install V8013B files and safe .dockerignore"
install -m 0644 "$PACKAGE_DIR/app/main.py" "$BASE/app/main.py"
install -m 0644 "$PACKAGE_DIR/app/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
install -m 0644 "$PACKAGE_DIR/app/routes/v8013b_score_gap_timing_audit.py" "$BASE/app/routes/v8013b_score_gap_timing_audit.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8013b.yml" "$BASE/docker-compose.yml"
install -m 0644 "$PACKAGE_DIR/.dockerignore.v8013b" "$BASE/.dockerignore"
install -m 0755 "$PACKAGE_DIR/ops/v8013_score_gap_check.sh" "$BASE/ops/v8013_score_gap_check.sh"
install -m 0755 "$PACKAGE_DIR/ops/v8013b_storage_dry_run.py" "$BASE/ops/v8013b_storage_dry_run.py"
install -m 0644 "$PACKAGE_DIR/README_V8013B.md" "$BASE/README_V8013B.md"
install -m 0644 "$PACKAGE_DIR/STATIC_AUDIT.json" "$BASE/STATIC_AUDIT_V8013B.json"
python3 -m py_compile "$BASE/app/main.py" "$BASE/app/v8003_master_navigation.py" "$BASE/app/routes/v8013b_score_gap_timing_audit.py" "$BASE/ops/v8013b_storage_dry_run.py"

echo "[6] Verify protected hashes remain unchanged"
[[ "$(sha "$BASE/app/routes/v8013a_b_review_breakdown.py")" == "$EXPECTED_V8013A" ]] || die "V8013A changed"
[[ "$(sha "$BASE/app/routes/v8012e_dashboard_extraction.py")" == "$EXPECTED_V8012E" ]] || die "V8012E changed"
[[ "$(sha "$BASE/app/routes/v8012d_dashboard_extraction.py")" == "$EXPECTED_V8012D" ]] || die "V8012D changed"
[[ "$(sha "$BASE/app/v8011_ingress.py")" == "$EXPECTED_INGRESS" ]] || die "Ingress changed"
[[ "$(sha "$BASE/app/v8004_quality_router.py")" == "$EXPECTED_V8004" ]] || die "V8004 changed"
[[ "$(sha "$BASE/app/v8006_calendar_execution_correction.py")" == "$EXPECTED_V8006" ]] || die "V8006 changed"
[[ "$(sha "$BASE/app/v8007_v8001_gate_bridge.py")" == "$EXPECTED_V8007" ]] || die "V8007 changed"
[[ "$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")" == "$EXPECTED_PINE" ]] || die "Pine changed"

echo "[7] Build V8013B image with optimized context"
cd "$BASE"
docker compose config >/dev/null
set -o pipefail
docker compose build tradingbot 2>&1 | tee "$BUILD_LOG"
echo "Build context lines:"
grep -E 'transferring context:' "$BUILD_LOG" | tail -n 5 || true

echo "[8] Start backend + ingress"
docker compose up -d --force-recreate --remove-orphans
wait_http_200 http://127.0.0.1/health 75 2 || die "Public health did not become ready"

echo "[9] Generate storage cleanup dry-run – no deletion"
python3 "$BASE/ops/v8013b_storage_dry_run.py" -o /dev/null || die "Storage dry-run failed"

echo "[10] Validate V8013B selftest and live data"
curl -fsS --max-time 90 http://127.0.0.1/v8013/selftest-b.json -o "$TMP_DIR/selftest.json"
curl -fsS --max-time 90 'http://127.0.0.1/v8013/score-gap-timing.json?window=all&limit=10' -o "$TMP_DIR/data.json"
python3 - "$TMP_DIR/selftest.json" "$TMP_DIR/data.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:s=json.load(f)
with open(sys.argv[2],encoding='utf-8') as f:d=json.load(f)
summary=d.get('summary') or {}; timing=d.get('ingress_timing') or {}; gap=d.get('score_gap') or {}; fresh=d.get('freshness_audit') or {}; safe=d.get('safety') or {}
print(json.dumps({
 'selftest_ok':s.get('ok'),'version':s.get('version'),'missing_routes':s.get('missing_routes'),'duplicate_routes':s.get('duplicate_routes'),
 'evaluated_all':summary.get('evaluated'),'b_review_all':summary.get('b_review'),'avg_gap':summary.get('avg_score_gap'),
 'stale_all':summary.get('stale_blocked'),'stale_valid_all':summary.get('stale_with_valid_entry_quality'),
 'queue_matches':timing.get('matched'),'avg_queue_wait_ms':timing.get('avg_queue_wait_ms'),'avg_backend_latency_ms':timing.get('avg_backend_latency_ms'),
 'server_confidence_directly_used_for_grade':gap.get('server_confidence_directly_used_for_v8004_grade'),
 'threshold_change_applied':fresh.get('threshold_change_applied'),'db_writes':safe.get('db_writes'),'routing_changes':safe.get('routing_changes'),'threshold_changes':safe.get('threshold_changes')
},indent=2))
assert s.get('ok') is True
assert s.get('version')=='V8013B-SCORE-GAP-STALE-TIMING-AUDIT-OBSERVE-V1'
assert not (s.get('missing_routes') or [])
assert not (s.get('duplicate_routes') or [])
assert d.get('ok') is True
assert gap.get('server_confidence_directly_used_for_v8004_grade') is False
assert fresh.get('threshold_change_applied') is False
assert safe.get('db_writes') is False
assert safe.get('routing_changes') is False
assert safe.get('threshold_changes') is False
assert safe.get('image_deletion') is False
assert safe.get('backup_deletion') is False
assert safe.get('broker_auto_execution') is False
PY

echo "[11] Critical route status"
for route in /health /master /master-ai-review /v8004/selftest.json /v8006/selftest.json /v8007/selftest.json /v8011/selftest.json /v8012/selftest-e.json /v8013/selftest-a.json /v8013/selftest-b.json /v8013/b-review-breakdown /v8013/score-gap-timing /v8013/score-gap-timing.json /v8013/stale-audit.json /v8013/queue-correlation.json; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 90 "http://127.0.0.1$route" 2>/dev/null || true)"
  printf '%-54s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Route failed: $route status=$code"
done

echo "[12] Navigation"
curl -fsS --max-time 90 http://127.0.0.1/master | grep -q "V8013 Score-Gap & Freshness Audit" || die "Master link missing"
curl -fsS --max-time 90 http://127.0.0.1/master-ai-review | grep -q "V8013 Score-Gap & Freshness Audit" || die "AI Review link missing"
echo "Master link: PASS"
echo "AI Review link: PASS"

echo "[13] Token OFF and ingress health"
curl -fsS --max-time 30 http://127.0.0.1/v8011/selftest.json -o "$TMP_DIR/ingress.json"
python3 - "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps({'ok':d.get('ok'),'operational_status':d.get('operational_status'),'queue_depth':d.get('queue_depth'),'backend_ok':d.get('backend_ok'),'worker_alive':d.get('worker_alive'),'token_mode':d.get('token_mode'),'token_configured':d.get('token_configured'),'token_enforced':d.get('token_enforced')},indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY

echo "[14] Final protected hashes"
sha256sum "$BASE/app/routes/v8013a_b_review_breakdown.py" "$BASE/app/routes/v8012e_dashboard_extraction.py" "$BASE/app/routes/v8012d_dashboard_extraction.py" "$BASE/app/v8011_ingress.py" "$BASE/app/v8004_quality_router.py" "$BASE/app/v8006_calendar_execution_correction.py" "$BASE/app/v8007_v8001_gate_bridge.py" "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"

echo "[15] Containers"
docker compose ps
ROLLBACK_ARMED=0
rm -rf "$TMP_DIR"
trap - ERR
cat <<EOF
================================================================================
V8013B INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Build log: $BUILD_LOG
Dashboard:    http://91.107.237.214/v8013/score-gap-timing
JSON:         http://91.107.237.214/v8013/score-gap-timing.json
Stale audit:  http://91.107.237.214/v8013/stale-audit.json
Queue audit:  http://91.107.237.214/v8013/queue-correlation.json
Selftest:     http://91.107.237.214/v8013/selftest-b.json
COMPLETED:
  Pine/server score gap separated from actual V8004 grade logic
  B/Review A-gate failure reasons decomposed
  FRESH / VALID / LATE semantics audited
  STALE_SIGNAL distinguished from network timing
  V8011 queue and backend times correlated by signal event ID
  Conservative .dockerignore installed before build
  Storage cleanup candidate report generated
CLEANUP SAFETY:
  Automatic cleanup FALSE
  Files deleted 0
  Images deleted 0
  Backups deleted 0
UNCHANGED:
  V8004 / V8006 / V8007
  Canonical Pine
  V8011 ingress/queue/dead-letter
  Existing trading DB schema and rows
  Live scoring/routing and thresholds
  Token OFF
  Broker auto execution FALSE
EOF
