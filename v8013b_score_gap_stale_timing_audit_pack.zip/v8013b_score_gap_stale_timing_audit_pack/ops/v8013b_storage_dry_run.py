#!/usr/bin/env python3
from __future__ import annotations
import json, shutil, subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path('/opt/tradingbot_v6000')
OUT=ROOT/'data'/'v8013b_storage_dry_run.json'

def run(args):
    try:
        return subprocess.run(args,text=True,capture_output=True,check=False).stdout.strip()
    except Exception:
        return ''

def size(path):
    total=0
    try:
        for p in path.rglob('*'):
            try:
                if p.is_file(): total += p.stat().st_size
            except Exception: pass
    except Exception: pass
    return total

usage=shutil.disk_usage(ROOT)
images=[]
for line in run(['docker','image','ls','--format','{{.Repository}}|{{.Tag}}|{{.ID}}|{{.Size}}']).splitlines():
    parts=line.split('|',3)
    if len(parts)==4 and parts[0]=='tradingbot_v6000-app':
        images.append({'repository':parts[0],'tag':parts[1],'id':parts[2],'size_display':parts[3]})
keep={'v8013b','v8013a','v8012e'}
for x in images:
    x['keep']=x['tag'] in keep
    x['cleanup_candidate']=not x['keep']
result={
 'ok':True,'version':'V8013B-SCORE-GAP-STALE-TIMING-AUDIT-OBSERVE-V1',
 'generated_utc':datetime.now(timezone.utc).isoformat(),
 'disk_used_percent':round(usage.used/usage.total*100,2),
 'backup_count':sum(1 for p in (ROOT/'backups').glob('*')) if (ROOT/'backups').exists() else 0,
 'backup_total_mib':round(size(ROOT/'backups')/1024/1024,2),
 'dockerignore_present':(ROOT/'.dockerignore').exists(),
 'dockerignore_sha256':run(['sha256sum',str(ROOT/'.dockerignore')]).split(' ')[0] if (ROOT/'.dockerignore').exists() else None,
 'tradingbot_images':images,
 'cleanup_candidate_count':sum(1 for x in images if x['cleanup_candidate']),
 'keep_tags':sorted(keep),
 'automatic_cleanup':False,'deletion_performed':False,'images_deleted':0,'backups_deleted':0,'files_deleted':0,
}
OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2,ensure_ascii=False))
