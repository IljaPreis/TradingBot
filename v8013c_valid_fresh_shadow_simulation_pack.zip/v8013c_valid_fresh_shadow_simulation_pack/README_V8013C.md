# V8013C – VALID/FRESH Shadow Simulation

Version: `V8013C-VALID-FRESH-SHADOW-SIMULATION-V1`

V8013C beantwortet read-only die Frage, welche historischen `NO_TRADE`-Signale nur deshalb blockiert wurden, weil `entry_quality=VALID` in der bestehenden V8004-Konfiguration nicht als `is_fresh=true` gilt.

## Simulationsregel

Nur Datensätze mit allen folgenden Eigenschaften sind Kandidaten:

- `V8004_STALE_SIGNAL` vorhanden
- `entry_quality=VALID`
- `is_late_entry=false`
- `is_chase=false`

Für diese Datensätze wird ausschließlich `V8004_STALE_SIGNAL` aus der kopierten Blocker-Liste entfernt. Alle anderen Blocker, das bestehende Base-Gate, Pine-Scores, Bestätigungen, Bias-Zählungen und V8004-Schwellen bleiben unverändert.

Das Dashboard berechnet danach theoretische Grade und Routen mit den bestehenden V8004-Werten. Ein theoretisches `LIVE` ist nur Diagnose. V8013C öffnet keinen Trade und verändert keine Route.

## Seiten

- `/v8013/valid-fresh-simulation`
- `/v8013/valid-fresh-simulation.json`
- `/v8013/valid-rescues.json`
- `/v8013/valid-outcomes.json`
- `/v8013/selftest-c.json`

## Outcome-Abdeckung

V8013C sucht read-only nach bereits vorhandenen geschlossenen Ergebnissen in:

- `shadow_outcomes`
- `v7245a_trade_excursions`

Da echte `NO_TRADE`-Signale normalerweise keinen Shadow-Trade erzeugt haben, kann die historische Outcome-Abdeckung gering sein. Das wird ausdrücklich ausgewiesen; fehlende Performance wird nicht geschätzt.

## Sicherheit

- keine Datenbank-Schreibvorgänge
- keine Schemaänderungen
- keine V8004-/V8006-/V8007-Änderung
- keine Pine-Änderung
- keine Threshold-Änderung
- keine Live-Routing-Änderung
- keine historischen Trades
- Token bleibt aus
- Broker Auto Execution bleibt false
