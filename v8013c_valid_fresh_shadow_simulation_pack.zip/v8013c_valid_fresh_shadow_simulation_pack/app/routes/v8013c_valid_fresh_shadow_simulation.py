from __future__ import annotations

import html
import json
import math
import sqlite3
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import mean
from typing import Any
from urllib.parse import quote

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8013C-VALID-FRESH-SHADOW-SIMULATION-V1"
MODE = "read_only_valid_vs_fresh_counterfactual"
MAX_ROWS = 20000
WINDOWS: dict[str, timedelta | None] = {
    "1h": timedelta(hours=1),
    "6h": timedelta(hours=6),
    "24h": timedelta(hours=24),
    "7d": timedelta(days=7),
    "all": None,
}
REQUIRED_ROUTES = (
    "/v8013/valid-fresh-simulation",
    "/v8013/valid-fresh-simulation.json",
    "/v8013/valid-rescues.json",
    "/v8013/valid-outcomes.json",
    "/v8013/selftest-c.json",
)
SAFETY = {
    "observe_only": True,
    "db_writes": False,
    "db_schema_changes": False,
    "routing_changes": False,
    "threshold_changes": False,
    "live_rule_changes": False,
    "historical_trade_creation": False,
    "broker_auto_execution": False,
    "token_mode_changed": False,
}


def _root() -> Path:
    for p in (Path.cwd(), Path("/app"), Path("/opt/tradingbot_v6000")):
        try:
            if (p / "data").exists():
                return p
        except Exception:
            pass
    return Path.cwd()


def _db() -> Path:
    return _root() / "data" / "v7000_learning.sqlite3"


def _connect_ro(path: Path) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=5)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA busy_timeout=5000")
    return con


def _table_exists(con: sqlite3.Connection, table: str) -> bool:
    return con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone() is not None


def _columns(con: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in con.execute(f'PRAGMA table_info("{table}")')}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def _window(value: str) -> str:
    key = str(value or "24h").strip().lower()
    return key if key in WINDOWS else "24h"


def _cutoff(window: str) -> datetime | None:
    delta = WINDOWS[_window(window)]
    return _now() - delta if delta else None


def _num(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        number = float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None


def _int(value: Any, default: int = 0) -> int:
    number = _num(value)
    return int(number) if number is not None else int(default)


def _bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value or "").strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off", ""}:
        return False
    return default


def _obj(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    try:
        parsed = json.loads(str(value or "{}"))
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def _list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    try:
        parsed = json.loads(str(value or "[]"))
        if isinstance(parsed, list):
            return [str(x).strip() for x in parsed if str(x).strip()]
    except Exception:
        pass
    text = str(value or "").strip()
    return [text] if text else []


def _confirmations(signal: dict[str, Any], decision: dict[str, Any]) -> list[str]:
    raw = decision.get("confirmations")
    if isinstance(raw, list):
        return [str(x).strip().upper() for x in raw if str(x).strip()]
    text = str(signal.get("confirmations_csv") or "")
    for sep in (";", "|"):
        text = text.replace(sep, ",")
    return [x.strip().upper() for x in text.split(",") if x.strip()]


def _load_config() -> dict[str, Any]:
    path = _root() / "data" / "v8004_quality_router_config.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _thresholds(cfg: dict[str, Any], playbook: str) -> dict[str, Any]:
    section = cfg.get("playbook_a", {}) if playbook.startswith("PLAYBOOK_A") else cfg.get("playbook_b", {})
    if not isinstance(section, dict):
        section = {}
    return {
        "a_plus_score": _num(section.get("a_plus_score")) or 76.0,
        "a_score": _num(section.get("a_score")) or 68.0,
        "b_score": _num(section.get("b_score")) or 58.0,
        "review_score": _num(section.get("review_score")) or 52.0,
        "a_plus_min_confirmations": _int(cfg.get("a_plus_min_confirmations"), 3),
        "a_min_confirmations": _int(cfg.get("a_min_confirmations"), 2),
        "a_plus_min_aligned_biases": _int(cfg.get("a_plus_min_aligned_biases"), 3),
        "a_min_aligned_biases": _int(cfg.get("a_min_aligned_biases"), 2),
    }


def _counter_rows(counter: Counter[str], limit: int = 20) -> list[dict[str, Any]]:
    return [{"name": k, "count": int(v)} for k, v in counter.most_common(limit)]


def _avg(values: list[float]) -> float | None:
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    return round(mean(vals), 3) if vals else None


def _query_rows(window: str) -> tuple[list[sqlite3.Row], dict[str, Any]]:
    path = _db()
    meta = {"db_exists": path.exists(), "table_exists": False, "truncated": False}
    if not path.exists():
        return [], meta
    cutoff = _cutoff(window)
    con: sqlite3.Connection | None = None
    try:
        con = _connect_ro(path)
        if not _table_exists(con, "v8004_quality_router_log"):
            return [], meta
        meta["table_exists"] = True
        where = ""
        params: list[Any] = []
        if cutoff:
            where = "WHERE datetime(created_at) >= datetime(?)"
            params.append(_iso(cutoff))
        total = int(con.execute(f"SELECT COUNT(*) FROM v8004_quality_router_log {where}", params).fetchone()[0])
        meta["rows_available"] = total
        meta["truncated"] = total > MAX_ROWS
        rows = con.execute(
            f"""
            SELECT id, created_at, signal_event_id, client_trade_id, market, direction,
                   setup_name, playbook, pine_score, server_confidence, grade, route,
                   base_allow, final_allow, duplicate, reasons_json, blockers_json, raw_json
            FROM v8004_quality_router_log
            {where}
            ORDER BY id DESC
            LIMIT ?
            """,
            [*params, MAX_ROWS],
        ).fetchall()
        return rows, meta
    finally:
        if con is not None:
            con.close()


def _calculate_grade(
    cfg: dict[str, Any],
    playbook: str,
    setup: str,
    primary: str,
    signal: dict[str, Any],
    pine_score: float,
    confirmations: list[str],
    aligned: int,
    opposing: int,
) -> tuple[str, str]:
    t = _thresholds(cfg, playbook)
    playbook_a_premium = (
        playbook == "PLAYBOOK_A_HTF_OB_REACTION"
        and (_bool(signal.get("zone_first_touch"), False) or _int(signal.get("zone_touch_count"), 0) == 1)
    )
    playbook_b_premium = (
        playbook == "PLAYBOOK_B_SESSION_MOMENTUM"
        and ("MSS" in primary or "MSS" in setup)
    )
    premium = playbook_a_premium or playbook_b_premium

    if (
        pine_score >= t["a_plus_score"]
        and len(confirmations) >= t["a_plus_min_confirmations"]
        and aligned >= t["a_plus_min_aligned_biases"]
        and opposing == 0
        and premium
    ):
        return "A_PLUS", "V8013C_SIM_A_PLUS_STRICT"
    if (
        pine_score >= t["a_score"]
        and len(confirmations) >= t["a_min_confirmations"]
        and aligned >= t["a_min_aligned_biases"]
        and opposing == 0
    ):
        return "A", "V8013C_SIM_A_STRICT"
    if pine_score >= t["b_score"] and len(confirmations) >= 1:
        return "B", "V8013C_SIM_B_SHADOW_QUALITY"
    if pine_score >= t["review_score"]:
        return "REVIEW", "V8013C_SIM_REVIEW_SHADOW"
    return "WATCH", "V8013C_SIM_WATCH_ONLY"


def _calculate_route(cfg: dict[str, Any], grade: str, base_allow: bool, duplicate: bool, blockers: list[str]) -> str:
    if blockers:
        if duplicate:
            return str(cfg.get("duplicate_route") or "NO_TRADE").upper()
        return str(cfg.get("invalid_route") or "NO_TRADE").upper()
    live_grades = {str(x).upper() for x in cfg.get("live_grades", ["A_PLUS", "A"])}
    shadow_grades = {str(x).upper() for x in cfg.get("shadow_grades", ["B", "REVIEW"])}
    watch_grades = {str(x).upper() for x in cfg.get("watch_grades", ["WATCH"])}
    if grade in live_grades:
        if bool(cfg.get("require_existing_gate_allow_for_live", True)) and not base_allow:
            return "SHADOW"
        return "LIVE"
    if grade in shadow_grades:
        return "SHADOW"
    if grade in watch_grades:
        return "WATCH_ONLY"
    return "NO_TRADE"


def _load_outcomes() -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    path = _db()
    outcome_map: dict[str, dict[str, Any]] = {}
    meta: dict[str, Any] = {
        "db_exists": path.exists(),
        "shadow_outcomes_table": False,
        "excursions_table": False,
        "closed_rows_loaded": 0,
    }
    if not path.exists():
        return outcome_map, meta
    con: sqlite3.Connection | None = None
    try:
        con = _connect_ro(path)
        if _table_exists(con, "shadow_outcomes"):
            meta["shadow_outcomes_table"] = True
            cols = _columns(con, "shadow_outcomes")
            needed = {"client_trade_id", "pnl_r"}
            if needed.issubset(cols):
                rows = con.execute(
                    """
                    SELECT client_trade_id, shadow_id, market, direction, setup_name,
                           result, pnl_r, closed_at
                    FROM shadow_outcomes
                    WHERE client_trade_id IS NOT NULL AND pnl_r IS NOT NULL
                    ORDER BY id DESC
                    LIMIT 50000
                    """
                ).fetchall()
                for row in rows:
                    key = str(row["client_trade_id"] or "").strip()
                    if key and key not in outcome_map:
                        outcome_map[key] = {
                            "source": "shadow_outcomes",
                            "result": row["result"],
                            "final_r": _num(row["pnl_r"]),
                            "closed_at": row["closed_at"],
                        }
                meta["closed_rows_loaded"] += len(rows)
        if _table_exists(con, "v7245a_trade_excursions"):
            meta["excursions_table"] = True
            cols = _columns(con, "v7245a_trade_excursions")
            needed = {"client_trade_id", "final_r", "is_open"}
            if needed.issubset(cols):
                rows = con.execute(
                    """
                    SELECT client_trade_id, trade_key, source, final_status, final_r, last_update_at
                    FROM v7245a_trade_excursions
                    WHERE COALESCE(is_open, 1)=0 AND final_r IS NOT NULL
                    ORDER BY id DESC
                    LIMIT 50000
                    """
                ).fetchall()
                for row in rows:
                    keys = [str(row["client_trade_id"] or "").strip(), str(row["trade_key"] or "").strip()]
                    for key in keys:
                        if key and key not in outcome_map:
                            outcome_map[key] = {
                                "source": "v7245a_trade_excursions",
                                "result": row["final_status"],
                                "final_r": _num(row["final_r"]),
                                "closed_at": row["last_update_at"],
                            }
                meta["closed_rows_loaded"] += len(rows)
    except Exception as exc:
        meta["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if con is not None:
            con.close()
    meta["unique_outcomes"] = len(outcome_map)
    return outcome_map, meta


def build_simulation(window: str = "24h", limit: int = 100) -> dict[str, Any]:
    selected = _window(window)
    cfg = _load_config()
    rows, db_meta = _query_rows(selected)
    outcomes, outcome_meta = _load_outcomes()

    current_grade_counts: Counter[str] = Counter()
    current_route_counts: Counter[str] = Counter()
    simulated_grade_counts: Counter[str] = Counter()
    simulated_route_counts: Counter[str] = Counter()
    grade_transitions: Counter[str] = Counter()
    route_transitions: Counter[str] = Counter()
    rescue_market: Counter[str] = Counter()
    rescue_setup: Counter[str] = Counter()
    rescue_session: Counter[str] = Counter()
    rescue_playbook: Counter[str] = Counter()
    rescue_direction: Counter[str] = Counter()
    remaining_blockers: Counter[str] = Counter()
    candidate_outcomes: list[float] = []
    rescued_outcomes: list[float] = []
    latest: list[dict[str, Any]] = []

    eligible_valid = 0
    rescued = 0
    still_blocked = 0
    theoretical_live = 0
    theoretical_shadow = 0
    theoretical_watch = 0
    outcome_matched = 0
    outcome_closed_rescued = 0
    wins = 0
    losses = 0
    breakeven = 0

    for row in rows:
        raw = _obj(row["raw_json"])
        signal = raw.get("signal") if isinstance(raw.get("signal"), dict) else raw
        decision = raw.get("decision") if isinstance(raw.get("decision"), dict) else {}
        blockers = [str(x).upper() for x in _list(row["blockers_json"])]
        reasons = [str(x).upper() for x in _list(row["reasons_json"])]
        current_grade = str(row["grade"] or "UNKNOWN").upper()
        current_route = str(row["route"] or "UNKNOWN").upper()
        market = str(row["market"] or "UNKNOWN").upper()
        direction = str(row["direction"] or "UNKNOWN").upper()
        setup = str(row["setup_name"] or "UNKNOWN").upper()
        playbook = str(row["playbook"] or "UNKNOWN").upper()
        session = str(signal.get("session") or decision.get("session") or "UNKNOWN").upper()
        quality = str(signal.get("entry_quality") or signal.get("entry_state") or "UNKNOWN").upper()
        is_late = _bool(signal.get("is_late_entry"), False)
        is_chase = _bool(signal.get("is_chase"), False)
        pine = _num(row["pine_score"]) or 0.0
        confs = _confirmations(signal, decision)
        aligned = _int(decision.get("aligned_bias_count"), 0)
        opposing = _int(decision.get("opposing_bias_count"), 0)
        primary = str(signal.get("primary_trigger") or decision.get("primary_trigger") or setup).upper()
        duplicate = bool(row["duplicate"])
        base_allow = bool(row["base_allow"])
        stale_present = "V8004_STALE_SIGNAL" in blockers

        current_grade_counts[current_grade] += 1
        current_route_counts[current_route] += 1

        eligible = stale_present and quality == "VALID" and not is_late and not is_chase
        simulated_blockers = list(blockers)
        simulated_grade = current_grade
        simulated_route = current_route
        sim_reason = "UNCHANGED_NOT_ELIGIBLE"

        if eligible:
            eligible_valid += 1
            simulated_blockers = [b for b in blockers if b != "V8004_STALE_SIGNAL"]
            if not simulated_blockers:
                simulated_grade, sim_reason = _calculate_grade(
                    cfg, playbook, setup, primary, signal, pine, confs, aligned, opposing
                )
                simulated_route = _calculate_route(cfg, simulated_grade, base_allow, duplicate, simulated_blockers)
                rescued += 1
                rescue_market[market] += 1
                rescue_setup[setup] += 1
                rescue_session[session] += 1
                rescue_playbook[playbook] += 1
                rescue_direction[direction] += 1
                if simulated_route == "LIVE":
                    theoretical_live += 1
                elif simulated_route == "SHADOW":
                    theoretical_shadow += 1
                elif simulated_route == "WATCH_ONLY":
                    theoretical_watch += 1
            else:
                simulated_grade = "NO_TRADE"
                simulated_route = _calculate_route(cfg, simulated_grade, base_allow, duplicate, simulated_blockers)
                sim_reason = "STILL_BLOCKED_AFTER_VALID_RECLASSIFICATION"
                still_blocked += 1
                for blocker in simulated_blockers:
                    remaining_blockers[blocker] += 1

            signal_id = str(row["signal_event_id"] or row["client_trade_id"] or "").strip()
            outcome = outcomes.get(signal_id)
            if outcome and outcome.get("final_r") is not None:
                value = float(outcome["final_r"])
                candidate_outcomes.append(value)
                outcome_matched += 1
                if not simulated_blockers:
                    rescued_outcomes.append(value)
                    outcome_closed_rescued += 1
                    if value > 0:
                        wins += 1
                    elif value < 0:
                        losses += 1
                    else:
                        breakeven += 1
            else:
                outcome = None

            if len(latest) < max(1, min(int(limit), 300)):
                latest.append({
                    "created_at": row["created_at"],
                    "signal_event_id": signal_id,
                    "market": market,
                    "direction": direction,
                    "setup": setup,
                    "playbook": playbook,
                    "session": session,
                    "pine_score": round(pine, 2),
                    "entry_quality": quality,
                    "current_grade": current_grade,
                    "current_route": current_route,
                    "simulated_grade": simulated_grade,
                    "simulated_route": simulated_route,
                    "safe_observe_action": "SHADOW_REVIEW_ONLY" if not simulated_blockers else "KEEP_NO_TRADE",
                    "remaining_blockers": simulated_blockers,
                    "simulation_reason": sim_reason,
                    "outcome": outcome,
                })

        simulated_grade_counts[simulated_grade] += 1
        simulated_route_counts[simulated_route] += 1
        grade_transitions[f"{current_grade} → {simulated_grade}"] += 1
        route_transitions[f"{current_route} → {simulated_route}"] += 1

    eligible_pct = round(eligible_valid / len(rows) * 100.0, 2) if rows else 0.0
    rescue_pct = round(rescued / eligible_valid * 100.0, 2) if eligible_valid else 0.0
    closed_count = len(rescued_outcomes)
    win_rate = round(wins / closed_count * 100.0, 2) if closed_count else None
    evidence_sufficient = closed_count >= 30

    return {
        "ok": bool(db_meta.get("table_exists")),
        "version": VERSION,
        "mode": MODE,
        "generated_utc": _iso(_now()),
        "window": selected,
        "available_windows": list(WINDOWS),
        "simulation_rule": {
            "current": "require_fresh=true: is_fresh=false creates V8004_STALE_SIGNAL",
            "counterfactual": "Only entry_quality=VALID with is_late_entry=false and is_chase=false may remove V8004_STALE_SIGNAL in simulation.",
            "late_unchanged": True,
            "chase_unchanged": True,
            "all_other_blockers_unchanged": True,
            "base_gate_unchanged": True,
            "calculated_live_is_theoretical_only": True,
            "safe_observe_action_for_rescued": "SHADOW_REVIEW_ONLY",
        },
        "summary": {
            "evaluated": len(rows),
            "current_no_trade": int(current_route_counts.get("NO_TRADE", 0)),
            "eligible_valid_stale": eligible_valid,
            "eligible_share_percent": eligible_pct,
            "rescued_after_removing_stale_only": rescued,
            "rescue_share_of_eligible_percent": rescue_pct,
            "still_blocked_by_other_rules": still_blocked,
            "theoretical_live_calculated": theoretical_live,
            "theoretical_shadow_calculated": theoretical_shadow,
            "theoretical_watch_only_calculated": theoretical_watch,
            "actual_routes_changed": 0,
            "actual_trades_created": 0,
        },
        "current": {
            "grade_counts": dict(current_grade_counts),
            "route_counts": dict(current_route_counts),
        },
        "simulated": {
            "grade_counts": dict(simulated_grade_counts),
            "route_counts": dict(simulated_route_counts),
            "grade_transitions": _counter_rows(grade_transitions, 30),
            "route_transitions": _counter_rows(route_transitions, 30),
        },
        "rescued_breakdown": {
            "markets": _counter_rows(rescue_market, 20),
            "setups": _counter_rows(rescue_setup, 20),
            "sessions": _counter_rows(rescue_session, 20),
            "playbooks": _counter_rows(rescue_playbook, 20),
            "directions": _counter_rows(rescue_direction, 10),
            "remaining_blockers": _counter_rows(remaining_blockers, 20),
        },
        "outcome_evidence": {
            "outcome_source_meta": outcome_meta,
            "eligible_outcomes_matched": outcome_matched,
            "rescued_closed_outcomes": closed_count,
            "wins": wins,
            "losses": losses,
            "breakeven": breakeven,
            "win_rate_percent": win_rate,
            "avg_final_r": _avg(rescued_outcomes),
            "all_eligible_avg_final_r": _avg(candidate_outcomes),
            "minimum_closed_outcomes_before_rule_review": 30,
            "evidence_sufficient_for_live_rule_change": evidence_sufficient,
            "note": "NO_TRADE rows usually have no created Shadow trade, so historical outcome coverage may be low. This dashboard reports coverage instead of inventing performance.",
        },
        "latest_eligible": latest,
        "recommendation": {
            "change_require_fresh_now": False,
            "reason": "Run observe-only collection until enough VALID candidates have closed outcome evidence. LATE and CHASE remain blocked.",
            "next_safe_step": "Optionally create a future shadow-only capture path for new VALID candidates after manual approval; do not route them LIVE.",
        },
        "db": db_meta,
        "safety": dict(SAFETY),
    }


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _token_ok(request: Request) -> bool:
    try:
        from app.v7200_event_risk import _token_ok as real_token_ok
        return bool(real_token_ok(request))
    except Exception:
        return True


def _suffix(token: str) -> str:
    return f"?token={quote(token)}" if token else ""


def _metric(label: str, value: Any, cls: str = "") -> str:
    return f"<div class='metric {cls}'><span>{_esc(label)}</span><b>{_esc(value)}</b></div>"


def _bars(rows: list[dict[str, Any]], total: int) -> str:
    if not rows:
        return "<div class='empty'>Keine Daten.</div>"
    out = []
    for row in rows:
        count = int(row.get("count") or 0)
        width = max(2.0, min(100.0, count / max(total, 1) * 100.0))
        out.append(
            f"<div class='barrow'><div><b>{_esc(row.get('name'))}</b><span>{count}</span></div>"
            f"<div class='bar'><i style='width:{width:.2f}%'></i></div></div>"
        )
    return "".join(out)


def _latest_table(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<div class='empty'>Keine VALID/Stale-Kandidaten im gewählten Fenster.</div>"
    body = []
    for row in rows:
        blockers = ", ".join(row.get("remaining_blockers") or []) or "—"
        outcome = row.get("outcome") or {}
        outcome_text = "—" if not outcome else f"{outcome.get('final_r')}R"
        body.append(
            "<tr>"
            f"<td>{_esc(row.get('created_at'))}</td><td>{_esc(row.get('market'))}</td>"
            f"<td>{_esc(row.get('direction'))}</td><td>{_esc(row.get('setup'))}</td>"
            f"<td>{_esc(row.get('pine_score'))}</td><td>{_esc(row.get('current_grade'))}/{_esc(row.get('current_route'))}</td>"
            f"<td>{_esc(row.get('simulated_grade'))}/{_esc(row.get('simulated_route'))}</td>"
            f"<td>{_esc(blockers)}</td><td>{_esc(outcome_text)}</td>"
            "</tr>"
        )
    return "<div class='scroll'><table><thead><tr><th>Zeit</th><th>Markt</th><th>Dir</th><th>Setup</th><th>Pine</th><th>Aktuell</th><th>Simulation</th><th>Restblocker</th><th>Outcome</th></tr></thead><tbody>" + "".join(body) + "</tbody></table></div>"


def page_html(data: dict[str, Any], token: str = "") -> str:
    summary = data.get("summary") or {}
    rescued = data.get("rescued_breakdown") or {}
    outcomes = data.get("outcome_evidence") or {}
    suffix = _suffix(token)
    tabs = []
    for key in WINDOWS:
        active = "active" if key == data.get("window") else ""
        tabs.append(f"<a class='{active}' href='/v8013/valid-fresh-simulation?window={key}{'&token='+quote(token) if token else ''}'>{key}</a>")
    metrics = "".join([
        _metric("Ausgewertet", summary.get("evaluated", 0)),
        _metric("VALID + STALE", summary.get("eligible_valid_stale", 0), "warn"),
        _metric("Nur durch Stale rettbar", summary.get("rescued_after_removing_stale_only", 0), "good"),
        _metric("Andere Blocker bleiben", summary.get("still_blocked_by_other_rules", 0)),
        _metric("Theoretisch LIVE", summary.get("theoretical_live_calculated", 0), "danger"),
        _metric("Theoretisch SHADOW", summary.get("theoretical_shadow_calculated", 0), "good"),
        _metric("Geschlossene Outcomes", outcomes.get("rescued_closed_outcomes", 0)),
        _metric("Ø R", outcomes.get("avg_final_r")),
    ])
    return f"""<!doctype html><html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>V8013C VALID/FRESH Simulation</title><style>
:root{{--bg:#07111f;--card:#101d2e;--line:#29415e;--text:#eef5ff;--muted:#9fb1c8;--good:#24d17e;--warn:#ffcc33;--danger:#ff6b6b;--blue:#55aaff}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 system-ui,-apple-system,sans-serif}}.wrap{{max-width:1500px;margin:auto;padding:18px}}.hero,.card{{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:18px;margin-bottom:16px}}h1,h2{{margin:0 0 10px}}.muted{{color:var(--muted)}}.nav,.tabs{{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}}a{{color:#d8ebff;text-decoration:none;border:1px solid var(--line);padding:8px 11px;border-radius:10px}}a.active{{background:#1d4f78}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-top:14px}}.metric{{border:1px solid var(--line);border-radius:14px;padding:13px;background:#0b1727}}.metric span{{display:block;color:var(--muted)}}.metric b{{display:block;font-size:26px;margin-top:4px}}.metric.good b{{color:var(--good)}}.metric.warn b{{color:var(--warn)}}.metric.danger b{{color:var(--danger)}}.cols{{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}}.barrow{{margin:10px 0}}.barrow>div:first-child{{display:flex;justify-content:space-between;gap:12px}}.bar{{height:8px;background:#07111f;border-radius:8px;overflow:hidden;margin-top:4px}}.bar i{{display:block;height:100%;background:var(--blue)}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;min-width:1050px}}th,td{{text-align:left;border-bottom:1px solid var(--line);padding:9px;white-space:nowrap}}th{{color:#a8cff4}}.notice{{border-left:5px solid var(--warn);padding:12px;background:#172235;border-radius:8px}}.safe{{border-left-color:var(--good)}}.empty{{color:var(--muted);padding:10px 0}}code{{color:#c8e6ff}}@media(max-width:700px){{.wrap{{padding:10px}}.hero,.card{{border-radius:12px;padding:13px}}}}
</style></head><body><div class='wrap'><div class='hero'><h1>V8013C VALID-vs-FRESH Shadow-Simulation</h1><div class='muted'>Counterfactual, vollständig read-only: Nur VALID entfernt simuliert den STALE-Block. LATE, CHASE, alle anderen Blocker und das Base-Gate bleiben unverändert.</div><div class='nav'><a href='/master{suffix}'>Master</a><a href='/master-ai-review{suffix}'>AI Review</a><a href='/v8013/score-gap-timing{suffix}'>Score-Gap</a><a href='/v8013/valid-fresh-simulation.json?window={data.get('window')}{'&token='+quote(token) if token else ''}'>JSON</a><a href='/v8013/selftest-c.json{suffix}'>Selftest</a></div><div class='tabs'>{''.join(tabs)}</div><div class='grid'>{metrics}</div></div>
<div class='card notice safe'><b>Sicherheitsmodus:</b> Es wird kein alter Trade eröffnet, keine Route geändert und kein Threshold gespeichert. Selbst theoretisch LIVE berechnete Fälle bleiben nur Diagnose.</div>
<div class='cols'><div class='card'><h2>Rettbare Märkte</h2>{_bars(rescued.get('markets') or [], max(int(summary.get('rescued_after_removing_stale_only') or 0),1))}</div><div class='card'><h2>Rettbare Setups</h2>{_bars(rescued.get('setups') or [], max(int(summary.get('rescued_after_removing_stale_only') or 0),1))}</div><div class='card'><h2>Restblocker</h2>{_bars(rescued.get('remaining_blockers') or [], max(int(summary.get('still_blocked_by_other_rules') or 0),1))}</div><div class='card'><h2>Outcome-Evidenz</h2><p>Matched: <b>{_esc(outcomes.get('rescued_closed_outcomes'))}</b> · Winrate: <b>{_esc(outcomes.get('win_rate_percent'))}</b> · Ø R: <b>{_esc(outcomes.get('avg_final_r'))}</b></p><p class='muted'>Mindestens 30 geschlossene Outcomes vor einer Regelentscheidung. Evidenz ausreichend: {_esc(outcomes.get('evidence_sufficient_for_live_rule_change'))}</p></div></div>
<div class='card'><h2>Neueste VALID/Stale-Kandidaten</h2>{_latest_table(data.get('latest_eligible') or [])}</div>
<div class='card notice'><b>Empfehlung:</b> <code>require_fresh</code> jetzt nicht ändern. Zuerst ausreichende Shadow-Outcome-Evidenz sammeln; LATE und CHASE bleiben strikt blockiert.</div></div></body></html>"""


def selftest_payload(app) -> dict[str, Any]:
    paths = [getattr(route, "path", "") for route in getattr(app, "routes", [])]
    missing = [path for path in REQUIRED_ROUTES if path not in paths]
    duplicates = [path for path in REQUIRED_ROUTES if paths.count(path) > 1]
    data = build_simulation("24h", 5)
    return {
        "ok": bool(data.get("ok")) and not missing and not duplicates,
        "version": VERSION,
        "mode": MODE,
        "required_routes": len(REQUIRED_ROUTES),
        "missing_routes": missing,
        "duplicate_routes": duplicates,
        "table_exists": bool((data.get("db") or {}).get("table_exists")),
        "evaluated_24h": (data.get("summary") or {}).get("evaluated"),
        "eligible_valid_stale_24h": (data.get("summary") or {}).get("eligible_valid_stale"),
        "rescued_24h": (data.get("summary") or {}).get("rescued_after_removing_stale_only"),
        "actual_routes_changed": 0,
        "actual_trades_created": 0,
        "safety": dict(SAFETY),
    }


def install_v8013c_valid_fresh_shadow_simulation(app) -> None:
    @app.get("/v8013/valid-fresh-simulation", response_class=HTMLResponse)
    def v8013c_page(request: Request, window: str = "24h", token: str = ""):
        if not _token_ok(request):
            return HTMLResponse("Unauthorized", status_code=401)
        return HTMLResponse(page_html(build_simulation(window, 150), token))

    @app.get("/v8013/valid-fresh-simulation.json")
    def v8013c_json(request: Request, window: str = "24h", limit: int = 100):
        if not _token_ok(request):
            return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
        return JSONResponse(build_simulation(window, limit))

    @app.get("/v8013/valid-rescues.json")
    def v8013c_rescues(request: Request, window: str = "24h", limit: int = 200):
        if not _token_ok(request):
            return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
        data = build_simulation(window, limit)
        return JSONResponse({
            "ok": data.get("ok"),
            "version": VERSION,
            "window": data.get("window"),
            "summary": data.get("summary"),
            "rescued_breakdown": data.get("rescued_breakdown"),
            "latest_eligible": data.get("latest_eligible"),
            "safety": data.get("safety"),
        })

    @app.get("/v8013/valid-outcomes.json")
    def v8013c_outcomes(request: Request, window: str = "all"):
        if not _token_ok(request):
            return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
        data = build_simulation(window, 20)
        return JSONResponse({
            "ok": data.get("ok"),
            "version": VERSION,
            "window": data.get("window"),
            "outcome_evidence": data.get("outcome_evidence"),
            "recommendation": data.get("recommendation"),
            "safety": data.get("safety"),
        })

    @app.get("/v8013/selftest-c.json")
    def v8013c_selftest(request: Request):
        if not _token_ok(request):
            return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
        return JSONResponse(selftest_payload(app))

    print("[V8013C] VALID-vs-FRESH counterfactual simulation installed (read-only; no route changes)")
