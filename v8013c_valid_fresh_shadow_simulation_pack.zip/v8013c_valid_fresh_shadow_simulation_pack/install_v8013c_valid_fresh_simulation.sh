#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="V8013C-VALID-FRESH-SHADOW-SIMULATION-V1"
BASE="/opt/tradingbot_v6000"
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$BASE/backups/v8013c_before_$STAMP"
LOG="/root/v8013c_install_$STAMP.log"
BUILD_LOG="/root/v8013c_build_$STAMP.log"
TMP_DIR="$(mktemp -d)"
ROLLBACK_ARMED=0

exec > >(tee -a "$LOG") 2>&1

die(){ echo "ERROR: $*" >&2; return 1; }
sha(){ sha256sum "$1" | awk '{print $1}'; }
wait_http_200(){
  local url="$1" tries="${2:-75}" sleep_s="${3:-2}" code i
  for i in $(seq 1 "$tries"); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 10 "$url" 2>/dev/null || true)"
    if [[ "$code" == "200" ]]; then return 0; fi
    if [[ "$i" == "1" || $((i % 5)) -eq 0 ]]; then echo "WAIT [$i/$tries] $url status=$code"; fi
    sleep "$sleep_s"
  done
  return 1
}

rollback(){
  local rc="${1:-1}"
  set +e
  echo "=== V8013C ROLLBACK START ==="
  if [[ -d "$BACKUP" ]]; then
    [[ -f "$BACKUP/main.py" ]] && cp -a "$BACKUP/main.py" "$BASE/app/main.py"
    [[ -f "$BACKUP/v8003_master_navigation.py" ]] && cp -a "$BACKUP/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
    [[ -f "$BACKUP/docker-compose.yml" ]] && cp -a "$BACKUP/docker-compose.yml" "$BASE/docker-compose.yml"
    [[ -f "$BACKUP/.env" ]] && cp -a "$BACKUP/.env" "$BASE/.env" && chmod 600 "$BASE/.env"
    if [[ -f "$BACKUP/dockerignore_was_present" ]]; then
      [[ -f "$BACKUP/.dockerignore" ]] && cp -a "$BACKUP/.dockerignore" "$BASE/.dockerignore"
    else
      rm -f "$BASE/.dockerignore"
    fi
  fi
  rm -f "$BASE/app/routes/v8013c_valid_fresh_shadow_simulation.py"
  rm -f "$BASE/ops/v8013c_valid_fresh_check.sh"
  rm -f "$BASE/README_V8013C.md" "$BASE/STATIC_AUDIT_V8013C.json"
  cd "$BASE" || true
  docker compose build tradingbot || true
  docker compose up -d --force-recreate --remove-orphans || true
  echo "Rollback backup: $BACKUP"
  echo "Original error code: $rc"
  echo "=== V8013C ROLLBACK ENDE ==="
  rm -rf "$TMP_DIR"
  exit "$rc"
}

on_error(){
  local rc=$?
  if [[ "$ROLLBACK_ARMED" == "1" ]]; then rollback "$rc"; fi
  rm -rf "$TMP_DIR"
  exit "$rc"
}
trap on_error ERR

EXPECTED_MAIN="e0504a6168e3f6cdbe0b80a51ebf2b603b6ea5d6f16ac9d129829c859e39a50d"
EXPECTED_NAV="98bc454e571007aec531924717a22c38ba038bf87c988a867edcade545a4ac0b"
EXPECTED_COMPOSE="1d80c133a3a77f43eb6bc2cd711a99759ce9c28149149fc5d4a30b146804bb0c"
EXPECTED_DOCKERIGNORE="e60d13c9c22a68d87261c31bbd574df1f20ef0e64451f5b854a3139c201a7cbc"
EXPECTED_V8013B="456e54834552032545485845fdec540e9c4f696354fce4806697d81b2c07820e"
EXPECTED_V8013A="f7894e681d858cf70414616b37f8c09c4dce5906715f69f3f447b8934aa23689"
EXPECTED_V8012E="c8a37f938e0d0f44a7df7b64f75edfe27c59be55b2046d8c9264641baafd0db4"
EXPECTED_V8012D="d2b5d8c0d0ee5d8dadf26bf025f1c994fd217b52ca801b02346ff0849d0c9d28"
EXPECTED_INGRESS="0b50a8dcce8e0f2ef71dead1d5489bdd1c915b932acefa166eec656828806c8b"
EXPECTED_V8004="cc90eb5917a92ca715bd2ddd15a5230a04eab657d94604c42a98969d470db793"
EXPECTED_V8006="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

echo "================================================================================"
echo "$VERSION INSTALL"
echo "================================================================================"
echo "Generated UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"
echo "Project: $BASE"
echo "Package: $PACKAGE_DIR"
echo "Scope:"
echo "  VALID versus FRESH counterfactual simulation: ADD"
echo "  Remove only V8004_STALE_SIGNAL for strict VALID cases: SIMULATE ONLY"
echo "  LATE and CHASE blockers: UNCHANGED"
echo "  Other blockers and existing base gate: UNCHANGED"
echo "  Grade and route transitions: CALCULATE ONLY"
echo "  Closed outcome coverage: READ ONLY"
echo "Safety:"
echo "  DB writes/schema changes: 0"
echo "  V8004/V8006/V8007 changes: 0"
echo "  Canonical Pine changes: 0"
echo "  Threshold/routing changes: 0"
echo "  Historical trades created: 0"
echo "  Token mode: OFF"
echo "  Broker auto execution: FALSE"

[[ -d "$BASE/app" && -d "$BASE/data" ]] || die "Project structure missing"
[[ -f "$PACKAGE_DIR/MANIFEST.sha256" ]] || die "Package manifest missing"

echo "[1] Verify package hashes and static audit"
(cd "$PACKAGE_DIR" && sha256sum -c MANIFEST.sha256)
python3 - "$PACKAGE_DIR/STATIC_AUDIT.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
assert d.get('version')=='V8013C-VALID-FRESH-SHADOW-SIMULATION-V1'
local=d.get('local_validation') or {}; safe=d.get('safety') or {}
for key in ('python_compile','module_import','synthetic_simulation','route_test','main_registration','navigation_links'):
    assert local.get(key) is True,(key,local.get(key))
assert local.get('duplicate_v8013c_routes')==0
for key in ('db_writes','db_schema_changes','routing_changes','threshold_changes','live_rule_changes','historical_trade_creation','token_mode_changed','broker_auto_execution'):
    assert safe.get(key) is False,(key,safe.get(key))
print('Static audit: PASS')
PY

echo "[2] Verify production baseline"
for pair in \
 "$BASE/app/main.py|$EXPECTED_MAIN|main.py" \
 "$BASE/app/v8003_master_navigation.py|$EXPECTED_NAV|V8003 nav" \
 "$BASE/docker-compose.yml|$EXPECTED_COMPOSE|compose" \
 "$BASE/.dockerignore|$EXPECTED_DOCKERIGNORE|dockerignore" \
 "$BASE/app/routes/v8013b_score_gap_timing_audit.py|$EXPECTED_V8013B|V8013B.1" \
 "$BASE/app/routes/v8013a_b_review_breakdown.py|$EXPECTED_V8013A|V8013A" \
 "$BASE/app/routes/v8012e_dashboard_extraction.py|$EXPECTED_V8012E|V8012E" \
 "$BASE/app/routes/v8012d_dashboard_extraction.py|$EXPECTED_V8012D|V8012D" \
 "$BASE/app/v8011_ingress.py|$EXPECTED_INGRESS|ingress" \
 "$BASE/app/v8004_quality_router.py|$EXPECTED_V8004|V8004" \
 "$BASE/app/v8006_calendar_execution_correction.py|$EXPECTED_V8006|V8006" \
 "$BASE/app/v8007_v8001_gate_bridge.py|$EXPECTED_V8007|V8007" \
 "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine|$EXPECTED_PINE|Pine"; do
 IFS='|' read -r file expected label <<<"$pair"
 actual="$(sha "$file")"
 echo "$label: $actual"
 [[ "$actual" == "$expected" ]] || die "$label baseline mismatch"
done
[[ ! -e "$BASE/app/routes/v8013c_valid_fresh_shadow_simulation.py" ]] || die "V8013C module already exists"

echo "[3] Create rollback backup"
mkdir -p "$BACKUP"
cp -a "$BASE/app/main.py" "$BACKUP/main.py"
cp -a "$BASE/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
cp -a "$BASE/docker-compose.yml" "$BACKUP/docker-compose.yml"
cp -a "$BASE/.env" "$BACKUP/.env"
chmod 600 "$BACKUP/.env"
if [[ -f "$BASE/.dockerignore" ]]; then
  touch "$BACKUP/dockerignore_was_present"
  cp -a "$BASE/.dockerignore" "$BACKUP/.dockerignore"
fi
ROLLBACK_ARMED=1

echo "[4] Keep webhook token fully OFF"
python3 - <<'PY'
from pathlib import Path
p=Path('/opt/tradingbot_v6000/.env')
lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
changes={'V8011_TOKEN_MODE':'off','V8011_ENFORCE_TOKEN':'false','V8011_WEBHOOK_TOKEN':''}
out=[]; seen=set()
for line in lines:
    if '=' not in line or line.lstrip().startswith('#'):
        out.append(line); continue
    key=line.split('=',1)[0].strip()
    if key in changes:
        if key not in seen: out.append(f"{key}={changes[key]}"); seen.add(key)
    else: out.append(line)
for key,value in changes.items():
    if key not in seen: out.append(f"{key}={value}")
p.write_text('\n'.join(out).rstrip()+'\n',encoding='utf-8')
print('token_mode: off')
print('token_configured: false')
print('token_enforced: false')
PY
chmod 600 "$BASE/.env"

echo "[5] Install V8013C files"
install -m 0644 "$PACKAGE_DIR/app/main.py" "$BASE/app/main.py"
install -m 0644 "$PACKAGE_DIR/app/v8003_master_navigation.py" "$BASE/app/v8003_master_navigation.py"
install -m 0644 "$PACKAGE_DIR/app/routes/v8013c_valid_fresh_shadow_simulation.py" "$BASE/app/routes/v8013c_valid_fresh_shadow_simulation.py"
install -m 0644 "$PACKAGE_DIR/docker-compose.v8013c.yml" "$BASE/docker-compose.yml"
install -m 0644 "$PACKAGE_DIR/.dockerignore.v8013c" "$BASE/.dockerignore"
install -m 0755 "$PACKAGE_DIR/ops/v8013c_valid_fresh_check.sh" "$BASE/ops/v8013c_valid_fresh_check.sh"
install -m 0644 "$PACKAGE_DIR/README_V8013C.md" "$BASE/README_V8013C.md"
install -m 0644 "$PACKAGE_DIR/STATIC_AUDIT.json" "$BASE/STATIC_AUDIT_V8013C.json"
python3 -m py_compile "$BASE/app/main.py" "$BASE/app/v8003_master_navigation.py" "$BASE/app/routes/v8013c_valid_fresh_shadow_simulation.py"

echo "[6] Verify protected hashes remain unchanged"
[[ "$(sha "$BASE/app/routes/v8013b_score_gap_timing_audit.py")" == "$EXPECTED_V8013B" ]] || die "V8013B changed"
[[ "$(sha "$BASE/app/routes/v8013a_b_review_breakdown.py")" == "$EXPECTED_V8013A" ]] || die "V8013A changed"
[[ "$(sha "$BASE/app/routes/v8012e_dashboard_extraction.py")" == "$EXPECTED_V8012E" ]] || die "V8012E changed"
[[ "$(sha "$BASE/app/routes/v8012d_dashboard_extraction.py")" == "$EXPECTED_V8012D" ]] || die "V8012D changed"
[[ "$(sha "$BASE/app/v8011_ingress.py")" == "$EXPECTED_INGRESS" ]] || die "Ingress changed"
[[ "$(sha "$BASE/app/v8004_quality_router.py")" == "$EXPECTED_V8004" ]] || die "V8004 changed"
[[ "$(sha "$BASE/app/v8006_calendar_execution_correction.py")" == "$EXPECTED_V8006" ]] || die "V8006 changed"
[[ "$(sha "$BASE/app/v8007_v8001_gate_bridge.py")" == "$EXPECTED_V8007" ]] || die "V8007 changed"
[[ "$(sha "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine")" == "$EXPECTED_PINE" ]] || die "Pine changed"

echo "[7] Build V8013C image with optimized context"
cd "$BASE"
docker compose config >/dev/null
set -o pipefail
docker compose build tradingbot 2>&1 | tee "$BUILD_LOG"
echo "Build context lines:"
grep -E 'transferring context:' "$BUILD_LOG" | tail -n 5 || true

echo "[8] Start backend + ingress"
docker compose up -d --force-recreate --remove-orphans
wait_http_200 http://127.0.0.1/health 75 2 || die "Public health did not become ready"

echo "[9] Validate V8013A/B.1/C selftests and simulation"
for path in selftest-a selftest-b selftest-c; do
  curl -fsS --max-time 90 "http://127.0.0.1/v8013/${path}.json" -o "$TMP_DIR/${path}.json"
done
curl -fsS --max-time 90 'http://127.0.0.1/v8013/valid-fresh-simulation.json?window=all&limit=20' -o "$TMP_DIR/simulation.json"
python3 - "$TMP_DIR/selftest-a.json" "$TMP_DIR/selftest-b.json" "$TMP_DIR/selftest-c.json" "$TMP_DIR/simulation.json" <<'PY'
import json,sys
files=[]
for p in sys.argv[1:]:
    with open(p,encoding='utf-8') as f: files.append(json.load(f))
a,b,c,d=files
summary=d.get('summary') or {}; outcomes=d.get('outcome_evidence') or {}; safe=d.get('safety') or {}
print(json.dumps({
 'v8013a_ok':a.get('ok'),'v8013b_ok':b.get('ok'),'v8013c_ok':c.get('ok'),'version':c.get('version'),
 'missing_routes':c.get('missing_routes'),'duplicate_routes':c.get('duplicate_routes'),
 'evaluated_all':summary.get('evaluated'),'current_no_trade':summary.get('current_no_trade'),
 'eligible_valid_stale':summary.get('eligible_valid_stale'),
 'rescued_after_removing_stale_only':summary.get('rescued_after_removing_stale_only'),
 'still_blocked_by_other_rules':summary.get('still_blocked_by_other_rules'),
 'theoretical_live_calculated':summary.get('theoretical_live_calculated'),
 'theoretical_shadow_calculated':summary.get('theoretical_shadow_calculated'),
 'rescued_closed_outcomes':outcomes.get('rescued_closed_outcomes'),
 'evidence_sufficient':outcomes.get('evidence_sufficient_for_live_rule_change'),
 'actual_routes_changed':summary.get('actual_routes_changed'),'actual_trades_created':summary.get('actual_trades_created')
},indent=2))
assert a.get('ok') is True
assert b.get('ok') is True
assert c.get('ok') is True
assert c.get('version')=='V8013C-VALID-FRESH-SHADOW-SIMULATION-V1'
assert not (c.get('missing_routes') or [])
assert not (c.get('duplicate_routes') or [])
assert d.get('ok') is True
assert summary.get('actual_routes_changed')==0
assert summary.get('actual_trades_created')==0
for key in ('db_writes','db_schema_changes','routing_changes','threshold_changes','live_rule_changes','historical_trade_creation','broker_auto_execution','token_mode_changed'):
    assert safe.get(key) is False,(key,safe.get(key))
PY

echo "[10] Critical route status"
for route in /health /master /master-ai-review /v8004/selftest.json /v8006/selftest.json /v8007/selftest.json /v8011/selftest.json /v8012/selftest-e.json /v8013/selftest-a.json /v8013/selftest-b.json /v8013/selftest-c.json /v8013/b-review-breakdown /v8013/score-gap-timing /v8013/valid-fresh-simulation /v8013/valid-fresh-simulation.json /v8013/valid-rescues.json /v8013/valid-outcomes.json; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 90 "http://127.0.0.1$route" 2>/dev/null || true)"
  printf '%-58s %s\n' "$route" "$code"
  [[ "$code" == "200" ]] || die "Route failed: $route status=$code"
done

echo "[11] Navigation"
curl -fsS --max-time 90 http://127.0.0.1/master -o "$TMP_DIR/master.html" || die "Master page fetch failed"
curl -fsS --max-time 90 http://127.0.0.1/master-ai-review -o "$TMP_DIR/master-ai-review.html" || die "AI Review page fetch failed"
grep -Fq "/v8013/valid-fresh-simulation" "$TMP_DIR/master.html" || die "Master link missing"
grep -Fq "/v8013/valid-fresh-simulation" "$TMP_DIR/master-ai-review.html" || die "AI Review link missing"
echo "Master link: PASS"
echo "AI Review link: PASS"

echo "[12] Token OFF and ingress health"
curl -fsS --max-time 30 http://127.0.0.1/v8011/selftest.json -o "$TMP_DIR/ingress.json"
python3 - "$TMP_DIR/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps({'ok':d.get('ok'),'operational_status':d.get('operational_status'),'queue_depth':d.get('queue_depth'),'backend_ok':d.get('backend_ok'),'worker_alive':d.get('worker_alive'),'token_mode':d.get('token_mode'),'token_configured':d.get('token_configured'),'token_enforced':d.get('token_enforced')},indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY

echo "[13] Final protected hashes"
sha256sum "$BASE/app/routes/v8013b_score_gap_timing_audit.py" "$BASE/app/routes/v8013a_b_review_breakdown.py" "$BASE/app/routes/v8012e_dashboard_extraction.py" "$BASE/app/routes/v8012d_dashboard_extraction.py" "$BASE/app/v8011_ingress.py" "$BASE/app/v8004_quality_router.py" "$BASE/app/v8006_calendar_execution_correction.py" "$BASE/app/v8007_v8001_gate_bridge.py" "$BASE/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"

echo "[14] Containers"
docker compose ps
ROLLBACK_ARMED=0
rm -rf "$TMP_DIR"
trap - ERR
cat <<EOF
================================================================================
V8013C INSTALLATION FERTIG
================================================================================
Backup: $BACKUP
Install log: $LOG
Build log: $BUILD_LOG
Dashboard: http://91.107.237.214/v8013/valid-fresh-simulation
JSON:      http://91.107.237.214/v8013/valid-fresh-simulation.json
Rescues:   http://91.107.237.214/v8013/valid-rescues.json
Outcomes:  http://91.107.237.214/v8013/valid-outcomes.json
Selftest:  http://91.107.237.214/v8013/selftest-c.json
COMPLETED:
  Strict VALID-vs-FRESH counterfactual simulation added
  Only V8004_STALE_SIGNAL is removed in eligible simulation rows
  LATE, CHASE and every other blocker remain unchanged
  Theoretical grade and route transitions calculated
  Outcome coverage measured without inventing missing performance
  Master + AI Review links added
UNCHANGED:
  V8004 / V8006 / V8007
  Canonical Pine
  V8011 ingress/queue/dead-letter
  Existing DB schema and rows
  Live scoring/routing and thresholds
  Token OFF
  Broker auto execution FALSE
EOF
