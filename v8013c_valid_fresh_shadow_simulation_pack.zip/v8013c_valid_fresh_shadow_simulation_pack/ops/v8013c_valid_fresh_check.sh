#!/usr/bin/env bash
set -u
BASE="/opt/tradingbot_v6000"
cd "$BASE" || exit 1
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "=== V8013C VALID/FRESH SHADOW SIMULATION CHECK ==="
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"

echo "[1] Containers"
docker compose ps

echo "[2] V8013A / B.1 / C selftests"
for name in a b c; do
  curl -fsS --max-time 60 "http://127.0.0.1/v8013/selftest-${name}.json" -o "$TMP/${name}.json" || exit 1
done
python3 - "$TMP/a.json" "$TMP/b.json" "$TMP/c.json" <<'PY'
import json,sys
items=[]
for p in sys.argv[1:]:
    with open(p,encoding='utf-8') as f: items.append(json.load(f))
a,b,c=items
print(json.dumps({
 'v8013a_ok':a.get('ok'),'v8013b_ok':b.get('ok'),'v8013c_ok':c.get('ok'),
 'version':c.get('version'),'missing_routes':c.get('missing_routes'),
 'duplicate_routes':c.get('duplicate_routes'),'evaluated_24h':c.get('evaluated_24h'),
 'eligible_valid_stale_24h':c.get('eligible_valid_stale_24h'),
 'rescued_24h':c.get('rescued_24h'),'actual_routes_changed':c.get('actual_routes_changed'),
 'actual_trades_created':c.get('actual_trades_created'),'safety':c.get('safety')
},indent=2))
assert a.get('ok') is True
assert b.get('ok') is True
assert c.get('ok') is True
assert c.get('version')=='V8013C-VALID-FRESH-SHADOW-SIMULATION-V1'
assert not (c.get('missing_routes') or [])
assert not (c.get('duplicate_routes') or [])
assert c.get('actual_routes_changed')==0
assert c.get('actual_trades_created')==0
PY

echo "[3] Core simulation result"
curl -fsS --max-time 60 'http://127.0.0.1/v8013/valid-fresh-simulation.json?window=all&limit=20' -o "$TMP/sim.json" || exit 1
python3 - "$TMP/sim.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
s=d.get('summary') or {}; o=d.get('outcome_evidence') or {}; r=d.get('rescued_breakdown') or {}; safe=d.get('safety') or {}
print(json.dumps({
 'ok':d.get('ok'),'window':d.get('window'),'evaluated':s.get('evaluated'),
 'current_no_trade':s.get('current_no_trade'),'eligible_valid_stale':s.get('eligible_valid_stale'),
 'rescued_after_removing_stale_only':s.get('rescued_after_removing_stale_only'),
 'still_blocked_by_other_rules':s.get('still_blocked_by_other_rules'),
 'theoretical_live_calculated':s.get('theoretical_live_calculated'),
 'theoretical_shadow_calculated':s.get('theoretical_shadow_calculated'),
 'theoretical_watch_only_calculated':s.get('theoretical_watch_only_calculated'),
 'top_rescued_markets':(r.get('markets') or [])[:10],
 'top_rescued_setups':(r.get('setups') or [])[:10],
 'remaining_blockers':(r.get('remaining_blockers') or [])[:10],
 'rescued_closed_outcomes':o.get('rescued_closed_outcomes'),
 'wins':o.get('wins'),'losses':o.get('losses'),'win_rate_percent':o.get('win_rate_percent'),
 'avg_final_r':o.get('avg_final_r'),'evidence_sufficient':o.get('evidence_sufficient_for_live_rule_change'),
 'actual_routes_changed':s.get('actual_routes_changed'),'actual_trades_created':s.get('actual_trades_created')
},indent=2))
assert d.get('ok') is True
assert s.get('actual_routes_changed')==0
assert s.get('actual_trades_created')==0
for key in ('db_writes','db_schema_changes','routing_changes','threshold_changes','live_rule_changes','historical_trade_creation','broker_auto_execution','token_mode_changed'):
    assert safe.get(key) is False,(key,safe.get(key))
PY

echo "[4] Outcome evidence"
curl -fsS --max-time 60 'http://127.0.0.1/v8013/valid-outcomes.json?window=all' | python3 -m json.tool

echo "[5] Ingress health and token OFF"
curl -fsS --max-time 30 http://127.0.0.1/v8011/selftest.json -o "$TMP/ingress.json" || exit 1
python3 - "$TMP/ingress.json" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf-8') as f:d=json.load(f)
print(json.dumps({'ok':d.get('ok'),'operational_status':d.get('operational_status'),'queue_depth':d.get('queue_depth'),'backend_ok':d.get('backend_ok'),'worker_alive':d.get('worker_alive'),'token_mode':d.get('token_mode'),'token_configured':d.get('token_configured'),'token_enforced':d.get('token_enforced')},indent=2))
assert d.get('ok') is True
assert d.get('backend_ok') is True
assert d.get('worker_alive') is True
assert d.get('token_mode')=='off'
assert d.get('token_configured') is False
assert d.get('token_enforced') is False
PY

echo "[6] Critical routes"
for route in /health /master /master-ai-review /v8004/selftest.json /v8011/selftest.json /v8012/selftest-e.json /v8013/selftest-a.json /v8013/selftest-b.json /v8013/selftest-c.json /v8013/b-review-breakdown /v8013/score-gap-timing /v8013/valid-fresh-simulation /v8013/valid-fresh-simulation.json /v8013/valid-rescues.json /v8013/valid-outcomes.json; do
 code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 60 "http://127.0.0.1$route" 2>/dev/null || true)"
 printf '%-56s %s\n' "$route" "$code"
 [[ "$code" == "200" ]] || exit 1
done

echo "[7] Navigation"
curl -fsS --max-time 60 http://127.0.0.1/master -o "$TMP/master.html" || exit 1
curl -fsS --max-time 60 http://127.0.0.1/master-ai-review -o "$TMP/master-ai-review.html" || exit 1
grep -Fq '/v8013/valid-fresh-simulation' "$TMP/master.html" || exit 1
grep -Fq '/v8013/valid-fresh-simulation' "$TMP/master-ai-review.html" || exit 1
echo 'Master link: PASS'
echo 'AI Review link: PASS'

echo "[8] Actual errors last 30m"
docker logs tradingbot --since 30m 2>&1 | grep -E 'Traceback|ERROR|Exception|install error|V8013C' | tail -n 80 || true

echo "[9] Host resources"
uptime
free -h
df -h /
echo "=== V8013C CHECK FERTIG ==="
