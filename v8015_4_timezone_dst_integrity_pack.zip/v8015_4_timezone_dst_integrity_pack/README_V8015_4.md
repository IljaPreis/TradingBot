# V8015.4 Timezone & DST Integrity

This patch keeps all database and JSON timestamps in UTC.
It changes only human-facing presentation and adds diagnostics.

- Dashboards: Europe/Berlin with CET/CEST and UTC reference
- Telegram: UTC timestamps converted to German local time; UTC remains visible
- DST tests: Berlin, London and New York
- Source audit: reports naive datetime usage without changing trading rules
- No V8004, FRESH/VALID, news-window, session, Pine or broker-execution changes

The HTML middleware injects a display-only browser script.
API JSON remains machine-safe UTC.
