import httpx
from app.core.config import BOT, CHAT
from app.v8015_4_timezone import localize_telegram_text

async def send_telegram(text):
    if not BOT or not CHAT:
        return {"sent": False, "reason": "Telegram env fehlt"}
    localized_text = localize_telegram_text(
        text,
        add_sent_footer=True,
    )
    url = f"https://api.telegram.org/bot{BOT}/sendMessage"
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.post(
            url,
            json={"chat_id": CHAT, "text": localized_text},
        )
    return {
        "sent": r.status_code == 200,
        "status": r.status_code,
        "display_timezone": "Europe/Berlin",
        "utc_reference_preserved": True,
    }
