from __future__ import annotations

import html
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8015.4-TIMEZONE-DST-INTEGRITY-V1"
DISPLAY_ZONE_NAME = "Europe/Berlin"
UTC_ZONE = timezone.utc
BERLIN_ZONE = ZoneInfo(DISPLAY_ZONE_NAME)
LONDON_ZONE = ZoneInfo("Europe/London")
NEW_YORK_ZONE = ZoneInfo("America/New_York")

_ISO_UTC_RE = re.compile(
    r"(?<![A-Za-z0-9_])"
    r"(20\d{2}-\d{2}-\d{2})[T ]"
    r"(\d{2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?)"
    r"(?:Z|\+00:00)"
)
_HUMAN_UTC_RE = re.compile(
    r"(?<![A-Za-z0-9_])"
    r"(20\d{2}-\d{2}-\d{2})[ T]"
    r"(\d{2}:\d{2}(?::\d{2})?)\s*UTC\b",
    re.IGNORECASE,
)


def utc_now() -> datetime:
    return datetime.now(UTC_ZONE)


def _root() -> Path:
    for candidate in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        try:
            if (candidate / "app").exists():
                return candidate
        except Exception:
            pass
    return Path.cwd()


def parse_timestamp(value: Any, *, assume_naive_utc: bool = True) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, (int, float)):
        number = float(value)
        if number > 10_000_000_000:
            number /= 1000.0
        try:
            parsed = datetime.fromtimestamp(number, tz=UTC_ZONE)
        except Exception:
            return None
    else:
        text = str(value).strip()
        if not text:
            return None
        try:
            number = float(text)
            if number > 10_000_000_000:
                number /= 1000.0
            parsed = datetime.fromtimestamp(number, tz=UTC_ZONE)
        except Exception:
            try:
                parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            except Exception:
                parsed = None
                for fmt in (
                    "%Y-%m-%d %H:%M:%S UTC",
                    "%Y-%m-%d %H:%M UTC",
                    "%Y-%m-%d %H:%M:%S",
                    "%Y-%m-%d %H:%M",
                ):
                    try:
                        parsed = datetime.strptime(text, fmt)
                        break
                    except Exception:
                        continue
                if parsed is None:
                    return None
    if parsed.tzinfo is None:
        if not assume_naive_utc:
            return None
        parsed = parsed.replace(tzinfo=UTC_ZONE)
    return parsed.astimezone(UTC_ZONE)


def format_berlin(
    value: Any,
    *,
    include_date: bool = True,
    include_seconds: bool = True,
    include_utc: bool = True,
) -> str:
    parsed = parse_timestamp(value)
    if parsed is None:
        return str(value or "")
    local = parsed.astimezone(BERLIN_ZONE)
    if include_date and include_seconds:
        local_fmt = "%d.%m.%Y %H:%M:%S %Z"
    elif include_date:
        local_fmt = "%d.%m.%Y %H:%M %Z"
    elif include_seconds:
        local_fmt = "%H:%M:%S %Z"
    else:
        local_fmt = "%H:%M %Z"
    rendered = local.strftime(local_fmt)
    if include_utc:
        utc_fmt = "%H:%M:%S UTC" if include_seconds else "%H:%M UTC"
        rendered += f" ({parsed.strftime(utc_fmt)})"
    return rendered


def utc_age_seconds(value: Any, *, now: datetime | None = None) -> float | None:
    parsed = parse_timestamp(value)
    if parsed is None:
        return None
    reference = parse_timestamp(now or utc_now())
    if reference is None:
        return None
    return max(0.0, (reference - parsed).total_seconds())


def _replacement_from_parts(date_part: str, time_part: str) -> str:
    normalized = f"{date_part}T{time_part}+00:00"
    return format_berlin(
        normalized,
        include_date=True,
        include_seconds=(time_part.count(":") >= 2),
        include_utc=True,
    )


def localize_telegram_text(text: Any, *, add_sent_footer: bool = True) -> str:
    original = str(text or "")

    def repl(match: re.Match[str]) -> str:
        return _replacement_from_parts(match.group(1), match.group(2))

    localized = _ISO_UTC_RE.sub(repl, original)
    localized = _HUMAN_UTC_RE.sub(repl, localized)

    if add_sent_footer and "🕒 Gesendet:" not in localized:
        footer = (
            "🕒 Gesendet: "
            + format_berlin(
                utc_now(),
                include_date=True,
                include_seconds=True,
                include_utc=True,
            )
        )
        if len(localized) + len(footer) + 2 <= 4096:
            localized = localized.rstrip() + "\n\n" + footer
    return localized


_HTML_SCRIPT = r"""<script id="tb-v80154-timezone">
(function(){
  if (window.__tbV80154Loaded) return;
  window.__tbV80154Loaded = true;
  const zone = 'Europe/Berlin';
  const isoRe = /\b(20\d{2}-\d{2}-\d{2})[T ](\d{2}:\d{2}(?::\d{2}(?:\.\d{1,6})?)?)(Z|\+00:00)\b/g;
  const humanRe = /\b(20\d{2}-\d{2}-\d{2})[ T](\d{2}:\d{2}(?::\d{2})?)\s*UTC\b/gi;
  const formatter = new Intl.DateTimeFormat('de-DE', {
    timeZone: zone,
    day:'2-digit', month:'2-digit', year:'numeric',
    hour:'2-digit', minute:'2-digit', second:'2-digit',
    timeZoneName:'short'
  });
  function utcClock(d){
    return String(d.getUTCHours()).padStart(2,'0')+':' +
           String(d.getUTCMinutes()).padStart(2,'0')+':' +
           String(d.getUTCSeconds()).padStart(2,'0')+' UTC';
  }
  function render(dateText,timeText){
    const safeTime=timeText.replace(/\.(\d{3})\d+$/,'.$1');
    const d = new Date(dateText+'T'+safeTime+'Z');
    if (Number.isNaN(d.getTime())) return dateText+' '+timeText+' UTC';
    return formatter.format(d)+' ('+utcClock(d)+')';
  }
  function replaceText(text){
    let out=text.replace(isoRe,function(_,d,t){return render(d,t);});
    out=out.replace(humanRe,function(_,d,t){return render(d,t);});
    out=out.replace(/\bZeit UTC\b/g,'Zeit Berlin / UTC');
    out=out.replace(/\bTime UTC\b/g,'Zeit Berlin / UTC');
    out=out.replace(/\bNow UTC\b/g,'Jetzt Berlin / UTC');
    return out;
  }
  function localizeNode(node){
    if(!node || node.nodeType!==Node.TEXT_NODE) return;
    const parent=node.parentElement;
    if(!parent || /^(SCRIPT|STYLE|TEXTAREA|NOSCRIPT)$/i.test(parent.tagName)) return;
    if(parent.closest('[data-tb-timezone-ignore="1"]')) return;
    const next=replaceText(node.nodeValue||'');
    if(next!==node.nodeValue) node.nodeValue=next;
  }
  function localize(root){
    const walker=document.createTreeWalker(root||document.body,NodeFilter.SHOW_TEXT);
    const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(localizeNode);
  }
  function badge(){
    if(document.getElementById('tb-v80154-clock')) return;
    const el=document.createElement('div');
    el.id='tb-v80154-clock';
    el.style.cssText='position:fixed;right:10px;bottom:10px;z-index:2147483647;background:#07111eee;color:#e6f4ff;border:1px solid #31506f;border-radius:10px;padding:7px 10px;font:700 11px Arial;box-shadow:0 4px 16px #0008;pointer-events:none';
    document.body.appendChild(el);
    function tick(){
      const d=new Date();
      el.textContent='🕒 '+formatter.format(d)+' | '+utcClock(d);
    }
    tick(); setInterval(tick,1000);
  }
  function boot(){localize(document.body);badge();}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot);
  else boot();
  const observer=new MutationObserver(function(items){
    items.forEach(function(item){
      item.addedNodes.forEach(function(n){
        if(n.nodeType===1) localize(n); else localizeNode(n);
      });
    });
  });
  if(document.documentElement){
    observer.observe(document.documentElement,{childList:true,subtree:true});
  }
})();
</script>"""


class TimezoneDisplayMiddleware:
    """Display-only HTML localization. JSON and database values remain UTC."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if (
            scope.get("type") != "http"
            or str(scope.get("method") or "GET").upper() != "GET"
        ):
            await self.app(scope, receive, send)
            return

        path = str(scope.get("path") or "")
        if path.endswith(".json") or path.startswith("/webhook/"):
            await self.app(scope, receive, send)
            return

        start_message: dict[str, Any] | None = None
        body_parts: list[bytes] = []
        is_html = False

        async def wrapped_send(message):
            nonlocal start_message, body_parts, is_html
            if message["type"] == "http.response.start":
                start_message = dict(message)
                headers = list(start_message.get("headers") or [])
                content_type = ""
                for key, value in headers:
                    if key.lower() == b"content-type":
                        content_type = value.decode(
                            "latin-1", errors="ignore"
                        ).lower()
                is_html = (
                    "text/html" in content_type
                    and int(start_message.get("status") or 200) < 400
                )
                if not is_html:
                    await send(message)
                return

            if message["type"] != "http.response.body" or not is_html:
                await send(message)
                return

            body_parts.append(message.get("body") or b"")
            if message.get("more_body", False):
                return

            raw = b"".join(body_parts)
            try:
                text = raw.decode("utf-8")
                if "tb-v80154-timezone" not in text:
                    lower = text.lower()
                    if "</body>" in lower:
                        index = lower.rfind("</body>")
                        text = text[:index] + _HTML_SCRIPT + text[index:]
                    else:
                        text += _HTML_SCRIPT
                raw = text.encode("utf-8")
            except Exception:
                pass

            assert start_message is not None
            headers = []
            for key, value in list(start_message.get("headers") or []):
                if key.lower() == b"content-length":
                    continue
                headers.append((key, value))
            headers.append(
                (b"x-tb-display-timezone", DISPLAY_ZONE_NAME.encode("ascii"))
            )
            start_message["headers"] = headers
            await send(start_message)
            await send(
                {
                    "type": "http.response.body",
                    "body": raw,
                    "more_body": False,
                }
            )

        await self.app(scope, receive, wrapped_send)


def _offset_hours(dt_utc: datetime, zone: ZoneInfo) -> float:
    local = dt_utc.astimezone(zone)
    offset = local.utcoffset()
    return round(
        (offset.total_seconds() if offset else 0.0) / 3600.0,
        2,
    )


def _source_audit() -> dict[str, Any]:
    app_dir = _root() / "app"
    result = {
        "files_scanned": 0,
        "aware_utc_now_occurrences": 0,
        "naive_datetime_now_occurrences": 0,
        "datetime_utcnow_occurrences": 0,
        "naive_files": [],
        "utcnow_files": [],
    }
    if not app_dir.exists():
        return result

    naive_re = re.compile(r"datetime\.now\(\s*\)")
    utcnow_re = re.compile(r"datetime\.utcnow\(\s*\)")
    aware_re = re.compile(
        r"datetime\.now\(\s*(?:timezone\.utc|UTC_ZONE)\s*\)"
    )
    for path in app_dir.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        result["files_scanned"] += 1
        naive = len(naive_re.findall(text))
        utcnow = len(utcnow_re.findall(text))
        aware = len(aware_re.findall(text))
        result["aware_utc_now_occurrences"] += aware
        result["naive_datetime_now_occurrences"] += naive
        result["datetime_utcnow_occurrences"] += utcnow
        rel = str(path.relative_to(_root()))
        if naive:
            result["naive_files"].append({"file": rel, "count": naive})
        if utcnow:
            result["utcnow_files"].append({"file": rel, "count": utcnow})

    result["naive_files"] = sorted(
        result["naive_files"],
        key=lambda row: (-row["count"], row["file"]),
    )[:50]
    result["utcnow_files"] = sorted(
        result["utcnow_files"],
        key=lambda row: (-row["count"], row["file"]),
    )[:50]
    return result


def selftest_payload() -> dict[str, Any]:
    summer = datetime(2026, 7, 14, 14, 45, tzinfo=UTC_ZONE)
    winter = datetime(2026, 1, 14, 14, 45, tzinfo=UTC_ZONE)
    spring_before = datetime(2026, 3, 29, 0, 30, tzinfo=UTC_ZONE)
    spring_after = datetime(2026, 3, 29, 1, 30, tzinfo=UTC_ZONE)
    fall_before = datetime(2026, 10, 25, 0, 30, tzinfo=UTC_ZONE)
    fall_after = datetime(2026, 10, 25, 1, 30, tzinfo=UTC_ZONE)
    telegram_sample = localize_telegram_text(
        "Event 2026-07-14 14:45 UTC",
        add_sent_footer=False,
    )
    checks = {
        "berlin_summer_utc_plus_2": (
            _offset_hours(summer, BERLIN_ZONE) == 2.0
        ),
        "berlin_winter_utc_plus_1": (
            _offset_hours(winter, BERLIN_ZONE) == 1.0
        ),
        "london_summer_utc_plus_1": (
            _offset_hours(summer, LONDON_ZONE) == 1.0
        ),
        "london_winter_utc_plus_0": (
            _offset_hours(winter, LONDON_ZONE) == 0.0
        ),
        "new_york_summer_utc_minus_4": (
            _offset_hours(summer, NEW_YORK_ZONE) == -4.0
        ),
        "new_york_winter_utc_minus_5": (
            _offset_hours(winter, NEW_YORK_ZONE) == -5.0
        ),
        "berlin_spring_dst_transition": (
            _offset_hours(spring_before, BERLIN_ZONE) == 1.0
            and _offset_hours(spring_after, BERLIN_ZONE) == 2.0
        ),
        "berlin_fall_dst_transition": (
            _offset_hours(fall_before, BERLIN_ZONE) == 2.0
            and _offset_hours(fall_after, BERLIN_ZONE) == 1.0
        ),
        "telegram_utc_converted_to_cest": (
            "16:45" in telegram_sample
            and "CEST" in telegram_sample
            and "14:45 UTC" in telegram_sample
        ),
        "utc_age_aware": (
            utc_age_seconds(
                "2026-07-14T14:44:00+00:00",
                now=summer,
            )
            == 60.0
        ),
        "database_storage_policy_utc": True,
        "json_storage_unchanged": True,
        "trading_rules_unchanged": True,
    }
    return {
        "ok": all(checks.values()),
        "version": VERSION,
        "display_timezone": DISPLAY_ZONE_NAME,
        "storage_timezone": "UTC",
        "checks": checks,
        "examples": {
            "summer": format_berlin(summer),
            "winter": format_berlin(winter),
            "telegram": telegram_sample,
            "london_summer": summer.astimezone(LONDON_ZONE).isoformat(),
            "new_york_summer": summer.astimezone(
                NEW_YORK_ZONE
            ).isoformat(),
        },
        "safety": {
            "database_timestamps_rewritten": False,
            "json_timestamps_rewritten": False,
            "v8004_threshold_changes": False,
            "fresh_valid_rule_changes": False,
            "news_window_rule_changes": False,
            "session_rule_changes": False,
            "pine_changes": False,
            "broker_auto_execution": False,
        },
    }


def integrity_payload() -> dict[str, Any]:
    now = utc_now()
    return {
        **selftest_payload(),
        "generated_utc": now.isoformat(),
        "generated_berlin": now.astimezone(BERLIN_ZONE).isoformat(),
        "current_display": format_berlin(now),
        "telegram_localization_active": True,
        "html_display_localization_active": True,
        "source_audit": _source_audit(),
    }


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def page_html() -> str:
    data = integrity_payload()
    checks = data["checks"]
    rows = "".join(
        (
            "<tr><td>"
            + _esc(name)
            + "</td><td class='"
            + ("ok" if value else "bad")
            + "'>"
            + ("PASS" if value else "FAIL")
            + "</td></tr>"
        )
        for name, value in checks.items()
    )
    audit = data["source_audit"]
    naive = "".join(
        (
            "<li><code>"
            + _esc(row["file"])
            + "</code> – "
            + _esc(row["count"])
            + "</li>"
        )
        for row in audit.get("naive_files", [])[:20]
    ) or "<li>Keine gefunden.</li>"
    utcnow = "".join(
        (
            "<li><code>"
            + _esc(row["file"])
            + "</code> – "
            + _esc(row["count"])
            + "</li>"
        )
        for row in audit.get("utcnow_files", [])[:20]
    ) or "<li>Keine gefunden.</li>"
    status_class = "ok" if data["ok"] else "bad"
    status_text = "PASS" if data["ok"] else "FAIL"
    return f"""<!doctype html><html lang='de'><head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>V8015.4 Timezone Integrity</title>
<style>
body{{margin:0;background:#07111e;color:#eef6ff;font-family:Arial,sans-serif}}
.wrap{{max-width:1250px;margin:auto;padding:16px}}
.panel{{background:#101d2e;border:1px solid #2b4059;border-radius:16px;padding:16px;margin:12px 0}}
h1,h2{{margin-top:0}}a{{color:#93c5fd}}
.grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}}
.stat{{background:#0b1728;border:1px solid #2b4059;border-radius:12px;padding:12px}}
.label{{color:#9caec4;font-size:12px}}.value{{font-size:20px;font-weight:900;margin-top:5px}}
table{{width:100%;border-collapse:collapse}}th,td{{border-bottom:1px solid #2b4059;padding:8px;text-align:left}}
.ok{{color:#4ade80;font-weight:900}}.bad{{color:#fb7185;font-weight:900}}
code{{color:#a5d8ff}}ul{{line-height:1.5}}
@media(max-width:800px){{.grid{{grid-template-columns:1fr}}}}
</style></head><body><div class='wrap'>
<p><a href='/master'>Master</a> · <a href='/master-ai-review'>AI Review</a> ·
<a href='/v8015/timezone-integrity.json'>JSON</a> ·
<a href='/v8015/timezone-selftest.json'>Selftest</a></p>
<div class='panel'><h1>V8015.4 Timezone & DST Integrity</h1>
<p>Interne Speicherung bleibt UTC. HTML-Dashboards und Telegram werden
für Deutschland in <b>Europe/Berlin</b> dargestellt; UTC bleibt als
Referenz sichtbar.</p></div>
<div class='grid'>
<div class='stat'><div class='label'>Deutschland jetzt</div><div class='value'>{_esc(data['current_display'])}</div></div>
<div class='stat'><div class='label'>Storage</div><div class='value'>UTC unverändert</div></div>
<div class='stat'><div class='label'>Gesamtstatus</div><div class='value {status_class}'>{status_text}</div></div>
</div>
<div class='panel'><h2>DST- und Zeitzonentests</h2>
<table><tr><th>Test</th><th>Status</th></tr>{rows}</table></div>
<div class='panel'><h2>Darstellungsbeispiele</h2>
<pre>{_esc(json.dumps(data['examples'], indent=2, ensure_ascii=False))}</pre></div>
<div class='panel'><h2>Source Audit</h2>
<p>Gescannte Dateien: {_esc(audit.get('files_scanned'))} ·
UTC-aware now: {_esc(audit.get('aware_utc_now_occurrences'))} ·
naive datetime.now(): {_esc(audit.get('naive_datetime_now_occurrences'))} ·
datetime.utcnow(): {_esc(audit.get('datetime_utcnow_occurrences'))}</p>
<h3>Naive datetime.now()</h3><ul>{naive}</ul>
<h3>datetime.utcnow()</h3><ul>{utcnow}</ul>
<p>Diese Liste ist Diagnose. V8015.4 ändert keine Trading-, Session-
oder News-Regel automatisch.</p></div>
<div class='panel'><h2>Sicherheit</h2>
<pre>{_esc(json.dumps(data['safety'], indent=2, ensure_ascii=False))}</pre></div>
</div></body></html>"""


def install_v8015_4_timezone(app) -> None:
    if getattr(app.state, "v8015_4_timezone_installed", False):
        return

    @app.get("/v8015/timezone-selftest.json")
    def v80154_selftest():
        return JSONResponse(selftest_payload())

    @app.get("/v8015/timezone-integrity.json")
    def v80154_integrity_json():
        return JSONResponse(integrity_payload())

    @app.get(
        "/v8015/timezone-integrity",
        response_class=HTMLResponse,
    )
    def v80154_integrity_page(request: Request):
        return HTMLResponse(page_html())

    app.add_middleware(TimezoneDisplayMiddleware)
    app.state.v8015_4_timezone_installed = True
    print(
        "[V8015.4] Europe/Berlin display + Telegram UTC "
        "localization installed; storage remains UTC"
    )
