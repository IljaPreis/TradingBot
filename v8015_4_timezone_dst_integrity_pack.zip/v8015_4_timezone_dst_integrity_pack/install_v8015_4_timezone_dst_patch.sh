#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="V8015.4-TIMEZONE-DST-INTEGRITY-V1"
PROJECT="/opt/tradingbot_v6000"
PACKAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE="$PROJECT/docker-compose.yml"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8015_4_before_${STAMP}"
INSTALL_LOG="/root/v8015_4_install_${STAMP}.log"
BUILD_LOG="/root/v8015_4_build_${STAMP}.log"
ROLLBACK_ACTIVE=0

exec > >(tee -a "$INSTALL_LOG") 2>&1

FILES=(
  "app/main.py"
  "app/v8003_master_navigation.py"
  "app/engines/telegram_engine.py"
  "app/v8015_4_timezone.py"
  "ops/v8015_4_timezone_check.sh"
)

baseline_check() {
  local rel="$1" expected="$2" actual
  [[ -f "$PROJECT/$rel" ]] || {
    echo "FEHLER: Baseline-Datei fehlt: $rel"
    return 1
  }
  actual="$(sha256sum "$PROJECT/$rel" | awk '{print $1}')"
  printf '%-60s %s\n' "$rel" "$actual"
  [[ "$actual" == "$expected" ]] || {
    echo "FEHLER: Unerwartete V8015.3-Baseline bei $rel"
    echo "Erwartet: $expected"
    echo "Ist:      $actual"
    return 1
  }
}

rollback() {
  local rc=$?
  if [[ "$ROLLBACK_ACTIVE" != "1" ]]; then
    exit "$rc"
  fi
  trap - ERR INT TERM
  echo
  echo "=== V8015.4 FEHLER – AUTOMATISCHER ROLLBACK ==="
  set +e
  cd "$PROJECT"
  docker compose stop tradingbot_ingress tradingbot >/dev/null 2>&1 || true
  for rel in "${FILES[@]}"; do
    rm -f "$PROJECT/$rel"
  done
  [[ -d "$BACKUP/files" ]] &&
    cp -a "$BACKUP/files/." "$PROJECT/"
  [[ -f "$BACKUP/docker-compose.yml" ]] &&
    cp -a "$BACKUP/docker-compose.yml" "$COMPOSE"
  docker compose up -d --force-recreate || true
  echo "Rollback: $BACKUP"
  echo "Log: $INSTALL_LOG"
  exit "$rc"
}
trap rollback ERR INT TERM

echo "================================================================================"
echo "$VERSION INSTALL"
echo "================================================================================"
echo "UTC:     $(date -u --iso-8601=seconds)"
echo "Project: $PROJECT"
echo "Package: $PACKAGE"
echo
echo "Umfang:"
echo "  HTML-Dashboards zeigen Europe/Berlin + UTC"
echo "  Telegram-Timestamps zeigen CET/CEST + UTC"
echo "  DST-Selbsttests für Berlin, London und New York"
echo "  UTC-aware Altersberechnung und Source-Audit"
echo "  Datenbank und JSON bleiben unverändert in UTC"
echo
echo "Unverändert:"
echo "  V8004 Schwellen/FRESH/VALID"
echo "  News- und Session-Regeln"
echo "  Pine-Skripte"
echo "  Webhook-Tokenmodus OFF"
echo "  Broker Auto Execution FALSE"

[[ -d "$PROJECT" ]] || {
  echo "FEHLER: Projekt fehlt"
  exit 1
}
[[ -f "$COMPOSE" ]] || {
  echo "FEHLER: Compose fehlt"
  exit 1
}

cd "$PACKAGE"
echo "[1] Paket-Hashes und statisches Audit"
sha256sum -c MANIFEST.sha256
python3 - <<'PY'
import json
x=json.load(open('STATIC_AUDIT.json',encoding='utf-8'))
assert x['version']=='V8015.4-TIMEZONE-DST-INTEGRITY-V1'
for key in (
    'python_compile','shell_syntax','dst_selftest',
    'telegram_localization_test','html_injection_test',
):
    assert x['validation'][key] is True
for key in (
    'database_timestamp_rewrite','v8004_threshold_changes',
    'fresh_valid_rule_changes','news_window_rule_changes',
    'session_rule_changes','pine_changes',
    'broker_auto_execution',
):
    assert x['safety'][key] is False
print('Static audit: PASS')
PY

echo "[2] V8015.3 Produktions-Baseline prüfen"
baseline_check   "app/main.py"   "57aee573164717f477d138b5c28cc8b9e36abc6e4ef41ced0c9206594eb6bcaa"
baseline_check   "app/v8003_master_navigation.py"   "90cb9e06dd783f6885ecedf3091cdbb06ab35365baa9dd358d731bbff3760583"
baseline_check   "app/engines/telegram_engine.py"   "1bfa78232ebf68d8a8aa3afac37c61b276464e9fdf6726822293250a7d303329"
baseline_check   "app/v7243_6_macro_actual_extractor.py"   "88b82c1e816470f6ed8ae5e570afabf7e087fa75e936fbf4a1403cb439cab2d2"
baseline_check   "app/v8011_ingress.py"   "da789babd83b67f08d4cc496aa6aa5f15c1dd208bf2c38bff2f5618e14cf1d57"
baseline_check   "app/routes/v8015_reliability.py"   "cb7957c3b98de9653beacf880ef5a158d861873eab2210b4e22223a91111f688"

PROTECTED=(
  "app/v8004_quality_router.py"
  "app/v8006_calendar_execution_correction.py"
  "app/v8007_v8001_gate_bridge.py"
  "pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"
)

mkdir -p "$BACKUP/files"
cp -a "$COMPOSE" "$BACKUP/docker-compose.yml"

for rel in "${FILES[@]}"; do
  if [[ -f "$PROJECT/$rel" ]]; then
    mkdir -p "$BACKUP/files/$(dirname "$rel")"
    cp -a "$PROJECT/$rel" "$BACKUP/files/$rel"
  fi
done

for rel in "${PROTECTED[@]}"; do
  if [[ -f "$PROJECT/$rel" ]]; then
    sha256sum "$PROJECT/$rel" >> "$BACKUP/protected_before.sha256"
  fi
done

ROLLBACK_ACTIVE=1
cd "$PROJECT"
docker compose stop tradingbot_ingress tradingbot

echo "[3] V8015.4 Dateien installieren"
for rel in "${FILES[@]}"; do
  mkdir -p "$PROJECT/$(dirname "$rel")"
  cp -a "$PACKAGE/$rel" "$PROJECT/$rel"
done
chmod 700 "$PROJECT/ops/v8015_4_timezone_check.sh"
find "$PROJECT/app" -type d -name __pycache__ -prune   -exec rm -rf {} + 2>/dev/null || true

python3 -m py_compile   "$PROJECT/app/main.py"   "$PROJECT/app/v8003_master_navigation.py"   "$PROJECT/app/engines/telegram_engine.py"   "$PROJECT/app/v8015_4_timezone.py"

echo "[4] Geschützte Trading-Komponenten unverändert"
if [[ -s "$BACKUP/protected_before.sha256" ]]; then
  (cd / && sha256sum -c "$BACKUP/protected_before.sha256")
fi

echo "[5] Compose auf v8015_4 setzen"
python3 - "$COMPOSE" <<'PY'
from pathlib import Path
import sys
path=Path(sys.argv[1])
lines=path.read_text(encoding='utf-8').splitlines()
out=[]
service=None
for line in lines:
    if (
        line.startswith('  ')
        and not line.startswith('    ')
        and line.rstrip().endswith(':')
    ):
        service=line.strip()[:-1]
    if (
        service in {'tradingbot','tradingbot_ingress'}
        and line.startswith('    image:')
    ):
        out.append('    image: tradingbot_v6000-app:v8015_4')
    else:
        out.append(line)
path.write_text('\n'.join(out)+'\n', encoding='utf-8')
PY

echo "[6] Image bauen und Container starten"
docker compose build 2>&1 | tee "$BUILD_LOG"
docker compose up -d --force-recreate

for i in $(seq 1 90); do
  code="$(
    curl -s -o /dev/null -w '%{http_code}'       http://127.0.0.1/health || true
  )"
  if [[ "$code" == "200" ]]; then
    echo "Health: 200"
    break
  fi
  echo "WAIT [$i/90] health=$code"
  sleep 2
done
[[ "$(
  curl -s -o /dev/null -w '%{http_code}'     http://127.0.0.1/health
)" == "200" ]]

for i in $(seq 1 60); do
  status="$(
    docker inspect -f '{{.State.Health.Status}}'       tradingbot_ingress 2>/dev/null || true
  )"
  if [[ "$status" == "healthy" ]]; then
    echo "Ingress: healthy"
    break
  fi
  echo "WAIT [$i/60] ingress=$status"
  sleep 2
done
[[ "$(
  docker inspect -f '{{.State.Health.Status}}'     tradingbot_ingress
)" == "healthy" ]]

echo "[7] Vollständiger V8015.4 Check"
bash "$PROJECT/ops/v8015_4_timezone_check.sh"

echo "[8] Token OFF und ältere Module weiter gesund"
python3 - <<'PY'
import json
from urllib.request import urlopen
for route in (
    '/v8015/selftest.json',
    '/v8011/selftest.json',
    '/v8004/selftest.json',
):
    x=json.load(urlopen(
        'http://127.0.0.1'+route,
        timeout=30,
    ))
    assert x.get('ok') is True, (route,x)
ing=json.load(urlopen(
    'http://127.0.0.1/v8011/selftest.json',
    timeout=30,
))
assert ing.get('token_mode')=='off'
assert ing.get('token_enforced') is False
print('Older selftests and token OFF: PASS')
PY

ROLLBACK_ACTIVE=0
trap - ERR INT TERM

echo "================================================================================"
echo "V8015.4 INSTALLATION FERTIG"
echo "================================================================================"
echo "Backup: $BACKUP"
echo "Install log: $INSTALL_LOG"
echo "Build log: $BUILD_LOG"
echo "Dashboard: http://91.107.237.214/v8015/timezone-integrity"
echo "Storage/JSON bleiben UTC; Darstellung ist Europe/Berlin + UTC."
