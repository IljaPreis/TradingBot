#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="/opt/tradingbot_v6000"
cd "$PROJECT"

echo "=== V8015.4 TIMEZONE & DST INTEGRITY CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"

echo "[1] Containers"
docker compose ps

echo "[2] Critical routes"
for route in \
  /health \
  /master \
  /master-ai-review \
  /v8015/timezone-integrity \
  /v8015/timezone-integrity.json \
  /v8015/timezone-selftest.json \
  /v8015/reliability.json \
  /v8015/selftest.json \
  /v8011/selftest.json \
  /v8004/selftest.json; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' "http://127.0.0.1$route")"
  printf '%-52s %s\n' "$route" "$code"
  [[ "$code" == "200" ]]
done

echo "[3] Timezone selftest"
curl -fsS http://127.0.0.1/v8015/timezone-selftest.json |
python3 -m json.tool

python3 - <<'PY'
import json
from urllib.request import urlopen
x=json.load(urlopen(
    'http://127.0.0.1/v8015/timezone-selftest.json',
    timeout=30,
))
assert x.get('ok') is True
checks=x.get('checks') or {}
required=[
 'berlin_summer_utc_plus_2','berlin_winter_utc_plus_1',
 'london_summer_utc_plus_1','london_winter_utc_plus_0',
 'new_york_summer_utc_minus_4','new_york_winter_utc_minus_5',
 'berlin_spring_dst_transition','berlin_fall_dst_transition',
 'telegram_utc_converted_to_cest','utc_age_aware',
 'database_storage_policy_utc','json_storage_unchanged'
]
missing=[name for name in required if checks.get(name) is not True]
assert not missing, missing
s=x.get('safety') or {}
assert s.get('database_timestamps_rewritten') is False
assert s.get('v8004_threshold_changes') is False
assert s.get('fresh_valid_rule_changes') is False
assert s.get('news_window_rule_changes') is False
assert s.get('session_rule_changes') is False
assert s.get('pine_changes') is False
assert s.get('broker_auto_execution') is False
print('Timezone/DST selftest: PASS')
PY

echo "[4] HTML display injection"
TMP_HEADERS="$(mktemp)"
TMP_BODY="$(mktemp)"
trap 'rm -f "$TMP_HEADERS" "$TMP_BODY"' EXIT
curl -fsS \
  -D "$TMP_HEADERS" \
  -o "$TMP_BODY" \
  http://127.0.0.1/v8015/timezone-integrity
tr -d '\r' < "$TMP_HEADERS" | \
  grep -i '^x-tb-display-timezone: Europe/Berlin$'
grep -q 'tb-v80154-timezone' "$TMP_BODY"
rm -f "$TMP_HEADERS" "$TMP_BODY"
trap - EXIT
echo "HTML Berlin display injection: PASS"

echo "[5] Telegram localization unit check"
docker exec -i tradingbot python - <<'PY'
from app.v8015_4_timezone import (
    localize_telegram_text,
    format_berlin,
)
text=localize_telegram_text(
    'Outcome 2026-07-14 14:45 UTC',
    add_sent_footer=False,
)
print(text)
assert '16:45' in text
assert 'CEST' in text
assert '14:45 UTC' in text
print(format_berlin('2026-01-14T14:45:00+00:00'))
PY

echo "[6] Storage remains UTC"
python3 - <<'PY'
import sqlite3
from pathlib import Path
p=Path('data/v7000_learning.sqlite3')
con=sqlite3.connect(
    f'file:{p}?mode=ro',
    uri=True,
    timeout=60,
)
integrity=con.execute('PRAGMA integrity_check').fetchone()[0]
print('integrity:', integrity)
assert integrity=='ok'
con.close()
PY

echo "[7] Ingress remains GREEN and token OFF"
python3 - <<'PY'
import json
from urllib.request import urlopen
x=json.load(urlopen(
    'http://127.0.0.1/v8011/selftest.json',
    timeout=30,
))
print(json.dumps({
    k:x.get(k)
    for k in (
        'ok','operational_status','queue_depth',
        'active_dead_letter_total','token_mode',
        'token_enforced',
    )
}, indent=2))
assert x.get('ok') is True
assert x.get('operational_status') == 'GREEN'
assert x.get('queue_depth') == 0
assert x.get('active_dead_letter_total') == 0
assert x.get('token_mode') == 'off'
assert x.get('token_enforced') is False
PY

echo "[8] Errors last 30m"
for c in tradingbot tradingbot_ingress; do
  echo "--- $c ---"
  docker logs "$c" --since 30m 2>&1 |
  grep -Ei 'traceback|exception|error|failed' |
  tail -n 30 || true
done

echo "[9] Resources"
free -h
df -h /

echo "=== V8015.4 CHECK FERTIG ==="
