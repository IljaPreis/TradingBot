# V8015.5 Trade Levels & Live Status

Adds entry, SL, TP1, current heartbeat price, current R and status to new LIVE and V8004 SHADOW Telegram messages.

Adds a compact automatically refreshing open-trades table to `/v8004/quality-router` and a full page at `/v8015/trade-levels`.

The table contains open LIVE and SHADOW positions only. Current price is read from `price_heartbeats`. No trade, routing, threshold, Pine or broker rule is changed. No database schema or row is changed.

Internal timestamps remain UTC. Visible time uses the V8015.4 Europe/Berlin display layer.
