from __future__ import annotations

import html
import json
import math
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8015.5-TRADE-LEVELS-LIVE-STATUS-V1"
DISPLAY_TZ = "Europe/Berlin"


def _root() -> Path:
    env = os.getenv("V80155_ROOT", "").strip()
    if env:
        return Path(env)
    for candidate in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        try:
            if (candidate / "data").exists():
                return candidate
        except Exception:
            pass
    return Path.cwd()


def _db() -> Path:
    return _root() / "data" / "v7000_learning.sqlite3"


def _connect() -> sqlite3.Connection:
    con = sqlite3.connect(str(_db()), timeout=20)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=20000")
    return con


def _table_exists(con: sqlite3.Connection, table: str) -> bool:
    return con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
        (table,),
    ).fetchone() is not None


def _text(value: Any) -> str:
    return str(value or "").strip()


def _upper(value: Any) -> str:
    return _text(value).upper()


def _num(value: Any, default: float | None = None) -> float | None:
    try:
        if value is None or value == "":
            return default
        result = float(str(value).replace(",", "."))
        return result if math.isfinite(result) else default
    except Exception:
        return default


def _canonical_market(raw: Any) -> str:
    try:
        from app.routes.v8014a_heartbeat_integrity import canonicalize_market
        return _upper(canonicalize_market(raw))
    except Exception:
        key = _upper(raw).replace(" ", "").replace("_", "").replace("-", "")
        aliases = {
            "NIKKEI": "JP225",
            "JPN225": "JP225",
            "JAPAN225": "JP225",
            "NI225": "JP225",
            "UKOILSPOT": "BRENT",
            "UKOIL": "BRENT",
            "DE40": "GER40",
            "DAX": "GER40",
            "DAX40": "GER40",
            "NAS100": "US100",
            "USTEC": "US100",
            "NDX": "US100",
            "SPX500": "US500",
            "SP500": "US500",
            "AUS200": "ASX200",
            "AU200": "ASX200",
        }
        return aliases.get(key, key)


def _parse_utc(value: Any) -> datetime | None:
    if value is None or value == "":
        return None
    try:
        if isinstance(value, (int, float)):
            number = float(value)
            if number > 10_000_000_000:
                number /= 1000.0
            return datetime.fromtimestamp(number, tz=timezone.utc)
        text = str(value).strip()
        try:
            number = float(text)
            if number > 10_000_000_000:
                number /= 1000.0
            return datetime.fromtimestamp(number, tz=timezone.utc)
        except ValueError:
            pass
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _local_time(value: Any) -> str:
    try:
        from app.v8015_4_timezone import format_berlin
        return format_berlin(value)
    except Exception:
        dt = _parse_utc(value)
        return dt.isoformat() if dt else _text(value)


def _price(value: Any) -> str:
    number = _num(value)
    if number is None:
        return "–"
    absolute = abs(number)
    if absolute >= 1000:
        digits = 2
    elif absolute >= 10:
        digits = 3
    elif absolute >= 1:
        digits = 5
    else:
        digits = 5
    return f"{number:.{digits}f}".rstrip("0").rstrip(".")


def _signed(value: float | None, suffix: str = "") -> str:
    if value is None:
        return "–"
    return f"{value:+.2f}{suffix}"


def _position_metrics(
    direction: str,
    entry: float | None,
    sl: float | None,
    tp: float | None,
    current: float | None,
    heartbeat_age_seconds: float | None,
) -> dict[str, Any]:
    direction = _upper(direction)
    risk = abs(entry - sl) if entry is not None and sl is not None else None
    target = abs(tp - entry) if entry is not None and tp is not None else None

    current_r: float | None = None
    progress_pct: float | None = None
    distance_sl: float | None = None
    distance_tp: float | None = None

    if current is not None and entry is not None:
        move = current - entry if direction == "LONG" else entry - current
        if risk and risk > 0:
            current_r = move / risk
        if target and target > 0:
            progress_pct = move / target * 100.0

    if current is not None and sl is not None:
        distance_sl = abs(current - sl)
    if current is not None and tp is not None:
        distance_tp = abs(tp - current)

    status = "OPEN"
    status_class = "neutral"
    if current is None:
        status = "KEIN PREIS"
        status_class = "bad"
    elif heartbeat_age_seconds is not None and heartbeat_age_seconds > 180:
        status = "PREIS STALE"
        status_class = "warn"
    elif direction == "LONG" and sl is not None and current <= sl:
        status = "SL-BEREICH"
        status_class = "bad"
    elif direction == "SHORT" and sl is not None and current >= sl:
        status = "SL-BEREICH"
        status_class = "bad"
    elif direction == "LONG" and tp is not None and current >= tp:
        status = "TP-BEREICH"
        status_class = "good"
    elif direction == "SHORT" and tp is not None and current <= tp:
        status = "TP-BEREICH"
        status_class = "good"
    elif current_r is not None and current_r >= 0:
        status = "IM PLUS"
        status_class = "good"
    elif current_r is not None:
        status = "IM MINUS"
        status_class = "warn"

    return {
        "risk_distance": risk,
        "target_distance": target,
        "current_r": current_r,
        "progress_pct": progress_pct,
        "distance_to_sl": distance_sl,
        "distance_to_tp": distance_tp,
        "status_text": status,
        "status_class": status_class,
    }


def _heartbeat_map(con: sqlite3.Connection) -> dict[str, dict[str, Any]]:
    if not _table_exists(con, "price_heartbeats"):
        return {}
    result: dict[str, dict[str, Any]] = {}
    for row in con.execute(
        "SELECT market, ticker, close, received_at FROM price_heartbeats"
    ).fetchall():
        data = dict(row)
        market = _canonical_market(data.get("market"))
        received = _parse_utc(data.get("received_at"))
        age = (
            max(0.0, (datetime.now(timezone.utc) - received).total_seconds())
            if received
            else None
        )
        result[market] = {
            "current_price": _num(data.get("close")),
            "heartbeat_at": data.get("received_at"),
            "heartbeat_age_seconds": age,
            "heartbeat_ticker": data.get("ticker"),
        }
    return result


def _latest_router_map(con: sqlite3.Connection) -> dict[str, dict[str, Any]]:
    if not _table_exists(con, "v8004_quality_router_log"):
        return {}
    rows = con.execute(
        """
        SELECT client_trade_id, grade, route, pine_score, playbook
        FROM v8004_quality_router_log
        WHERE client_trade_id IS NOT NULL AND client_trade_id <> ''
        ORDER BY id DESC
        """
    ).fetchall()
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        cid = _text(row["client_trade_id"])
        if cid and cid not in result:
            result[cid] = dict(row)
    return result


def trade_level_rows(limit: int = 50) -> list[dict[str, Any]]:
    con = _connect()
    try:
        heartbeats = _heartbeat_map(con)
        router = _latest_router_map(con)
        rows: list[dict[str, Any]] = []

        if _table_exists(con, "open_trades"):
            live_rows = con.execute(
                """
                SELECT client_trade_id, market, direction, setup_name,
                       entry, sl, tp1, status, opened_at
                FROM open_trades
                WHERE UPPER(COALESCE(status,'OPEN'))='OPEN'
                ORDER BY opened_at DESC
                """
            ).fetchall()
            for raw in live_rows:
                data = dict(raw)
                data["trade_type"] = "LIVE"
                rows.append(data)

        if _table_exists(con, "shadow_trades"):
            shadow_rows = con.execute(
                """
                SELECT client_trade_id, shadow_id, market, direction, setup_name,
                       entry, sl, tp1, status, opened_at
                FROM shadow_trades
                WHERE UPPER(COALESCE(status,'OPEN'))='OPEN'
                ORDER BY opened_at DESC
                """
            ).fetchall()
            for raw in shadow_rows:
                data = dict(raw)
                data["trade_type"] = "SHADOW"
                rows.append(data)

        output: list[dict[str, Any]] = []
        for data in rows[: max(1, min(int(limit), 200))]:
            market = _canonical_market(data.get("market"))
            hb = heartbeats.get(market, {})
            route = router.get(_text(data.get("client_trade_id")), {})
            entry = _num(data.get("entry"))
            sl = _num(data.get("sl"))
            tp = _num(data.get("tp1"))
            current = _num(hb.get("current_price"))
            metrics = _position_metrics(
                _upper(data.get("direction")),
                entry,
                sl,
                tp,
                current,
                _num(hb.get("heartbeat_age_seconds")),
            )
            opened_at = data.get("opened_at")
            item = {
                "trade_type": data.get("trade_type"),
                "client_trade_id": data.get("client_trade_id"),
                "shadow_id": data.get("shadow_id"),
                "market": market,
                "direction": _upper(data.get("direction")),
                "setup_name": data.get("setup_name"),
                "entry": entry,
                "sl": sl,
                "tp1": tp,
                "current_price": current,
                "opened_at_utc": opened_at,
                "opened_at_display": _local_time(opened_at),
                "heartbeat_at_utc": hb.get("heartbeat_at"),
                "heartbeat_age_seconds": hb.get("heartbeat_age_seconds"),
                "heartbeat_ticker": hb.get("heartbeat_ticker"),
                "grade": route.get("grade"),
                "route": route.get("route") or data.get("trade_type"),
                "pine_score": route.get("pine_score"),
                "playbook": route.get("playbook"),
                **metrics,
            }
            item["stand_text"] = (
                f"{_signed(item.get('current_r'), 'R')} · "
                f"{_signed(item.get('progress_pct'), '%')} zum TP"
            )
            output.append(item)
        return output
    finally:
        con.close()


def trade_levels_payload(limit: int = 50) -> dict[str, Any]:
    rows = trade_level_rows(limit=limit)
    return {
        "ok": True,
        "version": VERSION,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "display_timezone": DISPLAY_TZ,
        "storage_timezone": "UTC",
        "summary": {
            "open_total": len(rows),
            "open_live": sum(1 for row in rows if row.get("trade_type") == "LIVE"),
            "open_shadow": sum(1 for row in rows if row.get("trade_type") == "SHADOW"),
            "in_profit": sum(1 for row in rows if (row.get("current_r") or 0) > 0),
            "in_loss": sum(1 for row in rows if (row.get("current_r") or 0) < 0),
            "stale_prices": sum(1 for row in rows if row.get("status_text") == "PREIS STALE"),
        },
        "rows": rows,
        "safety": {
            "display_only": True,
            "database_writes": False,
            "routing_changes": False,
            "threshold_changes": False,
            "fresh_valid_rule_changes": False,
            "pine_changes": False,
            "broker_auto_execution": False,
        },
    }


def _latest_price_status(market: Any, direction: Any, entry: Any, sl: Any, tp: Any) -> dict[str, Any]:
    canonical = _canonical_market(market)
    try:
        con = _connect()
        row = None
        if _table_exists(con, "price_heartbeats"):
            rows = con.execute(
                "SELECT market, close, received_at FROM price_heartbeats"
            ).fetchall()
            for candidate in rows:
                if _canonical_market(candidate["market"]) == canonical:
                    row = candidate
                    break
        con.close()
        current = _num(row["close"]) if row else _num(entry)
        received = _parse_utc(row["received_at"]) if row else None
        age = (
            max(0.0, (datetime.now(timezone.utc) - received).total_seconds())
            if received
            else None
        )
    except Exception:
        current = _num(entry)
        age = None
    metrics = _position_metrics(
        _upper(direction),
        _num(entry),
        _num(sl),
        _num(tp),
        current,
        age,
    )
    return {"market": canonical, "current": current, "age": age, **metrics}


def _append_level_block(
    base_text: str,
    *,
    market: Any,
    direction: Any,
    entry: Any,
    sl: Any,
    tp: Any,
    trade_type: str,
) -> str:
    if "📊 LEVELS" in base_text:
        return base_text
    status = _latest_price_status(market, direction, entry, sl, tp)
    return (
        f"{base_text}\n"
        f"📊 LEVELS\n"
        f"Einstieg: {_price(entry)}\n"
        f"SL: {_price(sl)} | TP1: {_price(tp)}\n"
        f"Aktuell: {_price(status.get('current'))} | Stand: {_signed(status.get('current_r'), 'R')}\n"
        f"Status: {trade_type} {status.get('status_text')}"
    )


def _obj_dict(obj: Any) -> dict[str, Any]:
    if isinstance(obj, dict):
        return dict(obj)
    try:
        if hasattr(obj, "model_dump"):
            data = obj.model_dump()
            return data if isinstance(data, dict) else {}
        if hasattr(obj, "dict"):
            data = obj.dict()
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}


def patch_telegram_formatters() -> dict[str, bool]:
    patched_live = False
    patched_shadow = False

    main_module = sys.modules.get("app.main")
    if main_module is not None and hasattr(main_module, "_format_v7000_telegram"):
        original = getattr(main_module, "_format_v7000_telegram")
        if not getattr(original, "_v80155_patched", False):
            def live_wrapper(signal_obj: Any, old_d: dict[str, Any], v7: dict[str, Any]) -> str:
                base = original(signal_obj, old_d, v7)
                payload = _obj_dict(signal_obj)
                return _append_level_block(
                    base,
                    market=v7.get("market") or payload.get("market"),
                    direction=v7.get("direction") or payload.get("side"),
                    entry=v7.get("entry") or payload.get("entry") or payload.get("price"),
                    sl=v7.get("sl") or payload.get("sl"),
                    tp=v7.get("tp1") or payload.get("tp1"),
                    trade_type="LIVE",
                )
            live_wrapper._v80155_patched = True  # type: ignore[attr-defined]
            setattr(main_module, "_format_v7000_telegram", live_wrapper)
            patched_live = True

    try:
        from app import v8004_quality_router as router
        original_shadow = router.v8004_shadow_telegram
        if not getattr(original_shadow, "_v80155_patched", False):
            def shadow_wrapper(signal_obj: Any, v7: dict[str, Any]) -> str:
                base = original_shadow(signal_obj, v7)
                payload = _obj_dict(signal_obj)
                decision = v7.get("v8004_quality_router") if isinstance(v7.get("v8004_quality_router"), dict) else {}
                return _append_level_block(
                    base,
                    market=decision.get("market") or payload.get("market") or v7.get("market"),
                    direction=decision.get("direction") or payload.get("direction") or payload.get("side") or v7.get("direction"),
                    entry=payload.get("entry") or payload.get("price") or v7.get("entry"),
                    sl=payload.get("sl") or v7.get("sl"),
                    tp=payload.get("tp1") or v7.get("tp1"),
                    trade_type="SHADOW",
                )
            shadow_wrapper._v80155_patched = True  # type: ignore[attr-defined]
            router.v8004_shadow_telegram = shadow_wrapper
            patched_shadow = True
    except Exception:
        pass

    return {
        "live_telegram_patched": patched_live or bool(
            getattr(getattr(main_module, "_format_v7000_telegram", None), "_v80155_patched", False)
        ),
        "shadow_telegram_patched": patched_shadow,
    }


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _token_ok(request: Request) -> bool:
    try:
        from app.v7200_event_risk import _token_ok as real_token_ok
        return bool(real_token_ok(request))
    except Exception:
        return True


def _rows_html(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<tr><td colspan='10'>Keine offenen Live- oder Shadow-Trades.</td></tr>"
    output = []
    for row in rows:
        css = _esc(row.get("status_class") or "neutral")
        output.append(
            "<tr>"
            f"<td><b>{_esc(row.get('trade_type'))}</b></td>"
            f"<td>{_esc(row.get('market'))}</td>"
            f"<td>{_esc(row.get('direction'))}</td>"
            f"<td>{_esc(_price(row.get('entry')))}</td>"
            f"<td>{_esc(_price(row.get('sl')))}</td>"
            f"<td>{_esc(_price(row.get('tp1')))}</td>"
            f"<td>{_esc(_price(row.get('current_price')))}</td>"
            f"<td>{_esc(row.get('stand_text'))}</td>"
            f"<td><span class='v80155-status {css}'>{_esc(row.get('status_text'))}</span></td>"
            f"<td>{_esc(row.get('opened_at_display'))}</td>"
            "</tr>"
        )
    return "".join(output)


def _panel_html(payload: dict[str, Any]) -> str:
    summary = payload.get("summary") or {}
    return f"""
<section id='v80155-trade-levels' class='c v80155-card'>
  <div class='v80155-head'>
    <div>
      <h2>Offene Trades – Einstieg / SL / TP / aktueller Stand</h2>
      <div class='v80155-sub'>Live {int(summary.get('open_live',0))} · Shadow {int(summary.get('open_shadow',0))} · automatische Aktualisierung alle 20 Sekunden</div>
    </div>
    <a href='/v8015/trade-levels'>Große Ansicht</a>
  </div>
  <div class='v80155-scroll'>
    <table class='v80155-table'>
      <thead><tr><th>Typ</th><th>Markt</th><th>Dir</th><th>Einstieg</th><th>SL</th><th>TP</th><th>Aktuell</th><th>Stand</th><th>Status</th><th>Eröffnet</th></tr></thead>
      <tbody id='v80155-body'>{_rows_html(payload.get('rows') or [])}</tbody>
    </table>
  </div>
</section>
<style id='v80155-style'>
.v80155-card{{border-color:#315273!important}}.v80155-head{{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:9px}}.v80155-head h2{{font-size:16px;margin:0 0 3px}}.v80155-sub{{font-size:11px;color:#9fb1c8}}.v80155-scroll{{overflow:auto}}.v80155-table{{min-width:980px}}.v80155-status{{padding:4px 7px;border-radius:999px;font-weight:800;font-size:10px}}.v80155-status.good{{color:#24d17e;background:#0b3325}}.v80155-status.warn{{color:#ffd166;background:#3a2d0b}}.v80155-status.bad{{color:#ff6b6b;background:#3a151b}}.v80155-status.neutral{{color:#a5d8ff;background:#142b45}}
</style>
<script id='v80155-script'>
(function(){{
  function esc(v){{return String(v==null?'–':v).replace(/[&<>"']/g,function(c){{return {{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}}[c];}});}}
  function price(v){{if(v==null)return '–';var n=Number(v);if(!Number.isFinite(n))return '–';var d=Math.abs(n)>=1000?2:(Math.abs(n)>=10?3:5);return n.toFixed(d).replace(/0+$/,'').replace(/\\.$/,'');}}
  function row(r){{return '<tr><td><b>'+esc(r.trade_type)+'</b></td><td>'+esc(r.market)+'</td><td>'+esc(r.direction)+'</td><td>'+price(r.entry)+'</td><td>'+price(r.sl)+'</td><td>'+price(r.tp1)+'</td><td>'+price(r.current_price)+'</td><td>'+esc(r.stand_text)+'</td><td><span class="v80155-status '+esc(r.status_class||'neutral')+'">'+esc(r.status_text)+'</span></td><td>'+esc(r.opened_at_display)+'</td></tr>';}}
  async function refresh(){{try{{var res=await fetch('/v8015/trade-levels.json',{{credentials:'same-origin',cache:'no-store'}});if(!res.ok)return;var d=await res.json();var body=document.getElementById('v80155-body');if(!body)return;body.innerHTML=(d.rows&&d.rows.length)?d.rows.map(row).join(''):'<tr><td colspan="10">Keine offenen Live- oder Shadow-Trades.</td></tr>';}}catch(e){{}}}}
  setInterval(refresh,20000);
}})();
</script>
"""


class TradeLevelsQualityPageMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if (
            scope.get("type") != "http"
            or _upper(scope.get("method") or "GET") != "GET"
            or scope.get("path") != "/v8004/quality-router"
        ):
            await self.app(scope, receive, send)
            return

        start: dict[str, Any] | None = None
        chunks: list[bytes] = []

        async def capture(message):
            nonlocal start
            if message["type"] == "http.response.start":
                start = dict(message)
                return
            if message["type"] != "http.response.body":
                return
            chunks.append(message.get("body", b""))
            if message.get("more_body", False):
                return
            if start is None:
                return
            body = b"".join(chunks)
            headers = list(start.get("headers", []))
            content_type = next(
                (value.decode("latin1") for key, value in headers if key.lower() == b"content-type"),
                "",
            )
            if start.get("status") == 200 and "text/html" in content_type:
                text = body.decode("utf-8", errors="ignore")
                if "id='v80155-trade-levels'" not in text:
                    panel = _panel_html(trade_levels_payload(limit=50))
                    marker = "<div class='c'><b>Wichtig:</b>"
                    if marker in text:
                        text = text.replace(marker, panel + marker, 1)
                    elif "</body>" in text:
                        text = text.replace("</body>", panel + "</body>", 1)
                    body = text.encode("utf-8")
            headers = [
                (key, value)
                for key, value in headers
                if key.lower() not in {b"content-length", b"content-encoding"}
            ]
            headers.append((b"content-length", str(len(body)).encode("ascii")))
            start["headers"] = headers
            await send(start)
            await send({"type": "http.response.body", "body": body, "more_body": False})

        await self.app(scope, receive, capture)


def _page(payload: dict[str, Any]) -> str:
    panel = _panel_html(payload)
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>V8015.5 Trade Levels</title><style>:root{{--bg:#07111f;--card:#101d2e;--line:#29415e;--text:#eef5ff;--muted:#9fb1c8}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 system-ui}}.w{{max-width:1500px;margin:auto;padding:16px}}.hero,.c{{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;margin-bottom:14px}}a{{color:#a5d8ff}}</style></head><body><div class='w'><div class='hero'><h1>V8015.5 Trade Levels & Live Status</h1><p>Offene Live- und Shadow-Trades mit Einstieg, SL, TP, aktuellem Heartbeat-Preis, R-Stand und Status. Anzeige Europe/Berlin; Daten bleiben UTC.</p><a href='/v8004/quality-router'>Zur V8004-Seite</a> · <a href='/master'>Master</a> · <a href='/v8015/trade-levels.json'>JSON</a></div>{panel}</div></body></html>"""


def selftest_payload() -> dict[str, Any]:
    long_metrics = _position_metrics("LONG", 100.0, 90.0, 120.0, 105.0, 20.0)
    short_metrics = _position_metrics("SHORT", 100.0, 110.0, 80.0, 95.0, 20.0)
    stale = _position_metrics("LONG", 100.0, 90.0, 120.0, 101.0, 500.0)
    telegram = _append_level_block(
        "🧪 V8004 SHADOW",
        market="TEST",
        direction="LONG",
        entry=100,
        sl=90,
        tp=120,
        trade_type="SHADOW",
    )
    checks = {
        "long_current_r_half": abs((long_metrics.get("current_r") or 0) - 0.5) < 1e-9,
        "short_current_r_half": abs((short_metrics.get("current_r") or 0) - 0.5) < 1e-9,
        "stale_status": stale.get("status_text") == "PREIS STALE",
        "telegram_has_entry": "Einstieg: 100" in telegram,
        "telegram_has_sl_tp": "SL: 90 | TP1: 120" in telegram,
        "telegram_has_current_status": "Aktuell:" in telegram and "Status: SHADOW" in telegram,
    }
    return {
        "ok": all(checks.values()),
        "version": VERSION,
        "checks": checks,
        "safety": {
            "display_only": True,
            "database_writes": False,
            "routing_changes": False,
            "threshold_changes": False,
            "fresh_valid_rule_changes": False,
            "pine_changes": False,
            "broker_auto_execution": False,
        },
    }


def install_v8015_5_trade_levels(app) -> None:
    if getattr(app.state, "v8015_5_trade_levels_installed", False):
        return

    patch_state = patch_telegram_formatters()

    @app.get("/v8015/trade-levels", response_class=HTMLResponse)
    def trade_levels_page(request: Request, limit: int = 50):
        if not _token_ok(request):
            return HTMLResponse("unauthorized", status_code=401)
        return HTMLResponse(_page(trade_levels_payload(limit=limit)))

    @app.get("/v8015/trade-levels.json")
    def trade_levels_json(request: Request, limit: int = 50):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return JSONResponse(trade_levels_payload(limit=limit))

    @app.get("/v8015/trade-levels-selftest.json")
    def trade_levels_selftest(request: Request):
        if not _token_ok(request):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        data = selftest_payload()
        data["telegram_patch_state"] = patch_state
        return JSONResponse(data)

    app.add_middleware(TradeLevelsQualityPageMiddleware)
    app.state.v8015_5_trade_levels_installed = True
    print(
        "[V8015.5] Trade levels + live status installed; "
        f"telegram_live={patch_state.get('live_telegram_patched')} "
        f"telegram_shadow={patch_state.get('shadow_telegram_patched')}"
    )
