#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="/opt/tradingbot_v6000"
PACKAGE="/root/v8015_5_trade_levels_live_status_pack"
COMPOSE="$PROJECT/docker-compose.yml"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8015_5_before_${STAMP}"
LOG="/root/v8015_5_install_${STAMP}.log"
EXPECTED_MAIN="ca3628c02234a55c6de4bf7cd714f5b8fe8f0f0bee331e862626a5c37fc94f5b"

exec > >(tee -a "$LOG") 2>&1

rollback() {
  echo "================================================================================"
  echo "V8015.5 FEHLER – ROLLBACK"
  echo "================================================================================"
  docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot || true
  [[ -f "$BACKUP/main.py" ]] && cp -a "$BACKUP/main.py" "$PROJECT/app/main.py"
  [[ -f "$BACKUP/v8015_5_trade_levels.py" ]] && cp -a "$BACKUP/v8015_5_trade_levels.py" "$PROJECT/app/v8015_5_trade_levels.py" || rm -f "$PROJECT/app/v8015_5_trade_levels.py"
  [[ -f "$BACKUP/docker-compose.yml" ]] && cp -a "$BACKUP/docker-compose.yml" "$COMPOSE"
  rm -f "$PROJECT/ops/v8015_5_trade_levels_check.sh"
  docker compose -f "$COMPOSE" up -d --force-recreate || true
  echo "Backup: $BACKUP"
}
trap rollback ERR INT TERM

echo "================================================================================"
echo "V8015.5-TRADE-LEVELS-LIVE-STATUS-V1 INSTALL"
echo "================================================================================"
echo "UTC: $(date -u --iso-8601=seconds)"

echo "[1] Package hashes"
cd "$PACKAGE"
sha256sum -c MANIFEST.sha256
python3 - <<'PY'
import json
x=json.load(open('STATIC_AUDIT.json',encoding='utf-8'))
assert x['version']=='V8015.5-TRADE-LEVELS-LIVE-STATUS-V1'
assert x['safety']['database_writes'] is False
assert x['safety']['signal_routing_changes'] is False
assert x['safety']['broker_auto_execution'] is False
print('Static audit: PASS')
PY

echo "[2] V8015.4 baseline"
actual_main="$(sha256sum "$PROJECT/app/main.py" | awk '{print $1}')"
echo "main.py: $actual_main"
if [[ "$actual_main" != "$EXPECTED_MAIN" ]]; then
  echo "FEHLER: main.py entspricht nicht der erwarteten V8015.4-Baseline."
  exit 1
fi
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen("http://127.0.0.1/v8015/timezone-selftest.json", timeout=60) as response:
    x=json.load(response)
assert x.get('ok') is True
print('V8015.4 timezone baseline: PASS')
PY

echo "[3] Backup and stop"
mkdir -p "$BACKUP"
cp -a "$PROJECT/app/main.py" "$BACKUP/main.py"
[[ -f "$PROJECT/app/v8015_5_trade_levels.py" ]] && cp -a "$PROJECT/app/v8015_5_trade_levels.py" "$BACKUP/v8015_5_trade_levels.py" || true
cp -a "$COMPOSE" "$BACKUP/docker-compose.yml"
docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot

echo "[4] Install files"
cp -a "$PACKAGE/app/main.py" "$PROJECT/app/main.py"
cp -a "$PACKAGE/app/v8015_5_trade_levels.py" "$PROJECT/app/v8015_5_trade_levels.py"
cp -a "$PACKAGE/ops/v8015_5_trade_levels_check.sh" "$PROJECT/ops/v8015_5_trade_levels_check.sh"
chmod 700 "$PROJECT/ops/v8015_5_trade_levels_check.sh"
python3 -m py_compile "$PROJECT/app/main.py" "$PROJECT/app/v8015_5_trade_levels.py"

echo "[5] Compose image tag"
python3 - "$COMPOSE" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1])
s=p.read_text(encoding='utf-8')
s,n=re.subn(r'tradingbot_v6000-app:v8015_[0-9]+', 'tradingbot_v6000-app:v8015_5', s)
if n < 1:
    raise SystemExit('compose image tag not found')
p.write_text(s,encoding='utf-8')
print('compose patch: PASS')
PY

echo "[6] Build and start"
cd "$PROJECT"
docker compose build tradingbot
docker compose up -d --force-recreate tradingbot tradingbot_ingress

for i in $(seq 1 90); do
  code="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/health || true)"
  if [[ "$code" == "200" ]]; then echo "Health: 200"; break; fi
  echo "WAIT [$i/90] health=$code"
  sleep 2
  [[ "$i" == "90" ]] && exit 1
done

for i in $(seq 1 60); do
  state="$(docker inspect -f '{{.State.Health.Status}}' tradingbot_ingress 2>/dev/null || true)"
  if [[ "$state" == "healthy" ]]; then echo "Ingress: healthy"; break; fi
  echo "WAIT [$i/60] ingress=$state"
  sleep 2
  [[ "$i" == "60" ]] && exit 1
done

echo "[7] Full check"
bash "$PROJECT/ops/v8015_5_trade_levels_check.sh"

trap - ERR INT TERM

echo "================================================================================"
echo "V8015.5 INSTALLATION FERTIG"
echo "================================================================================"
echo "Backup: $BACKUP"
echo "Log: $LOG"
echo "Dashboard: http://91.107.237.214/v8015/trade-levels"
echo "V8004: http://91.107.237.214/v8004/quality-router"
echo "Keine Trading-, Routing-, Threshold-, Pine- oder Broker-Regel wurde geändert."
