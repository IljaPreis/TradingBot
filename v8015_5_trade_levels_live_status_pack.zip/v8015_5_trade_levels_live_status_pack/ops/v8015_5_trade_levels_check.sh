#!/usr/bin/env bash
set -Eeuo pipefail

BASE="http://127.0.0.1"

echo "=== V8015.5 TRADE LEVELS & LIVE STATUS CHECK ==="
echo "UTC: $(date -u --iso-8601=seconds)"

echo "[1] Containers"
docker compose -f /opt/tradingbot_v6000/docker-compose.yml ps

echo "[2] Critical routes"
for path in \
  /health \
  /master \
  /v8004/quality-router \
  /v8015/trade-levels \
  /v8015/trade-levels.json \
  /v8015/trade-levels-selftest.json \
  /v8015/timezone-selftest.json \
  /v8015/selftest.json \
  /v8011/selftest.json; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' "$BASE$path" || true)"
  printf '%-52s %s\n' "$path" "$code"
  [[ "$code" == "200" ]]
done

echo "[3] Selftest"
curl -fsS "$BASE/v8015/trade-levels-selftest.json" | python3 -m json.tool

echo "[4] Current table summary"
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen("http://127.0.0.1/v8015/trade-levels.json", timeout=60) as response:
    x=json.load(response)
print(json.dumps({
  "ok":x.get("ok"),
  "version":x.get("version"),
  "summary":x.get("summary"),
  "first_rows":(x.get("rows") or [])[:5],
  "safety":x.get("safety"),
},indent=2,ensure_ascii=False))
PY

echo "[5] V8004 page injection"
html="$(curl -fsS "$BASE/v8004/quality-router")"
grep -q "v80155-trade-levels" <<<"$html"
grep -q "Einstieg / SL / TP / aktueller Stand" <<<"$html"
echo "Compact table injection: PASS"

echo "[6] Ingress/token"
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen("http://127.0.0.1/v8011/selftest.json", timeout=60) as response:
    x=json.load(response)
print(json.dumps({
 "ok":x.get("ok"),
 "operational_status":x.get("operational_status"),
 "queue_depth":x.get("queue_depth"),
 "active_dead_letter_total":x.get("active_dead_letter_total"),
 "token_mode":x.get("token_mode"),
 "token_enforced":x.get("token_enforced"),
},indent=2))
PY

echo "[7] Errors last 30m"
for c in tradingbot tradingbot_ingress; do
  echo "--- $c ---"
  docker logs "$c" --since 30m 2>&1 | grep -E 'Traceback|ERROR|Exception' || true
done

echo "=== V8015.5 CHECK FERTIG ==="
