# V8016A.1 – Installer-Fix

Diese Revision behebt ausschließlich den Python-Quote-Fehler im Compose-Tag-Schritt des V8016A-Installers. Der vorherige Lauf wurde korrekt zurückgerollt. Runtime-Funktionen und Trading-Regeln bleiben identisch zu V8016A.

# V8016A Clean AI Review Rebuild

Read-only Neubau der AI-Review-Auswertung nach V8015. Primäre Quelle ist `shadow_outcomes.pnl_r`. Historische MFE/MAE-Werte werden nicht verwendet. V7602–V7612 werden im AI-Review-Menü als Legacy/Reference markiert. Keine DB-, Filter-, Routing- oder Live-Regeländerung.
