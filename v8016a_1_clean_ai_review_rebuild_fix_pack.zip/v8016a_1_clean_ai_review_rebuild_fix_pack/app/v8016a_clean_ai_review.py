from __future__ import annotations
import html, json, math, os, sqlite3, statistics
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from zoneinfo import ZoneInfo
from fastapi.responses import HTMLResponse, JSONResponse

VERSION="V8016A-CLEAN-AI-REVIEW-REBUILD-V1"
MODE="read_only_clean_outcome_rebuild"
BERLIN=ZoneInfo("Europe/Berlin")
SAFETY={
 "observe_only":True,"database_writes":False,"database_schema_changes":False,
 "live_rule_changes":False,"routing_changes":False,"threshold_changes":False,
 "automatic_blocking":False,"automatic_filtering":False,
 "fresh_valid_rule_changes":False,"pine_changes":False,
 "historical_trade_creation":False,"broker_auto_execution":False,
}
LEGACY_ROUTES=[
 "/v7600-intelligence","/v7601-deep-intelligence","/v7602-weakness-audit",
 "/v7603-candidate-blocklist-review","/v7604-derived-session-audit",
 "/v7605-cross-check-matrix","/v7606-proposed-filter-report",
 "/v7607-top-cluster-trade-detail","/v7608-root-cause-summary",
 "/v7609-v7601-confirmation-bridge","/v7610-disabled-rule-draft-board",
 "/v7611-warning-only-simulation-board","/v7612-warning-dashboard",
]

def _root()->Path:
 for p in (Path('/app'),Path('/opt/tradingbot_v6000'),Path.cwd()):
  if (p/'app').exists() and (p/'data').exists(): return p
 return Path.cwd()

def _db()->Path:
 override=os.getenv('V8016A_DB','').strip()
 return Path(override) if override else _root()/'data/v7000_learning.sqlite3'

def _connect()->sqlite3.Connection:
 con=sqlite3.connect(f"file:{_db()}?mode=ro",uri=True,timeout=20)
 con.row_factory=sqlite3.Row
 return con

def _exists(con:sqlite3.Connection,table:str)->bool:
 return con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone() is not None

def _json(value:Any)->dict[str,Any]:
 try:
  x=value if isinstance(value,dict) else json.loads(str(value or '{}'))
  return x if isinstance(x,dict) else {}
 except Exception:return {}

def _num(value:Any)->float|None:
 try:
  x=float(value)
  return x if math.isfinite(x) else None
 except Exception:return None

def _summary(rows:list[dict[str,Any]])->dict[str,Any]:
 vals=[float(r['pnl_r']) for r in rows if _num(r.get('pnl_r')) is not None]
 wins=sum(x>0 for x in vals); losses=sum(x<0 for x in vals)
 return {
  'n':len(vals),'wins':wins,'losses':losses,'breakeven':len(vals)-wins-losses,
  'win_rate_percent':round(wins/len(vals)*100,2) if vals else None,
  'total_r':round(sum(vals),4) if vals else None,
  'avg_r':round(sum(vals)/len(vals),4) if vals else None,
  'median_r':round(statistics.median(vals),4) if vals else None,
  'min_r':round(min(vals),4) if vals else None,'max_r':round(max(vals),4) if vals else None,
 }

def _label(stats:dict[str,Any])->str:
 n=int(stats.get('n') or 0); avg=_num(stats.get('avg_r')) or 0.0
 if n<5:return 'TOO_SMALL'
 if n<10:return 'LOW_SAMPLE'
 if avg<=-0.20:return 'NEGATIVE_REVIEW'
 if avg>=0.10:return 'POSITIVE_WATCH'
 return 'MIXED_NEUTRAL'

def _aggregate(rows:list[dict[str,Any]],name:str,key:Callable[[dict[str,Any]],str])->list[dict[str,Any]]:
 groups:dict[str,list[dict[str,Any]]]=defaultdict(list)
 for row in rows: groups[str(key(row) or 'UNKNOWN').strip() or 'UNKNOWN'].append(row)
 out=[]
 for value,members in groups.items():
  stats=_summary(members); out.append({name:value,**stats,'evidence':_label(stats)})
 out.sort(key=lambda x:(-int(x['n']),float(x.get('avg_r') or 0)))
 return out

def _clean_rows(con:sqlite3.Connection)->tuple[list[dict[str,Any]],dict[str,Any]]:
 if not _exists(con,'shadow_outcomes'):return [],{'error':'shadow_outcomes missing'}
 by_shadow={}; by_client={}
 if _exists(con,'shadow_trades'):
  for row in con.execute('SELECT * FROM shadow_trades'):
   item=dict(row)
   if item.get('shadow_id'):by_shadow[str(item['shadow_id'])]=item
   if item.get('client_trade_id'):by_client[str(item['client_trade_id'])]=item
 rows=[]; unmatched=0; parse_errors=0; versions=Counter()
 for outcome_row in con.execute('SELECT * FROM shadow_outcomes ORDER BY id'):
  o=dict(outcome_row); t=by_shadow.get(str(o.get('shadow_id') or '')) or by_client.get(str(o.get('client_trade_id') or ''))
  if not t: unmatched+=1; continue
  raw=_json(t.get('raw_json'))
  if t.get('raw_json') and not raw:parse_errors+=1
  d=raw.get('decision') if isinstance(raw.get('decision'),dict) else {}
  s=raw.get('signal') if isinstance(raw.get('signal'),dict) else {}
  pnl=_num(o.get('pnl_r'))
  if pnl is None:continue
  version=str(d.get('version') or raw.get('source') or 'UNKNOWN'); versions[version]+=1
  rows.append({
   'outcome_id':o.get('id'),'shadow_id':o.get('shadow_id'),
   'market':o.get('market') or t.get('market') or d.get('market') or 'UNKNOWN',
   'direction':o.get('direction') or t.get('direction') or d.get('direction') or 'UNKNOWN',
   'setup':o.get('setup_name') or t.get('setup_name') or d.get('setup_name') or 'UNKNOWN',
   'session':d.get('session') or s.get('session') or 'UNKNOWN',
   'playbook':d.get('playbook') or s.get('playbook') or 'UNKNOWN',
   'grade':d.get('grade') or 'UNKNOWN','route':d.get('route') or 'UNKNOWN',
   'source_version':version,'current_router_cohort':'V8004.2' in version,
   'pine_score':_num(d.get('pine_score') or t.get('confidence')),
   'result':o.get('result'),'pnl_r':pnl,'closed_at':o.get('closed_at'),
  })
 return rows,{
  'shadow_outcomes_total':int(con.execute('SELECT COUNT(*) FROM shadow_outcomes').fetchone()[0]),
  'matched_clean_outcomes':len(rows),'unmatched_shadow_outcomes':unmatched,
  'raw_json_parse_failures':parse_errors,'source_versions':dict(versions.most_common()),
 }

def _valid_evidence(con:sqlite3.Connection)->dict[str,Any]:
 if not _exists(con,'v8013d_valid_shadow_capture_log'):
  return {'available':False,'captured':0,'closed':0,'evidence_sufficient':False}
 captures=[dict(r) for r in con.execute('SELECT * FROM v8013d_valid_shadow_capture_log')]
 outcomes={}
 if _exists(con,'shadow_outcomes'):
  for r in con.execute('SELECT * FROM shadow_outcomes'):
   d=dict(r)
   if d.get('shadow_id'):outcomes[str(d['shadow_id'])]=d
 closed=[]
 for c in captures:
  o=outcomes.get(str(c.get('shadow_id') or ''))
  if o and _num(o.get('pnl_r')) is not None:closed.append({'pnl_r':float(o['pnl_r'])})
 stats=_summary(closed)
 return {'available':True,'captured':len(captures),'closed':stats['n'],'wins':stats['wins'],
  'losses':stats['losses'],'win_rate_percent':stats['win_rate_percent'],'total_r':stats['total_r'],
  'avg_r':stats['avg_r'],'minimum_closed_before_review':30,'evidence_sufficient':stats['n']>=30}

def _excursion_quality(con:sqlite3.Connection)->dict[str,Any]:
 if not _exists(con,'v7245a_trade_excursions'):return {'available':False}
 cols={r[1] for r in con.execute('PRAGMA table_info(v7245a_trade_excursions)')}
 total=int(con.execute('SELECT COUNT(*) FROM v7245a_trade_excursions').fetchone()[0])
 if 'excursion_data_valid' not in cols:
  return {'available':True,'total':total,'clean_flag_available':False,'historical_excursions_used_for_clusters':False}
 valid=int(con.execute('SELECT COUNT(*) FROM v7245a_trade_excursions WHERE COALESCE(excursion_data_valid,0)=1').fetchone()[0])
 open_valid=int(con.execute('SELECT COUNT(*) FROM v7245a_trade_excursions WHERE COALESCE(excursion_data_valid,0)=1 AND COALESCE(is_open,0)=1').fetchone()[0])
 return {'available':True,'total':total,'valid_live_tracking_rows':valid,'invalid_historical_rows':total-valid,
  'open_valid_rows':open_valid,'historical_excursions_used_for_clusters':False,
  'note':'Cluster performance uses shadow_outcomes.pnl_r only. Historical MFE/MAE is excluded.'}

def _rank(aggregates:dict[str,list[dict[str,Any]]])->tuple[list[dict[str,Any]],list[dict[str,Any]]]:
 flat=[]
 for dimension,items in aggregates.items():
  for item in items:flat.append({'dimension':dimension,'name':item.get(dimension),**item})
 neg=[x for x in flat if int(x.get('n') or 0)>=5 and (_num(x.get('avg_r')) or 0)<0]
 pos=[x for x in flat if int(x.get('n') or 0)>=5 and (_num(x.get('avg_r')) or 0)>0]
 neg.sort(key=lambda x:(float(x.get('avg_r') or 0),-int(x.get('n') or 0)))
 pos.sort(key=lambda x:(-float(x.get('avg_r') or 0),-int(x.get('n') or 0)))
 return neg[:30],pos[:30]

def clean_ai_review_payload()->dict[str,Any]:
 db=_db(); now=datetime.now(timezone.utc)
 if not db.exists():return {'ok':False,'version':VERSION,'error':f'database missing: {db}','safety':SAFETY}
 con=_connect()
 try:
  integrity=str(con.execute('PRAGMA quick_check').fetchone()[0])
  rows,quality=_clean_rows(con)
  current=[r for r in rows if r.get('current_router_cohort')]
  if not current:current=[r for r in rows if 'V8004' in str(r.get('source_version') or '')]
  aggs={
   'playbook':_aggregate(current,'playbook',lambda r:str(r.get('playbook') or 'UNKNOWN')),
   'setup':_aggregate(current,'setup',lambda r:str(r.get('setup') or 'UNKNOWN')),
   'market':_aggregate(current,'market',lambda r:str(r.get('market') or 'UNKNOWN')),
   'direction':_aggregate(current,'direction',lambda r:str(r.get('direction') or 'UNKNOWN')),
   'session':_aggregate(current,'session',lambda r:str(r.get('session') or 'UNKNOWN')),
   'grade':_aggregate(current,'grade',lambda r:str(r.get('grade') or 'UNKNOWN')),
   'market_direction':_aggregate(current,'market_direction',lambda r:f"{r.get('market','UNKNOWN')} {r.get('direction','UNKNOWN')}"),
   'setup_direction':_aggregate(current,'setup_direction',lambda r:f"{r.get('setup','UNKNOWN')} {r.get('direction','UNKNOWN')}"),
  }
  neg,pos=_rank(aggs)
  live_rows=[dict(r) for r in con.execute('SELECT pnl_r FROM trade_outcomes')] if _exists(con,'trade_outcomes') else []
  valid=_valid_evidence(con)
  return {
   'ok':integrity=='ok','version':VERSION,'mode':MODE,'generated_utc':now.isoformat(),
   'generated_berlin':now.astimezone(BERLIN).strftime('%d.%m.%Y %H:%M:%S %Z'),
   'database':str(db),'integrity_check':integrity,
   'source_policy':{'performance_source_of_truth':'shadow_outcomes.pnl_r','live_summary_source':'trade_outcomes.pnl_r',
    'historical_excursion_metrics_used':False,'current_router_filter':'V8004.2 when available, otherwise V8004'},
   'data_quality':quality,'all_clean_shadow_outcomes':_summary(rows),
   'current_router_cohort':{'summary':_summary(current),'rows':len(current),
    'source_versions':dict(Counter(str(r.get('source_version') or 'UNKNOWN') for r in current).most_common())},
   'aggregates':aggs,'negative_review_clusters':neg,'positive_watch_clusters':pos,
   'v8013d_valid_shadow_evidence':valid,'live_outcomes_summary':_summary(live_rows),
   'excursion_quality':_excursion_quality(con),
   'legacy_ai_review':{'status':'REFERENCE_ONLY_PRE_V8015','routes':LEGACY_ROUTES,'automatic_rules_allowed':False},
   'recommendation':{'automatic_rule_change_now':False,
    'reason':'Use V8016A for clean observe-only review. Wait for at least 30 closed V8013D VALID outcomes before FRESH/VALID changes.',
    'next_review_trigger':'v8013d closed >= 30'},'safety':dict(SAFETY),
  }
 finally:con.close()

def _esc(x:Any)->str:return html.escape(str('' if x is None else x))
def _fmt(x:Any,d:int=2)->str:
 n=_num(x); return '–' if n is None else f'{n:.{d}f}'
def _table(rows:list[dict[str,Any]])->str:
 if not rows:return "<tr><td colspan='8'>Keine ausreichend großen Cluster.</td></tr>"
 out=[]
 for r in rows[:15]:
  ev=str(r.get('evidence') or ''); cls='bad' if ev=='NEGATIVE_REVIEW' else ('good' if ev=='POSITIVE_WATCH' else 'muted')
  out.append(f"<tr><td>{_esc(r.get('dimension'))}</td><td><b>{_esc(r.get('name'))}</b></td><td>{r.get('n')}</td>"
   f"<td>{_fmt(r.get('win_rate_percent'))}%</td><td class='{cls}'>{_fmt(r.get('avg_r'),3)}R</td>"
   f"<td>{_fmt(r.get('total_r'))}R</td><td>{_fmt(r.get('median_r'))}R</td><td class='{cls}'>{_esc(ev)}</td></tr>")
 return ''.join(out)

def clean_ai_review_html()->str:
 d=clean_ai_review_payload()
 if not d.get('ok'):return f"<h1>V8016A Fehler</h1><pre>{_esc(json.dumps(d,indent=2,ensure_ascii=False))}</pre>"
 cur=d['current_router_cohort']['summary']; all_s=d['all_clean_shadow_outcomes']; val=d['v8013d_valid_shadow_evidence']; q=d['data_quality']
 return f"""<!doctype html><html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><meta http-equiv='refresh' content='60'><title>V8016A Clean AI Review</title><style>
:root{{--bg:#07111e;--panel:#101d2e;--panel2:#0b1728;--line:#273a52;--text:#eef6ff;--muted:#9caec4;--green:#22c55e;--red:#f87171;--yellow:#facc15;--blue:#93c5fd}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Arial,sans-serif}}.w{{max-width:1500px;margin:auto;padding:14px}}a{{color:var(--blue)}}.hero,.p{{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:15px;margin:10px 0}}h1,h2{{margin:0 0 8px}}p{{color:var(--muted)}}.bad{{color:var(--red)}}.good{{color:var(--green)}}.warn{{color:var(--yellow)}}.muted{{color:var(--muted)}}.pill{{display:inline-block;border:1px solid var(--line);background:var(--panel2);border-radius:999px;padding:6px 10px;margin:3px;font-size:12px;font-weight:800}}.stats{{display:grid;grid-template-columns:repeat(6,1fr);gap:9px}}.s{{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:10px}}.l{{font-size:11px;color:var(--muted)}}.v{{font-size:23px;font-weight:900}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{padding:8px;border-bottom:1px solid var(--line);text-align:left}}th{{background:var(--panel2)}}.scroll{{overflow:auto;max-height:600px}}.banner{{border:1px solid #7c5d18;background:#30250b;color:#fde68a;border-radius:14px;padding:12px}}@media(max-width:900px){{.stats{{grid-template-columns:repeat(2,1fr)}}.grid{{grid-template-columns:1fr}}}}</style></head><body><div class='w'>
<div class='hero'><h1>V8016A Clean AI Review</h1><p>Primäre Observe-only-Auswertung aus echten <code>shadow_outcomes.pnl_r</code>. Historische kontaminierte MFE/MAE-Werte sind ausgeschlossen.</p><span class='pill good'>DB {_esc(d['integrity_check'])}</span><span class='pill'>READ ONLY</span><span class='pill'>NO AUTO BLOCK</span><span class='pill'>NO LIVE RULE CHANGE</span><span class='pill'>{_esc(d['generated_berlin'])}</span></div>
<div class='banner'><b>Legacy-Hinweis:</b> V7602–V7612 bleiben erreichbar, sind aber nur Referenz vor V8015. Für neue Entscheidungen ist V8016A maßgeblich.</div>
<div class='p'><h2>Aktuelle V8004.2-Kohorte</h2><div class='stats'><div class='s'><div class='l'>Geschlossen</div><div class='v'>{cur['n']}</div></div><div class='s'><div class='l'>Winrate</div><div class='v'>{_fmt(cur['win_rate_percent'])}%</div></div><div class='s'><div class='l'>Gesamt R</div><div class='v'>{_fmt(cur['total_r'])}R</div></div><div class='s'><div class='l'>Ø R</div><div class='v'>{_fmt(cur['avg_r'],3)}R</div></div><div class='s'><div class='l'>VALID Captures</div><div class='v'>{val.get('captured',0)}</div></div><div class='s'><div class='l'>VALID geschlossen</div><div class='v'>{val.get('closed',0)}/30</div></div></div></div>
<div class='grid'><div class='p'><h2>Negative Review-Cluster</h2><div class='scroll'><table><tr><th>Dimension</th><th>Cluster</th><th>N</th><th>Winrate</th><th>Ø R</th><th>Total</th><th>Median</th><th>Evidenz</th></tr>{_table(d['negative_review_clusters'])}</table></div></div><div class='p'><h2>Positive Watch-Cluster</h2><div class='scroll'><table><tr><th>Dimension</th><th>Cluster</th><th>N</th><th>Winrate</th><th>Ø R</th><th>Total</th><th>Median</th><th>Evidenz</th></tr>{_table(d['positive_watch_clusters'])}</table></div></div></div>
<div class='grid'><div class='p'><h2>Datenqualität</h2><table><tr><td>Outcomes gesamt</td><td>{q.get('shadow_outcomes_total')}</td></tr><tr><td>Sauber zugeordnet</td><td>{q.get('matched_clean_outcomes')}</td></tr><tr><td>Nicht zugeordnet</td><td>{q.get('unmatched_shadow_outcomes')}</td></tr><tr><td>RAW Parsefehler</td><td>{q.get('raw_json_parse_failures')}</td></tr><tr><td>Alle sauberen Outcomes</td><td>{all_s['n']} · {_fmt(all_s['total_r'])}R · Ø {_fmt(all_s['avg_r'],3)}R</td></tr><tr><td>Historische MFE/MAE verwendet</td><td class='good'>NEIN</td></tr></table></div><div class='p'><h2>V8013D VALID-Evidenz</h2><table><tr><td>Erfasst</td><td>{val.get('captured')}</td></tr><tr><td>Geschlossen</td><td>{val.get('closed')}</td></tr><tr><td>Winrate</td><td>{_fmt(val.get('win_rate_percent'))}%</td></tr><tr><td>Ø R</td><td>{_fmt(val.get('avg_r'),3)}R</td></tr><tr><td>Regelreview</td><td class='warn'>{'JA' if val.get('evidence_sufficient') else 'NEIN – Ziel 30 geschlossen'}</td></tr></table><p><a href='/v8013/valid-shadow-capture'>V8013D</a> · <a href='/master-ai-review'>AI Review Menü</a></p></div></div>
<div class='p'><h2>Excursion-Qualität</h2><pre>{_esc(json.dumps(d['excursion_quality'],indent=2,ensure_ascii=False))}</pre></div></div></body></html>"""

def selftest_payload()->dict[str,Any]:
 rows=[{'pnl_r':1.5,'playbook':'A'},{'pnl_r':-1.0,'playbook':'A'},{'pnl_r':1.5,'playbook':'B'},{'pnl_r':1.5,'playbook':'B'}]
 s=_summary(rows); g=_aggregate(rows,'playbook',lambda r:r['playbook'])
 checks={'summary_n_4':s['n']==4,'summary_total_r_3_5':s['total_r']==3.5,'two_playbooks':len(g)==2,
  'read_only':SAFETY['database_writes'] is False,'no_rule_change':SAFETY['live_rule_changes'] is False,'legacy_reference_only':len(LEGACY_ROUTES)>=10}
 return {'ok':all(checks.values()),'version':VERSION,'checks':checks,'safety':SAFETY}

def install_v8016a_clean_ai_review(app)->None:
 if getattr(app.state,'v8016a_clean_ai_review_installed',False):return
 @app.get('/v8016/clean-ai-review.json')
 def review_json():return JSONResponse(clean_ai_review_payload())
 @app.get('/v8016/clean-clusters.json')
 def clusters_json():
  x=clean_ai_review_payload(); return JSONResponse({'ok':x.get('ok'),'version':VERSION,'negative_review_clusters':x.get('negative_review_clusters',[]),'positive_watch_clusters':x.get('positive_watch_clusters',[]),'safety':SAFETY})
 @app.get('/v8016/legacy-ai-review-status.json')
 def legacy_json():return JSONResponse({'ok':True,'version':VERSION,'status':'REFERENCE_ONLY_PRE_V8015','routes':LEGACY_ROUTES,'automatic_rules_allowed':False,'safety':SAFETY})
 @app.get('/v8016/clean-ai-review-selftest.json')
 def selftest_json():return JSONResponse(selftest_payload())
 @app.get('/v8016/clean-ai-review',response_class=HTMLResponse)
 def review_page():return HTMLResponse(clean_ai_review_html())
 app.state.v8016a_clean_ai_review_installed=True
 print('[V8016A] Clean AI Review rebuild installed (read-only, outcome source of truth)')
