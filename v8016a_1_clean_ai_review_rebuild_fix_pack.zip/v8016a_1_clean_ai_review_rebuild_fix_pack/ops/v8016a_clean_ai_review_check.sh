#!/usr/bin/env bash
set -Eeuo pipefail
BASE="http://127.0.0.1"
echo "=== V8016A CLEAN AI REVIEW CHECK ==="
docker compose -f /opt/tradingbot_v6000/docker-compose.yml ps
for p in /health /master /master-ai-review /v8016/clean-ai-review /v8016/clean-ai-review.json /v8016/clean-clusters.json /v8016/legacy-ai-review-status.json /v8016/clean-ai-review-selftest.json /v8015/reliability.json /v8015/trade-levels.json /v8013/selftest-d.json /v8011/selftest.json; do c="$(curl -sS -o /dev/null -w '%{http_code}' "$BASE$p"||true)"; printf '%-55s %s\n' "$p" "$c"; [[ "$c" == 200 ]]; done
echo "[SELFTEST]"; curl -fsS "$BASE/v8016/clean-ai-review-selftest.json"|python3 -m json.tool
echo "[SUMMARY]"
python3 - <<'PY_SUM'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8016/clean-ai-review.json',timeout=90) as r:x=json.load(r)
print(json.dumps({'ok':x.get('ok'),'version':x.get('version'),'integrity_check':x.get('integrity_check'),'source_policy':x.get('source_policy'),'data_quality':x.get('data_quality'),'all_clean_shadow_outcomes':x.get('all_clean_shadow_outcomes'),'current_router_cohort':x.get('current_router_cohort'),'negative_top5':(x.get('negative_review_clusters') or [])[:5],'positive_top5':(x.get('positive_watch_clusters') or [])[:5],'v8013d':x.get('v8013d_valid_shadow_evidence'),'excursion_quality':x.get('excursion_quality'),'recommendation':x.get('recommendation'),'safety':x.get('safety')},indent=2,ensure_ascii=False))
assert x.get('ok') is True and x.get('integrity_check')=='ok'
assert x['source_policy']['historical_excursion_metrics_used'] is False
assert x['safety']['database_writes'] is False and x['safety']['automatic_blocking'] is False
PY_SUM
echo "[NAVIGATION]"; h="$(curl -fsS "$BASE/master-ai-review")"; grep -q "V8016A Clean AI Review"<<<"$h"; grep -q "Clean Evidence"<<<"$h"; grep -q "LEGACY/REFERENCE ONLY"<<<"$h"; echo "AI Review navigation: PASS"
echo "[INGRESS]"
python3 - <<'PY_ING'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8011/selftest.json',timeout=60) as r:x=json.load(r)
print(json.dumps({k:x.get(k) for k in ('ok','operational_status','queue_depth','active_dead_letter_total','token_mode','token_enforced')},indent=2))
assert x.get('ok') is True and x.get('operational_status')=='GREEN' and x.get('active_dead_letter_total',0)==0 and x.get('token_mode')=='off'
PY_ING
for c in tradingbot tradingbot_ingress; do echo "--- $c errors ---"; docker logs "$c" --since 30m 2>&1|grep -E 'Traceback|ERROR|Exception'||true; done
free -h; df -h /
echo "=== V8016A CHECK FERTIG ==="
