from __future__ import annotations

import html
import json
import math
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from fastapi.responses import HTMLResponse, JSONResponse

from app.v8016a_clean_ai_review import clean_ai_review_payload

VERSION = "V8016B-EVIDENCE-MONITOR-V1"
MODE = "read_only_evidence_progress_monitor"
TARGET_CLOSED = 30
BERLIN = ZoneInfo("Europe/Berlin")

SAFETY = {
    "observe_only": True,
    "database_writes": False,
    "database_schema_changes": False,
    "live_rule_changes": False,
    "routing_changes": False,
    "threshold_changes": False,
    "automatic_blocking": False,
    "automatic_filtering": False,
    "automatic_promotion": False,
    "fresh_valid_rule_changes": False,
    "pine_changes": False,
    "telegram_changes": False,
    "broker_auto_execution": False,
}


def _root() -> Path:
    for candidate in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        if (candidate / "app").exists() and (candidate / "data").exists():
            return candidate
    return Path.cwd()


def _db_path() -> Path:
    override = os.getenv("V8016A_DB", "").strip()
    return Path(override) if override else _root() / "data/v7000_learning.sqlite3"


def _num(value: Any) -> float | None:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None


def _pick(row: dict[str, Any], *names: str) -> Any:
    for name in names:
        value = row.get(name)
        if value is not None and str(value).strip() != "":
            return value
    return None


def _normalize(value: Any) -> str:
    return " ".join(str(value or "").strip().upper().split())


def _find_cluster(
    aggregates: dict[str, list[dict[str, Any]]],
    dimension: str,
    name: str,
) -> dict[str, Any]:
    wanted = _normalize(name)
    for row in aggregates.get(dimension, []) or []:
        if _normalize(row.get(dimension)) == wanted:
            return {
                "available": True,
                "dimension": dimension,
                "name": row.get(dimension),
                "n": int(row.get("n") or 0),
                "wins": int(row.get("wins") or 0),
                "losses": int(row.get("losses") or 0),
                "win_rate_percent": row.get("win_rate_percent"),
                "total_r": row.get("total_r"),
                "avg_r": row.get("avg_r"),
                "median_r": row.get("median_r"),
                "evidence": row.get("evidence"),
            }
    return {
        "available": False,
        "dimension": dimension,
        "name": name,
        "n": 0,
        "wins": 0,
        "losses": 0,
        "win_rate_percent": None,
        "total_r": None,
        "avg_r": None,
        "median_r": None,
        "evidence": "NO_MATCH",
    }


def _latest_valid_rows(limit: int = 20) -> dict[str, Any]:
    db = _db_path()
    if not db.exists():
        return {"available": False, "rows": [], "error": f"database missing: {db}"}

    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=20)
    con.row_factory = sqlite3.Row
    try:
        table = "v8013d_valid_shadow_capture_log"
        exists = con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (table,),
        ).fetchone()
        if not exists:
            return {"available": False, "rows": [], "error": f"{table} missing"}

        columns = [row[1] for row in con.execute(f"PRAGMA table_info({table})")]
        order_column = "id" if "id" in columns else "rowid"
        captures = [
            dict(row)
            for row in con.execute(
                f"SELECT * FROM {table} ORDER BY {order_column} DESC LIMIT ?",
                (max(1, min(int(limit), 100)),),
            )
        ]

        outcomes: dict[str, dict[str, Any]] = {}
        outcome_exists = con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='shadow_outcomes'"
        ).fetchone()
        if outcome_exists:
            ids = [str(row.get("shadow_id")) for row in captures if row.get("shadow_id")]
            if ids:
                placeholders = ",".join("?" for _ in ids)
                for row in con.execute(
                    f"SELECT * FROM shadow_outcomes WHERE shadow_id IN ({placeholders})",
                    ids,
                ):
                    item = dict(row)
                    outcomes[str(item.get("shadow_id"))] = item

        rows: list[dict[str, Any]] = []
        for capture in captures:
            shadow_id = str(capture.get("shadow_id") or "")
            outcome = outcomes.get(shadow_id, {})
            pnl_r = _num(outcome.get("pnl_r"))
            status = "CLOSED" if pnl_r is not None else "OPEN"
            rows.append(
                {
                    "capture_id": _pick(capture, "id", "capture_id"),
                    "shadow_id": shadow_id or None,
                    "market": _pick(capture, "market", "symbol", "canonical_market") or "UNKNOWN",
                    "direction": _pick(capture, "direction", "side") or "UNKNOWN",
                    "setup": _pick(capture, "setup_name", "setup", "trigger") or "UNKNOWN",
                    "grade": _pick(capture, "grade", "original_grade") or "UNKNOWN",
                    "route": _pick(capture, "route", "original_route") or "SHADOW",
                    "captured_at_utc": _pick(
                        capture,
                        "captured_at",
                        "created_at",
                        "inserted_at",
                        "received_at",
                        "opened_at",
                    ),
                    "status": status,
                    "result": outcome.get("result"),
                    "pnl_r": pnl_r,
                    "closed_at_utc": outcome.get("closed_at"),
                }
            )
        return {
            "available": True,
            "table": table,
            "columns": columns,
            "rows": rows,
            "limit": len(rows),
        }
    except Exception as exc:
        return {"available": False, "rows": [], "error": str(exc)}
    finally:
        con.close()


def _progress(closed: int, target: int = TARGET_CLOSED) -> dict[str, Any]:
    safe_closed = max(0, int(closed or 0))
    safe_target = max(1, int(target or 1))
    percent = min(100.0, safe_closed / safe_target * 100.0)
    remaining = max(0, safe_target - safe_closed)
    if safe_closed >= safe_target:
        status = "REVIEW_READY"
    elif safe_closed == 0:
        status = "WAITING_FOR_CLOSED_OUTCOMES"
    else:
        status = "COLLECTING"
    return {
        "closed": safe_closed,
        "target": safe_target,
        "remaining": remaining,
        "percent": round(percent, 2),
        "status": status,
        "review_ready": safe_closed >= safe_target,
    }


def evidence_monitor_payload() -> dict[str, Any]:
    now = datetime.now(timezone.utc)
    base = clean_ai_review_payload()
    if not base.get("ok"):
        return {
            "ok": False,
            "version": VERSION,
            "mode": MODE,
            "generated_utc": now.isoformat(),
            "error": "V8016A clean payload unavailable",
            "base": base,
            "safety": dict(SAFETY),
        }

    valid = base.get("v8013d_valid_shadow_evidence") or {}
    closed = int(valid.get("closed") or 0)
    captured = int(valid.get("captured") or 0)
    progress = _progress(closed)
    aggregates = base.get("aggregates") or {}
    current = ((base.get("current_router_cohort") or {}).get("summary") or {})

    focus_clusters = [
        {
            "focus": "POSITIVE_WATCH",
            "reason": "Stärkster aktueller Setup-/Richtungscluster",
            **_find_cluster(aggregates, "setup_direction", "MSS_BEAR SHORT"),
        },
        {
            "focus": "NEGATIVE_REVIEW",
            "reason": "Negativer Cluster mit aktueller Stichprobe >= 10",
            **_find_cluster(aggregates, "market_direction", "CADJPY SHORT"),
        },
    ]

    latest = _latest_valid_rows(limit=20)
    return {
        "ok": True,
        "version": VERSION,
        "mode": MODE,
        "generated_utc": now.isoformat(),
        "generated_berlin": now.astimezone(BERLIN).strftime("%d.%m.%Y %H:%M:%S %Z"),
        "progress": progress,
        "v8013d": {
            "available": bool(valid.get("available")),
            "captured": captured,
            "open_estimate": max(0, captured - closed),
            "closed": closed,
            "wins": int(valid.get("wins") or 0),
            "losses": int(valid.get("losses") or 0),
            "win_rate_percent": valid.get("win_rate_percent"),
            "total_r": valid.get("total_r"),
            "avg_r": valid.get("avg_r"),
            "evidence_sufficient": bool(valid.get("evidence_sufficient")),
        },
        "current_router_cohort": current,
        "focus_clusters": focus_clusters,
        "latest_valid_captures": latest,
        "top_positive": (base.get("positive_watch_clusters") or [])[:5],
        "top_negative": (base.get("negative_review_clusters") or [])[:5],
        "data_quality": base.get("data_quality") or {},
        "recommendation": {
            "automatic_rule_change_now": False,
            "next_review_trigger": "V8013D closed >= 30",
            "status": progress["status"],
            "reason": (
                "30 geschlossene VALID-Shadow-Outcomes erreicht; manuelles Review möglich."
                if progress["review_ready"]
                else f"Noch {progress['remaining']} geschlossene VALID-Outcomes bis zum manuellen Review."
            ),
        },
        "safety": dict(SAFETY),
    }


def _esc(value: Any) -> str:
    return html.escape(str("" if value is None else value))


def _fmt(value: Any, digits: int = 2) -> str:
    number = _num(value)
    return "–" if number is None else f"{number:.{digits}f}"


def _focus_cards(rows: list[dict[str, Any]]) -> str:
    cards: list[str] = []
    for row in rows:
        focus = str(row.get("focus") or "")
        css = "good" if focus == "POSITIVE_WATCH" else "bad"
        cards.append(
            "<div class='focus'>"
            f"<div class='tag {css}'>{_esc(focus)}</div>"
            f"<h3>{_esc(row.get('name'))}</h3>"
            f"<p>{_esc(row.get('reason'))}</p>"
            "<div class='mini'>"
            f"<span>N <b>{int(row.get('n') or 0)}</b></span>"
            f"<span>WR <b>{_fmt(row.get('win_rate_percent'))}%</b></span>"
            f"<span>Gesamt <b>{_fmt(row.get('total_r'))}R</b></span>"
            f"<span>Ø <b>{_fmt(row.get('avg_r'), 3)}R</b></span>"
            "</div>"
            f"<div class='muted'>Evidenz: {_esc(row.get('evidence'))}</div>"
            "</div>"
        )
    return "".join(cards)


def _latest_table(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<tr><td colspan='8'>Noch keine V8013D-Captures verfügbar.</td></tr>"
    output: list[str] = []
    for row in rows:
        status = str(row.get("status") or "")
        css = "good" if status == "CLOSED" and (_num(row.get("pnl_r")) or 0) > 0 else (
            "bad" if status == "CLOSED" and (_num(row.get("pnl_r")) or 0) < 0 else "warn"
        )
        output.append(
            "<tr>"
            f"<td>{_esc(row.get('market'))}</td>"
            f"<td>{_esc(row.get('direction'))}</td>"
            f"<td>{_esc(row.get('setup'))}</td>"
            f"<td>{_esc(row.get('grade'))}</td>"
            f"<td class='{css}'>{_esc(status)}</td>"
            f"<td>{_esc(row.get('result') or '–')}</td>"
            f"<td>{_fmt(row.get('pnl_r'))}R</td>"
            f"<td>{_esc(row.get('captured_at_utc') or '–')}</td>"
            "</tr>"
        )
    return "".join(output)


def evidence_monitor_html() -> str:
    data = evidence_monitor_payload()
    if not data.get("ok"):
        return (
            "<h1>V8016B Fehler</h1><pre>"
            + _esc(json.dumps(data, indent=2, ensure_ascii=False))
            + "</pre>"
        )

    progress = data["progress"]
    valid = data["v8013d"]
    current = data["current_router_cohort"]
    latest = (data.get("latest_valid_captures") or {}).get("rows") or []
    review_class = "good" if progress["review_ready"] else "warn"

    return f"""<!doctype html><html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><meta http-equiv='refresh' content='60'><title>V8016B Evidence Monitor</title><style>
:root{{--bg:#07111e;--panel:#101d2e;--panel2:#0b1728;--line:#273a52;--text:#eef6ff;--muted:#9caec4;--green:#22c55e;--red:#f87171;--yellow:#facc15;--blue:#93c5fd}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font-family:Arial,sans-serif}}a{{color:var(--blue)}}.w{{max-width:1450px;margin:auto;padding:14px}}.hero,.p,.focus{{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:15px;margin:10px 0}}h1,h2,h3{{margin:0 0 8px}}p,.muted{{color:var(--muted)}}.good{{color:var(--green)}}.bad{{color:var(--red)}}.warn{{color:var(--yellow)}}.pill,.tag{{display:inline-block;border:1px solid var(--line);background:var(--panel2);border-radius:999px;padding:6px 10px;margin:3px;font-size:12px;font-weight:800}}.stats{{display:grid;grid-template-columns:repeat(6,1fr);gap:9px}}.s{{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:10px}}.l{{font-size:11px;color:var(--muted)}}.v{{font-size:23px;font-weight:900}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}.bar{{height:24px;background:#06101c;border:1px solid var(--line);border-radius:999px;overflow:hidden}}.fill{{height:100%;background:linear-gradient(90deg,#2563eb,#22c55e);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:900;min-width:44px}}.mini{{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin:12px 0}}.mini span{{background:var(--panel2);border:1px solid var(--line);padding:8px;border-radius:10px}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{padding:8px;border-bottom:1px solid var(--line);text-align:left}}th{{background:var(--panel2)}}.scroll{{overflow:auto}}.banner{{border:1px solid #7c5d18;background:#30250b;color:#fde68a;border-radius:14px;padding:12px;margin:10px 0}}@media(max-width:900px){{.stats{{grid-template-columns:repeat(2,1fr)}}.grid{{grid-template-columns:1fr}}.mini{{grid-template-columns:repeat(2,1fr)}}}}</style></head><body><div class='w'>
<div class='hero'><h1>V8016B Evidence Monitor</h1><p>Observe-only Fortschrittsmonitor für die nächste FRESH/VALID-Entscheidung.</p><span class='pill'>READ ONLY</span><span class='pill'>NO AUTO RULE</span><span class='pill'>NO LIVE PROMOTION</span><span class='pill'>{_esc(data['generated_berlin'])}</span></div>
<div class='p'><h2>V8013D Fortschritt bis zum manuellen Review</h2><div class='bar'><div class='fill' style='width:{max(3.0, progress['percent'])}%'>{progress['closed']} / {progress['target']} · {_fmt(progress['percent'])}%</div></div><p class='{review_class}'><b>{_esc(progress['status'])}</b> · Noch {progress['remaining']} geschlossene Outcomes.</p><div class='stats'><div class='s'><div class='l'>Erfasst</div><div class='v'>{valid['captured']}</div></div><div class='s'><div class='l'>Offen</div><div class='v'>{valid['open_estimate']}</div></div><div class='s'><div class='l'>Geschlossen</div><div class='v'>{valid['closed']}</div></div><div class='s'><div class='l'>Gewinner</div><div class='v'>{valid['wins']}</div></div><div class='s'><div class='l'>Verlierer</div><div class='v'>{valid['losses']}</div></div><div class='s'><div class='l'>Gesamt</div><div class='v'>{_fmt(valid['total_r'])}R</div></div></div></div>
<div class='banner'><b>Regel bleibt unverändert:</b> Vor 30 geschlossenen V8013D-Outcomes keine Änderung an FRESH/VALID. LATE/CHASE bleibt ausgeschlossen.</div>
<div class='grid'><div><h2>Fokuscluster</h2>{_focus_cards(data['focus_clusters'])}</div><div class='p'><h2>Aktuelle V8004.2-Kohorte</h2><table><tr><td>Geschlossen</td><td>{int(current.get('n') or 0)}</td></tr><tr><td>Winrate</td><td>{_fmt(current.get('win_rate_percent'))}%</td></tr><tr><td>Gesamt</td><td>{_fmt(current.get('total_r'))}R</td></tr><tr><td>Ø pro Trade</td><td>{_fmt(current.get('avg_r'),3)}R</td></tr><tr><td>Median</td><td>{_fmt(current.get('median_r'))}R</td></tr></table><p><a href='/v8016/clean-ai-review'>V8016A Clean AI Review</a> · <a href='/v8013/valid-shadow-capture'>V8013D Detail</a> · <a href='/master-ai-review'>AI Review Menü</a></p></div></div>
<div class='p'><h2>Letzte V8013D-Captures</h2><div class='scroll'><table><tr><th>Markt</th><th>Richtung</th><th>Setup</th><th>Grade</th><th>Status</th><th>Ergebnis</th><th>R</th><th>Erfasst UTC</th></tr>{_latest_table(latest)}</table></div></div>
<div class='p'><h2>Sicherheit</h2><pre>{_esc(json.dumps(data['safety'], indent=2, ensure_ascii=False))}</pre></div>
</div></body></html>"""


def selftest_payload() -> dict[str, Any]:
    aggregates = {
        "setup_direction": [
            {"setup_direction": "MSS_BEAR SHORT", "n": 10, "wins": 7, "losses": 3, "win_rate_percent": 70.0, "total_r": 7.5, "avg_r": 0.75, "median_r": 1.5, "evidence": "POSITIVE_WATCH"}
        ],
        "market_direction": [
            {"market_direction": "CADJPY SHORT", "n": 11, "wins": 1, "losses": 10, "win_rate_percent": 9.09, "total_r": -8.5, "avg_r": -0.7727, "median_r": -1.0, "evidence": "NEGATIVE_REVIEW"}
        ],
    }
    checks = {
        "progress_one_of_thirty": _progress(1)["percent"] == 3.33,
        "progress_review_ready": _progress(30)["review_ready"] is True,
        "progress_caps_at_100": _progress(40)["percent"] == 100.0,
        "mss_bear_focus_found": _find_cluster(aggregates, "setup_direction", "MSS_BEAR SHORT")["n"] == 10,
        "cadjpy_short_focus_found": _find_cluster(aggregates, "market_direction", "CADJPY SHORT")["total_r"] == -8.5,
        "read_only": SAFETY["database_writes"] is False,
        "no_rule_change": SAFETY["fresh_valid_rule_changes"] is False,
        "no_auto_promotion": SAFETY["automatic_promotion"] is False,
    }
    return {"ok": all(checks.values()), "version": VERSION, "checks": checks, "safety": dict(SAFETY)}


def install_v8016b_evidence_monitor(app) -> None:
    if getattr(app.state, "v8016b_evidence_monitor_installed", False):
        return

    @app.get("/v8016/evidence-monitor.json")
    def monitor_json():
        return JSONResponse(evidence_monitor_payload())

    @app.get("/v8016/evidence-monitor-selftest.json")
    def monitor_selftest_json():
        return JSONResponse(selftest_payload())

    @app.get("/v8016/evidence-monitor", response_class=HTMLResponse)
    def monitor_page():
        return HTMLResponse(evidence_monitor_html())

    app.state.v8016b_evidence_monitor_installed = True
    print("[V8016B] Evidence monitor installed (read-only, target=30)")
