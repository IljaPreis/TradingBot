#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="/opt/tradingbot_v6000"
PACKAGE="/root/v8016b_evidence_monitor_pack"
COMPOSE="$PROJECT/docker-compose.yml"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8016b_before_${STAMP}"
LOG="/root/v8016b_install_${STAMP}.log"
EXPECTED_MAIN="c13a18c4338a0d8f0ba5adbcb1d24c04fd1ca8b1a55c6daecd74dd7d6fe033f8"
EXPECTED_NAV="eaf32c4214073ca90000fd26744005bef492584e46f4c0d0a4399ef9b159d3b5"
EXPECTED_V8016A="c2a3b69b7b8a4f705c764dc2483f36b0f30478309ab70e8e6a3dd58d49fe4ac2"
exec > >(tee -a "$LOG") 2>&1

rollback() {
    echo "V8016B FEHLER – ROLLBACK"
    docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot || true
    [[ -f "$BACKUP/main.py" ]] && cp -a "$BACKUP/main.py" "$PROJECT/app/main.py"
    [[ -f "$BACKUP/v8003_master_navigation.py" ]] && cp -a "$BACKUP/v8003_master_navigation.py" "$PROJECT/app/v8003_master_navigation.py"
    if [[ -f "$BACKUP/v8016b_evidence_monitor.py" ]]; then
        cp -a "$BACKUP/v8016b_evidence_monitor.py" "$PROJECT/app/v8016b_evidence_monitor.py"
    else
        rm -f "$PROJECT/app/v8016b_evidence_monitor.py"
    fi
    [[ -f "$BACKUP/docker-compose.yml" ]] && cp -a "$BACKUP/docker-compose.yml" "$COMPOSE"
    rm -f "$PROJECT/ops/v8016b_evidence_monitor_check.sh"
    docker compose -f "$COMPOSE" up -d --force-recreate || true
    echo "Backup: $BACKUP"
}
trap rollback ERR INT TERM

echo "=== V8016B EVIDENCE MONITOR INSTALL ==="
echo "[1] Paketprüfung"
cd "$PACKAGE"
sha256sum -c MANIFEST.sha256
python3 - <<'PY_AUDIT'
import json
x=json.load(open('STATIC_AUDIT.json',encoding='utf-8'))
assert x['version']=='V8016B-EVIDENCE-MONITOR-V1'
assert x['safety']['database_writes'] is False
assert x['safety']['fresh_valid_rule_changes'] is False
assert x['safety']['automatic_promotion'] is False
assert x['safety']['broker_auto_execution'] is False
print('Static audit: PASS')
PY_AUDIT

echo "[2] V8016A Baseline"
actual_main="$(sha256sum "$PROJECT/app/main.py" | awk '{print $1}')"
actual_nav="$(sha256sum "$PROJECT/app/v8003_master_navigation.py" | awk '{print $1}')"
actual_v8016a="$(sha256sum "$PROJECT/app/v8016a_clean_ai_review.py" | awk '{print $1}')"
echo "main=$actual_main"
echo "nav=$actual_nav"
echo "v8016a=$actual_v8016a"
[[ "$actual_main" == "$EXPECTED_MAIN" ]] || { echo "FEHLER main baseline"; exit 1; }
[[ "$actual_nav" == "$EXPECTED_NAV" ]] || { echo "FEHLER nav baseline"; exit 1; }
[[ "$actual_v8016a" == "$EXPECTED_V8016A" ]] || { echo "FEHLER V8016A baseline"; exit 1; }
python3 - <<'PY_BASE'
import json
from urllib.request import urlopen
for path in ('/v8016/clean-ai-review-selftest.json','/v8015/selftest.json','/v8015/timezone-selftest.json','/v8015/trade-levels-selftest.json','/v8011/selftest.json'):
    with urlopen('http://127.0.0.1'+path, timeout=60) as response:
        payload=json.load(response)
    assert payload.get('ok') is True, (path, payload)
print('Baseline selftests: PASS')
PY_BASE

echo "[3] Backup und Stop"
mkdir -p "$BACKUP"
cp -a "$PROJECT/app/main.py" "$BACKUP/main.py"
cp -a "$PROJECT/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
[[ -f "$PROJECT/app/v8016b_evidence_monitor.py" ]] && cp -a "$PROJECT/app/v8016b_evidence_monitor.py" "$BACKUP/v8016b_evidence_monitor.py" || true
cp -a "$COMPOSE" "$BACKUP/docker-compose.yml"
docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot

echo "[4] Dateien installieren"
cp -a "$PACKAGE/app/main.py" "$PROJECT/app/main.py"
cp -a "$PACKAGE/app/v8003_master_navigation.py" "$PROJECT/app/v8003_master_navigation.py"
cp -a "$PACKAGE/app/v8016b_evidence_monitor.py" "$PROJECT/app/v8016b_evidence_monitor.py"
cp -a "$PACKAGE/ops/v8016b_evidence_monitor_check.sh" "$PROJECT/ops/v8016b_evidence_monitor_check.sh"
chmod 700 "$PROJECT/ops/v8016b_evidence_monitor_check.sh"
python3 -m py_compile "$PROJECT/app/main.py" "$PROJECT/app/v8003_master_navigation.py" "$PROJECT/app/v8016a_clean_ai_review.py" "$PROJECT/app/v8016b_evidence_monitor.py"

echo "[5] Compose Image"
python3 - "$COMPOSE" <<'PY_COMPOSE'
from pathlib import Path
import re, sys
path=Path(sys.argv[1])
text=path.read_text(encoding='utf-8')
text,count=re.subn(r'tradingbot_v6000-app:v8016a\b','tradingbot_v6000-app:v8016b',text)
if count < 1:
    text,count=re.subn(r"tradingbot_v6000-app:v8016[^\s\"']*",'tradingbot_v6000-app:v8016b',text)
if count < 1:
    raise SystemExit('image tag not found')
path.write_text(text,encoding='utf-8')
print('compose patch: PASS')
PY_COMPOSE

echo "[6] Build und Start"
cd "$PROJECT"
docker compose build tradingbot
docker compose up -d --force-recreate tradingbot tradingbot_ingress
for i in $(seq 1 90); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/health || true)"
    [[ "$code" == 200 ]] && { echo "Health: 200"; break; }
    echo "WAIT [$i/90] health=$code"
    sleep 2
    [[ "$i" == 90 ]] && exit 1
done
for i in $(seq 1 60); do
    state="$(docker inspect -f '{{.State.Health.Status}}' tradingbot_ingress 2>/dev/null || true)"
    [[ "$state" == healthy ]] && { echo "Ingress: healthy"; break; }
    echo "WAIT [$i/60] ingress=$state"
    sleep 2
    [[ "$i" == 60 ]] && exit 1
done

echo "[7] Check"
bash "$PROJECT/ops/v8016b_evidence_monitor_check.sh"
trap - ERR INT TERM
echo "=== V8016B INSTALLATION FERTIG ==="
echo "Backup: $BACKUP"
echo "Log: $LOG"
echo "Dashboard: http://91.107.237.214/v8016/evidence-monitor"
echo "Keine Trading-, FRESH/VALID-, Routing-, Pine- oder Broker-Regel geändert."
