#!/usr/bin/env bash
set -Eeuo pipefail
BASE="http://127.0.0.1"
echo "=== V8016B EVIDENCE MONITOR CHECK ==="
docker compose -f /opt/tradingbot_v6000/docker-compose.yml ps
for path in /health /master /master-ai-review /v8016/clean-ai-review /v8016/evidence-monitor /v8016/evidence-monitor.json /v8016/evidence-monitor-selftest.json /v8013/valid-shadow-capture /v8015/reliability.json /v8015/trade-levels.json /v8011/selftest.json; do
    code="$(curl -sS -o /dev/null -w '%{http_code}' "$BASE$path" || true)"
    printf '%-58s %s\n' "$path" "$code"
    [[ "$code" == 200 ]]
done

echo "[SELFTEST]"
curl -fsS "$BASE/v8016/evidence-monitor-selftest.json" | python3 -m json.tool

echo "[MONITOR]"
python3 - <<'PY_MONITOR'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8016/evidence-monitor.json', timeout=90) as response:
    payload=json.load(response)
summary={
    'ok': payload.get('ok'),
    'version': payload.get('version'),
    'progress': payload.get('progress'),
    'v8013d': payload.get('v8013d'),
    'current_router_cohort': payload.get('current_router_cohort'),
    'focus_clusters': payload.get('focus_clusters'),
    'latest_valid_rows': len(((payload.get('latest_valid_captures') or {}).get('rows') or [])),
    'recommendation': payload.get('recommendation'),
    'safety': payload.get('safety'),
}
print(json.dumps(summary, indent=2, ensure_ascii=False))
assert payload.get('ok') is True
assert payload['progress']['target'] == 30
assert payload['progress']['closed'] == payload['v8013d']['closed']
assert payload['safety']['database_writes'] is False
assert payload['safety']['fresh_valid_rule_changes'] is False
assert payload['safety']['automatic_promotion'] is False
assert payload['safety']['broker_auto_execution'] is False
focus={row.get('name'): row for row in payload.get('focus_clusters') or []}
assert 'MSS_BEAR SHORT' in focus
assert 'CADJPY SHORT' in focus
PY_MONITOR

echo "[NAVIGATION]"
html="$(curl -fsS "$BASE/master-ai-review")"
grep -q "V8016B Evidence Monitor" <<<"$html"
grep -q "/v8016/evidence-monitor" <<<"$html"
echo "AI Review navigation: PASS"

echo "[INGRESS]"
python3 - <<'PY_INGRESS'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8011/selftest.json', timeout=60) as response:
    payload=json.load(response)
print(json.dumps({key: payload.get(key) for key in ('ok','operational_status','queue_depth','active_dead_letter_total','token_mode','token_enforced')}, indent=2))
assert payload.get('ok') is True
assert payload.get('operational_status') == 'GREEN'
assert payload.get('active_dead_letter_total', 0) == 0
assert payload.get('token_mode') == 'off'
PY_INGRESS

for container in tradingbot tradingbot_ingress; do
    echo "--- $container errors ---"
    docker logs "$container" --since 30m 2>&1 | grep -E 'Traceback|ERROR|Exception' || true
done
free -h
df -h /
echo "=== V8016B CHECK FERTIG ==="
