# V8017.1 Combined Evidence & Operations – Ingress Watchdog Fix

This release keeps all six V8017 modules and fixes one false RED condition.

Backend and ingress run in separate Docker services. V8017 queried the
ingress-only `/v8011/selftest.json` path from backend localhost, which
correctly returned HTTP 404. V8017.1 uses Docker service DNS:

`http://tradingbot_ingress:80/v8011/selftest.json`

The reliability endpoint remains local to the backend. The installer accepts
either the clean V8016B rollback state or the installed V8017 state.

No trading rules, databases, Pine scripts, token mode, or broker execution
are changed.
