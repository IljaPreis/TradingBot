#!/usr/bin/env bash
set -Eeuo pipefail
BASE="http://127.0.0.1"

echo "=== V8017.1 COMBINED EVIDENCE & OPERATIONS CHECK ==="
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"

echo "[1] Containers"
docker compose -f /opt/tradingbot_v6000/docker-compose.yml ps

echo "[2] Critical routes"
for path in \
  /health \
  /master \
  /master-ai-review \
  /v8016/clean-ai-review \
  /v8016/evidence-monitor \
  /v8017/overview \
  /v8017/overview.json \
  /v8017/selftest.json \
  /v8016/evidence-alerts \
  /v8016/evidence-alerts.json \
  /v8016/playbook-trend \
  /v8016/playbook-trend.json \
  /v8017/exit-be-simulation \
  /v8017/exit-be-simulation.json \
  /v8017/macro-unmatched \
  /v8017/macro-unmatched.json \
  /v8017/ops-watchdog \
  /v8017/ops-watchdog.json \
  /v8017/storage-maintenance \
  /v8017/storage-maintenance.json \
  /v8015/reliability.json \
  /v8015/trade-levels.json \
  /v8011/selftest.json; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' "$BASE$path" || true)"
  printf '%-58s %s\n' "$path" "$code"
  [[ "$code" == "200" ]] || exit 1
done

echo "[3] Combined selftest"
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8017/selftest.json', timeout=60) as r:
    x=json.load(r)
print(json.dumps(x,indent=2,ensure_ascii=False))
assert x.get('ok') is True
s=x['safety']
assert s['database_writes'] is False
assert s['live_rule_changes'] is False
assert s['fresh_valid_rule_changes'] is False
assert s['pine_changes'] is False
assert s['broker_auto_execution'] is False
print('V8017 selftest: PASS')
PY

echo "[4] Evidence alerts + progress"
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8016/evidence-alerts.json', timeout=60) as r:
    x=json.load(r)
cur=x.get('current') or {}
print(json.dumps({
 'ok':x.get('ok'),
 'milestones':x.get('milestones'),
 'progress':cur.get('progress'),
 'state':x.get('state'),
},indent=2,ensure_ascii=False))
assert x.get('ok') is True
assert x.get('milestones') == [5,10,20,30]
PY

echo "[5] Playbook/cohort trend"
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8016/playbook-trend.json', timeout=90) as r:
    x=json.load(r)
print(json.dumps({
 'ok':x.get('ok'),
 'windows':x.get('windows'),
 'playbooks_current':(x.get('playbooks') or {}).get('current_router'),
 'cohort_count':len(x.get('cohorts') or []),
},indent=2,ensure_ascii=False))
assert x.get('ok') is True
assert ((x.get('windows') or {}).get('current_router') or {}).get('n',0) >= 1
assert x['policy']['automatic_rule_change'] is False
PY

echo "[6] Exit/BE collector"
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8017/exit-be-simulation.json', timeout=90) as r:
    x=json.load(r)
print(json.dumps({
 'ok':x.get('ok'),
 'collector':x.get('collector'),
 'strategies':x.get('strategies'),
 'methodology':x.get('methodology'),
},indent=2,ensure_ascii=False))
assert x.get('ok') is True
assert x['safety']['database_writes'] is False
assert x['safety']['broker_auto_execution'] is False
PY

echo "[7] Macro unmatched review"
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8017/macro-unmatched.json', timeout=90) as r:
    x=json.load(r)
print(json.dumps({
 'ok':x.get('ok'),
 'summary':x.get('summary'),
 'policy':x.get('policy'),
},indent=2,ensure_ascii=False))
assert x.get('ok') is True
assert x['policy']['automatic_mapping_changes'] is False
assert x['policy']['automatic_calendar_updates_from_unmatched'] is False
PY

echo "[8] Operations watchdog"
echo "Direct backend -> ingress service check"
for i in $(seq 1 30); do
  if docker exec tradingbot python3 - <<'PY_INGRESS'
import json
from urllib.request import urlopen
with urlopen(
    'http://tradingbot_ingress:80/v8011/selftest.json',
    timeout=10,
) as response:
    payload = json.load(response)
assert payload.get('ok') is True
assert payload.get('operational_status') == 'GREEN'
assert int(payload.get('active_dead_letter_total') or 0) == 0
print(json.dumps({
    'ok': payload.get('ok'),
    'operational_status': payload.get('operational_status'),
    'queue_depth': payload.get('queue_depth'),
    'active_dead_letter_total': payload.get(
        'active_dead_letter_total'
    ),
}, indent=2, ensure_ascii=False))
PY_INGRESS
  then
    echo "Backend -> ingress service DNS: PASS"
    break
  fi
  echo "WAIT [$i/30] ingress service DNS"
  sleep 2
  [[ "$i" == 30 ]] && exit 1
done

python3 - <<'PY_WATCHDOG'
import json
import time
from urllib.request import urlopen

last = None
for attempt in range(1, 31):
    with urlopen(
        'http://127.0.0.1/v8017/ops-watchdog.json',
        timeout=90,
    ) as response:
        payload = json.load(response)
    current = payload.get('current') or {}
    last = (payload, current)
    if current.get('status') == 'GREEN':
        break
    print(
        f"WAIT [{attempt}/30] watchdog="
        f"{current.get('status')} issues={current.get('issues')}"
    )
    time.sleep(2)

payload, current = last
print(json.dumps({
    'route_ok': payload.get('ok'),
    'status': current.get('status'),
    'issues': current.get('issues'),
    'checks': current.get('checks'),
    'state': payload.get('state'),
}, indent=2, ensure_ascii=False))

assert payload.get('ok') is True
assert current.get('status') == 'GREEN', current
checks = current.get('checks') or {}
assert (checks.get('main_db') or {}).get('ok') is True
assert (checks.get('queue_db') or {}).get('ok') is True
ingress_http = checks.get('ingress_http') or {}
assert ingress_http.get('ok') is True
assert 'tradingbot_ingress' in str(ingress_http.get('url') or '')
summary = checks.get('ingress_summary') or {}
assert summary.get('operational_status') == 'GREEN'
assert int(summary.get('active_dead_letter_total') or 0) == 0
print('V8017.1 watchdog ingress target: PASS')
PY_WATCHDOG

echo "[9] Storage maintenance + timer"
python3 - <<'PY'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8017/storage-maintenance.json', timeout=60) as r:
    x=json.load(r)
print(json.dumps(x,indent=2,ensure_ascii=False))
assert x.get('ok') is True
assert x['policy']['databases_deleted'] is False
assert x['policy']['tagged_images_deleted'] is False
PY
if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  systemctl is-enabled tradingbot-v8017-storage.timer
  systemctl status tradingbot-v8017-storage.timer --no-pager -l | sed -n '1,30p'
else
  echo "systemd timer check skipped: systemd not active"
fi

echo "[10] Older safety selftests"
python3 - <<'PY'
import json
from urllib.request import urlopen
for path in (
 '/v8016/clean-ai-review-selftest.json',
 '/v8016/evidence-monitor-selftest.json',
 '/v8015/selftest.json',
 '/v8015/timezone-selftest.json',
 '/v8015/trade-levels-selftest.json',
 '/v8011/selftest.json',
):
    with urlopen('http://127.0.0.1'+path, timeout=90) as r:
        x=json.load(r)
    assert x.get('ok') is True, (path,x)
print('Older selftests: PASS')
PY

echo "[11] Errors last 30m"
echo "--- tradingbot ---"
docker logs --since 30m tradingbot 2>&1 | grep -Ei 'traceback|exception|error|critical|database is locked' | tail -n 80 || true
echo "--- tradingbot_ingress ---"
docker logs --since 30m tradingbot_ingress 2>&1 | grep -Ei 'traceback|exception|error|critical|database is locked' | tail -n 80 || true

echo "[12] Resources"
free -h
df -h /

echo "=== V8017.1 CHECK FERTIG ==="
