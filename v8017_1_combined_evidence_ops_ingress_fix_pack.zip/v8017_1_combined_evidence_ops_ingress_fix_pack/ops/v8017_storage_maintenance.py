#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VERSION = "V8017D-STORAGE-MAINTENANCE-V1"
PROJECT = Path("/opt/tradingbot_v6000")
RUNTIME = PROJECT / "data/v8017_runtime"
REPORT = RUNTIME / "storage_host_report.json"
BACKUPS = PROJECT / "backups"
ROOT = Path("/root")
APPLY_THRESHOLD = 70.0
BUILDER_THRESHOLD = 80.0
KEEP_BACKUPS = 10
KEEP_ZIPS = 10
KEEP_LOGS = 20
MIN_BACKUP_AGE_DAYS = 14
MIN_ZIP_AGE_DAYS = 14
MIN_LOG_AGE_DAYS = 30


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso() -> str:
    return now_utc().isoformat()


def age_days(path: Path) -> float:
    return max(0.0, (now_utc().timestamp() - path.stat().st_mtime) / 86400.0)


def disk_payload() -> dict[str, Any]:
    usage = shutil.disk_usage("/")
    used_percent = round(usage.used / usage.total * 100.0, 2) if usage.total else 0.0
    return {
        "total_bytes": usage.total,
        "used_bytes": usage.used,
        "free_bytes": usage.free,
        "used_percent": used_percent,
    }


def sorted_existing(paths: list[Path]) -> list[Path]:
    return sorted((path for path in paths if path.exists()), key=lambda p: p.stat().st_mtime, reverse=True)


def eligible_old(items: list[Path], keep: int, minimum_age_days: int) -> list[Path]:
    kept = set(items[:keep])
    return [path for path in items if path not in kept and age_days(path) >= minimum_age_days]


def contains_protected_file(path: Path) -> bool:
    if path.is_file():
        low = path.name.lower()
        return any(token in low for token in (".sqlite", ".db", "database"))
    if path.is_dir():
        try:
            for item in path.rglob("*"):
                if item.is_file():
                    low = item.name.lower()
                    if any(token in low for token in (".sqlite", ".db", "database")):
                        return True
        except Exception:
            return True
    return False


def safe_delete(path: Path) -> tuple[bool, str]:
    resolved = path.resolve()
    text = str(resolved)
    forbidden_parts = (".sqlite", "/data/", "/app/")
    if any(part in text.lower() for part in forbidden_parts):
        return False, "protected_path"
    if contains_protected_file(resolved):
        return False, "contains_protected_database_file"
    if PROJECT not in resolved.parents and ROOT not in resolved.parents:
        return False, "outside_allowed_roots"
    try:
        if resolved.is_dir():
            shutil.rmtree(resolved)
        elif resolved.is_file() or resolved.is_symlink():
            resolved.unlink()
        else:
            return False, "not_found"
        return True, "deleted"
    except Exception as exc:
        return False, str(exc)


def command(cmd: list[str], timeout: int = 120) -> dict[str, Any]:
    try:
        result = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout, check=False)
        return {
            "command": cmd,
            "returncode": result.returncode,
            "stdout": result.stdout[-5000:],
            "stderr": result.stderr[-5000:],
            "ok": result.returncode == 0,
        }
    except Exception as exc:
        return {"command": cmd, "ok": False, "error": str(exc)}


def inventory() -> dict[str, Any]:
    backup_items = sorted_existing([p for p in BACKUPS.iterdir()] if BACKUPS.exists() else [])
    zip_items = sorted_existing(list(ROOT.glob("v*.zip")))
    log_items = sorted_existing(list(ROOT.glob("v*_*.log")))
    docker_images = command(["docker", "image", "ls", "--format", "{{.Repository}}:{{.Tag}}|{{.ID}}|{{.Size}}"], 60)
    return {
        "backups": [
            {"path": str(p), "age_days": round(age_days(p), 2), "bytes": directory_size(p)}
            for p in backup_items
        ],
        "repo_zips": [
            {"path": str(p), "age_days": round(age_days(p), 2), "bytes": p.stat().st_size}
            for p in zip_items
        ],
        "logs": [
            {"path": str(p), "age_days": round(age_days(p), 2), "bytes": p.stat().st_size}
            for p in log_items
        ],
        "docker_images": docker_images,
    }


def directory_size(path: Path) -> int:
    if path.is_file():
        return path.stat().st_size
    total = 0
    try:
        for item in path.rglob("*"):
            if item.is_file() and not item.is_symlink():
                try:
                    total += item.stat().st_size
                except OSError:
                    pass
    except Exception:
        pass
    return total


def apply_safe_cleanup() -> dict[str, Any]:
    before = disk_payload()
    apply_allowed = before["used_percent"] >= APPLY_THRESHOLD
    actions: list[dict[str, Any]] = []
    if not apply_allowed:
        return {
            "applied": False,
            "reason": f"disk_below_{APPLY_THRESHOLD}_percent",
            "actions": actions,
            "before": before,
            "after": before,
        }

    backups = sorted_existing([p for p in BACKUPS.iterdir()] if BACKUPS.exists() else [])
    zips = sorted_existing(list(ROOT.glob("v*.zip")))
    logs = sorted_existing(list(ROOT.glob("v*_*.log")))

    candidates = [
        *(eligible_old(backups, KEEP_BACKUPS, MIN_BACKUP_AGE_DAYS)),
        *(eligible_old(zips, KEEP_ZIPS, MIN_ZIP_AGE_DAYS)),
        *(eligible_old(logs, KEEP_LOGS, MIN_LOG_AGE_DAYS)),
    ]
    for path in candidates:
        size = directory_size(path)
        ok, reason = safe_delete(path)
        actions.append({"path": str(path), "bytes": size, "deleted": ok, "reason": reason})

    actions.append({"docker_image_prune": command(["docker", "image", "prune", "-f"], 180)})
    mid = disk_payload()
    if mid["used_percent"] >= BUILDER_THRESHOLD:
        actions.append(
            {
                "docker_builder_prune": command(
                    ["docker", "builder", "prune", "-f", "--filter", "until=336h"], 300
                )
            }
        )
    after = disk_payload()
    return {"applied": True, "reason": "threshold_reached", "actions": actions, "before": before, "after": after}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply-safe", action="store_true")
    parser.add_argument("--report-only", action="store_true")
    args = parser.parse_args()

    RUNTIME.mkdir(parents=True, exist_ok=True)
    cleanup = apply_safe_cleanup() if args.apply_safe else {
        "applied": False,
        "reason": "report_only",
        "actions": [],
        "before": disk_payload(),
        "after": disk_payload(),
    }
    payload = {
        "ok": True,
        "version": VERSION,
        "generated_utc": iso(),
        "policy": {
            "apply_threshold_percent": APPLY_THRESHOLD,
            "builder_prune_threshold_percent": BUILDER_THRESHOLD,
            "keep_backups": KEEP_BACKUPS,
            "keep_repo_zips": KEEP_ZIPS,
            "keep_logs": KEEP_LOGS,
            "minimum_backup_age_days": MIN_BACKUP_AGE_DAYS,
            "minimum_zip_age_days": MIN_ZIP_AGE_DAYS,
            "minimum_log_age_days": MIN_LOG_AGE_DAYS,
            "delete_databases": False,
            "delete_tagged_images": False,
        },
        "cleanup": cleanup,
        "inventory": inventory(),
    }
    temporary = REPORT.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, REPORT)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
