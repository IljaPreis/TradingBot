# V8017.2 Combined Evidence & Operations – Preflight Fix

V8017.2 keeps all six V8017 modules and the V8017.1 Docker-service-DNS
watchdog fix. It corrects the production preflight contract:

- `/health` legitimately returns `{ "status": "online", ... }` rather than
  `{ "ok": true }`.
- rollback is armed only after all preflight checks pass and a complete backup
  exists, so a preflight failure cannot stop or recreate production.
- the direct backend-to-ingress check uses `docker exec -i`, ensuring the
  Python validation script receives its here-document over stdin.

The installer accepts either the clean V8016B rollback state or an installed
V8017 state. It changes no trading rules, databases, Pine scripts, token mode,
or broker execution.
