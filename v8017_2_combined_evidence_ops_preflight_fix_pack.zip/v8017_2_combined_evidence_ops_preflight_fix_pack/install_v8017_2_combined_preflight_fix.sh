#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="/opt/tradingbot_v6000"
PACKAGE="/root/v8017_2_combined_evidence_ops_preflight_fix_pack"
COMPOSE="$PROJECT/docker-compose.yml"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8017_2_before_${STAMP}"
LOG="/root/v8017_2_install_${STAMP}.log"
BUILD_LOG="/root/v8017_2_build_${STAMP}.log"

V8016B_MAIN="236042be6e9854f6e8c882c29863cbf038f6a933980ec40caad8539ee5400382"
V8016B_NAV="8fe106d2708795e40863deabab262e39d2bdb6f099532da489b0d2a0249b47b0"
V8017_MAIN="91be39188ec4bbfa9b00b68cb732085c2199eeebd03323994a0ec408452e23d0"
V8017_NAV="aa71a27312272749a22275fb71e234aca61d212d76f69f14cb75501f30529005"
V8017_MODULE_ORIGINAL="f3d783369206a21b0c9828c6993cda18e5b024dfea6322b3d9973bb2099e27a6"
V8017_MODULE_DNS_FIX="651cd39a0a54f68fe58b849387a127519a31b851defc8d7adfa6fe74a92bb5b6"
EXPECTED_V8016A="c2a3b69b7b8a4f705c764dc2483f36b0f30478309ab70e8e6a3dd58d49fe4ac2"
EXPECTED_V8016B="26ae27841a1102988ee3fbb70958d3915ecc630118afaa4426f0c535d5e586d1"

SERVICE="/etc/systemd/system/tradingbot-v8017-storage.service"
TIMER="/etc/systemd/system/tradingbot-v8017-storage.timer"

exec > >(tee -a "$LOG") 2>&1

rollback() {
    echo "V8017.2 FEHLER NACH MUTATIONSBEGINN – ROLLBACK"
    docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot || true

    [[ -f "$BACKUP/main.py" ]] && \
      cp -a "$BACKUP/main.py" "$PROJECT/app/main.py"
    [[ -f "$BACKUP/v8003_master_navigation.py" ]] && \
      cp -a "$BACKUP/v8003_master_navigation.py" \
        "$PROJECT/app/v8003_master_navigation.py"

    if [[ -f "$BACKUP/v8017_combined_evidence_ops.py" ]]; then
        cp -a "$BACKUP/v8017_combined_evidence_ops.py" \
          "$PROJECT/app/v8017_combined_evidence_ops.py"
    else
        rm -f "$PROJECT/app/v8017_combined_evidence_ops.py"
    fi

    if [[ -f "$BACKUP/v8017_storage_maintenance.py" ]]; then
        cp -a "$BACKUP/v8017_storage_maintenance.py" \
          "$PROJECT/ops/v8017_storage_maintenance.py"
    else
        rm -f "$PROJECT/ops/v8017_storage_maintenance.py"
    fi

    if [[ -f "$BACKUP/v8017_combined_check.sh" ]]; then
        cp -a "$BACKUP/v8017_combined_check.sh" \
          "$PROJECT/ops/v8017_combined_check.sh"
    else
        rm -f "$PROJECT/ops/v8017_combined_check.sh"
    fi

    [[ -f "$BACKUP/docker-compose.yml" ]] && \
      cp -a "$BACKUP/docker-compose.yml" "$COMPOSE"

    if [[ -f "$BACKUP/tradingbot-v8017-storage.service" ]]; then
        cp -a "$BACKUP/tradingbot-v8017-storage.service" "$SERVICE"
    else
        rm -f "$SERVICE"
    fi

    if [[ -f "$BACKUP/tradingbot-v8017-storage.timer" ]]; then
        cp -a "$BACKUP/tradingbot-v8017-storage.timer" "$TIMER"
    else
        rm -f "$TIMER"
    fi

    if command -v systemctl >/dev/null 2>&1 && \
       [[ -d /run/systemd/system ]]; then
        systemctl daemon-reload || true
        systemctl disable --now \
          tradingbot-v8017-storage.timer >/dev/null 2>&1 || true
        if [[ -f "$TIMER" ]]; then
            systemctl enable --now \
              tradingbot-v8017-storage.timer >/dev/null 2>&1 || true
        fi
    fi

    docker compose -f "$COMPOSE" up -d --force-recreate || true
    echo "Rollback-Backup: $BACKUP"
}

# Deliberately no rollback trap during package/baseline preflight.
# A preflight failure must not stop or recreate production containers.

echo "================================================================================"
echo "V8017.2 COMBINED EVIDENCE & OPERATIONS PREFLIGHT FIX"
echo "================================================================================"
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"
echo "Fixes: /health legacy contract + no rollback before mutation + docker exec stdin"
echo "Unverändert: 6 Module, Trading-Regeln, FRESH/VALID, Pine, Token, Broker"

echo "[1] Paketprüfung"
cd "$PACKAGE"
sha256sum -c MANIFEST.sha256

python3 - <<'PY_AUDIT'
import json
with open("STATIC_AUDIT.json", encoding="utf-8") as handle:
    payload = json.load(handle)
assert payload["version"] == \
    "V8017.2-COMBINED-EVIDENCE-OPS-PREFLIGHT-FIX-V1"
assert payload["components_total"] == 6
fix = payload["fix"]
assert fix["health_legacy_contract"] is True
assert fix["preflight_no_mutation_rollback"] is True
assert fix["docker_exec_stdin"] is True
safety = payload["safety"]
assert safety["database_writes"] is False
assert safety["live_rule_changes"] is False
assert safety["fresh_valid_rule_changes"] is False
assert safety["pine_changes"] is False
assert safety["broker_auto_execution"] is False
print("Static audit: PASS")
PY_AUDIT

python3 -m py_compile \
  "$PACKAGE/app/main.py" \
  "$PACKAGE/app/v8003_master_navigation.py" \
  "$PACKAGE/app/v8017_combined_evidence_ops.py" \
  "$PACKAGE/ops/v8017_storage_maintenance.py" \
  "$PACKAGE/ops/v8017_2_baseline_preflight.py"

bash -n "$PACKAGE/install_v8017_2_combined_preflight_fix.sh"
bash -n "$PACKAGE/ops/v8017_combined_check.sh"
python3 "$PACKAGE/ops/v8017_2_baseline_preflight.py" --selftest

echo "[2] Produktions-Baseline erkennen"
actual_main="$(sha256sum "$PROJECT/app/main.py" | awk '{print $1}')"
actual_nav="$(
  sha256sum "$PROJECT/app/v8003_master_navigation.py" |
  awk '{print $1}'
)"
actual_v8016a="$(
  sha256sum "$PROJECT/app/v8016a_clean_ai_review.py" |
  awk '{print $1}'
)"
actual_v8016b="$(
  sha256sum "$PROJECT/app/v8016b_evidence_monitor.py" |
  awk '{print $1}'
)"
actual_v8017="MISSING"
if [[ -f "$PROJECT/app/v8017_combined_evidence_ops.py" ]]; then
    actual_v8017="$(
      sha256sum "$PROJECT/app/v8017_combined_evidence_ops.py" |
      awk '{print $1}'
    )"
fi

echo "main=$actual_main"
echo "nav=$actual_nav"
echo "v8016a=$actual_v8016a"
echo "v8016b=$actual_v8016b"
echo "v8017=$actual_v8017"

[[ "$actual_v8016a" == "$EXPECTED_V8016A" ]] || {
    echo "FEHLER V8016A baseline – keine Änderung vorgenommen"
    exit 1
}
[[ "$actual_v8016b" == "$EXPECTED_V8016B" ]] || {
    echo "FEHLER V8016B baseline – keine Änderung vorgenommen"
    exit 1
}

BASELINE_MODE=""
if [[ "$actual_main" == "$V8016B_MAIN" ]] && \
   [[ "$actual_nav" == "$V8016B_NAV" ]] && \
   [[ "$actual_v8017" == "MISSING" ]]; then
    BASELINE_MODE="V8016B_ROLLBACK"
elif [[ "$actual_main" == "$V8017_MAIN" ]] && \
     [[ "$actual_nav" == "$V8017_NAV" ]] && \
     { [[ "$actual_v8017" == "$V8017_MODULE_ORIGINAL" ]] ||
       [[ "$actual_v8017" == "$V8017_MODULE_DNS_FIX" ]]; }; then
    BASELINE_MODE="V8017_INSTALLED"
else
    echo "FEHLER: unbekannter Baseline-Stand. Keine Änderung vorgenommen."
    exit 1
fi
echo "Baseline mode: $BASELINE_MODE"

python3 "$PACKAGE/ops/v8017_2_baseline_preflight.py" \
  --base http://127.0.0.1 \
  --timeout 90

echo "Preflight vollständig: PASS – erst jetzt beginnt die Mutation"

echo "[3] Backup erstellen"
mkdir -p "$BACKUP"
cp -a "$PROJECT/app/main.py" "$BACKUP/main.py"
cp -a "$PROJECT/app/v8003_master_navigation.py" \
  "$BACKUP/v8003_master_navigation.py"
[[ -f "$PROJECT/app/v8017_combined_evidence_ops.py" ]] && \
  cp -a "$PROJECT/app/v8017_combined_evidence_ops.py" \
    "$BACKUP/v8017_combined_evidence_ops.py" || true
[[ -f "$PROJECT/ops/v8017_storage_maintenance.py" ]] && \
  cp -a "$PROJECT/ops/v8017_storage_maintenance.py" \
    "$BACKUP/v8017_storage_maintenance.py" || true
[[ -f "$PROJECT/ops/v8017_combined_check.sh" ]] && \
  cp -a "$PROJECT/ops/v8017_combined_check.sh" \
    "$BACKUP/v8017_combined_check.sh" || true
cp -a "$COMPOSE" "$BACKUP/docker-compose.yml"
[[ -f "$SERVICE" ]] && \
  cp -a "$SERVICE" "$BACKUP/tradingbot-v8017-storage.service" || true
[[ -f "$TIMER" ]] && \
  cp -a "$TIMER" "$BACKUP/tradingbot-v8017-storage.timer" || true

# Rollback is armed only after a complete backup exists.
trap rollback ERR INT TERM

echo "[4] Container stoppen"
docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot

echo "[5] Korrigierte V8017-Dateien installieren"
cp -a "$PACKAGE/app/main.py" "$PROJECT/app/main.py"
cp -a "$PACKAGE/app/v8003_master_navigation.py" \
  "$PROJECT/app/v8003_master_navigation.py"
cp -a "$PACKAGE/app/v8017_combined_evidence_ops.py" \
  "$PROJECT/app/v8017_combined_evidence_ops.py"
cp -a "$PACKAGE/ops/v8017_storage_maintenance.py" \
  "$PROJECT/ops/v8017_storage_maintenance.py"
cp -a "$PACKAGE/ops/v8017_combined_check.sh" \
  "$PROJECT/ops/v8017_combined_check.sh"
chmod 700 \
  "$PROJECT/ops/v8017_storage_maintenance.py" \
  "$PROJECT/ops/v8017_combined_check.sh"
mkdir -p "$PROJECT/data/v8017_runtime"
chmod 700 "$PROJECT/data/v8017_runtime"

python3 -m py_compile \
  "$PROJECT/app/main.py" \
  "$PROJECT/app/v8003_master_navigation.py" \
  "$PROJECT/app/v8017_combined_evidence_ops.py" \
  "$PROJECT/ops/v8017_storage_maintenance.py"

echo "[6] Geschützte Trading-Komponenten unverändert"
for file in \
  "$PROJECT/app/v8004_quality_router.py" \
  "$PROJECT/app/v8006_calendar_execution_correction.py" \
  "$PROJECT/app/v8007_v8001_gate_bridge.py" \
  "$PROJECT/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"; do
  [[ -f "$file" ]] || {
    echo "FEHLER geschützt fehlt: $file"
    exit 1
  }
  sha256sum "$file"
done

echo "[7] Compose Image auf v8017_2"
python3 - "$COMPOSE" <<'PY_COMPOSE'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
text, count = re.subn(
    r"tradingbot_v6000-app:v801[0-9A-Za-z_.-]*",
    "tradingbot_v6000-app:v8017_2",
    text,
)
if count < 1:
    raise SystemExit("image tag not found")
path.write_text(text, encoding="utf-8")
print("compose patch: PASS")
PY_COMPOSE

echo "[8] Storage Timer sicherstellen"
cp -a "$PACKAGE/systemd/tradingbot-v8017-storage.service" "$SERVICE"
cp -a "$PACKAGE/systemd/tradingbot-v8017-storage.timer" "$TIMER"
chmod 644 "$SERVICE" "$TIMER"
if command -v systemctl >/dev/null 2>&1 && \
   [[ -d /run/systemd/system ]]; then
    systemctl daemon-reload
    systemctl enable --now tradingbot-v8017-storage.timer
fi
python3 "$PROJECT/ops/v8017_storage_maintenance.py" \
  --report-only >"/root/v8017_2_storage_report_${STAMP}.log"

echo "[9] Image bauen und Container starten"
cd "$PROJECT"
docker compose build tradingbot 2>&1 | tee "$BUILD_LOG"
docker compose up -d --force-recreate \
  tradingbot tradingbot_ingress

for i in $(seq 1 90); do
    code="$(
      curl -sS -o /dev/null -w '%{http_code}' \
        http://127.0.0.1/health || true
    )"
    if [[ "$code" == 200 ]]; then
        echo "Health: 200"
        break
    fi
    echo "WAIT [$i/90] health=$code"
    sleep 2
    [[ "$i" == 90 ]] && exit 1
done

for i in $(seq 1 60); do
    state="$(
      docker inspect -f '{{.State.Health.Status}}' \
        tradingbot_ingress 2>/dev/null || true
    )"
    if [[ "$state" == healthy ]]; then
        echo "Ingress: healthy"
        break
    fi
    echo "WAIT [$i/60] ingress=$state"
    sleep 2
    [[ "$i" == 60 ]] && exit 1
done

sleep 10

echo "[10] Vollständiger V8017.2 Check"
bash "$PROJECT/ops/v8017_combined_check.sh"

trap - ERR INT TERM
echo "================================================================================"
echo "V8017.2 INSTALLATION FERTIG"
echo "================================================================================"
echo "Baseline: $BASELINE_MODE"
echo "Backup: $BACKUP"
echo "Install log: $LOG"
echo "Build log: $BUILD_LOG"
echo "Dashboard: http://91.107.237.214/v8017/overview"
echo "Watchdog: http://91.107.237.214/v8017/ops-watchdog"
echo "Keine Trading-, FRESH/VALID-, Routing-, Pine-, Token- oder Broker-Regel geändert."
