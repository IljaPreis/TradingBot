#!/usr/bin/env python3
"""V8017.2 read-only production preflight validation."""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any
from urllib.request import urlopen

PATHS = (
    "/health",
    "/v8016/clean-ai-review-selftest.json",
    "/v8016/evidence-monitor-selftest.json",
    "/v8015/selftest.json",
    "/v8011/selftest.json",
)


def payload_is_healthy(path: str, payload: dict[str, Any]) -> bool:
    """Accept the legacy /health contract and strict selftest contracts."""
    if path == "/health":
        status = str(payload.get("status") or "").strip().lower()
        return payload.get("ok") is True or status in {
            "online",
            "ok",
            "healthy",
        }
    return payload.get("ok") is True


def validate_payload(path: str, payload: dict[str, Any]) -> None:
    if not payload_is_healthy(path, payload):
        raise AssertionError((path, payload))


def run_selftest() -> None:
    validate_payload("/health", {"status": "online"})
    validate_payload("/health", {"ok": True})
    validate_payload("/v8015/selftest.json", {"ok": True})

    rejected = 0
    for path, payload in (
        ("/health", {"status": "offline"}),
        ("/v8015/selftest.json", {"ok": False}),
    ):
        try:
            validate_payload(path, payload)
        except AssertionError:
            rejected += 1
    if rejected != 2:
        raise AssertionError("negative validation selftest failed")
    print("V8017.2 preflight validator selftest: PASS")


def run_live(base: str, timeout: int) -> None:
    for path in PATHS:
        with urlopen(base.rstrip("/") + path, timeout=timeout) as response:
            if response.status != 200:
                raise AssertionError((path, response.status))
            payload = json.load(response)
        validate_payload(path, payload)
        if path == "/health":
            result = payload.get("status") or payload.get("ok")
        else:
            result = payload.get("ok")
        print(f"{path}: PASS ({result})")
    print("Baseline selftests: PASS")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="http://127.0.0.1")
    parser.add_argument("--timeout", type=int, default=90)
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()

    if args.selftest:
        run_selftest()
    else:
        run_live(args.base, args.timeout)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"V8017.2 preflight failed: {exc}", file=sys.stderr)
        raise
