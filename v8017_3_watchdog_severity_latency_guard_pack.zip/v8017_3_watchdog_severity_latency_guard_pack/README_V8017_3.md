# V8017.3 Watchdog Severity & Latency Guard

Dieses Minimal-Update korrigiert ausschließlich die Schweregradlogik des
V8017 Operations Watchdogs.

## Verhalten

- `GREEN`: alle Prüfungen gesund.
- `YELLOW`: ausschließlich vorübergehende Backend-Latenz, während Backend,
  Worker, Cleanup, Queue-Datenbank, Queue und Dead Letters gesund bleiben.
- `RED`: echter Betriebsfehler, etwa nicht erreichbares Backend, toter Worker,
  aktive Dead Letters, Datenbankfehler, fehlender Heartbeat oder Macro-Guard.

Telegram:

- RED erst nach 2 aufeinanderfolgenden RED-Prüfungen.
- YELLOW-Latenzwarnung erst nach 3 aufeinanderfolgenden YELLOW-Prüfungen.
- Ein einzelner Latenz-Spike erzeugt keine kritische Nachricht.
- Recovery erst bei vollständiger Rückkehr zu GREEN.

Der vorhandene Legacy-Watchdog-State wird ohne alte Fehlerserie übernommen:
Alte `consecutive_failures` lösen nach dem Update keinen Alarm aus.

## Unverändert

- alle sechs V8017-Module,
- Datenbanken und Tabellen,
- V8004 und FRESH/VALID,
- Routing und Schwellen,
- Pine,
- Webhook-Tokenmodus OFF,
- Broker Auto Execution FALSE,
- Storage-Timer und Schutzregeln.
