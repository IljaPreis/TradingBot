#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="/opt/tradingbot_v6000"
PACKAGE="/root/v8017_3_watchdog_severity_latency_guard_pack"
COMPOSE="$PROJECT/docker-compose.yml"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8017_3_before_$STAMP"
LOG="/root/v8017_3_install_$STAMP.log"
BUILD_LOG="/root/v8017_3_build_$STAMP.log"

EXPECTED_MAIN="91be39188ec4bbfa9b00b68cb732085c2199eeebd03323994a0ec408452e23d0"
EXPECTED_NAV="aa71a27312272749a22275fb71e234aca61d212d76f69f14cb75501f30529005"
EXPECTED_MODULE="651cd39a0a54f68fe58b849387a127519a31b851defc8d7adfa6fe74a92bb5b6"
EXPECTED_CHECK="721ebecc1ea38c1ff635369e388565a688c65881adbfe7e6d7de4c10062c73d1"
EXPECTED_STORAGE="ae2824143d2b5c9d29adb49be4fccb67739d09cc2bba9eeacde9382bcb929d6c"
EXPECTED_V8004="7f0e12aa0a51e11259331f51c8f41f0bbe30a2d93da82e006dadc87a41457f6d"
EXPECTED_V8006="1d687b5a1400f26a8a63492287af9e055821fa1d53800d255de956070229d373"
EXPECTED_V8007="a24d7cd9e1c69f8c3fd364db6ba88dc4c90beb4ce2999e7d66f58fdd33b338f5"
EXPECTED_PINE="6e84a724c6e1a3f932a3d8f85324f6a82e236f6e18db471eacb0626b7f71778c"

exec > >(tee -a "$LOG") 2>&1

rollback() {
    echo "V8017.3 FEHLER NACH MUTATIONSBEGINN – ROLLBACK"
    docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot || true
    cp -a "$BACKUP/v8017_combined_evidence_ops.py" \
      "$PROJECT/app/v8017_combined_evidence_ops.py"
    cp -a "$BACKUP/v8017_combined_check.sh" \
      "$PROJECT/ops/v8017_combined_check.sh"
    cp -a "$BACKUP/docker-compose.yml" "$COMPOSE"
    docker compose -f "$COMPOSE" up -d --force-recreate || true
    echo "Rollback-Backup: $BACKUP"
}

echo "================================================================================"
echo "V8017.3 WATCHDOG SEVERITY & LATENCY GUARD INSTALL"
echo "================================================================================"
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"
echo "Fix: YELLOW-Latenz ist kein RED-Ausfall; getrennte Warn-/Alarmserien."
echo "Unverändert: 6 Module, Trading-Regeln, DB, FRESH/VALID, Pine, Token, Broker"

echo "[1] Paketprüfung"
cd "$PACKAGE"
sha256sum -c MANIFEST.sha256
python3 - <<'PY_AUDIT'
import json
with open('STATIC_AUDIT.json', encoding='utf-8') as handle:
    payload = json.load(handle)
assert payload['version'] == 'V8017.3-WATCHDOG-SEVERITY-LATENCY-GUARD-V1'
fix = payload['fix']
assert fix['latency_only_yellow_not_red'] is True
assert fix['red_alert_after_consecutive_checks'] == 2
assert fix['yellow_alert_after_consecutive_checks'] == 3
assert fix['legacy_state_safe_migration'] is True
assert fix['compact_storage_check'] is True
safety = payload['safety']
assert safety['database_writes'] is False
assert safety['live_rule_changes'] is False
assert safety['fresh_valid_rule_changes'] is False
assert safety['pine_changes'] is False
assert safety['broker_auto_execution'] is False
print('Static audit: PASS')
PY_AUDIT
python3 -m py_compile "$PACKAGE/app/v8017_combined_evidence_ops.py"
bash -n "$PACKAGE/install_v8017_3_watchdog_severity_latency_guard.sh"
bash -n "$PACKAGE/ops/v8017_combined_check.sh"

echo "[2] V8017.2 Produktions-Baseline – vor jeder Mutation"
check_hash() {
    local expected="$1"
    local path="$2"
    local actual
    actual="$(sha256sum "$path" | awk '{print $1}')"
    printf '%-70s %s\n' "$path" "$actual"
    [[ "$actual" == "$expected" ]]
}
check_hash "$EXPECTED_MAIN" "$PROJECT/app/main.py"
check_hash "$EXPECTED_NAV" "$PROJECT/app/v8003_master_navigation.py"
check_hash "$EXPECTED_MODULE" "$PROJECT/app/v8017_combined_evidence_ops.py"
check_hash "$EXPECTED_CHECK" "$PROJECT/ops/v8017_combined_check.sh"
check_hash "$EXPECTED_STORAGE" "$PROJECT/ops/v8017_storage_maintenance.py"
grep -q 'tradingbot_v6000-app:v8017_2' "$COMPOSE"

python3 - <<'PY_PREFLIGHT'
import json
from urllib.request import urlopen

def get(path):
    with urlopen('http://127.0.0.1' + path, timeout=90) as response:
        return json.load(response)

health = get('/health')
selftest = get('/v8017/selftest.json')
ingress = get('/v8011/selftest.json')
assert health.get('status') == 'online'
assert selftest.get('ok') is True
assert selftest.get('version') == 'V8017.1-COMBINED-EVIDENCE-OPS-INGRESS-FIX-V1'
assert ingress.get('ok') is True
assert ingress.get('backend_ok') is True
assert ingress.get('worker_alive') is True
assert ingress.get('cleanup_alive') is True
assert int(ingress.get('active_dead_letter_total') or 0) == 0
assert int(ingress.get('queue_depth') or 0) <= 100
status = str(ingress.get('operational_status') or 'UNKNOWN').upper()
reasons = [str(item) for item in ingress.get('operational_reasons') or []]
assert status in {'GREEN', 'YELLOW'}, (status, reasons)
if status == 'YELLOW':
    assert reasons and all(
        reason.startswith('backend_latency_warning:')
        for reason in reasons
    )
print('V8017.2 runtime baseline: PASS')
PY_PREFLIGHT

echo "Preflight vollständig: PASS – erst jetzt beginnt die Mutation"

echo "[3] Backup"
mkdir -p "$BACKUP"
cp -a "$PROJECT/app/v8017_combined_evidence_ops.py" \
  "$BACKUP/v8017_combined_evidence_ops.py"
cp -a "$PROJECT/ops/v8017_combined_check.sh" \
  "$BACKUP/v8017_combined_check.sh"
cp -a "$COMPOSE" "$BACKUP/docker-compose.yml"
trap rollback ERR INT TERM

echo "[4] Container stoppen"
docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot

echo "[5] Minimalen Watchdog-Fix installieren"
cp -a "$PACKAGE/app/v8017_combined_evidence_ops.py" \
  "$PROJECT/app/v8017_combined_evidence_ops.py"
cp -a "$PACKAGE/ops/v8017_combined_check.sh" \
  "$PROJECT/ops/v8017_combined_check.sh"
chmod 700 "$PROJECT/ops/v8017_combined_check.sh"
python3 -m py_compile "$PROJECT/app/v8017_combined_evidence_ops.py"

echo "[6] Geschützte Komponenten exakt unverändert"
check_hash "$EXPECTED_V8004" "$PROJECT/app/v8004_quality_router.py"
check_hash "$EXPECTED_V8006" "$PROJECT/app/v8006_calendar_execution_correction.py"
check_hash "$EXPECTED_V8007" "$PROJECT/app/v8007_v8001_gate_bridge.py"
check_hash "$EXPECTED_PINE" "$PROJECT/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"

echo "[7] Compose Image auf v8017_3"
python3 - "$COMPOSE" <<'PY_COMPOSE'
from pathlib import Path
import re
import sys
path = Path(sys.argv[1])
text = path.read_text(encoding='utf-8')
text, count = re.subn(
    r'tradingbot_v6000-app:v801[0-9A-Za-z_.-]*',
    'tradingbot_v6000-app:v8017_3',
    text,
)
if count < 1:
    raise SystemExit('image tag not found')
path.write_text(text, encoding='utf-8')
print('compose patch: PASS')
PY_COMPOSE

echo "[8] Image bauen und Container starten"
cd "$PROJECT"
docker compose build tradingbot 2>&1 | tee "$BUILD_LOG"
docker compose up -d --force-recreate tradingbot tradingbot_ingress

for i in $(seq 1 90); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/health || true)"
    if [[ "$code" == 200 ]]; then
        echo "Health: 200"
        break
    fi
    echo "WAIT [$i/90] health=$code"
    sleep 2
    [[ "$i" == 90 ]] && exit 1
done

for i in $(seq 1 60); do
    state="$(docker inspect -f '{{.State.Health.Status}}' tradingbot_ingress 2>/dev/null || true)"
    if [[ "$state" == healthy ]]; then
        echo "Ingress: healthy"
        break
    fi
    echo "WAIT [$i/60] ingress=$state"
    sleep 2
    [[ "$i" == 60 ]] && exit 1
done

echo "[9] Vollständiger V8017.3 Check"
bash "$PROJECT/ops/v8017_combined_check.sh"

trap - ERR INT TERM

echo "================================================================================"
echo "V8017.3 INSTALLATION FERTIG"
echo "================================================================================"
echo "Backup: $BACKUP"
echo "Install log: $LOG"
echo "Build log: $BUILD_LOG"
echo "Dashboard: http://91.107.237.214/v8017/ops-watchdog"
echo "Keine Trading-, DB-, FRESH/VALID-, Pine-, Token- oder Broker-Regel geändert."
