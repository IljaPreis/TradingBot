#!/usr/bin/env bash
set -Eeuo pipefail
BASE="http://127.0.0.1"

echo "=== V8017.3 WATCHDOG SEVERITY & LATENCY GUARD CHECK ==="
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"

echo "[1] Containers"
docker compose -f /opt/tradingbot_v6000/docker-compose.yml ps

echo "[2] Critical routes"
for path in \
  /health \
  /master \
  /master-ai-review \
  /v8016/clean-ai-review \
  /v8016/evidence-monitor \
  /v8017/overview \
  /v8017/selftest.json \
  /v8017/ops-watchdog \
  /v8017/ops-watchdog.json \
  /v8017/storage-maintenance.json \
  /v8015/reliability.json \
  /v8015/trade-levels.json \
  /v8011/selftest.json; do
  code="$(curl -sS -o /dev/null -w '%{http_code}' "$BASE$path" || true)"
  printf '%-58s %s\n' "$path" "$code"
  [[ "$code" == "200" ]] || exit 1
done

echo "[3] V8017.3 selftest"
python3 - <<'PY_SELFTEST'
import json
from urllib.request import urlopen
with urlopen('http://127.0.0.1/v8017/selftest.json', timeout=90) as response:
    payload = json.load(response)
print(json.dumps(payload, indent=2, ensure_ascii=False))
assert payload.get('ok') is True
assert payload.get('version') == 'V8017.3-WATCHDOG-SEVERITY-LATENCY-GUARD-V1'
checks = payload.get('checks') or {}
for name in (
    'latency_only_is_yellow',
    'latency_yellow_is_operational',
    'latency_not_in_critical_issues',
    'latency_warning_present',
    'backend_failure_is_red',
    'backend_failure_is_critical',
):
    assert checks.get(name) is True, (name, checks)
safety = payload.get('safety') or {}
assert safety.get('watchdog_latency_yellow_not_red') is True
assert safety.get('database_writes') is False
assert safety.get('live_rule_changes') is False
assert safety.get('fresh_valid_rule_changes') is False
assert safety.get('pine_changes') is False
assert safety.get('broker_auto_execution') is False
print('V8017.3 selftest: PASS')
PY_SELFTEST

echo "[4] Direct backend -> ingress service"
docker exec -i tradingbot python3 - <<'PY_INGRESS'
import json
from urllib.request import urlopen
with urlopen(
    'http://tradingbot_ingress:80/v8011/selftest.json',
    timeout=30,
) as response:
    payload = json.load(response)
status = str(payload.get('operational_status') or 'UNKNOWN').upper()
reasons = [str(item) for item in payload.get('operational_reasons') or []]
assert payload.get('ok') is True
assert payload.get('backend_ok') is True
assert payload.get('worker_alive') is True
assert payload.get('cleanup_alive') is True
assert payload.get('queue_db_quick_check') is True
assert int(payload.get('active_dead_letter_total') or 0) == 0
assert int(payload.get('queue_depth') or 0) <= 100
assert status in {'GREEN', 'YELLOW'}, (status, reasons)
if status == 'YELLOW':
    assert reasons
    assert all(
        reason.startswith('backend_latency_warning:')
        for reason in reasons
    ), reasons
print(json.dumps({
    'ok': payload.get('ok'),
    'operational_status': status,
    'operational_reasons': reasons,
    'backend_ok': payload.get('backend_ok'),
    'worker_alive': payload.get('worker_alive'),
    'cleanup_alive': payload.get('cleanup_alive'),
    'queue_depth': payload.get('queue_depth'),
    'active_dead_letter_total': payload.get('active_dead_letter_total'),
}, indent=2, ensure_ascii=False))
print('Backend -> ingress service: PASS')
PY_INGRESS

echo "[5] Watchdog severity"
python3 - <<'PY_WATCHDOG'
import json
from urllib.request import urlopen
with urlopen(
    'http://127.0.0.1/v8017/ops-watchdog.json',
    timeout=90,
) as response:
    payload = json.load(response)
current = payload.get('current') or {}
checks = current.get('checks') or {}
summary = checks.get('ingress_summary') or {}
status = str(current.get('status') or 'UNKNOWN').upper()
critical = current.get('critical_issues') or []
warnings = current.get('warnings') or []
policy = current.get('alert_policy') or {}
compact = {
    'route_ok': payload.get('ok'),
    'version': payload.get('version'),
    'status': status,
    'ok': current.get('ok'),
    'critical_issues': critical,
    'warnings': warnings,
    'ingress': summary,
    'alert_policy': policy,
    'state': payload.get('state'),
}
print(json.dumps(compact, indent=2, ensure_ascii=False))
assert payload.get('ok') is True
assert payload.get('version') == 'V8017.3-WATCHDOG-SEVERITY-LATENCY-GUARD-V1'
assert status in {'GREEN', 'YELLOW'}, current
assert current.get('ok') is True
assert critical == [], critical
assert (checks.get('main_db') or {}).get('ok') is True
assert (checks.get('queue_db') or {}).get('ok') is True
assert (checks.get('ingress_http') or {}).get('ok') is True
assert summary.get('backend_ok') is True
assert summary.get('worker_alive') is True
assert summary.get('cleanup_alive') is True
assert summary.get('queue_db_quick_check') is True
assert int(summary.get('active_dead_letter_total') or 0) == 0
if status == 'YELLOW':
    assert warnings == ['INGRESS_BACKEND_LATENCY'], warnings
else:
    assert warnings == [], warnings
assert policy.get('yellow_is_critical') is False
assert policy.get('red_consecutive_checks_before_alert') == 2
assert policy.get('yellow_consecutive_checks_before_alert') == 3
print('Watchdog GREEN/YELLOW severity: PASS')
PY_WATCHDOG

echo "[6] Ingress, reliability and storage compact"
python3 - <<'PY_COMPACT'
import json
from urllib.request import urlopen

def get(path):
    with urlopen('http://127.0.0.1' + path, timeout=90) as response:
        return json.load(response)

ingress = get('/v8011/selftest.json')
reliability = get('/v8015/reliability.json')
storage = get('/v8017/storage-maintenance.json')
report = storage.get('host_report') or {}
cleanup = report.get('cleanup') or {}
print(json.dumps({
    'ingress_operational_status': ingress.get('operational_status'),
    'queue_depth': ingress.get('queue_depth'),
    'active_dead_letters': ingress.get('active_dead_letter_total'),
    'token_mode': ingress.get('token_mode'),
    'macro_cpi_identity_exact': (
        (reliability.get('macro') or {}).get('cpi_identity_exact')
    ),
    'disk': storage.get('container_disk'),
    'cleanup_applied': cleanup.get('applied'),
    'cleanup_reason': cleanup.get('reason'),
    'storage_policy': storage.get('policy'),
}, indent=2, ensure_ascii=False))
assert ingress.get('ok') is True
assert int(ingress.get('active_dead_letter_total') or 0) == 0
assert (reliability.get('macro') or {}).get('cpi_identity_exact') is True
assert storage.get('ok') is True
assert (storage.get('policy') or {}).get('databases_deleted') is False
assert (storage.get('policy') or {}).get('tagged_images_deleted') is False
print('Core safety compact: PASS')
PY_COMPACT

echo "[7] Storage timer"
if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  systemctl is-enabled tradingbot-v8017-storage.timer
  systemctl is-active tradingbot-v8017-storage.timer
  systemctl list-timers tradingbot-v8017-storage.timer --no-pager
else
  echo "systemd timer check skipped: systemd not active"
fi

echo "[8] Errors last 30m"
echo "--- tradingbot ---"
docker logs --since 30m tradingbot 2>&1 | \
  grep -Ei 'traceback|exception|critical|database is locked|(^|[^a-z])error([^a-z]|$)' | \
  grep -Eiv 'errors=0|error_count.?[:=].?0' | tail -n 80 || true
echo "--- tradingbot_ingress ---"
docker logs --since 30m tradingbot_ingress 2>&1 | \
  grep -Ei 'traceback|exception|critical|database is locked|(^|[^a-z])error([^a-z]|$)' | \
  grep -Eiv 'errors=0|error_count.?[:=].?0' | tail -n 80 || true

echo "[9] Resources"
free -h
df -h /

echo "=== V8017.3 CHECK FERTIG ==="
