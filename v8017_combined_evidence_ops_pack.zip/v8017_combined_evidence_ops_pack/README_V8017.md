# V8017 Combined Evidence & Operations Pack

Dieses Paket installiert sechs Bausteine gemeinsam auf dem stabilen V8016B-Stand.

## Enthalten

1. **V8016C Evidence Telegram Alerts**
   - Fortschrittsmeldungen bei 5, 10, 20 und 30 geschlossenen V8013D-Outcomes.
   - Der erste Lauf initialisiert den aktuellen Stand ohne historische Telegram-Nachricht.
   - Keine automatische FRESH/VALID-Änderung.

2. **V8016D Playbook & Cohort Trend Monitor**
   - Playbook A/B, Router-Versionen, 7-/30-Tage-Fenster und Tagestrend.
   - Quelle: `shadow_outcomes.pnl_r` über V8016A Clean AI Review.
   - Keine historischen MFE-/MAE-Werte für Performance-Cluster.

3. **V8017A Exit/BE Shadow Collector**
   - Minütliche Sequenz-Snapshots für neue, als gültig markierte Excursion-Reihen.
   - Vergleicht Fixed TP/SL, BE 0,5R/0,75R/1R, 50% Teilgewinn bei 1R und 0,5R-Trailing nach 1R.
   - Schreibt nur JSONL/JSON in `data/v8017_runtime`; keine Trading-DB-Änderung.
   - Observe-only, keine Order und keine echte Exit-Regel.

4. **V8017B Macro Unmatched Review**
   - Zeigt nicht eindeutig zugeordnete Actuals, Guard-Gründe und Headlines.
   - Keine automatische Zuordnung und kein Kalender-Write aus unklaren Treffern.

5. **V8017C Operations Watchdog**
   - Prüft Main-DB, Queue-DB, Ingress, Queue, Dead Letters, globalen Heartbeat, Macro-Identity und Disk.
   - Telegram erst nach zwei aufeinanderfolgenden Fehlerprüfungen; Recovery-Meldung bei GREEN.
   - Keine Warnung für einzelne geschlossene Märkte; nur wenn überhaupt kein Heartbeat länger als fünf Minuten ankommt.

6. **V8017D Safe Storage Maintenance**
   - Wöchentlicher systemd-Timer.
   - Cleanup wird nur ab 70% Plattenbelegung angewendet.
   - Behält mindestens 10 Backups, 10 Repo-ZIPs und 20 Logs.
   - Datenbanken, `data/` und getaggte Docker-Images werden nie gelöscht.
   - Docker räumt nur dangling Images auf; Builder-Cache erst ab 80% und nur älter als 14 Tage.

## Neue Seiten

- `/v8017/overview`
- `/v8016/evidence-alerts`
- `/v8016/playbook-trend`
- `/v8017/exit-be-simulation`
- `/v8017/macro-unmatched`
- `/v8017/ops-watchdog`
- `/v8017/storage-maintenance`

## Sicherheitsgrenzen

- keine Datenbank-Schemaänderung
- keine Trading-DB-Writes
- keine V8004-Schwellenänderung
- keine FRESH/VALID-Änderung
- keine automatische Blockierung oder Promotion
- keine Pine-Änderung
- keine Änderung des Webhook-Tokenmodus
- keine Broker-Autoausführung

## Installationsbasis

Das Paket erwartet den exakt geprüften V8016B-Produktionsstand. Bei einer Hash-Abweichung stoppt der Installer vor dem Stoppen der Container. Nicht umgehen.
