from __future__ import annotations

import asyncio
import html
import json
import math
import os
import shutil
import sqlite3
import statistics
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.request import urlopen
from zoneinfo import ZoneInfo

from fastapi.responses import HTMLResponse, JSONResponse

VERSION = "V8017-COMBINED-EVIDENCE-OPS-V1"
MODE = "observe_only_learning_operations_bundle"
BERLIN = ZoneInfo("Europe/Berlin")
MILESTONES = (5, 10, 20, 30)
POLL_SECONDS = 60
ALERT_POLL_SECONDS = 300
WATCHDOG_POLL_SECONDS = 300
SAMPLE_INTERVAL_SECONDS = 60

SAFETY = {
    "observe_only": True,
    "database_writes": False,
    "database_schema_changes": False,
    "runtime_file_writes": True,
    "live_rule_changes": False,
    "routing_changes": False,
    "threshold_changes": False,
    "automatic_blocking": False,
    "automatic_filtering": False,
    "automatic_promotion": False,
    "fresh_valid_rule_changes": False,
    "pine_changes": False,
    "telegram_trade_message_changes": False,
    "telegram_operational_alerts": True,
    "broker_auto_execution": False,
    "storage_safe_cleanup_threshold_percent": 70,
    "storage_never_delete_databases": True,
    "storage_never_delete_active_images": True,
}


def _root() -> Path:
    for candidate in (Path("/app"), Path("/opt/tradingbot_v6000"), Path.cwd()):
        if (candidate / "app").exists() and (candidate / "data").exists():
            return candidate
    return Path.cwd()


def _main_db() -> Path:
    override = os.getenv("V8017_MAIN_DB", "").strip()
    return Path(override) if override else _root() / "data/v7000_learning.sqlite3"


def _queue_db() -> Path:
    override = os.getenv("V8017_QUEUE_DB", "").strip()
    return Path(override) if override else _root() / "data/v8011_ingress.sqlite3"


def _runtime_dir() -> Path:
    override = os.getenv("V8017_RUNTIME_DIR", "").strip()
    path = Path(override) if override else _root() / "data/v8017_runtime"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _now()).astimezone(timezone.utc).isoformat()


def _parse_dt(value: Any) -> datetime | None:
    try:
        dt = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _berlin(value: Any) -> str:
    dt = value if isinstance(value, datetime) else _parse_dt(value)
    if not dt:
        return str(value or "")
    return dt.astimezone(BERLIN).strftime("%d.%m.%Y %H:%M:%S %Z")


def _num(value: Any) -> float | None:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _esc(value: Any) -> str:
    return html.escape(str("" if value is None else value))


def _fmt(value: Any, digits: int = 2) -> str:
    number = _num(value)
    return "–" if number is None else f"{number:.{digits}f}"


def _read_json(path: Path, default: Any) -> Any:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data
    except Exception:
        return default


def _write_json_atomic(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")


def _load_jsonl(path: Path, limit: int | None = None) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                    if isinstance(item, dict):
                        rows.append(item)
                except Exception:
                    continue
    except Exception:
        return []
    if limit and len(rows) > limit:
        return rows[-limit:]
    return rows


def _connect_ro(path: Path) -> sqlite3.Connection:
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=20)
    con.row_factory = sqlite3.Row
    return con


def _table_exists(con: sqlite3.Connection, table: str) -> bool:
    return con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone() is not None


def _columns(con: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in con.execute(f"PRAGMA table_info({table})")}


def _quick_check(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"available": False, "ok": False, "result": "missing", "path": str(path)}
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=20)
        result = str(con.execute("PRAGMA quick_check").fetchone()[0])
        con.close()
        return {"available": True, "ok": result == "ok", "result": result, "path": str(path)}
    except Exception as exc:
        return {"available": True, "ok": False, "result": str(exc), "path": str(path)}


def _summary(values: Iterable[float]) -> dict[str, Any]:
    vals = [float(value) for value in values if _num(value) is not None]
    wins = sum(value > 0 for value in vals)
    losses = sum(value < 0 for value in vals)
    return {
        "n": len(vals),
        "wins": wins,
        "losses": losses,
        "breakeven": len(vals) - wins - losses,
        "win_rate_percent": round(wins / len(vals) * 100, 2) if vals else None,
        "total_r": round(sum(vals), 4) if vals else None,
        "avg_r": round(sum(vals) / len(vals), 4) if vals else None,
        "median_r": round(statistics.median(vals), 4) if vals else None,
        "min_r": round(min(vals), 4) if vals else None,
        "max_r": round(max(vals), 4) if vals else None,
    }


# ---------------------------------------------------------------------------
# 1) Evidence Telegram alerts
# ---------------------------------------------------------------------------


def _evidence_payload() -> dict[str, Any]:
    try:
        from app.v8016b_evidence_monitor import evidence_monitor_payload

        return evidence_monitor_payload()
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def _cluster_signature(row: dict[str, Any]) -> str:
    return "|".join(
        [
            str(row.get("focus") or ""),
            str(row.get("name") or ""),
            str(_int(row.get("n"))),
            str(round(_num(row.get("avg_r")) or 0.0, 3)),
            str(round(_num(row.get("win_rate_percent")) or 0.0, 2)),
        ]
    )


def _evidence_alert_decision(
    previous: dict[str, Any], current: dict[str, Any]
) -> dict[str, Any]:
    progress = current.get("progress") or {}
    closed = _int(progress.get("closed"))
    previous_closed = _int(previous.get("last_closed"), closed)
    crossed = [m for m in MILESTONES if previous_closed < m <= closed]

    focus_rows = current.get("focus_clusters") or []
    sent_signatures = set(previous.get("sent_cluster_signatures") or [])
    new_cluster_rows: list[dict[str, Any]] = []
    for row in focus_rows:
        n = _int(row.get("n"))
        avg_r = _num(row.get("avg_r"))
        focus = str(row.get("focus") or "")
        meaningful = n >= 15 and (
            (focus == "POSITIVE_WATCH" and avg_r is not None and avg_r >= 0.10)
            or (focus == "NEGATIVE_REVIEW" and avg_r is not None and avg_r <= -0.20)
        )
        signature = _cluster_signature(row)
        if meaningful and signature not in sent_signatures:
            new_cluster_rows.append(row)

    return {
        "closed": closed,
        "previous_closed": previous_closed,
        "crossed_milestones": crossed,
        "new_cluster_rows": new_cluster_rows,
        "should_send": bool(crossed or new_cluster_rows),
    }


def _evidence_alert_text(current: dict[str, Any], decision: dict[str, Any]) -> str:
    progress = current.get("progress") or {}
    valid = current.get("v8013d") or {}
    lines = ["🧠 V8017 EVIDENCE UPDATE"]
    crossed = decision.get("crossed_milestones") or []
    if crossed:
        lines.append(f"Meilenstein: {max(crossed)}/30 geschlossen")
    lines.extend(
        [
            f"Fortschritt: {_int(progress.get('closed'))}/30 ({_fmt(progress.get('percent'))}%)",
            f"Gewinner/Verlierer: {_int(valid.get('wins'))}/{_int(valid.get('losses'))}",
            f"Gesamt: {_fmt(valid.get('total_r'))}R · Ø {_fmt(valid.get('avg_r'), 3)}R",
        ]
    )
    for row in (decision.get("new_cluster_rows") or [])[:2]:
        lines.append(
            f"{row.get('focus')}: {row.get('name')} · N {_int(row.get('n'))} · "
            f"WR {_fmt(row.get('win_rate_percent'))}% · Ø {_fmt(row.get('avg_r'), 3)}R"
        )
    if _int(progress.get("closed")) >= 30:
        lines.extend(["", "✅ MANUELLER VALID/FRESH-REVIEW IST BEREIT.", "Keine Regel wurde automatisch geändert."])
    else:
        lines.extend(["", f"Noch {_int(progress.get('remaining'))} geschlossene Fälle bis zum Review."])
    lines.append(f"Zeit: {_berlin(_now())}")
    return "\n".join(lines)


async def _send_telegram(text: str) -> dict[str, Any]:
    try:
        from app.engines.telegram_engine import send_telegram

        result = await send_telegram(text)
        return result if isinstance(result, dict) else {"sent": bool(result)}
    except Exception as exc:
        return {"sent": False, "error": str(exc)}


async def run_evidence_alert_once(send: bool = True) -> dict[str, Any]:
    state_path = _runtime_dir() / "evidence_alert_state.json"
    current = _evidence_payload()
    if not current.get("ok"):
        return {"ok": False, "version": VERSION, "error": current.get("error"), "sent": False}

    previous = _read_json(state_path, {})
    initialized = bool(previous.get("initialized"))
    if not initialized:
        previous = {
            "initialized": True,
            "last_closed": _int((current.get("progress") or {}).get("closed")),
            "sent_cluster_signatures": [
                _cluster_signature(row) for row in (current.get("focus_clusters") or [])
            ],
            "updated_at": _iso(),
        }
        _write_json_atomic(state_path, previous)
        return {
            "ok": True,
            "version": VERSION,
            "initialized": True,
            "sent": False,
            "reason": "baseline_initialized_without_historical_alert",
            "state": previous,
        }

    decision = _evidence_alert_decision(previous, current)
    telegram_result: dict[str, Any] = {"sent": False, "reason": "no_new_evidence"}
    if decision["should_send"] and send:
        telegram_result = await _send_telegram(_evidence_alert_text(current, decision))

    sent_signatures = set(previous.get("sent_cluster_signatures") or [])
    if telegram_result.get("sent"):
        for row in decision.get("new_cluster_rows") or []:
            sent_signatures.add(_cluster_signature(row))

    new_state = {
        "initialized": True,
        "last_closed": decision["closed"],
        "last_milestone_sent": max(decision.get("crossed_milestones") or [previous.get("last_milestone_sent", 0)]),
        "sent_cluster_signatures": sorted(sent_signatures)[-100:],
        "last_decision": decision,
        "last_telegram_result": telegram_result,
        "updated_at": _iso(),
    }
    _write_json_atomic(state_path, new_state)
    return {
        "ok": True,
        "version": VERSION,
        "decision": decision,
        "sent": bool(telegram_result.get("sent")),
        "telegram": telegram_result,
        "state": new_state,
    }


def evidence_alert_status_payload() -> dict[str, Any]:
    state_path = _runtime_dir() / "evidence_alert_state.json"
    return {
        "ok": True,
        "version": VERSION,
        "milestones": list(MILESTONES),
        "state": _read_json(state_path, {}),
        "current": _evidence_payload(),
        "safety": dict(SAFETY),
    }


# ---------------------------------------------------------------------------
# 2) Playbook / cohort trend monitor
# ---------------------------------------------------------------------------


def _clean_rows_for_trend() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    try:
        from app.v8016a_clean_ai_review import _clean_rows, _connect

        con = _connect()
        try:
            rows, quality = _clean_rows(con)
            return rows, quality
        finally:
            con.close()
    except Exception as exc:
        return [], {"error": str(exc)}


def _date_key(value: Any) -> str:
    dt = _parse_dt(value)
    return dt.date().isoformat() if dt else "UNKNOWN"


def _group_stats(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    groups: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        value = str(row.get(key) or "UNKNOWN")
        pnl = _num(row.get("pnl_r"))
        if pnl is not None:
            groups[value].append(pnl)
    output = [{key: name, **_summary(values)} for name, values in groups.items()]
    output.sort(key=lambda item: (-_int(item.get("n")), -(_num(item.get("avg_r")) or -999.0)))
    return output


def playbook_trend_payload() -> dict[str, Any]:
    now = _now()
    rows, quality = _clean_rows_for_trend()
    if not rows:
        return {
            "ok": False,
            "version": VERSION,
            "generated_utc": now.isoformat(),
            "error": quality.get("error") or "no clean rows",
            "safety": dict(SAFETY),
        }

    dated = [(row, _parse_dt(row.get("closed_at"))) for row in rows]
    last_7 = [row for row, dt in dated if dt and dt >= now - timedelta(days=7)]
    last_30 = [row for row, dt in dated if dt and dt >= now - timedelta(days=30)]
    current_router = [row for row in rows if row.get("current_router_cohort")]
    if not current_router:
        current_router = [row for row in rows if "V8004" in str(row.get("source_version") or "")]

    daily_groups: dict[str, list[float]] = defaultdict(list)
    for row, dt in dated:
        if not dt or dt < now - timedelta(days=14):
            continue
        pnl = _num(row.get("pnl_r"))
        if pnl is not None:
            daily_groups[dt.date().isoformat()].append(pnl)
    daily = [{"date": date, **_summary(values)} for date, values in sorted(daily_groups.items())]

    cohorts = _group_stats(rows, "source_version")
    playbook_all = _group_stats(rows, "playbook")
    playbook_current = _group_stats(current_router, "playbook")
    playbook_30 = _group_stats(last_30, "playbook")

    return {
        "ok": True,
        "version": VERSION,
        "generated_utc": now.isoformat(),
        "generated_berlin": _berlin(now),
        "data_quality": quality,
        "windows": {
            "all": _summary([row["pnl_r"] for row in rows]),
            "last_7_days": _summary([row["pnl_r"] for row in last_7]),
            "last_30_days": _summary([row["pnl_r"] for row in last_30]),
            "current_router": _summary([row["pnl_r"] for row in current_router]),
        },
        "playbooks": {
            "all": playbook_all,
            "last_30_days": playbook_30,
            "current_router": playbook_current,
        },
        "cohorts": cohorts,
        "daily_last_14_days": daily,
        "policy": {
            "automatic_rule_change": False,
            "minimum_sample_for_attention": 10,
            "source_of_truth": "shadow_outcomes.pnl_r",
            "historical_excursion_metrics_used": False,
        },
        "safety": dict(SAFETY),
    }


# ---------------------------------------------------------------------------
# 3) Exit / BE sequence-aware shadow collector
# ---------------------------------------------------------------------------


def _trade_key(row: dict[str, Any]) -> str:
    for name in ("trade_key", "client_trade_id", "shadow_id", "source_id", "id"):
        value = row.get(name)
        if value is not None and str(value).strip():
            return str(value)
    return "UNKNOWN"


def _valid_excursion_rows() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    db = _main_db()
    if not db.exists():
        return [], {"available": False, "error": f"database missing: {db}"}
    con = _connect_ro(db)
    try:
        table = "v7245a_trade_excursions"
        if not _table_exists(con, table):
            return [], {"available": False, "error": f"{table} missing"}
        cols = _columns(con, table)
        where = []
        if "excursion_data_valid" in cols:
            where.append("COALESCE(excursion_data_valid,0)=1")
        sql = f"SELECT * FROM {table}"
        if where:
            sql += " WHERE " + " AND ".join(where)
        rows = [dict(row) for row in con.execute(sql)]
        return rows, {"available": True, "columns": sorted(cols), "rows": len(rows)}
    except Exception as exc:
        return [], {"available": True, "error": str(exc)}
    finally:
        con.close()


def _sample_from_excursion(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "sampled_at": _iso(),
        "trade_key": _trade_key(row),
        "source": row.get("source"),
        "source_id": row.get("source_id"),
        "client_trade_id": row.get("client_trade_id"),
        "market": row.get("market"),
        "direction": row.get("direction"),
        "setup_name": row.get("setup_name"),
        "entry": _num(row.get("entry")),
        "sl": _num(row.get("sl")),
        "tp1": _num(row.get("tp1")),
        "risk_points": _num(row.get("risk_points")),
        "current_price": _num(row.get("current_price")),
        "current_r": _num(row.get("current_r")),
        "mfe_r": _num(row.get("max_favorable_r") or row.get("mfe_r")),
        "mae_r": _num(row.get("max_adverse_r") or row.get("mae_r")),
        "status": row.get("status"),
        "is_open": _int(row.get("is_open")),
        "final_status": row.get("final_status"),
        "final_r": _num(row.get("final_r")),
        "last_update_at": row.get("last_update_at"),
        "opened_at": row.get("opened_at"),
    }


def collect_exit_samples_once() -> dict[str, Any]:
    rows, meta = _valid_excursion_rows()
    sample_path = _runtime_dir() / "exit_samples.jsonl"
    state_path = _runtime_dir() / "exit_sample_state.json"
    state = _read_json(state_path, {"last_signatures": {}})
    signatures = dict(state.get("last_signatures") or {})
    appended = 0
    open_rows = 0
    closed_rows = 0

    for row in rows:
        sample = _sample_from_excursion(row)
        key = sample["trade_key"]
        if sample["is_open"] == 1:
            open_rows += 1
        else:
            closed_rows += 1
        signature = "|".join(
            [
                str(sample.get("last_update_at") or ""),
                str(sample.get("current_r") if sample.get("current_r") is not None else ""),
                str(sample.get("is_open")),
                str(sample.get("final_r") if sample.get("final_r") is not None else ""),
            ]
        )
        if signatures.get(key) == signature:
            continue
        _append_jsonl(sample_path, sample)
        signatures[key] = signature
        appended += 1

    state = {
        "version": VERSION,
        "updated_at": _iso(),
        "last_signatures": signatures,
        "last_run": {
            "rows_seen": len(rows),
            "open_rows": open_rows,
            "closed_rows": closed_rows,
            "samples_appended": appended,
            "meta": meta,
        },
    }
    _write_json_atomic(state_path, state)
    return {"ok": not bool(meta.get("error")), **state["last_run"], "state_path": str(state_path)}


def _simulate_trajectory(samples: list[dict[str, Any]], baseline: float) -> dict[str, float]:
    ordered = sorted(samples, key=lambda row: str(row.get("sampled_at") or row.get("last_update_at") or ""))
    values = [
        (_parse_dt(row.get("sampled_at") or row.get("last_update_at")), _num(row.get("current_r")))
        for row in ordered
    ]
    values = [(dt, value) for dt, value in values if value is not None]

    def be_result(threshold: float) -> float:
        trigger_index = next((i for i, (_, value) in enumerate(values) if value >= threshold), None)
        if trigger_index is None:
            return baseline
        if any(value <= 0.0 for _, value in values[trigger_index + 1 :]):
            return 0.0
        return baseline

    reached_one_index = next((i for i, (_, value) in enumerate(values) if value >= 1.0), None)
    partial = 0.5 + 0.5 * baseline if reached_one_index is not None else baseline
    trailing = baseline
    if reached_one_index is not None and any(value <= 0.5 for _, value in values[reached_one_index + 1 :]):
        trailing = 0.5

    return {
        "fixed_baseline": round(baseline, 4),
        "be_at_0_5r": round(be_result(0.5), 4),
        "be_at_0_75r": round(be_result(0.75), 4),
        "be_at_1_0r": round(be_result(1.0), 4),
        "partial_50_at_1r": round(partial, 4),
        "trail_after_1r_to_0_5r": round(trailing, 4),
    }


def _closed_baselines() -> dict[str, float]:
    rows, _ = _valid_excursion_rows()
    result: dict[str, float] = {}
    for row in rows:
        final = _num(row.get("final_r"))
        if final is not None and _int(row.get("is_open")) == 0:
            result[_trade_key(row)] = final
    return result


def exit_simulation_payload() -> dict[str, Any]:
    samples = _load_jsonl(_runtime_dir() / "exit_samples.jsonl", limit=250000)
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in samples:
        groups[str(row.get("trade_key") or "UNKNOWN")].append(row)
    baselines = _closed_baselines()
    results = []
    for key, baseline in baselines.items():
        trajectory = groups.get(key) or []
        if len(trajectory) < 2:
            continue
        first = trajectory[0]
        sim = _simulate_trajectory(trajectory, baseline)
        results.append(
            {
                "trade_key": key,
                "market": first.get("market"),
                "direction": first.get("direction"),
                "setup_name": first.get("setup_name"),
                "samples": len(trajectory),
                **sim,
            }
        )

    strategy_names = (
        "fixed_baseline",
        "be_at_0_5r",
        "be_at_0_75r",
        "be_at_1_0r",
        "partial_50_at_1r",
        "trail_after_1r_to_0_5r",
    )
    strategies = {
        name: _summary([row[name] for row in results]) for name in strategy_names
    }
    sample_state = _read_json(_runtime_dir() / "exit_sample_state.json", {})
    active_keys = sum(1 for rows in groups.values() if rows and _int(rows[-1].get("is_open")) == 1)
    return {
        "ok": True,
        "version": VERSION,
        "generated_utc": _iso(),
        "collector": {
            "sample_file": str(_runtime_dir() / "exit_samples.jsonl"),
            "total_samples": len(samples),
            "tracked_trades": len(groups),
            "active_trades": active_keys,
            "closed_sequence_eligible": len(results),
            "last_run": sample_state.get("last_run") or {},
            "sampling_interval_seconds": SAMPLE_INTERVAL_SECONDS,
        },
        "strategies": strategies,
        "latest_results": results[-50:],
        "methodology": {
            "sequence_aware": True,
            "sampling_resolution_seconds": SAMPLE_INTERVAL_SECONDS,
            "baseline": "corrected v7245a final_r for valid new rows only",
            "be_rule": "after threshold first reached, later sampled current_r <= 0 exits at 0R",
            "partial_rule": "50% closed at +1R; remaining 50% follows baseline",
            "trail_rule": "after +1R, sampled retrace to +0.5R exits at +0.5R",
            "limitation": "Events between samples cannot be ordered perfectly; observe-only comparison only.",
        },
        "safety": dict(SAFETY),
    }


# ---------------------------------------------------------------------------
# 4) Macro unmatched review
# ---------------------------------------------------------------------------


def macro_unmatched_payload(limit: int = 100) -> dict[str, Any]:
    db = _main_db()
    if not db.exists():
        return {"ok": False, "version": VERSION, "error": f"database missing: {db}", "safety": dict(SAFETY)}
    con = _connect_ro(db)
    try:
        table = "v72436_macro_actual_updates"
        if not _table_exists(con, table):
            return {"ok": False, "version": VERSION, "error": f"{table} missing", "safety": dict(SAFETY)}
        statuses = [
            dict(row)
            for row in con.execute(
                f"SELECT * FROM {table} WHERE LOWER(COALESCE(status,'')) LIKE '%no%match%' "
                "OR LOWER(COALESCE(status,'')) LIKE '%blocked%' ORDER BY id DESC LIMIT ?",
                (max(1, min(int(limit), 500)),),
            )
        ]
        guard_by_source: dict[str, dict[str, Any]] = {}
        if _table_exists(con, "v80153_macro_runtime_guard_log"):
            for row in con.execute(
                "SELECT * FROM v80153_macro_runtime_guard_log ORDER BY id DESC LIMIT 1000"
            ):
                item = dict(row)
                key = str(item.get("source_news_id") or "")
                if key and key not in guard_by_source:
                    guard_by_source[key] = item

        rows: list[dict[str, Any]] = []
        reasons: Counter[str] = Counter()
        events: Counter[str] = Counter()
        countries: Counter[str] = Counter()
        for item in statuses:
            guard = guard_by_source.get(str(item.get("source_news_id") or ""), {})
            reason = str(guard.get("reason") or item.get("status") or "UNKNOWN")
            reasons[reason] += 1
            events[str(item.get("canonical_event") or item.get("event_key") or "UNKNOWN")] += 1
            countries[str(item.get("country") or "UNKNOWN")] += 1
            rows.append(
                {
                    "id": item.get("id"),
                    "created_at": item.get("created_at"),
                    "created_at_berlin": _berlin(item.get("created_at")),
                    "source_news_id": item.get("source_news_id"),
                    "country": item.get("country"),
                    "event_key": item.get("event_key"),
                    "canonical_event": item.get("canonical_event"),
                    "actual": item.get("actual"),
                    "forecast": item.get("forecast"),
                    "previous": item.get("previous"),
                    "status": item.get("status"),
                    "raw_title": item.get("raw_title"),
                    "guard_action": guard.get("action"),
                    "guard_reason": guard.get("reason"),
                    "candidate_title": guard.get("candidate_title"),
                    "review_action": "MANUAL_MAPPING_REVIEW_ONLY",
                }
            )
        return {
            "ok": True,
            "version": VERSION,
            "generated_utc": _iso(),
            "summary": {
                "rows_returned": len(rows),
                "reasons": dict(reasons.most_common()),
                "events": dict(events.most_common(20)),
                "countries": dict(countries.most_common()),
            },
            "rows": rows,
            "policy": {
                "automatic_mapping_changes": False,
                "automatic_calendar_updates_from_unmatched": False,
                "review_only": True,
                "safe_default": "leave unmatched rather than write a wrong Actual",
            },
            "safety": dict(SAFETY),
        }
    except Exception as exc:
        return {"ok": False, "version": VERSION, "error": str(exc), "safety": dict(SAFETY)}
    finally:
        con.close()


# ---------------------------------------------------------------------------
# 5) Operational watchdog
# ---------------------------------------------------------------------------


def _http_json(path: str, timeout: float = 4.0) -> dict[str, Any]:
    try:
        with urlopen("http://127.0.0.1" + path, timeout=timeout) as response:
            payload = json.load(response)
        return {"ok": True, "status": 200, "payload": payload}
    except Exception as exc:
        return {"ok": False, "status": None, "error": str(exc), "payload": {}}


def _heartbeat_health() -> dict[str, Any]:
    db = _main_db()
    if not db.exists():
        return {"available": False, "healthy": False, "error": "database missing"}
    con = _connect_ro(db)
    try:
        if not _table_exists(con, "price_heartbeats"):
            return {"available": False, "healthy": False, "error": "price_heartbeats missing"}
        row = con.execute(
            "SELECT COUNT(DISTINCT market), MAX(received_at) FROM price_heartbeats"
        ).fetchone()
        market_count = _int(row[0])
        latest = _parse_dt(row[1])
        age = (_now() - latest).total_seconds() if latest else None
        active_15m = 0
        cutoff = (_now() - timedelta(minutes=15)).isoformat()
        try:
            active_15m = _int(
                con.execute(
                    "SELECT COUNT(DISTINCT market) FROM price_heartbeats WHERE received_at>=?",
                    (cutoff,),
                ).fetchone()[0]
            )
        except Exception:
            active_15m = 0
        healthy = age is not None and age <= 300
        return {
            "available": True,
            "healthy": healthy,
            "market_count_total": market_count,
            "active_markets_15m": active_15m,
            "latest_received_at": latest.isoformat() if latest else None,
            "latest_age_seconds": round(age, 2) if age is not None else None,
            "rule": "alert only if no heartbeat at all for more than 5 minutes",
        }
    except Exception as exc:
        return {"available": True, "healthy": False, "error": str(exc)}
    finally:
        con.close()


def _disk_health() -> dict[str, Any]:
    usage = shutil.disk_usage(_root())
    used_percent = round(usage.used / usage.total * 100, 2) if usage.total else 0.0
    return {
        "total_bytes": usage.total,
        "used_bytes": usage.used,
        "free_bytes": usage.free,
        "used_percent": used_percent,
        "warning": used_percent >= 80.0,
        "cleanup_apply_threshold_percent": SAFETY["storage_safe_cleanup_threshold_percent"],
    }


def watchdog_payload() -> dict[str, Any]:
    main_db = _quick_check(_main_db())
    queue_db = _quick_check(_queue_db())
    ingress = _http_json("/v8011/selftest.json")
    reliability = _http_json("/v8015/reliability.json")
    heartbeat = _heartbeat_health()
    disk = _disk_health()

    ingress_payload = ingress.get("payload") or {}
    reliability_payload = reliability.get("payload") or {}
    operational_status = str(ingress_payload.get("operational_status") or "UNKNOWN")
    queue_depth = _int(ingress_payload.get("queue_depth"))
    active_dead_letters = _int(ingress_payload.get("active_dead_letter_total"))
    macro_exact = bool(
        ((reliability_payload.get("macro") or {}).get("cpi_identity_exact"))
        if reliability_payload
        else False
    )

    issues: list[str] = []
    if not main_db.get("ok"):
        issues.append("MAIN_DB_QUICK_CHECK")
    if not queue_db.get("ok"):
        issues.append("QUEUE_DB_QUICK_CHECK")
    if not ingress.get("ok") or operational_status != "GREEN":
        issues.append("INGRESS_NOT_GREEN")
    if queue_depth > 100:
        issues.append("QUEUE_DEPTH_GT_100")
    if active_dead_letters > 0:
        issues.append("ACTIVE_DEAD_LETTERS")
    if not heartbeat.get("healthy"):
        issues.append("NO_HEARTBEAT_GT_5M")
    if disk.get("warning"):
        issues.append("DISK_GT_80_PERCENT")
    if reliability.get("ok") and not macro_exact:
        issues.append("MACRO_CPI_IDENTITY_NOT_EXACT")

    status = "GREEN" if not issues else "RED"
    return {
        "ok": status == "GREEN",
        "version": VERSION,
        "generated_utc": _iso(),
        "generated_berlin": _berlin(_now()),
        "status": status,
        "issues": issues,
        "checks": {
            "main_db": main_db,
            "queue_db": queue_db,
            "ingress_http": ingress,
            "ingress_summary": {
                "operational_status": operational_status,
                "queue_depth": queue_depth,
                "active_dead_letter_total": active_dead_letters,
            },
            "reliability_http": {
                "ok": reliability.get("ok"),
                "macro_cpi_identity_exact": macro_exact,
            },
            "heartbeat": heartbeat,
            "disk": disk,
        },
        "alert_policy": {
            "poll_seconds": WATCHDOG_POLL_SECONDS,
            "consecutive_failures_before_alert": 2,
            "recovery_alert": True,
            "no_per_market_closed_session_alerts": True,
        },
        "safety": dict(SAFETY),
    }


def _watchdog_alert_text(payload: dict[str, Any], recovery: bool = False) -> str:
    if recovery:
        return "\n".join(
            [
                "✅ V8017 WATCHDOG ERHOLT",
                "Status wieder GREEN.",
                f"Zeit: {_berlin(_now())}",
            ]
        )
    lines = ["🚨 V8017 WATCHDOG ALARM", f"Status: {payload.get('status')}"]
    for issue in payload.get("issues") or []:
        lines.append(f"• {issue}")
    summary = (payload.get("checks") or {}).get("ingress_summary") or {}
    lines.extend(
        [
            f"Queue: {_int(summary.get('queue_depth'))}",
            f"Aktive Dead Letters: {_int(summary.get('active_dead_letter_total'))}",
            f"Zeit: {_berlin(_now())}",
        ]
    )
    return "\n".join(lines)


async def run_watchdog_once(send: bool = True) -> dict[str, Any]:
    state_path = _runtime_dir() / "watchdog_state.json"
    previous = _read_json(state_path, {})
    payload = watchdog_payload()
    failures = _int(previous.get("consecutive_failures"))
    previously_alerted = bool(previous.get("alert_active"))
    telegram: dict[str, Any] = {"sent": False}

    if payload.get("status") == "GREEN":
        if previously_alerted and send:
            telegram = await _send_telegram(_watchdog_alert_text(payload, recovery=True))
        new_state = {
            "updated_at": _iso(),
            "consecutive_failures": 0,
            "alert_active": False,
            "last_status": "GREEN",
            "last_payload": payload,
            "last_telegram": telegram,
        }
    else:
        failures += 1
        should_alert = failures >= 2 and not previously_alerted
        if should_alert and send:
            telegram = await _send_telegram(_watchdog_alert_text(payload))
        new_state = {
            "updated_at": _iso(),
            "consecutive_failures": failures,
            "alert_active": previously_alerted or bool(telegram.get("sent")),
            "last_status": payload.get("status"),
            "last_payload": payload,
            "last_telegram": telegram,
        }
    _write_json_atomic(state_path, new_state)
    return {"ok": True, "version": VERSION, "payload": payload, "state": new_state}


def watchdog_status_payload() -> dict[str, Any]:
    return {
        "ok": True,
        "version": VERSION,
        "current": watchdog_payload(),
        "state": _read_json(_runtime_dir() / "watchdog_state.json", {}),
        "safety": dict(SAFETY),
    }


# ---------------------------------------------------------------------------
# 6) Storage maintenance status (host cleanup is in ops script + systemd timer)
# ---------------------------------------------------------------------------


def storage_status_payload() -> dict[str, Any]:
    report_path = _runtime_dir() / "storage_host_report.json"
    report = _read_json(report_path, {})
    disk = _disk_health()
    return {
        "ok": True,
        "version": VERSION,
        "generated_utc": _iso(),
        "container_disk": disk,
        "host_report_available": bool(report),
        "host_report": report,
        "policy": {
            "timer": "weekly",
            "apply_only_when_disk_used_percent_gte": SAFETY["storage_safe_cleanup_threshold_percent"],
            "keep_newest_backups": 10,
            "keep_newest_repo_zips": 10,
            "keep_newest_logs": 20,
            "minimum_backup_age_days_before_delete": 14,
            "minimum_zip_age_days_before_delete": 14,
            "minimum_log_age_days_before_delete": 30,
            "docker_cleanup": "dangling images only; builder cache older than 14 days only when disk >=80%",
            "databases_deleted": False,
            "tagged_images_deleted": False,
        },
        "safety": dict(SAFETY),
    }


# ---------------------------------------------------------------------------
# HTML dashboards
# ---------------------------------------------------------------------------


CSS = """
:root{--bg:#07111e;--panel:#101d2e;--panel2:#0b1728;--line:#273a52;--text:#eef6ff;--muted:#9caec4;--green:#22c55e;--red:#f87171;--yellow:#facc15;--blue:#93c5fd}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Arial,sans-serif}.w{max-width:1500px;margin:auto;padding:14px}a{color:var(--blue)}.hero,.p{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:15px;margin:10px 0}h1,h2,h3{margin:0 0 8px}p,.muted{color:var(--muted)}.good{color:var(--green)}.bad{color:var(--red)}.warn{color:var(--yellow)}.pill{display:inline-block;border:1px solid var(--line);background:var(--panel2);border-radius:999px;padding:6px 10px;margin:3px;font-size:12px;font-weight:800}.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:9px}.s{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:10px}.l{font-size:11px;color:var(--muted)}.v{font-size:22px;font-weight:900}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:8px;border-bottom:1px solid var(--line);text-align:left}th{background:var(--panel2)}.scroll{overflow:auto;max-height:680px}pre{white-space:pre-wrap;word-break:break-word;background:var(--panel2);border:1px solid var(--line);padding:10px;border-radius:10px}@media(max-width:900px){.stats{grid-template-columns:repeat(2,1fr)}.grid{grid-template-columns:1fr}}
"""


def _page(title: str, body: str, refresh: int = 60) -> str:
    return (
        "<!doctype html><html lang='de'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<meta http-equiv='refresh' content='{refresh}'><title>{_esc(title)}</title>"
        f"<style>{CSS}</style></head><body><div class='w'>{body}</div></body></html>"
    )


def _stats_cards(rows: list[tuple[str, Any, str]]) -> str:
    return "<div class='stats'>" + "".join(
        f"<div class='s'><div class='l'>{_esc(label)}</div><div class='v {css}'>{_esc(value)}</div></div>"
        for label, value, css in rows
    ) + "</div>"


def overview_html() -> str:
    evidence = evidence_alert_status_payload()
    trend = playbook_trend_payload()
    exit_data = exit_simulation_payload()
    macro = macro_unmatched_payload(30)
    watch = watchdog_status_payload()
    storage = storage_status_payload()
    progress = ((evidence.get("current") or {}).get("progress") or {})
    current = (trend.get("windows") or {}).get("current_router") or {}
    watcher = watch.get("current") or {}
    body = f"""
<div class='hero'><h1>V8017 Combined Evidence & Operations</h1><p>Sechs Observe-only Bausteine in einem Paket: Evidence Alerts, Playbook-Trends, Exit/BE-Simulation, Macro-Unmatched, Watchdog und sichere Speicherpflege.</p><span class='pill'>NO LIVE RULE CHANGE</span><span class='pill'>NO BROKER EXECUTION</span><span class='pill'>DB READ ONLY</span><span class='pill'>{_esc(_berlin(_now()))}</span></div>
<div class='p'>{_stats_cards([
('VALID geschlossen', f"{_int(progress.get('closed'))}/30", 'warn' if _int(progress.get('closed')) < 30 else 'good'),
('Router Gesamt', f"{_fmt(current.get('total_r'))}R", 'good' if (_num(current.get('total_r')) or 0) >= 0 else 'warn'),
('Exit Samples', (exit_data.get('collector') or {}).get('total_samples', 0), ''),
('Macro Unmatched', (macro.get('summary') or {}).get('rows_returned', 0), 'warn'),
('Watchdog', watcher.get('status', 'UNKNOWN'), 'good' if watcher.get('status') == 'GREEN' else 'bad'),
('Disk', f"{_fmt((storage.get('container_disk') or {}).get('used_percent'))}%", 'warn' if ((storage.get('container_disk') or {}).get('used_percent') or 0) >= 70 else 'good'),
])}</div>
<div class='grid'><div class='p'><h2>Learning</h2><p><a href='/v8016/evidence-alerts'>Evidence Alerts</a></p><p><a href='/v8016/playbook-trend'>Playbook/Cohort Trend</a></p><p><a href='/v8017/exit-be-simulation'>Exit & BE Shadow Simulation</a></p></div><div class='p'><h2>Betrieb</h2><p><a href='/v8017/macro-unmatched'>Macro Unmatched Review</a></p><p><a href='/v8017/ops-watchdog'>Operations Watchdog</a></p><p><a href='/v8017/storage-maintenance'>Storage Maintenance</a></p></div></div>
<div class='p'><h2>Sicherheit</h2><pre>{_esc(json.dumps(SAFETY, indent=2, ensure_ascii=False))}</pre></div>
"""
    return _page("V8017 Combined", body)


def evidence_alert_html() -> str:
    data = evidence_alert_status_payload()
    current = data.get("current") or {}
    progress = current.get("progress") or {}
    state = data.get("state") or {}
    body = f"""
<div class='hero'><h1>V8016C Evidence Telegram Alerts</h1><p>Telegram-Meilensteine bei 5/10/20/30 geschlossenen V8013D-Outcomes. Erster Lauf initialisiert ohne historische Nachricht.</p><span class='pill'>ALERT ONLY</span><span class='pill'>NO RULE CHANGE</span></div>
<div class='p'>{_stats_cards([('Geschlossen', f"{_int(progress.get('closed'))}/30", 'warn'),('Rest', _int(progress.get('remaining')), ''),('Status', progress.get('status','UNKNOWN'), ''),('Letzter Stand', state.get('last_closed','–'), ''),('Telegram zuletzt', (state.get('last_telegram_result') or {}).get('sent', False), ''),('Aktualisiert', state.get('updated_at','–'), '')])}</div>
<div class='p'><h2>Status</h2><pre>{_esc(json.dumps(data, indent=2, ensure_ascii=False))}</pre></div>
"""
    return _page("V8016C Evidence Alerts", body)


def _simple_table(rows: list[dict[str, Any]], columns: list[tuple[str, str]], limit: int = 50) -> str:
    if not rows:
        return f"<tr><td colspan='{len(columns)}'>Keine Daten.</td></tr>"
    output = []
    for row in rows[:limit]:
        output.append("<tr>" + "".join(f"<td>{_esc(row.get(key, '–'))}</td>" for key, _ in columns) + "</tr>")
    return "".join(output)


def playbook_trend_html() -> str:
    data = playbook_trend_payload()
    windows = data.get("windows") or {}
    current = windows.get("current_router") or {}
    rows = (data.get("playbooks") or {}).get("current_router") or []
    body = f"""
<div class='hero'><h1>V8016D Playbook & Cohort Trend</h1><p>Getrennte Entwicklung nach Playbook, Router-Version und Zeitfenster. Ausschließlich echte shadow_outcomes.pnl_r.</p><span class='pill'>READ ONLY</span><span class='pill'>NO AUTO BLOCK</span></div>
<div class='p'>{_stats_cards([('Current N', current.get('n',0),''),('Winrate', f"{_fmt(current.get('win_rate_percent'))}%",''),('Gesamt', f"{_fmt(current.get('total_r'))}R",'good' if (_num(current.get('total_r')) or 0)>=0 else 'warn'),('Ø', f"{_fmt(current.get('avg_r'),3)}R",''),('7 Tage', f"{_fmt((windows.get('last_7_days') or {}).get('total_r'))}R",''),('30 Tage', f"{_fmt((windows.get('last_30_days') or {}).get('total_r'))}R",'')])}</div>
<div class='grid'><div class='p'><h2>Playbooks – aktueller Router</h2><table><tr><th>Playbook</th><th>N</th><th>WR</th><th>Total</th><th>Ø</th></tr>{_simple_table(rows,[('playbook','Playbook'),('n','N'),('win_rate_percent','WR'),('total_r','Total'),('avg_r','Avg')])}</table></div><div class='p'><h2>Kohorten</h2><div class='scroll'><table><tr><th>Version</th><th>N</th><th>WR</th><th>Total</th><th>Ø</th></tr>{_simple_table(data.get('cohorts') or [],[('source_version','Version'),('n','N'),('win_rate_percent','WR'),('total_r','Total'),('avg_r','Avg')],100)}</table></div></div></div>
<div class='p'><h2>Tagestrend – 14 Tage</h2><table><tr><th>Datum</th><th>N</th><th>WR</th><th>Total</th><th>Ø</th></tr>{_simple_table(data.get('daily_last_14_days') or [],[('date','Datum'),('n','N'),('win_rate_percent','WR'),('total_r','Total'),('avg_r','Avg')],30)}</table></div>
"""
    return _page("V8016D Playbook Trend", body)


def exit_simulation_html() -> str:
    data = exit_simulation_payload()
    collector = data.get("collector") or {}
    strategies = data.get("strategies") or {}
    strategy_rows = [{"strategy": name, **stats} for name, stats in strategies.items()]
    body = f"""
<div class='hero'><h1>V8017A Exit & BE Shadow Collector</h1><p>Minütliche, sequence-aware Snapshot-Sammlung für neue gültige Excursion-Reihen. Keine echte Order und keine Exit-Regel.</p><span class='pill'>SHADOW SIMULATION</span><span class='pill'>FILE SAMPLES ONLY</span><span class='pill'>NO DB WRITE</span></div>
<div class='p'>{_stats_cards([('Samples',collector.get('total_samples',0),''),('Trades',collector.get('tracked_trades',0),''),('Aktiv',collector.get('active_trades',0),''),('Auswertbar',collector.get('closed_sequence_eligible',0),'warn'),('Intervall',f"{collector.get('sampling_interval_seconds',60)}s",''),('Letzter Lauf',(collector.get('last_run') or {}).get('samples_appended','–'),'')])}</div>
<div class='p'><h2>Strategievergleich</h2><table><tr><th>Strategie</th><th>N</th><th>WR</th><th>Total</th><th>Ø</th><th>Median</th></tr>{_simple_table(strategy_rows,[('strategy','Strategie'),('n','N'),('win_rate_percent','WR'),('total_r','Total'),('avg_r','Avg'),('median_r','Median')],20)}</table></div>
<div class='p'><h2>Methodik</h2><pre>{_esc(json.dumps(data.get('methodology'), indent=2, ensure_ascii=False))}</pre></div>
"""
    return _page("V8017A Exit Simulation", body)


def macro_unmatched_html() -> str:
    data = macro_unmatched_payload(150)
    rows = data.get("rows") or []
    body = f"""
<div class='hero'><h1>V8017B Macro Unmatched Review</h1><p>Unklare Actuals werden sichtbar gemacht, aber nicht automatisch zugeordnet. Sicherer Standard bleibt: lieber unmatched als falscher Actual.</p><span class='pill'>REVIEW ONLY</span><span class='pill'>NO AUTO MAPPING</span></div>
<div class='p'>{_stats_cards([('Offene Review-Zeilen',(data.get('summary') or {}).get('rows_returned',0),'warn'),('Länder',len((data.get('summary') or {}).get('countries') or {}),''),('Events',len((data.get('summary') or {}).get('events') or {}),''),('Auto Mapping','AUS','good'),('DB Writes','0','good'),('Aktualisiert',_berlin(_now()),'')])}</div>
<div class='p'><h2>Letzte unklare Actuals</h2><div class='scroll'><table><tr><th>Zeit</th><th>Land</th><th>Event</th><th>Actual</th><th>Status/Grund</th><th>Headline</th></tr>{_simple_table(rows,[('created_at_berlin','Zeit'),('country','Land'),('canonical_event','Event'),('actual','Actual'),('guard_reason','Grund'),('raw_title','Headline')],150)}</table></div></div>
"""
    return _page("V8017B Macro Unmatched", body)


def watchdog_html() -> str:
    data = watchdog_status_payload()
    current = data.get("current") or {}
    state = data.get("state") or {}
    summary = (current.get("checks") or {}).get("ingress_summary") or {}
    disk = (current.get("checks") or {}).get("disk") or {}
    heartbeat = (current.get("checks") or {}).get("heartbeat") or {}
    body = f"""
<div class='hero'><h1>V8017C Operations Watchdog</h1><p>Telegram nur nach zwei aufeinanderfolgenden Fehlerprüfungen; Recovery-Nachricht nach Rückkehr zu GREEN.</p><span class='pill {'good' if current.get('status')=='GREEN' else 'bad'}'>{_esc(current.get('status'))}</span><span class='pill'>TOKEN OFF UNVERÄNDERT</span></div>
<div class='p'>{_stats_cards([('Queue',summary.get('queue_depth',0),'good' if _int(summary.get('queue_depth'))==0 else 'warn'),('Dead Letters',summary.get('active_dead_letter_total',0),'good' if _int(summary.get('active_dead_letter_total'))==0 else 'bad'),('Heartbeat Alter',f"{_fmt(heartbeat.get('latest_age_seconds'))}s",'good' if heartbeat.get('healthy') else 'bad'),('Aktive Märkte 15m',heartbeat.get('active_markets_15m',0),''),('Disk',f"{_fmt(disk.get('used_percent'))}%",'warn' if (disk.get('used_percent') or 0)>=70 else 'good'),('Fail-Serie',state.get('consecutive_failures',0),'')])}</div>
<div class='p'><h2>Aktuelle Prüfungen</h2><pre>{_esc(json.dumps(current, indent=2, ensure_ascii=False))}</pre></div>
"""
    return _page("V8017C Watchdog", body)


def storage_html() -> str:
    data = storage_status_payload()
    disk = data.get("container_disk") or {}
    report = data.get("host_report") or {}
    body = f"""
<div class='hero'><h1>V8017D Storage Maintenance</h1><p>Wöchentliche sichere Host-Pflege. Anwendung nur ab 70% Plattenbelegung; Datenbanken und getaggte Images werden nie gelöscht.</p><span class='pill'>SAFE CLEANUP</span><span class='pill'>DB PROTECTED</span><span class='pill'>TAGGED IMAGES PROTECTED</span></div>
<div class='p'>{_stats_cards([('Disk benutzt',f"{_fmt(disk.get('used_percent'))}%",'warn' if (disk.get('used_percent') or 0)>=70 else 'good'),('Frei GB',_fmt((disk.get('free_bytes') or 0)/1024**3,1),''),('Apply ab','70%',''),('Backups behalten','10',''),('ZIPs behalten','10',''),('Logs behalten','20','')])}</div>
<div class='p'><h2>Letzter Host-Report</h2><pre>{_esc(json.dumps(report, indent=2, ensure_ascii=False))}</pre></div>
<div class='p'><h2>Policy</h2><pre>{_esc(json.dumps(data.get('policy'), indent=2, ensure_ascii=False))}</pre></div>
"""
    return _page("V8017D Storage", body)


# ---------------------------------------------------------------------------
# Selftest + runtime
# ---------------------------------------------------------------------------


def selftest_payload() -> dict[str, Any]:
    evidence_decision = _evidence_alert_decision(
        {"last_closed": 4, "sent_cluster_signatures": []},
        {
            "progress": {"closed": 5},
            "focus_clusters": [
                {"focus": "POSITIVE_WATCH", "name": "X", "n": 15, "avg_r": 0.2, "win_rate_percent": 55}
            ],
        },
    )
    trajectory = [
        {"sampled_at": "2026-01-01T00:00:00+00:00", "current_r": 0.0},
        {"sampled_at": "2026-01-01T00:01:00+00:00", "current_r": 0.8},
        {"sampled_at": "2026-01-01T00:02:00+00:00", "current_r": -0.1},
    ]
    sim = _simulate_trajectory(trajectory, -1.0)
    checks = {
        "evidence_milestone_5": evidence_decision["crossed_milestones"] == [5],
        "evidence_cluster_detected": len(evidence_decision["new_cluster_rows"]) == 1,
        "be_0_5_exits_zero": sim["be_at_0_5r"] == 0.0,
        "be_1_not_triggered_keeps_baseline": sim["be_at_1_0r"] == -1.0,
        "partial_not_triggered_keeps_baseline": sim["partial_50_at_1r"] == -1.0,
        "runtime_file_writes_only": SAFETY["database_writes"] is False and SAFETY["runtime_file_writes"] is True,
        "no_live_rule_change": SAFETY["live_rule_changes"] is False,
        "no_fresh_valid_change": SAFETY["fresh_valid_rule_changes"] is False,
        "no_pine_change": SAFETY["pine_changes"] is False,
        "no_broker_execution": SAFETY["broker_auto_execution"] is False,
        "storage_db_protected": SAFETY["storage_never_delete_databases"] is True,
    }
    return {"ok": all(checks.values()), "version": VERSION, "checks": checks, "safety": dict(SAFETY)}


async def _runtime_loop() -> None:
    last_evidence = 0.0
    last_watchdog = 0.0
    while True:
        started = time.monotonic()
        try:
            collect_exit_samples_once()
        except Exception as exc:
            _write_json_atomic(
                _runtime_dir() / "runtime_error.json",
                {"updated_at": _iso(), "component": "exit_collector", "error": str(exc)},
            )
        now_monotonic = time.monotonic()
        if now_monotonic - last_evidence >= ALERT_POLL_SECONDS:
            try:
                await run_evidence_alert_once(send=True)
            except Exception as exc:
                _write_json_atomic(
                    _runtime_dir() / "runtime_error.json",
                    {"updated_at": _iso(), "component": "evidence_alert", "error": str(exc)},
                )
            last_evidence = now_monotonic
        if now_monotonic - last_watchdog >= WATCHDOG_POLL_SECONDS:
            try:
                await run_watchdog_once(send=True)
            except Exception as exc:
                _write_json_atomic(
                    _runtime_dir() / "runtime_error.json",
                    {"updated_at": _iso(), "component": "watchdog", "error": str(exc)},
                )
            last_watchdog = now_monotonic
        elapsed = time.monotonic() - started
        await asyncio.sleep(max(5.0, POLL_SECONDS - elapsed))


def install_v8017_combined_evidence_ops(app) -> None:
    if getattr(app.state, "v8017_combined_evidence_ops_installed", False):
        return

    @app.get("/v8017/overview.json")
    def overview_json():
        return JSONResponse(
            {
                "ok": True,
                "version": VERSION,
                "evidence_alerts": evidence_alert_status_payload(),
                "playbook_trend": playbook_trend_payload(),
                "exit_simulation": exit_simulation_payload(),
                "macro_unmatched": macro_unmatched_payload(30),
                "watchdog": watchdog_status_payload(),
                "storage": storage_status_payload(),
                "safety": dict(SAFETY),
            }
        )

    @app.get("/v8017/overview", response_class=HTMLResponse)
    def overview_page():
        return HTMLResponse(overview_html())

    @app.get("/v8017/selftest.json")
    def selftest_json():
        return JSONResponse(selftest_payload())

    @app.get("/v8016/evidence-alerts.json")
    def evidence_alerts_json():
        return JSONResponse(evidence_alert_status_payload())

    @app.get("/v8016/evidence-alerts", response_class=HTMLResponse)
    def evidence_alerts_page():
        return HTMLResponse(evidence_alert_html())

    @app.get("/v8016/playbook-trend.json")
    def playbook_trend_json():
        return JSONResponse(playbook_trend_payload())

    @app.get("/v8016/playbook-trend", response_class=HTMLResponse)
    def playbook_trend_page():
        return HTMLResponse(playbook_trend_html())

    @app.get("/v8017/exit-be-simulation.json")
    def exit_simulation_json():
        return JSONResponse(exit_simulation_payload())

    @app.get("/v8017/exit-be-simulation", response_class=HTMLResponse)
    def exit_simulation_page():
        return HTMLResponse(exit_simulation_html())

    @app.get("/v8017/macro-unmatched.json")
    def macro_unmatched_json():
        return JSONResponse(macro_unmatched_payload())

    @app.get("/v8017/macro-unmatched", response_class=HTMLResponse)
    def macro_unmatched_page():
        return HTMLResponse(macro_unmatched_html())

    @app.get("/v8017/ops-watchdog.json")
    def watchdog_json():
        return JSONResponse(watchdog_status_payload())

    @app.get("/v8017/ops-watchdog", response_class=HTMLResponse)
    def watchdog_page():
        return HTMLResponse(watchdog_html())

    @app.get("/v8017/storage-maintenance.json")
    def storage_json():
        return JSONResponse(storage_status_payload())

    @app.get("/v8017/storage-maintenance", response_class=HTMLResponse)
    def storage_page():
        return HTMLResponse(storage_html())

    @app.on_event("startup")
    async def _v8017_startup() -> None:
        if getattr(app.state, "v8017_runtime_task", None) is None:
            app.state.v8017_runtime_task = asyncio.create_task(_runtime_loop())

    @app.on_event("shutdown")
    async def _v8017_shutdown() -> None:
        task = getattr(app.state, "v8017_runtime_task", None)
        if task is not None:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            app.state.v8017_runtime_task = None

    app.state.v8017_combined_evidence_ops_installed = True
    print("[V8017] Combined evidence/ops bundle installed (6 modules, observe-only)")
