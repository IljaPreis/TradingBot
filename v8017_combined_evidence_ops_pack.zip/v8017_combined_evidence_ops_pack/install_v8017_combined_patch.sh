#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="/opt/tradingbot_v6000"
PACKAGE="/root/v8017_combined_evidence_ops_pack"
COMPOSE="$PROJECT/docker-compose.yml"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$PROJECT/backups/v8017_before_${STAMP}"
LOG="/root/v8017_install_${STAMP}.log"
BUILD_LOG="/root/v8017_build_${STAMP}.log"
EXPECTED_MAIN="236042be6e9854f6e8c882c29863cbf038f6a933980ec40caad8539ee5400382"
EXPECTED_NAV="8fe106d2708795e40863deabab262e39d2bdb6f099532da489b0d2a0249b47b0"
EXPECTED_V8016A="c2a3b69b7b8a4f705c764dc2483f36b0f30478309ab70e8e6a3dd58d49fe4ac2"
EXPECTED_V8016B="26ae27841a1102988ee3fbb70958d3915ecc630118afaa4426f0c535d5e586d1"
SERVICE="/etc/systemd/system/tradingbot-v8017-storage.service"
TIMER="/etc/systemd/system/tradingbot-v8017-storage.timer"

exec > >(tee -a "$LOG") 2>&1

rollback() {
    echo "V8017 FEHLER – ROLLBACK"
    docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot || true

    [[ -f "$BACKUP/main.py" ]] && cp -a "$BACKUP/main.py" "$PROJECT/app/main.py"
    [[ -f "$BACKUP/v8003_master_navigation.py" ]] && cp -a "$BACKUP/v8003_master_navigation.py" "$PROJECT/app/v8003_master_navigation.py"
    if [[ -f "$BACKUP/v8017_combined_evidence_ops.py" ]]; then
        cp -a "$BACKUP/v8017_combined_evidence_ops.py" "$PROJECT/app/v8017_combined_evidence_ops.py"
    else
        rm -f "$PROJECT/app/v8017_combined_evidence_ops.py"
    fi
    if [[ -f "$BACKUP/v8017_storage_maintenance.py" ]]; then
        cp -a "$BACKUP/v8017_storage_maintenance.py" "$PROJECT/ops/v8017_storage_maintenance.py"
    else
        rm -f "$PROJECT/ops/v8017_storage_maintenance.py"
    fi
    if [[ -f "$BACKUP/v8017_combined_check.sh" ]]; then
        cp -a "$BACKUP/v8017_combined_check.sh" "$PROJECT/ops/v8017_combined_check.sh"
    else
        rm -f "$PROJECT/ops/v8017_combined_check.sh"
    fi
    [[ -f "$BACKUP/docker-compose.yml" ]] && cp -a "$BACKUP/docker-compose.yml" "$COMPOSE"

    if [[ -f "$BACKUP/tradingbot-v8017-storage.service" ]]; then
        cp -a "$BACKUP/tradingbot-v8017-storage.service" "$SERVICE"
    else
        rm -f "$SERVICE"
    fi
    if [[ -f "$BACKUP/tradingbot-v8017-storage.timer" ]]; then
        cp -a "$BACKUP/tradingbot-v8017-storage.timer" "$TIMER"
    else
        rm -f "$TIMER"
    fi
    if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
        systemctl daemon-reload || true
        systemctl disable --now tradingbot-v8017-storage.timer >/dev/null 2>&1 || true
        if [[ -f "$TIMER" ]]; then
            systemctl enable --now tradingbot-v8017-storage.timer >/dev/null 2>&1 || true
        fi
    fi

    docker compose -f "$COMPOSE" up -d --force-recreate || true
    echo "Rollback-Backup: $BACKUP"
}
trap rollback ERR INT TERM

echo "================================================================================"
echo "V8017-COMBINED-EVIDENCE-OPS-V1 INSTALL"
echo "================================================================================"
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%S%:z)"
echo "Umfang:"
echo "  1. Evidence Telegram Alerts"
echo "  2. Playbook/Cohort Trend Monitor"
echo "  3. Exit/BE Shadow Collector"
echo "  4. Macro Unmatched Review"
echo "  5. Operations Watchdog"
echo "  6. Safe Storage Maintenance"
echo "Unverändert: Trading-Regeln, V8004, FRESH/VALID, Pine, Tokenmodus, Broker"

echo "[1] Paketprüfung"
cd "$PACKAGE"
sha256sum -c MANIFEST.sha256
python3 - <<'PY_AUDIT'
import json
x=json.load(open('STATIC_AUDIT.json',encoding='utf-8'))
assert x['version']=='V8017-COMBINED-EVIDENCE-OPS-V1'
assert x['components_total']==6
s=x['safety']
assert s['database_writes'] is False
assert s['live_rule_changes'] is False
assert s['fresh_valid_rule_changes'] is False
assert s['pine_changes'] is False
assert s['broker_auto_execution'] is False
assert s['storage_never_delete_databases'] is True
assert s['storage_never_delete_active_images'] is True
print('Static audit: PASS')
PY_AUDIT
python3 -m py_compile \
  "$PACKAGE/app/main.py" \
  "$PACKAGE/app/v8003_master_navigation.py" \
  "$PACKAGE/app/v8017_combined_evidence_ops.py" \
  "$PACKAGE/ops/v8017_storage_maintenance.py"
bash -n "$PACKAGE/install_v8017_combined_patch.sh"
bash -n "$PACKAGE/ops/v8017_combined_check.sh"

echo "[2] V8016B Produktions-Baseline"
actual_main="$(sha256sum "$PROJECT/app/main.py" | awk '{print $1}')"
actual_nav="$(sha256sum "$PROJECT/app/v8003_master_navigation.py" | awk '{print $1}')"
actual_v8016a="$(sha256sum "$PROJECT/app/v8016a_clean_ai_review.py" | awk '{print $1}')"
actual_v8016b="$(sha256sum "$PROJECT/app/v8016b_evidence_monitor.py" | awk '{print $1}')"
echo "main=$actual_main"
echo "nav=$actual_nav"
echo "v8016a=$actual_v8016a"
echo "v8016b=$actual_v8016b"
[[ "$actual_main" == "$EXPECTED_MAIN" ]] || { echo "FEHLER main baseline"; exit 1; }
[[ "$actual_nav" == "$EXPECTED_NAV" ]] || { echo "FEHLER nav baseline"; exit 1; }
[[ "$actual_v8016a" == "$EXPECTED_V8016A" ]] || { echo "FEHLER V8016A baseline"; exit 1; }
[[ "$actual_v8016b" == "$EXPECTED_V8016B" ]] || { echo "FEHLER V8016B baseline"; exit 1; }
python3 - <<'PY_BASE'
import json
from urllib.request import urlopen
for path in (
 '/v8016/clean-ai-review-selftest.json',
 '/v8016/evidence-monitor-selftest.json',
 '/v8015/selftest.json',
 '/v8015/timezone-selftest.json',
 '/v8015/trade-levels-selftest.json',
 '/v8011/selftest.json',
):
    with urlopen('http://127.0.0.1'+path, timeout=90) as response:
        payload=json.load(response)
    assert payload.get('ok') is True, (path,payload)
print('Baseline selftests: PASS')
PY_BASE

echo "[3] Backup und Stop"
mkdir -p "$BACKUP"
cp -a "$PROJECT/app/main.py" "$BACKUP/main.py"
cp -a "$PROJECT/app/v8003_master_navigation.py" "$BACKUP/v8003_master_navigation.py"
[[ -f "$PROJECT/app/v8017_combined_evidence_ops.py" ]] && cp -a "$PROJECT/app/v8017_combined_evidence_ops.py" "$BACKUP/v8017_combined_evidence_ops.py" || true
[[ -f "$PROJECT/ops/v8017_storage_maintenance.py" ]] && cp -a "$PROJECT/ops/v8017_storage_maintenance.py" "$BACKUP/v8017_storage_maintenance.py" || true
[[ -f "$PROJECT/ops/v8017_combined_check.sh" ]] && cp -a "$PROJECT/ops/v8017_combined_check.sh" "$BACKUP/v8017_combined_check.sh" || true
cp -a "$COMPOSE" "$BACKUP/docker-compose.yml"
[[ -f "$SERVICE" ]] && cp -a "$SERVICE" "$BACKUP/tradingbot-v8017-storage.service" || true
[[ -f "$TIMER" ]] && cp -a "$TIMER" "$BACKUP/tradingbot-v8017-storage.timer" || true

docker compose -f "$COMPOSE" stop tradingbot_ingress tradingbot

echo "[4] Dateien installieren"
cp -a "$PACKAGE/app/main.py" "$PROJECT/app/main.py"
cp -a "$PACKAGE/app/v8003_master_navigation.py" "$PROJECT/app/v8003_master_navigation.py"
cp -a "$PACKAGE/app/v8017_combined_evidence_ops.py" "$PROJECT/app/v8017_combined_evidence_ops.py"
cp -a "$PACKAGE/ops/v8017_storage_maintenance.py" "$PROJECT/ops/v8017_storage_maintenance.py"
cp -a "$PACKAGE/ops/v8017_combined_check.sh" "$PROJECT/ops/v8017_combined_check.sh"
chmod 700 "$PROJECT/ops/v8017_storage_maintenance.py" "$PROJECT/ops/v8017_combined_check.sh"
mkdir -p "$PROJECT/data/v8017_runtime"
chmod 700 "$PROJECT/data/v8017_runtime"
python3 -m py_compile \
  "$PROJECT/app/main.py" \
  "$PROJECT/app/v8003_master_navigation.py" \
  "$PROJECT/app/v8017_combined_evidence_ops.py" \
  "$PROJECT/ops/v8017_storage_maintenance.py"

echo "[5] Geschützte Trading-Komponenten unverändert"
for file in \
  "$PROJECT/app/v8004_quality_router.py" \
  "$PROJECT/app/v8006_calendar_execution_correction.py" \
  "$PROJECT/app/v8007_v8001_gate_bridge.py" \
  "$PROJECT/pine/V8001_DUAL_PLAYBOOK_ZONE_AUDIT.pine"; do
  [[ -f "$file" ]] || { echo "FEHLER geschützt fehlt: $file"; exit 1; }
  sha256sum "$file"
done

echo "[6] Compose Image auf v8017"
python3 - "$COMPOSE" <<'PY_COMPOSE'
from pathlib import Path
import re,sys
path=Path(sys.argv[1])
text=path.read_text(encoding='utf-8')
text,count=re.subn(r'tradingbot_v6000-app:v8016b\b','tradingbot_v6000-app:v8017',text)
if count < 1:
    text,count=re.subn(r"tradingbot_v6000-app:v801[0-9A-Za-z_.-]*",'tradingbot_v6000-app:v8017',text)
if count < 1:
    raise SystemExit('image tag not found')
path.write_text(text,encoding='utf-8')
print('compose patch: PASS')
PY_COMPOSE

echo "[7] Storage Timer installieren"
cp -a "$PACKAGE/systemd/tradingbot-v8017-storage.service" "$SERVICE"
cp -a "$PACKAGE/systemd/tradingbot-v8017-storage.timer" "$TIMER"
chmod 644 "$SERVICE" "$TIMER"
if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
    systemctl daemon-reload
    systemctl enable --now tradingbot-v8017-storage.timer
else
    echo "HINWEIS: systemd nicht aktiv; Script bleibt manuell nutzbar."
fi
python3 "$PROJECT/ops/v8017_storage_maintenance.py" --report-only >/root/v8017_storage_report_${STAMP}.log

echo "[8] Image bauen und Container starten"
cd "$PROJECT"
docker compose build tradingbot 2>&1 | tee "$BUILD_LOG"
docker compose up -d --force-recreate tradingbot tradingbot_ingress
for i in $(seq 1 90); do
    code="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1/health || true)"
    [[ "$code" == 200 ]] && { echo "Health: 200"; break; }
    echo "WAIT [$i/90] health=$code"
    sleep 2
    [[ "$i" == 90 ]] && exit 1
done
for i in $(seq 1 60); do
    state="$(docker inspect -f '{{.State.Health.Status}}' tradingbot_ingress 2>/dev/null || true)"
    [[ "$state" == healthy ]] && { echo "Ingress: healthy"; break; }
    echo "WAIT [$i/60] ingress=$state"
    sleep 2
    [[ "$i" == 60 ]] && exit 1
done

# Give the runtime loop enough time to initialize alert state and first samples.
sleep 8

echo "[9] Vollständiger Check"
bash "$PROJECT/ops/v8017_combined_check.sh"

trap - ERR INT TERM
echo "================================================================================"
echo "V8017 INSTALLATION FERTIG"
echo "================================================================================"
echo "Backup: $BACKUP"
echo "Install log: $LOG"
echo "Build log: $BUILD_LOG"
echo "Dashboard: http://91.107.237.214/v8017/overview"
echo "Keine Trading-, FRESH/VALID-, Routing-, Pine-, Token- oder Broker-Regel geändert."
